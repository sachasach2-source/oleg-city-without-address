# Optional, route-aware party stories. All state belongs to this playthrough.
init python:
    def week7_thread(name):
        return week7_venue.setdefault("threads", {}).setdefault(name, {})

    def week7_thread_note(name, key, value=True):
        week7_thread(name)[key] = value
        week7_event("party_thread", name+":"+key+":"+str(value))

label week7_threads_room(room):
    # At most one extra encounter per activity, not a queue of side quests.
    if room == "table" and not week7_thread("pizza"):
        call week7_pizza_start
    elif room == "games" and not week7_thread("pizza").get("found") and not week7_thread("pizza").get("done"):
        call week7_pizza_box
    elif room in ("music", "dance") and not week7_thread("chorus") and week7_clock+week7_venue_places[room]["duration"] <= 1275:
        call week7_chorus_start
    elif (room == "garden" or (room == "table" and week7_venue.get("visits", {}).get("table"))) and week7_colleagues().get("moon") and not week7_thread("moon").get("taxi"):
        call week7_moon_taxi(room)
    elif room in ("games", "garden", "table") and week7_thread("chorus").get("style") in ("oh", "again") and not week7_thread("chorus").get("done") and not week7_thread("chorus").get("recruited") and week7_clock+week7_venue_places[room]["duration"] <= 1275:
        call week7_chorus_recruit(room)
    scene expression week7_venue_scene("hall", week7_party_guest()) with dissolve
    return

label week7_threads_hall:
    if week7_thread("pizza").get("found") and not week7_thread("pizza").get("done"):
        call week7_pizza_finish
    elif week7_clock >= 1230 and week7_thread("pizza").get("started") and not week7_thread("pizza").get("done"):
        call week7_pizza_self
    if week7_thread("chorus").get("style") and not week7_thread("chorus").get("done") and week7_clock >= 1245:
        call week7_chorus_finish
    return

label week7_pizza_start:
    scene expression week7_colleague_scene("ilya") with dissolve
    call week7_colleague_greeting("ilya")
    "Илья приподнимает крышку пустой коробки. Под ней — три пакетика с соусом."
    w7i "Я шесть пицц заказал. Шесть. Мне за вечер уже три человека сказали, что очень вкусно."
    o "Ты вообще сегодня ел?"
    w7i "Ел. Но я пиццу выбирал сорок минут. У неё там груша была."
    menu:
        "Я в игровую ещё зайду. Если там осталась, принесу тебе.":
            w7i "Спасибо. Если нет, то и ладно. Я потом сам посмотрю, что осталось."
            $ week7_thread_note("pizza", "help", "bring")
        "Может, Катя для квиза оставила? Спроси у неё.":
            w7i "Спрошу. Спасибо."
            $ week7_thread_note("pizza", "help", "hint")
        "Жалко. Но я сейчас искать не пойду.":
            w7i "Да я не прошу. Сам потом схожу."
            $ week7_thread_note("pizza", "help", "no")
    $ week7_thread_note("pizza", "started")
    return

label week7_pizza_box:
    if week7_clock < 1230:
        scene expression week7_venue_scene("games", week7_party_guest(), True) with dissolve
        "Под стулом у Кати стоит ещё одна закрытая коробка. Она достаёт её отдельно от призовой."
        w7k "Так, ваш вариант... А, ты за пиццей. Эта музыкантам. Передайте, пусть заберут."
        $ week7_thread_note("pizza", "keeper", "katya")
    else:
        scene expression week7_colleague_scene("dasha", "games") with dissolve
        call week7_colleague_greeting("dasha")
        "Даша убирает со стула коробку, которую кто-то уже использует вместо полочки для телефона."
        w7d "Тут ещё пицца. Катя музыкантам оставила. Я думала, они её уже забрали."
        $ week7_thread_note("pizza", "keeper", "dasha")
    if week7_thread("pizza").get("help") == "bring":
        o "Илья её ищет. Я обещал посмотреть."
    elif week7_thread("pizza").get("started"):
        o "Илья у сцены. Ему там, кажется, только соус достался."
    else:
        "Олег заглядывает под крышку."
    menu:
        "Возьму ребятам по куску. Всё равно через зал идти.":
            "Олег раскладывает оставшиеся куски на большую бумажную тарелку. Один, похоже, с грушей; его кладёт отдельно с краю."
            $ week7_thread_note("pizza", "delivery", "carried")
        "Позови его, если увидишь. Я сейчас с тарелкой всё растеряю.":
            if week7_clock < 1230:
                w7k "Сейчас сама вынесу. Мне эти коробки уже ставить некуда."
            else:
                w7d "Я ему отнесу. Заодно воды возьму."
            $ week7_thread_note("pizza", "delivery", "colleague")
        "Пусть здесь стоит. Музыканты тоже умеют искать пиццу.":
            "Олег задвигает коробку подальше от края. Телефон на неё больше не кладут."
            $ week7_thread_note("pizza", "delivery", "left")
    $ week7_thread_note("pizza", "found")
    return

label week7_pizza_finish:
    scene expression week7_colleague_scene("ilya") with dissolve
    call week7_colleague_greeting("ilya")
    if week7_thread("pizza")["delivery"] == "carried":
        "Олег ставит тарелку на край буфета. Илья подходит, всё ещё держа медиатор в пальцах."
        o "Вот. С грушей с краю."
        w7i "О. Спасибо. Я уже начал думать, что её никто не привёз."
        "Он кладёт медиатор рядом с тарелкой и наконец берёт кусок. После первого укуса ненадолго замолкает."
        w7i "Блядь. Я с грушей выбирал, а это с ананасом."
        o "Поменяли?"
        w7i "Я в корзине замену нажал. Мне позвонили тогда. Ладно, тоже вкусно."
    elif week7_thread("pizza")["delivery"] == "colleague":
        "Илья уже ест у буфета. Рядом с ним стоит принесённая из игровой коробка."
        if week7_thread("pizza")["keeper"] == "katya":
            w7i "Катя принесла. Я ей говорю: «Где вы её прятали?» Она говорит: «Подо мной»."
        else:
            w7i "Даша принесла. Оказывается, всё это время в игровой стояла."
        o "Я тоже себе возьму."
        w7i "Да. Только не зови меня пока никуда."
    else:
        "Илья проходит мимо Олега в игровую. Через минуту возвращается с коробкой, поправляя сползший на затылок ободок."
        w7i "Нашёл. Прямо в игровой стояла. Теперь я с ней здесь останусь."
        if week7_thread("pizza").get("help") == "bring":
            o "Я видел. Решил не тащить."
            w7i "Ага. Ну вот, забрал."
    $ week7_thread_note("pizza", "done", "fed")
    return

label week7_pizza_self:
    scene expression week7_colleague_scene("ilya") with dissolve
    call week7_colleague_greeting("ilya")
    "Илья выходит из игровой с открытой коробкой. Увидев свободный край буфета, сразу ставит её туда."
    w7i "Всё, я нашёл. Катя нам оставила, никто не забрал."
    if week7_thread("pizza").get("help") == "bring":
        o "Я до игровой так и не дошёл."
        w7i "А я дошёл. Теперь пять минут ничего не подключаю."
    else:
        o "С грушей?"
        w7i "Нет. Это я сам в заказе напутал. Уже неважно."
    $ week7_thread_note("pizza", "done", "self")
    return

label week7_chorus_start:
    scene expression week7_colleague_scene("ilya") with dissolve
    call week7_colleague_greeting("ilya")
    w7i "Сейчас, ребят... Олег, мы во втором сете зал попеть хотим. Только у нас слова никто не знает. Что им дать спеть?"
    menu:
        "Так оставьте одно «о-о-о». Его все знают.":
            w7i "Да, давай. Я тогда просто покажу, где вступать."
            $ week7_thread_note("chorus", "style", "oh")
        "Пусть кричат «Ещё один!». И не надо потом отдельно на бис звать.":
            w7i "А если мы потом ещё играть хотим? Ладно, объясним."
            $ week7_thread_note("chorus", "style", "again")
        "А я просто послушаю. Слова сами придумайте.":
            w7i "Хорошо. Мы тогда сами разберёмся."
            $ week7_thread_note("chorus", "style", "listen")
    $ week7_thread_note("chorus", "started_at", week7_clock)
    return

label week7_chorus_recruit(room):
    scene expression week7_colleague_scene("dasha", "games" if room == "games" else "garden" if room == "garden" else "hall") with dissolve
    call week7_colleague_greeting("dasha")
    "Даша спрашивает, музыканты уже закончили или ещё будут играть."
    o "Во втором сете всех подпевать зовут."
    if week7_thread("chorus")["style"] == "oh":
        o "Нужно петь «о-о-о». Это весь текст."
        w7d "Мне подходит. А то я всегда уверенно начинаю, а потом оказывается, что это другая песня."
    else:
        o "Там надо кричать «Ещё один!». Но только по команде."
        w7d "А если мне не понравится?"
        o "Не обязательно петь. Я просто зову."
        w7d "Ладно. Я Максима ещё позову. Он громкий."
    $ week7_thread_note("chorus", "recruited", "dasha")
    return

label week7_chorus_finish:
    scene expression week7_colleague_scene("ilya") with dissolve
    call week7_colleague_greeting("ilya")
    if week7_clock > 1275:
        "У сцены уже убирают стойку. Илья отставляет её к стене."
        w7i "Мы общий номер уже спели. Тебя не видел, думал, уехал."
        if week7_thread("chorus")["style"] == "again":
            w7i "Про «Ещё один» ты зря предложил. Теперь барабанщик хочет обратно садиться."
        else:
            o "Значит, послушаю в другой раз."
        $ week7_thread_note("chorus", "done", "missed")
    else:
        "Илья возвращается к микрофону. Басист дожидается, пока у буфета перестанут спорить, и играет вступление ещё раз."
        scene expression week7_venue_scene("hall", week7_party_guest()) with dissolve
        if week7_thread("chorus").get("recruited"):
            "Даша уже у сцены. Максим встаёт рядом, откашливается и заранее пробует басом одну ноту."
        else:
            "Несколько человек придвигаются от столов к сцене. Кто-то ещё жуёт, прикрыв рот ладонью."
        if week7_thread("chorus")["style"] == "listen":
            "Илья объясняет залу, где вступать. Олег остаётся у края стола и слушает. С первого раза в нужное место попадают только музыканты."
            $ week7_thread_note("chorus", "voice", "listened")
        else:
            menu:
                "Подойду ближе. Сам предложил — сам и начну.":
                    "Олег встаёт перед сценой. Илья кивает ему на последнем такте."
                    $ week7_thread_note("chorus", "voice", "sang")
                "Останусь у стола. Хочу послушать, что получилось.":
                    "Олег отступает от прохода. Теперь между ним и сценой целый ряд чужих плеч и рожек."
                    $ week7_thread_note("chorus", "voice", "listened")
            if week7_thread("chorus")["style"] == "oh":
                "На «о-о-о» несколько человек берут выше Ильи. Он повторяет свою ноту, ждёт; на следующем круге её уже слышно сквозь зал."
                "К концу припева уже получается громко и почти вместе. Басист поворачивается к барабанщику и продолжает играть ещё круг."
            else:
                "Илья ещё не успевает подать знак, а из зала уже кричат: «Ещё один!» Он машет свободной рукой: рано."
                "Во второй раз вступают вовремя. После последнего аккорда кто-то опять требует ещё один. Илья наклоняется к микрофону: «Это текст был. Следующая уже другая»."
        $ week7_thread_note("chorus", "done", "heard")
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    return

label week7_moon_taxi(room):
    scene expression week7_colleague_scene("maxim", "garden" if room == "garden" else "hall") with dissolve
    call week7_colleague_greeting("maxim")
    "Максим замечает Олега и убирает телефон в карман. От бумажной луны он наконец отошёл, но разговор всё ещё про неё."
    w7m "Я машину к закрытию заказал. Водителю написал: «Будет мумия с луной». Он заказ отменил."
    o "А размеры ты написал?"
    w7m "Размеры, материал... Нет, я только про костюм написал."
    menu:
        "Напиши, что это бумажная декорация. И размеры у Даши спроси.":
            scene expression week7_venue_scene("garden" if room == "garden" else "hall", week7_party_guest()) with dissolve
            "Максим идёт уточнить размеры. Вернувшись, снова заказывает машину к половине одиннадцатого и прячет телефон."
            scene expression week7_colleague_scene("maxim", "garden" if room == "garden" else "hall") with dissolve
            w7m "Ответил: «Кладите поперёк». Ну вот. Договорились."
            $ week7_thread_note("moon", "taxi", "dimensions")
        "Позвони следующему. С текста правда похоже, что ты его проклясть собрался.":
            scene expression week7_venue_scene("garden" if room == "garden" else "hall", week7_party_guest()) with dissolve
            "Максим отходит на два шага. Олег слышит: «Нет, обычный корпоратив. Нет, большая, но плоская»."
            "Закончив разговор, он убирает телефон и возвращается."
            scene expression week7_colleague_scene("maxim", "garden" if room == "garden" else "hall") with dissolve
            w7m "Договорились. Сказал, только леску всю снять, чтоб за ручку не зацепилась."
            $ week7_thread_note("moon", "taxi", "called")
        "Я бы Дашу попросил объяснить. Ты сейчас только хуже делаешь.":
            w7m "Сейчас найду. Она уже спрашивала, сколько ещё мне это такси вызывать."
            scene expression week7_venue_scene("garden" if room == "garden" else "hall", week7_party_guest()) with dissolve
            "Максим идёт за Дашей. Через несколько минут они проходят обратно: она смеётся, он убирает телефон в карман."
            $ week7_thread_note("moon", "taxi", "dasha")
    scene expression week7_colleague_scene("maxim", "garden" if room == "garden" else "hall") with dissolve
    "На вопрос, когда выносить, Максим отвечает: «После закрытия». До тех пор луна останется висеть над буфетом."
    return

label week7_threads_farewell:
    if week7_thread("pizza").get("started") and not week7_thread("pizza").get("done"):
        scene expression week7_colleague_scene("ilya") with dissolve
        if week7_thread("pizza").get("help") == "bring":
            o "Я до игровой так и не дошёл. Прости."
            w7i "Ничего. Я сейчас сам туда схожу."
        else:
            w7i "Я пойду свою еду наконец поищу. Пока всё не разобрали."
        $ week7_thread_note("pizza", "exit", "looking_himself")
    if week7_thread("chorus").get("style") and not week7_thread("chorus").get("done"):
        scene expression week7_colleague_scene("ilya") with dissolve
        o "Я уже поеду. Общую песню без меня."
        w7i "Хорошо. Я ребятам скажу, что тебя не ждём."
        $ week7_thread_note("chorus", "done", "left_early")
    if week7_thread("moon").get("taxi"):
        scene expression week7_colleague_scene("maxim") with dissolve
        if week7_thread("moon")["taxi"] == "dimensions":
            w7m "Так, машина есть. До дома довезу, а там уже померяю, куда повесить."
        elif week7_thread("moon")["taxi"] == "called":
            w7m "Машину подтвердили. Теперь можно спокойно допить чай."
        else:
            w7m "Даша всё объяснила. Водитель подождёт, пока снимем."
        $ week7_thread_note("moon", "farewell")
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    return
