# Friday planning and weekend priority are genuine player choices.
screen chapter3_select():
    tag menu
    use menu_shell("Нормально посидим · глава третья"):
        vbox:
            xpos 100 ypos 160 xsize 1250 spacing 17
            text "Продолжи своё сохранение после второй главы или выбери готовую предысторию." size 23 color "#bfc6c9"
            for profile, title in [("nika", "Ника · свидание и обещанный рифф"), ("friends", "Ника · дружба, музыка, двор с Варей"), ("asya", "Ася · фотографии и квартира целиком"), ("lera", "Лера · воскресный обед, квартира на месяц"), ("rush", "Ника · пластинки и передача ключей"), ("quiet", "Свободные выходные · без подтверждённых встреч")]:
                textbutton title action [SetVariable("chapter3_entry_profile", profile), Start("chapter3_quick")] xsize 1160

# The same visual language as ordinary story choices, over the current location.
screen chapter3_intentions(prompt, options, side="left"):
    modal True
    if len(options) == 1:
        timer .01 action Return(options[0][1])
    else:
        use ui_story_options("ЧЕГО ХОЧЕТСЯ ОЛЕГУ?",[(caption,Return(answer)) for caption,answer in options],prompt,width=740 if side=="right" else 1000,left=800 if side=="right" else 54,size=22 if side=="right" else 23)

screen chapter3_planner():
    $ options = [(chapter3_write_intent(p), p) for p in chapter3_planning_people()]
    if chapter3_planning_people(True):
        $ options.append(("Хочу изменить одну из договорённостей.", "revise"))
    $ options.append(("Хватит телефона. Остальное потом.", "done"))
    use chapter3_intentions(chapter3_plan_thought(), options)

screen chapter3_revise_plans():
    $ options = [(chapter3_write_intent(p), p) for p in chapter3_planning_people(True)]
    $ options.append(("Нет, оставлю как договорились.", "back"))
    use chapter3_intentions("Кому написать?", options)

screen chapter3_day_agenda():
    $ options = chapter3_day_options()
    use chapter3_intentions(chapter3_day_thought(), options, side="right")

screen chapter3_reschedule():
    $ options = [("Написать " + {"nika":"Нике", "asya":"Асе", "lera":"Лере", "varya":"Варе", "keys":"агенту"}[p] + ". Сегодня уже не успею.", "defer:" + p) for p in chapter3_pending()]
    $ options.append(("Нет, всё-таки поеду на встречу.", "back"))
    use chapter3_intentions("Кому я сейчас честно скажу, что не приеду?", options, side="right")

screen chapter3_ending():
    modal True
    add Solid("#09151be8")
    frame:
        xalign .5 yalign .5 xsize 1190 padding (42, 32) background Solid("#12232c")
        vbox:
            spacing 20
            text "КОНЕЦ ТРЕТЬЕЙ ГЛАВЫ" size 17 kerning 3 color "#d5b384"
            text ending_title size 43
            text ending_body size 26 line_spacing 7 xmaximum 1050
            hbox:
                spacing 30
                textbutton "Четвёртая глава" action Return("week4")
                textbutton "Пройти иначе" action Return("again")
                textbutton "В главное меню" action Return("menu")
