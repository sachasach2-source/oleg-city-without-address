init -9 python:
    renpy.image("bg w7 pirate map",Transform("images/week7/pirate-map-v1.webp",xysize=(1600,900)))
    week7_wardrobes = {"nika":("standing",950), "lera":("indoor",950), "asya":("",950), "marta":("bookshop",1280), "zhenya":("indoor",1200), "ulya":("indoor",1050), "varya":("halloween",1000), "rita":("theatre",1340)}
    # Home visits keep everyday clothes; party costumes have a separate registry.
    week7_party_wardrobes = dict(week7_wardrobes)
    for person in ("nika","lera","asya","marta","zhenya","ulya"):
        path = "images/week7/" + person + "-costume-v1.webp"
        if person == "lera":
            path = "images/week7/lera-costume-v2.webp"
        elif person == "asya":
            path = "images/week7/asya-costume-v2.webp"
        cast_assets[(person,"halloween")] = {"neutral":path}
        week7_party_wardrobes[person] = ("halloween",1050)
        key = "w7 materials " + person
        clothes,height = week7_wardrobes[person]
        cast_stages[key] = ("images/week7/materials-shop-v1.webp",[("oleg","indoor",370,45,950),(person,clothes,1230,45,height)],None,"evening")
        renpy.image("bg " + key,Transform("images/week7/materials-shop-v1.webp",xysize=(1600,900)))
        renpy.image("bg w7 costume detail " + person,Composite((1600,900),(0,0),Transform("images/week7/party-hall-v7.webp",xysize=(1600,900)),(370,20),Transform(path,zoom=.84)))
    cast_assets[("varya", "halloween")] = {"neutral":"images/week7/varya-party-v1.webp"}
    for costume in ("vampire", "scientist", "scarecrow", "horns"):
        for action in ("music","dance"):
            renpy.image("bg w7 " + action + " " + costume,Transform("images/week7/"+action+"-"+costume+"-v2.webp",xysize=(1600,900)))
        wardrobe = "w7_" + costume
        path = "images/week7/oleg-" + costume + "-v1.webp"
        cast_assets[("oleg", wardrobe)] = {"neutral":path}
        detail_zoom, detail_y = (1.25,-460) if costume=="vampire" else (.9,-20)
        renpy.image("bg w7 detail " + costume, Composite((1600,900),(0,0),Solid("#17232b"),(350,detail_y),Transform(path,zoom=detail_zoom)))
        for guest in ("", "nika", "lera", "asya", "marta", "zhenya", "ulya", "varya"):
            key = "w7 party " + costume + (" " + guest if guest else "")
            actors = [("oleg",wardrobe,370,45,1000)]
            if guest:
                clothes,height=week7_party_wardrobes[guest]
                actors.append((guest,clothes,1230,45,height))
            cast_stages[key] = ("images/week7/party-hall-v7.webp",actors,None,"evening")
            renpy.image("bg " + key, Transform("images/week7/party-hall-v7.webp",xysize=(1600,900)))
        key="w7 fitting " + costume
        cast_stages[key] = ("images/week4/theatre-delivered-v1.webp",[("oleg",wardrobe,400,45,1000),("rita","theatre",1210,105,1340)],None,"evening")
        renpy.image("bg "+key,Transform("images/week4/theatre-delivered-v1.webp",xysize=(1600,900)))
    for costume in ("plain","vampire","scientist","scarecrow","horns"):
        for guest in ("", "nika", "lera", "asya", "marta", "zhenya", "ulya"):
            key="w7 home "+costume+(" "+guest if guest else "")
            renpy.image("bg "+key,DynamicDisplayable(lambda st,at:(home_keepsake_background(week7_home_path()),None)))

init 65 python:
    _week7_choice_layout = cast_choice_layout
    def cast_choice_layout():
        if cast_background_key() == "w7 pirate map":
            return "grid"
        return _week7_choice_layout()

    _week7_cast_stage = cast_stage_data
    def cast_stage_data():
        key=cast_background_key()
        if key.startswith("w7 home "):
            bits=key.split(); costume=bits[2]; guest=bits[3] if len(bits)>3 else ""
            actors=[("oleg","indoor" if costume=="plain" else "w7_"+costume,380,45,950 if costume=="plain" else 1000)]
            if guest:
                clothes,height=week7_wardrobes[guest]
                actors.append((guest,clothes,1230,45,height))
            return (week7_home_path(),actors,None,"evening")
        return _week7_cast_stage()

init 35 python:
    phone_media.update({
        "photo:w7_office_corridor_mon":dict(path="images/week7/office-mon-v2.webp",title="Саша · старый этаж",caption="У лифта"),
        "photo:w7_office_corridor_fri":dict(path="images/week7/office-fri-v1.webp",title="Саша · пятница",caption="Снова на этаже"),
        "photo:w7_after_office_coffee":dict(path="images/week7/after-office-coffee-v1.webp",title="Саша · после офиса",caption="Кофе на двоих"),
        "voice:w7_sasha_lift":dict(kind="voice",path="audio/week7/sasha-lift-v1.ogg",title="Саша · понедельник",caption="14 секунд",duration=14.,meaning_range=(10.,11.6),transcript="Саша: «Ладно, я пошёл». Щелчок. «Опять вырубилось. У лифта я уже». Шорох, шаги. Вдали негромко: будто «подержи дверь». Источник голоса неясен."),
        "voice:w7_sasha_lift_excerpt":dict(kind="voice",path="audio/week7/sasha-lift-excerpt-v1.ogg",title="Саша · фрагмент прежнего сообщения",caption="5 секунд",duration=5.5,meaning_range=(1.5,3.1),transcript="Конец понедельничного сообщения. Шорох. Далёкая фраза, похожая на «подержи дверь». Потом шаги. Это фрагмент той же записи."),
        "voice:w7_sasha_meeting_room":dict(kind="voice",path="audio/week7/sasha-meeting-room-v1.ogg",title="Саша · 19:12",caption="10 секунд",duration=10.,meaning_range=(5.,8.2),transcript="Гул помещения, шорох и короткий скрип. Саша тихо: «Сань, подойди. Я у переговорки». Слышен шаг."),
        "voice:w7_sasha_outside":dict(kind="voice",path="audio/week7/sasha-outside-v1.ogg",title="Саша · 19:21",caption="9 секунд",duration=9.,meaning_range=(.25,4.4),transcript="Шум улицы. Саша: «Всё, мы на улице. Сейчас кофе возьмём». Саня в стороне: «Мне большой». Дальше шум машин.")})
    for costume in ("vampire","scientist","scarecrow","horns"):
        phone_media["photo:w7_costume_"+costume] = dict(path="images/week7/oleg-selfie-"+costume+"-v1.webp",title="Олег · примерка",caption="К пятнице готов")
    week7_fixed_times = {"Кружку нашли. Без потерь.":1149,"photo:w7_office_corridor_fri":1148,"voice:w7_sasha_meeting_room":1152,"voice:w7_sasha_outside":1161,"Вышли.":1161,"Мы у охраны.":1159,"Я на этаже.":1147,"Ты уже у лифта?":1151,"Да, жду тебя здесь.":1151,"Ты сейчас просил дверь подержать?":1152,"Нет. Я тут стою.":1152}
