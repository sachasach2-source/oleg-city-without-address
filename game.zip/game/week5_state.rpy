default week5_started = False
default week5_finished = False
default week5_entry = {}
default week5_relations = {}
default week5_history = {}
default week5_home = {}
default week5_laundry = {}
default week5_events = []
default week5_person = ""
default week5_plan = "walk"
default week5_day = 0
default week5_clock = 475
default week5_chat_index = 0
default week5_phone_tokens = {}
default week5_phone_cursor = {}
default week5_date = {}
default week5_private_ready = False
default week5_prepared = False
default week5_result = ""
default week5_promise = ""
default week5_entry_profile = "nika"
default week5_varya = {}
default week5_marta = {}

init python:
    def week5_reset():
        global week5_started, week5_finished, week5_entry, week5_relations, week5_history
        global week5_home, week5_laundry, week5_events, week5_person, week5_plan, week5_day, week5_clock
        global week5_chat_index, week5_phone_tokens, week5_phone_cursor, week5_date
        global week5_private_ready, week5_prepared, week5_result, week5_promise
        global week5_varya
        global week5_marta
        global phone_reply_log, phone_message_times
        # Copy the actual ending; selecting chapter five never edits chapter four.
        week5_entry = copy.deepcopy({"relations":week4_relations, "home":week4_home,
            "laundry":week4_laundry, "events":week4_events, "work":week4_work,
            "marta":week4_entry.get("marta", {}), "rita_contact":week4_rita_contact,
            "rita_interest":week4_rita_interest, "housing_home":housing_home})
        week5_relations = copy.deepcopy(week4_relations)
        week5_history = copy.deepcopy(week4_history)
        week5_home, week5_laundry = copy.deepcopy(week4_home), copy.deepcopy(week4_laundry)
        week5_events, week5_person, week5_plan = [], "", "walk"
        week5_day, week5_clock, week5_chat_index = 0, 475, 0
        week5_phone_tokens, week5_phone_cursor = {}, {}
        week5_date = {"confirmed":False, "romantic":False, "limited":False,
            "mutual_time":False, "kiss":False, "invited_home":False, "night":False,
            "repair_only":False, "touch_renewed":False, "night_answer":"", "continuation":""}
        week5_private_ready = week5_prepared = week5_finished = False
        week5_result = week5_promise = ""
        week5_varya = {}
        week5_marta = {}
        phone_reply_log = {k:v for k,v in phone_reply_log.items() if not k[0].startswith("w5_")}
        phone_message_times = {k:v for k,v in phone_message_times.items() if not k[0].startswith("w5_")}
        week5_started = True

    def week5_stamp(location, minute=None, day=None):
        global week5_clock, week5_day, place_name, save_name
        if day is not None:
            week5_day = day
        if minute is not None:
            week5_clock = max(week5_clock, minute) if day is None else minute
        place_name = "{} · {}, {}".format(location, ("пятница", "суббота")[week5_day], chapter3_time(week5_clock))
        save_name = "Глава 5 · " + place_name

    def week5_event(event, detail="", person=None):
        person = week5_person if person is None else person
        item = {"person":person, "day":week5_day, "time":week5_clock, "event":event, "detail":detail}
        week5_events.append(item)
        bonus_gallery_event(person, event, 5)
        if person in week5_relations:
            week5_relations[person]["events"].append(copy.deepcopy(item))
            if event == "mutual_kiss":
                week5_relations[person]["new_touch"] = "kiss"
                week5_relations[person]["facts"]["kissed_chapter5"] = True
            elif event == "touch_boundary_renewed":
                week5_relations[person]["facts"]["touch_renewed_chapter5"] = True

    def week5_varya_state():
        # setdefault also makes mid-chapter saves from before this episode usable.
        for key, value in dict(advice="", advice_seen=False, call_done=False,
                answered=False, help="", safe=False, with_partner=False,
                partner_response="", interrupted=False, followup=False).items():
            week5_varya.setdefault(key, value)
        return week5_varya

    def week5_varya_known():
        return bool(week5_relations.get("varya", {}).get("known"))

    def week5_varya_memory():
        return {x["event"] for x in week5_entry.get("relations", {}).get("varya", {}).get("events", [])}

    def week5_varya_record(event, detail=""):
        week5_event(event, detail, person="varya")
        week5_relations["varya"].setdefault("facts", {})["chapter5_crush"] = copy.deepcopy(week5_varya)

    def week5_varya_joint_trip():
        return bool(week5_person and week5_date.get("confirmed") and week5_date.get("romantic")
            and week5_relations[week5_person].get("mode") != "friendship"
            and week5_date.get("night_answer") == "yes" and week5_night_welcome())

    def week5_has(event):
        return any(x["event"] == event for x in week5_events)

    def week5_issues(person):
        return [x for x in week5_relations[person].get("issues", []) if x["status"] != "resolved"]

    def week5_prior_kiss(person):
        r = week5_entry["relations"][person]
        return bool(r.get("new_touch") == "kiss" or r.get("facts", {}).get("kissed_chapter4"))

    def week5_prior_space(person):
        r = week5_entry["relations"][person]
        return r.get("previous_touch") == "space" and not r.get("new_touch")

    def week5_can_kiss():
        return (week5_date["confirmed"] and week5_date["romantic"] and week5_date["mutual_time"]
            and not week5_date["limited"] and not week5_date["repair_only"]
            and not week5_issues(week5_person)
            and (not week5_prior_space(week5_person) or week5_date["touch_renewed"]))

    def week5_night_welcome():
        # A kiss today does not retroactively create an established intimate history.
        return (week5_can_kiss() and week5_date["kiss"] and week5_prior_kiss(week5_person)
            and week5_entry["relations"][week5_person].get("outcome") == "warm")

    def week5_home_path(night=False):
        kind = week5_home.get("kind", "hotel")
        candidate = week5_home.get("actual_home") or week5_entry.get("housing_home")
        if kind == "new" and candidate:
            return {"studio": "images/housing/studio-night-v2.webp" if night else "images/housing/studio-v2.webp",
                "central":"images/housing/central-bedroom-evening-v2.webp" if night else "images/housing/central-bedroom-v1.webp",
                "modern":"images/housing/modern-evening-v2.webp",
                "quiet":"images/chapter3/ch3-rental-night-v2.webp" if night else "images/chapter3/ch3-rental-day-v2.webp"}.get(candidate, "images/chapter3/ch3-rental-night-v2.webp" if night else "images/chapter3/ch3-rental-day-v2.webp")
        if kind == "new":
            return "images/chapter3/ch3-rental-night-v2.webp" if night else "images/chapter3/ch3-rental-day-v2.webp"
        if kind in ("whole", "month"):
            return "images/chapter3/old-rental-night-v1.webp" if night else "images/cast/apartment-empty.webp"
        return "images/hotel-night.webp" if night else "images/hotel-morning.webp"

    def week5_home_bg(night=False):
        return home_keepsake_background(week5_home_path(night))

init 40 python:
    _week5_original_stamp = phone_stamp_messages
    _week5_original_status = phone_status_time

    def phone_stamp_messages(token, messages, caption=None):
        if not str(token).startswith("w5_"):
            return _week5_original_stamp(token, messages, caption)
        global week5_clock
        if caption is not None:
            phone_thread_contacts[token] = caption
        cursor = max(week5_clock, week5_phone_cursor.get(week5_day, week5_clock))
        for index, (sender, message) in enumerate(messages):
            key = (token, index)
            saved = phone_message_times.get(key)
            if saved and saved[:2] == (sender, message):
                hh, mm = map(int, saved[2].split(":"))
                sent = hh * 60 + mm
            else:
                sent = cursor + 1
                phone_message_times[key] = (sender, message, chapter3_time(sent))
            cursor = max(cursor, sent)
        for key in list(phone_message_times):
            if key[0] == token and key[1] >= len(messages):
                del phone_message_times[key]
        week5_clock = cursor
        week5_phone_cursor[week5_day] = cursor
        week5_phone_tokens[token] = week5_day
        week5_stamp(place_name.split(" · ")[0])

    def phone_status_time(index, token):
        if str(token).startswith("w5_"):
            return chapter3_time(week5_clock)
        return _week5_original_status(index, token)

label week5_chat(person, key, incoming, options):
    $ week5_chat_token = "w5_{}_{}_{}".format(person, key, week5_chat_index)
    $ week5_chat_index += 1
    $ week5_chat_dialogue = week4_phone_dialogue(incoming, options)
    if len(options) == 1:
        $ phone_record_reply(week5_chat_token, "start", options[0][0], [], week5_chat_dialogue)
    call screen phone_thread([], caption=week4_names[person], conversation=week5_chat_token, past=week5_history.get(person, [])[-2:], dialogue=week5_chat_dialogue)
    $ week5_chat_transcript, week5_chat_decisions, week5_chat_pending = phone_conversation_state(week5_chat_token, [], week5_chat_dialogue)
    $ week5_history[person] = (week5_history.get(person, []) + week5_chat_transcript)[-24:]
    return week5_chat_decisions[-1][1]
