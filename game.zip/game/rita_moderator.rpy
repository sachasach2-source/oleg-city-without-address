# A separate, optional organisational role. No attendance or romantic flag.
default rita_moderation = {}

init python:
    def rita_moderation_reset():
        global rita_moderation
        rita_moderation = {}

label rita_moderator_invitation:
    if rita_moderation.get("invited"):
        return
    $ rita_moderation["invited"] = True
    wr "А ты чем занимаешься? Не доставкой, это я уже поняла."
    o "Продуктовой аналитикой руковожу. В тревеле."
    "Рита перестаёт вытягивать нитку из шва."
    wr "То есть умеешь заставить нескольких взрослых людей ответить на один вопрос?"
    o "Не всегда, но мне за это платят."
    wr "У нас третью неделю не получается организовать оргию. Все хотят, никто не может выбрать день. Поможешь как менеджер?"
    o "В смысле — организовать?"
    wr "Модерировать чат. Тебя участвовать не зову. У нас люди хорошие, но я уже хочу телефон в кастрюле сварить."
    menu:
        "Могу попробовать. Только чат, и не круглосуточно.":
            $ rita_moderation.update(joined=True, active=True)
            wr "Да! И если надоест, скажи. Без передачи дел по акту."
            "Рита находит Олега в контактах. На экране появляется «Четверг точно»."
            $ week4_event("rita", "moderator_joined", "Только модерация, без участия и круглосуточной доступности")
            call rita_moderator_first_chat
        "Не возьмусь. Я сегодня как раз от таких чатов отдыхаю.":
            $ rita_moderation.update(joined=False, active=False)
            wr "Понимаю. Я вот сама отказалась бы, но я его создала."
            $ week4_event("rita", "moderator_declined")
    return

label rita_moderator_first_chat:
    call week4_chat("rita_group", "introductions", [("Рита", "Это Олег. Он поможет нам договориться. Только модератор, не участник."), ("Ира", "Привет! Я до десяти могу, потом ребёнка забрать от бабушки."), ("Лёша", "В пятницу машину на СТО. Если отдадут к вечеру, свободен."), ("Денис", "В субботу не могу. По субботам я пою в церковном хоре.")], [("poll", "Привет. Давайте каждый напишет два вечера, когда точно может. Без «если».", [("Лёша", "А если мастер скажет завтра?"), ("Ира", "Я могу оба. Извини, какие два?"), ("Рита", "Лёша, спроси мастера. Ира, любые два своих.")]), ("one", "Давайте пока один день проверим. Следующий четверг после восьми?", [("Ира", "Я за, до десяти."), ("Денис", "У меня хор по субботам."), ("Олег", "А четверг?"), ("Денис", "Четверг уточню.")])])
    "Новый участник присылает «Всем привет». На аватарке знакомый пиджак. Олег открывает профиль: тот самый агент по квартире."
    call week4_chat("rita_group", "agent", [("Агент", "Сразу обозначу: предпочитаю анальный секс. В остальном открыт к обсуждению."), ("Рита", "Хорошо. Ты в четверг можешь?"), ("Агент", "Вечер живой. Есть определённая гибкость.")], [("plain", "Это да или нет?", [("Агент", "После показа смогу сказать точнее."), ("Ира", "Запиши пока как «нет». Я так с няней делаю."), ("Агент", "Давайте всё же оставим потенциал.")]), ("recognise", "Мы с вами квартиру смотрели. Можно здесь хотя бы без «гибкости»?", [("Агент", "Олег, здравствуйте. Здесь я как частное лицо."), ("Рита", "Частное лицо, четверг. Да или нет?"), ("Агент", "Пока нет."), ("Лёша", "Вот. Человек осваивается.")])])
    $ rita_moderation["first_chat"] = True
    "На работе Олег хотя бы знает, кто ответит за разработку. Здесь пока удалось выяснить, кто отвечает за церковный хор."
    return

label rita_moderator_friday:
    if not rita_moderation.get("active") or rita_moderation.get("friday_read"):
        return
    $ rita_moderation["friday_read"] = True
    "В перерыве всплывает «Четверг точно». За утро — двадцать восемь сообщений. Олег открывает последние."
    call week5_chat("rita_group", "calendar", [("Лёша", "Машину отдали. Но в четверг родительское собрание."), ("Ира", "Лёш, а вчера ты почему про него не сказал?"), ("Лёша", "Я вчера про машину отвечал."), ("Денис", "Могу в воскресенье. До шести. Потом к маме полку вешать."), ("Агент", "Я тоже за воскресенье."), ("Рита", "Ты же вчера мне в личку написал, что уезжаешь на дачу."), ("Агент", "Я за сам вариант. Лично не смогу.")], [("limit", "Я поставлю опрос. Отмечайте только время, когда сами придёте. Вечером меня не будет. На следующей неделе вернусь к этому.", [("Ира", "Да, спасибо. Я свои отметила."), ("Рита", "Принято. Вечером не дёргаем."), ("Денис", "А мне хор отмечать как занято или просто не отмечать?"), ("Ира", "Не отмечай субботу, Денис.")]), ("leave", "Ребят, я переоценил силы. Дальше без меня, у меня и так рабочие чаты не кончаются.", [("Рита", "Ладно. Спасибо, что попробовал."), ("Лёша", "И опрос оставь, если сделал. Я теперь понял, как отвечать.")])])
    $ rita_moderation["friday_choice"] = _return
    if _return == "leave":
        $ rita_moderation["active"] = False
        $ week5_event("moderator_left", person="rita")
        "Олег выходит из чата. Рита пишет в личку: «Жилет дошила. Хоть с этим справилась»."
    else:
        $ rita_moderation["poll"] = True
        $ week5_event("moderator_poll", person="rita")
        call rita_calendar_puzzle
        "Олег ставит чат на беззвучный. На сегодня хватит."
        mind "Моя команда всё-таки проще. И это я ещё на Илью ворчал."
    return

init python:
    def rita_puzzle_state():
        # Old saves with an accepted moderator role start with no inferred answers.
        state = rita_moderation.setdefault("puzzle", {})
        for key, value in dict(asked=[], notes={}, proposal="", status="collecting", attempts=[],
                stage=1, next_step="confirm_next_week", confirmed=[], resolution="").items():
            state.setdefault(key, value)
        return state

    def rita_puzzle_propose(slot):
        state = rita_puzzle_state()
        conflicts = {"thursday":"lesha_school", "friday":"rita_premiere", "sunday_late":"denis_mother"}
        missing = [key for key in ("hours", "travel", "place") if key not in state["asked"]]
        result = "conflict" if slot in conflicts else "candidate_ready" if not missing else "needs_details"
        state["proposal"], state["status"] = slot, result
        state["attempts"].append({"slot":slot, "result":result, "missing":missing,
                                  "conflict":conflicts.get(slot, "")})
        # A feasible draft is not a confirmed meeting or a finished arc.
        state["confirmed"], state["resolution"] = [], ""
        return result

label rita_calendar_puzzle:
    $ rita_puzzle_state()
    "Олег уже собирается убрать телефон, но Рита присылает ещё одно сообщение."
    call week5_chat("rita_group", "next_week", [("Рита", "Эту неделю отпускаем. Давайте следующую. Мне надо заранее, я помещение не могу за час найти."), ("Ира", "И не ночью, пожалуйста. Мне ребёнка забирать."), ("Лёша", "Мне без разницы. Кроме четверга."), ("Денис", "Мне тоже. Кроме субботы и воскресного вечера.")], [("ask", "Подождите. Сначала уточню несколько вещей. А то мы опять выберем день, а потом начнётся.", [("Рита", "Давай. Я пока у машинки, но читаю.")]), ("later", "Сегодня уже не разберусь. Оставим на следующую неделю, я вернусь к переписке.", [("Ира", "Ок. Только пока ничего не бронируйте.")])])
    if _return == "later":
        $ rita_puzzle_state()["status"] = "deferred"
        return
label rita_calendar_questions:
    while len(rita_puzzle_state()["asked"]) < 3:
        $ rita_questions = []
        if "hours" not in rita_puzzle_state()["asked"]:
            $ rita_questions.append(("Хочу понять, сколько времени нужно и во сколько кому уходить.", "hours"))
        if "travel" not in rita_puzzle_state()["asked"]:
            $ rita_questions.append(("СТО и дача — это вы заняты или просто не на чем приехать?", "travel"))
        if "place" not in rita_puzzle_state()["asked"]:
            $ rita_questions.append(("А куда вы вообще собираетесь? У места тоже есть расписание.", "place"))
        $ rita_questions.append(("Кажется, можно уже предложить время.", "propose"))
        call screen chapter3_intentions("Что я ещё не выяснил?", rita_questions)
        $ rita_question = _return
        if rita_question == "propose":
            jump rita_calendar_proposal
        $ rita_puzzle_state()["asked"].append(rita_question)
        if rita_question == "hours":
            call week5_chat("rita_group", "hours", [("Олег", "Хочу понять, сколько времени нужно и во сколько кому уходить."), ("Рита", "Хочется хотя бы три часа. Не чтобы приехали и сразу куртки искать."), ("Ира", "В следующее воскресенье могу с трёх до шести. В половине седьмого забираю ребёнка, от центра успеваю."), ("Денис", "К маме в шесть. Раньше свободен."), ("Рита", "А я в пятницу до ночи на премьере. В воскресенье примерка до двух.")], [("note", "Значит, не просто «воскресенье». Надо закончить к шести.", [("Ира", "Да. Вот это важно.")])])
        elif rita_question == "travel":
            call week5_chat("rita_group", "travel", [("Олег", "СТО и дача — это вы заняты или просто не на чем приехать?"), ("Лёша", "Да я на метро приеду. Я про СТО зачем вообще написал, не знаю."), ("Агент", "С дачи в воскресенье к полудню вернусь. После часа могу."), ("Денис", "А хор всё ещё в субботу. Если кто записывает."), ("Рита", "Мы помним, Денис.")], [("note", "То есть отсутствие машины нам день не закрывает. И дача — не всё воскресенье.", [("Агент", "Совершенно верно. Транспортная доступность достойная.")])])
        else:
            call week5_chat("rita_group", "place", [("Олег", "А куда вы вообще собираетесь? У места тоже есть расписание."), ("Рита", "Есть отдельная студия в центре. В следующее воскресенье свободна с трёх до шести. Пока просто спросила, не бронировала."), ("Ира", "Оттуда до бабушки двадцать минут. Мне подходит."), ("Лёша", "А я думал, мы у тебя."), ("Рита", "У меня примерка. Там люди в булавках. Не надо к ним.")], [("note", "Пока без брони. Сначала все подтвердят именно эти три часа.", [("Рита", "Да. Хозяйке так и скажу.")])])
        $ rita_puzzle_state()["notes"][rita_question] = list(week5_chat_transcript)
label rita_calendar_proposal:
    call screen chapter3_intentions("Какое время им предложить?", [
        ("Следующий четверг, с восьми до одиннадцати.", "thursday"),
        ("Следующая пятница, с девяти до полуночи.", "friday"),
        ("Следующее воскресенье, с трёх до шести.", "sunday_early"),
        ("Следующее воскресенье, с семи до десяти.", "sunday_late"),
        ("Перечитать их ответы, прежде чем предлагать.", "review"),
        ("Я пока не уверен. Лучше уточнить потом, чем обещать за всех.", "defer")])
    if _return == "review":
        $ rita_readback = [message for topic in rita_puzzle_state()["asked"] for message in rita_puzzle_state()["notes"].get(topic, [])]
        if rita_readback:
            # Notes are saved excerpts, not a new delivery. Older notes have no timestamps.
            call screen phone_thread(rita_readback, caption="Четверг точно", past=[], instant=True, inbox_mode=True, archive_times=[""] * len(rita_readback))
        else:
            mind "Я же пока ничего толком не спросил. Вернусь к вопросам."
            jump rita_calendar_questions
        jump rita_calendar_proposal
    if _return == "defer":
        $ rita_puzzle_state()["status"] = "deferred"
        "Олег пишет, что вернётся к вопросу на следующей неделе. Рита оставляет помещение без брони."
        return
    $ rita_proposal = _return
    $ rita_proposal_result = rita_puzzle_propose(rita_proposal)
    $ rita_proposal_words = {"thursday":"Следующий четверг, 20–23?", "friday":"Следующая пятница, 21–00?", "sunday_early":"Следующее воскресенье, 15–18?", "sunday_late":"Следующее воскресенье, 19–22?"}[rita_proposal]
    if rita_proposal_result == "conflict":
        $ rita_objection = {"thursday":("Лёша", "Я же про четверг написал. Родительское собрание. Меня там ждут."), "friday":("Рита", "В пятницу я на премьере. Не могу."), "sunday_late":("Денис", "Я у мамы буду. Полка сама не повесится." )}[rita_proposal]
        call week5_chat("rita_group", "proposal_conflict", [], [("send", rita_proposal_words, [rita_objection, ("Ира", "Давайте пока ничего не оплачивать.")])])
        mind "Так. Я тоже умею не прочитать ответ."
        "Олег оставляет вопрос открытым. На следующей неделе придётся вернуться к тому, что он пропустил."
    elif rita_proposal_result == "needs_details":
        call week5_chat("rita_group", "proposal_unchecked", [], [("send", rita_proposal_words, [("Рита", "Похоже на вариант. Но ещё место и дорогу надо проверить."), ("Ира", "Держу карандашом. Не считайте пока согласием на всё.")])])
    else:
        call week5_chat("rita_group", "proposal_ready", [], [("send", "Следующее воскресенье, с трёх до шести. В центре, оттуда Ира успевает. У Риты примерка уже закончится, Денис ещё успеет к маме, вы с дачи вернётесь. Я ничего не упустил?", [("Лёша", "Кажется, нет. Я даже себе записал."), ("Ира", "По времени да."), ("Рита", "В понедельник ещё раз всех спрошу и узнаю, свободна ли студия. Пока не платим."), ("Агент", "Вот это уже конкретное предложение.")])])
        mind "Вот бы он про квартиры так отвечал."
    $ week5_event("moderator_calendar_draft", rita_proposal_result, person="rita")
    "Олег закрывает чат. До следующего воскресенья ещё больше недели; сейчас у него свой вечер."
    return
