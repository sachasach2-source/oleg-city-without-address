image bg w5 varya shop = Transform("images/week5/varya-night-shop-narrow-v2.webp", xysize=(1600, 900))

init -9 python:
    cast_assets[("varya", "cold")] = {"neutral":"images/week5/varya-cold-v1.webp"}
    path = "images/week5/varya-night-shop-narrow-v2.webp"
    for person in ("solo", "nika", "lera", "asya"):
        key = "w5 rescue " + person
        renpy.image("bg " + key, Transform(path, xysize=(1600, 900)))
        if person == "solo":
            people = [("oleg", "outdoor", 420, 60, 915), ("varya", "cold", 1220, 45, 920)]
        else:
            wardrobe = "coat" if person == "asya" else "outdoor"
            people = [("oleg", "outdoor", 300, 90, 865), ("varya", "cold", 820, 55, 800),
                (person, wardrobe, 1350, 85, 870)]
        cast_stages[key] = (path, people, None, "night")

init python:
    phone_media["photo:varya_date"] = {"path":"images/week5/varya-date-mirror-v5.webp",
        "title":"Варя · собирается на кофе", "caption":"Фото в зеркало · «Норм так?»"}
