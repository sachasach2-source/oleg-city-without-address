# Her information has a played source; neither contact nor friendship implies it.
init python:
    def week5_marta_home_identity():
        return copy.deepcopy({k: week5_home.get(k) for k in ("kind", "actual_home", "hotel")})

    def week5_marta_can_meet_near_home():
        return (week5_marta_known() and week5_marta.get("plan") == "saturday14"
            and week5_relations["marta"].get("mode") == "interest"
            and not week5_issues("marta") and not week5_marta.get("limited")
            and week5_marta.get("home_clue") == "bakery_pin"
            and week5_marta.get("home_when_shared") == week5_marta_home_identity()
            and not week5_marta.get("doorstep_seen"))

    def week5_marta_can_wait():
        events = week5_marta_events()
        personal = "midweek_mutual_interest" in events
        # Shared-group scenes count only if Oleg also answered her personal invitation.
        group_personal = "midweek_group_mutual_interest" in events
        return week5_marta_can_meet_near_home() and "midweek_meeting" in events and (personal or group_personal)

label week5_marta_share_neighbourhood:
    if week5_marta.get("plan") != "saturday14" or week5_relations["marta"].get("mode") != "interest" or week5_issues("marta") or week5_marta.get("clue_asked"):
        return
    $ week5_marta["clue_asked"] = True
    call week5_chat("marta", "bakery", [("Марта", "Сканер победила. Теперь надо где-нибудь еды взять. Ты случайно хорошую пекарню не знаешь?")], [("usual", "Я обычно в ближайшей беру. Пока без проверенных рекомендаций.", [("Марта", "Ладно, проверю сама. У меня сегодня уже один успех есть.")]), ("pin", "У меня прямо в доме пекарня. Булки хорошие, утром из-за них окно закрывать жалко. Сейчас точку скину.", [("Олег", "Отправил точку пекарни на карте."), ("Марта", "Сохранила. Ты там хорошо устроился.")])])
    if _return == "pin":
        $ week5_marta.update(home_clue="bakery_pin", home_when_shared=week5_marta_home_identity())
        $ week5_marta_record("marta_home_clue_shared", "Олег сам отправил точку пекарни и сказал, что живёт в том же доме; номер квартиры неизвестен")
    return

label week5_marta_doorstep:
    if not week5_marta_can_meet_near_home():
        return False
    if not week5_marta_can_wait():
        call week5_marta_bakery
        return False
    $ week5_marta["encounter"] = "waiting"
    $ week5_stamp("У дома · перед прогулкой", 800, 1)
    $ set_soundscape("ch3_outside")
    scene bg w5 marta waiting with fade
    if week5_home.get("kind", "hotel") == "hotel":
        "Выйдя из гостиницы, Олег замечает Марту у арки. Она стоит с блокнотом в руках и смотрит на дверь, из которой он только что вышел."
    else:
        "Олег выходит из подъезда и замечает Марту у арки. Она стоит с блокнотом в руках и смотрит прямо на его дверь."
    "Увидев его, она выпрямляется, не отводя глаз."
    scene bg w5 marta doorstep with dissolve
    m "Привет."
    o "Привет. Мы же у метро договаривались."
    m "А я раньше освободилась."
    o "Ты откуда знаешь, где я живу?"
    m "Вороны рассказали."
    o "И номер дома?"
    m "Очень наблюдательные птицы."
    "Олег смотрит на неё. Марта отводит глаза, всё ещё улыбаясь."
    m "Ты вчера пекарню прислал. И сказал, что живёшь в этом доме. Я дошла, посмотрела, где выходят."
    o "И решила меня подождать?"
    m "Да. Хотела увидеть тебя пораньше."
    "Она крепче прижимает блокнот к груди."
    "Марта ждёт ответа. Из арки тянет холодным воздухом; она всё ещё стоит на месте."
    $ week5_marta["doorstep_seen"] = True
    $ week5_marta_record("marta_unexpected_visit", "Ждала у дома по точке пекарни, без приглашения; объяснила источник после шутки про ворон")
    $ marta_attention_answered = False
    while not marta_attention_answered:
        menu:
            "Я рад тебя видеть. Но в следующий раз сначала напиши.":
                o "Я рад тебя видеть. Но в следующий раз сначала напиши. Я мог вообще не выйти."
                m "Я бы написала. Потом."
                o "Вот лучше до."
                m "Хорошо. До."
                $ week5_marta.update(attention="message_first", attention_first="message_first")
                $ marta_attention_answered = True
            "Передай воронам, что мне нравится, когда ты меня ждёшь.":
                o "Передай воронам, что мне нравится, когда ты меня ждёшь."
                "Марта поднимает глаза. Несколько секунд ничего не говорит."
                m "Ты сейчас серьёзно?"
                o "Да. Я рад, что ты захотела прийти. Можешь ещё так меня ловить."
                m "Зря ты это сказал. Я очень хорошо запоминаю."
                "Олег улыбается. Только теперь она подходит к нему ближе."
                "Теперь ей не нужно повышать голос, чтобы перекрыть шум улицы. Олег слышит короткий вдох перед следующей фразой. Ему приятно, что она подошла, и всё ещё немного странно представлять, сколько времени она смотрела на его дверь."
                m "Тогда сегодня даже случайность изображать не буду. Пошли? Я папку уже забрала."
                $ week5_marta.update(attention="encouraged", attention_first="encouraged")
                $ marta_attention_answered = True
            "Ты давно здесь ждёшь?" if not week5_marta.get("wait_admitted"):
                m "Да недавно."
                o "Сколько?"
                m "Минут двадцать пять."
                o "Марта."
                m "Я нарисовать хотела, пока жду. Но всё время смотрела, кто выходит."
                "Она прижимает к себе закрытый блокнот."
                $ week5_marta["wait_admitted"] = True
                $ week5_marta_record("marta_wait_admitted", "Призналась, что ждала двадцать пять минут")
            "Мне не нравится, что ты пришла к моему дому без спроса.":
                o "Мне не нравится, что ты пришла к моему дому без спроса. Сегодня я уже не хочу гулять."
                m "Я думала, ты обрадуешься."
                o "Я понимаю. Но мне не по себе."
                m "Ладно. Прости. Я уйду."
                "Она делает шаг в сторону метро, останавливается, чтобы застегнуть сумку. На этот раз ничего не говорит про птиц."
                $ week5_marta.update(attention="unwelcome", attention_first="unwelcome", scene_done=True, next="doorstep_refused", plan="cancelled_after_visit")
                $ week5_relations["marta"]["issues"].append({"cause":"uninvited_visit", "detail":"Марта ждала у дома без приглашения; Олегу стало не по себе", "status":"open"})
                $ week5_relations["marta"]["promises"] = [x for x in week5_relations["marta"]["promises"] if "Прогулка в следующую субботу" not in x]
                $ week5_marta_record("marta_doorstep_refused")
                $ week5_stamp("У дома", 810, 1)
                return True
    $ week5_marta_record("marta_attention_response", week5_marta["attention"])
    "До встречи у метро ещё есть время. Они идут туда вместе; Марта рассказывает, как продавец в книжном пытался сложить её папку пополам."
    return False

label week5_marta_bakery:
    $ week5_stamp("У пекарни · перед прогулкой", 800, 1)
    $ set_soundscape("ch3_outside")
    scene bg w5 marta bakery with fade
    "Свернув от двери к пекарне, Олег замечает Марту у витрины. Блокнот убран в сумку; на ладони булка в раскрытой бумажной обёртке."
    o "Привет. Ты уже тут?"
    m "Решила проверить твою рекомендацию."
    o "И как?"
    m "Пахнет убедительно. Я ещё не пробовала."
    "Она смотрит на булку, потом на Олега."
    m "Вообще я уже собиралась к метро. Потом подумала: вдруг ты сейчас выйдешь. Немножко задержалась."
    $ week5_marta.update(encounter="bakery", bakery_seen=True)
    menu:
        "Хорошо, что задержалась. Пойдём вместе?":
            o "Хорошо, что задержалась. Пойдём вместе?"
            m "Пойдём. Сейчас только с булкой разберусь."
            $ week5_marta["bakery_response"] = "welcome"
        "Давай я тебя у метро догоню. Ещё зайду за водой.":
            o "Давай я тебя у метро догоню. Ещё зайду за водой."
            m "Хорошо. Я тогда потихоньку пойду. До двух."
            $ week5_marta["bakery_response"] = "metro"
    "Марта откусывает булку и ловит пальцем осыпавшийся сахар."
    m "Да. Рекомендация хорошая."
    $ week5_marta_record("marta_bakery_encounter", week5_marta["bakery_response"])
    return

label week5_marta_attention_after_walk:
    if not week5_marta.get("doorstep_seen"):
        return
    if week5_relations["marta"]["mode"] == "friendship":
        m "Я услышала про дружбу. У дома больше караулить не буду. Мне самой надо немного привыкнуть."
        $ week5_marta["attention"] = "friendship_distance"
        $ week5_marta_record("marta_attention_friendship")
    elif week5_marta.get("attention") == "encouraged":
        m "Проводить тебя обратно? Сегодня могу официально, без ворон."
        menu:
            "Пойдём. Мне приятно, что ты не хочешь расходиться.":
                o "Пойдём. Мне приятно, что ты не хочешь расходиться."
                m "Очень не хочу. Я уже три повода придумала."
                o "Назови самый плохой."
                m "Что забыла, как идти до твоей пекарни."
                "Они смеются. Марта всё-таки убирает карту обратно в сумку."
                $ week5_marta.update(attention="encouraged", walk_home=True)
                $ week5_marta_record("marta_attention_invited_again", "Олег сам захотел, чтобы Марта проводила его до дома")
            "Мне понравилось. А дальше я сегодня хочу один.":
                o "Мне понравилось. А дальше я сегодня хочу один."
                m "Ты же сам сказал, что тебе нравится."
                o "Нравится. Но сейчас я хочу домой один. Это тоже всерьёз."
                "Марта смотрит на птицу на своей сумке."
                m "Ладно. А я уже до вечера маршрут придумала."
                o "Давай на сегодня попрощаемся?"
                m "Давай. Завтра напишу."
                $ week5_marta.update(attention="message_first", later_space=True)
                $ week5_marta_record("marta_attention_space_after_welcome", "Первое поощрение сохраняется; теперь Олег попросил время для себя")
    elif week5_marta.get("attention") == "message_first":
        m "Я бы тебя ещё проводила. Но ты просил сначала спрашивать. Хочешь?"
        menu:
            "Сейчас хочу. Давай пройдёмся ещё.":
                o "Сейчас хочу. Давай пройдёмся ещё."
                m "Вот. Спрашивать тоже работает."
                $ week5_marta["walk_home"] = True
                $ week5_marta_record("marta_walk_home_invited", "Одно приглашение, правило сначала писать сохраняется")
            "Я уже домой один. Спасибо, что спросила.":
                m "Хорошо. Тогда до связи."
                $ week5_marta_record("marta_attention_boundary_kept")
    return

image bg w5 marta doorstep = Transform("images/cast/courtyard-empty.webp", xysize=(1600,900))
init -9 python:
    cast_stages["w5 marta doorstep"] = ("images/cast/courtyard-empty.webp", [("oleg","outdoor",420,55,920),("marta","week5",1240,35,1280)], None, "shade")

image bg w5 marta waiting = Transform("images/week5/marta-waiting-door-v1.webp", xysize=(1600,900))
image bg w5 marta bakery = Transform("images/week5/marta-bakery-v3.webp", xysize=(1600,900))
