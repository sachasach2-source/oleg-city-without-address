image bg ch3 varya cafe = Transform("images/chapter3/varya-cafe-zine-v1.webp", xysize=(1600, 900))
image bg gallery walk = Transform("images/chapter2-gallery-walk-v1.webp", xysize=(1600, 900))
image bg ch3 nika dinner = Transform("images/chapter3/nika-dinner-v1.webp", xysize=(1600, 900))
image bg ch3 lera bench = Transform("images/chapter3/lera-bench-friends-v1.webp", xysize=(1600, 900))
image bg w4 nika farewell = Transform("images/week4/nika-farewell-v1.webp", xysize=(1600, 900))
image bg w4 nika goodbye hug = Transform("images/week4/nika-goodbye-hug-v1.webp", xysize=(1600, 900))

init python:
    cast_cues.update({
        ("nika", "Знаешь, что бесит? Я даже когда говорю «не трогайте меня», должна всем отдельно это сказать."):"earnest",
        ("nika", "Тебе не говорила. С тобой сейчас нормально."):"amused",
    })
