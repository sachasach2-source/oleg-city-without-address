label week7_dice_requested_track:
    if week7_venue.get("dice_request") in ("heavy","fast") and not week7_venue.get("dice_request_played"):
        if week7_venue["dice_request"]=="heavy":
            "В перерыве между номерами из колонок доносится тяжёлый гитарный рифф. Катя у ноутбука ловит взгляд Олега и показывает большой палец."
        else:
            "После короткой паузы начинается быстрый танцевальный трек. Катя у ноутбука кивает Олегу: его просьбу она не забыла."
        $ week7_venue["dice_request_played"]=True
    return

label week7_party_garden:
    scene expression week7_venue_scene("garden",week7_party_guest()) with dissolve
    if not week7_visit:
        "В оранжерее тепло. Вода снаружи бежит по стеклу, внутри пахнет мокрой землёй и чаем. На лейке сидит бумажная ворона; у одной тыквы рот вырезан почти до самого бока."
        if week7_party_guest():
            $ week7_say(week7_party_guest(),{"nika":"Здесь хорошо. Даже уходить пока не хочется.","lera":"А чай можно? Мне потом ещё полночи на ногах. Сейчас хоть погреюсь спокойно.","asya":"Не думала, что у этой площадки ещё и оранжерея есть. Хорошо они её придумали использовать.","marta":"Ворона бумажная, но вполне убедительная. Я бы её дома над дверью посадила.","zhenya":"О, тут можно и посидеть. Ноги устали.","ulya":"Хочу всё это снять. Но можно я сначала просто посмотрю? Без телефона."}[week7_party_guest()])
        menu:
            "Постою у стекла, посмотрю во двор.":
                "Олег прикрывает отражение ладонью. Во дворе человек осторожно обходит лужу; под его зонтом на секунду вспыхивает оранжевый свет тыквы."
            "Рассмотрю тыквы. Тут каждая со своим лицом.":
                "У самой маленькой тыквы один глаз выше другого. За ней прячется белая, совсем без лица. Олег поворачивается к ней другой стороной: нет, действительно только хвостик."
    else:
        "На шкафчике остались чистые чашки. Олег наливает чай, ждёт, пока можно будет пить, и перед уходом ставит пустую чашку обратно на поднос."
        if week7_party_guest():
            $ week7_say(week7_party_guest(),{"nika":"Я ещё на минуту здесь. Слушай, как дождь по стеклу стучит.","lera":"Сейчас допью. Хорошо, что мы сюда завернули.","asya":"На улице свет совсем синий стал. А здесь всё ещё оранжевое.","marta":"Я бы эту самую белую забрала. У неё лицо ещё не испортили.","zhenya":"Я уже пожалела, что похвалила скамейку. Теперь очень хочется сесть.","ulya":"Всё, я один кадр сделала. Остальное пусть таким и останется."}[week7_party_guest()])
    "За дверью снова слышен бас. Олег придерживает её за тяжёлую ручку и возвращается в зал."
    return

init python:
    week7_oracle_names=("Звезда","Колесо","Шут")
    week7_oracle_readings=(
        "В инструкции к колоде: «Оставьте место для того, чего пока не умеете объяснить. Звезда показывает направление, а не расстояние до цели».",
        "В инструкции к колоде: «Колесо уже повернулось. Посмотрите, за что вы всё ещё держитесь, прежде чем сделать следующий шаг».",
        "В инструкции к колоде: «Начало не обязано выглядеть разумно со стороны. У Шута есть сумка, но ещё нет готового маршрута»."
    )
    def week7_oracle_face(index,size=(310,520)):
        return Transform("images/week7/oracle-cards-v1.webp",crop=(index*560,0,560,936),xysize=size,fit="contain")

screen week7_oracle_pick():
    modal True
    key "game_menu" action ShowMenu("save")
    add Transform("images/week7/oracle-table-v3.webp",xysize=(1600,900),fit="contain")
    frame:
        xpos 60 ypos 28 padding (25,18) background mini_surface("oracle")
        text "Какую карту возьмёшь?" size 30 color "#4d394b"
    for i,x in enumerate((477,719,961)):
        button:
            id "w7_oracle_card_"+str(i)
            xpos x ypos 319 xsize 185 ysize 295 padding (0,0)
            background None hover_background Week7MapFocus()
            action Return(i)
    use minigame_system("oracle")

screen week7_oracle_result():
    modal True
    key "game_menu" action ShowMenu("save")
    $ info=week7_venue["oracle"]
    add Transform("images/week7/oracle-table-v3.webp",xysize=(1600,900),fit="contain")
    add Solid("#0a1020d9")
    add week7_oracle_face(info["card"],(340,569)) xcenter 510 ypos 130
    text week7_oracle_names[info["card"]] xcenter 510 ypos 655 size 25 color "#3b2819"
    frame:
        xpos 805 ypos 175 xsize 655 padding (30,30) background mini_surface("oracle")
        vbox:
            spacing 26
            text "КАРТА НА ВЕЧЕР" size 16 kerning 2 color "#776072"
            text info["question"] size 29 color "#4d394b"
            text week7_oracle_readings[info["card"]] size 24 color "#4d394b" line_spacing 3
            textbutton "Вернуться к столику" id "w7_oracle_close" action Return() properties mini_button("oracle")
    use minigame_system("oracle")

label week7_party_oracle:
    scene expression week7_venue_scene("quiet",week7_party_guest()) with dissolve
    "На круглом столике у дивана лежат карты. Рядом с колодой сложена инструкция; на обложке от руки: «Вопросы можно любые, чужие мысли не читаем»."
    if week7_party_guest()=="marta":
        m "О, эту я видела. Тут художник сам все дворы нарисовал. Хочешь, я почитаю?"
        o "Давай. Только я сначала вопрос выберу."
    menu:
        "Спрошу про ближайшую неделю.":
            $ week7_oracle_question="Про ближайшую неделю"
        "Про то, что я всё откладываю.":
            $ week7_oracle_question="Про то, что я откладываю"
        "Пусть будет про сегодняшний вечер.":
            $ week7_oracle_question="Про сегодняшний вечер"
    $ week7_venue["oracle"]=dict(question=week7_oracle_question,order=renpy.random.sample([0,1,2],3),person=week7_party_guest())
    call screen week7_oracle_pick
    $ week7_venue["oracle"]["position"]=_return
    $ week7_venue["oracle"]["card"]=week7_venue["oracle"]["order"][_return]
    call screen week7_oracle_result
    scene expression week7_venue_scene("quiet",week7_party_guest()) with dissolve
    if week7_party_guest():
        $ week7_say(week7_party_guest(),{"nika":"Красиво нарисовано. Я бы такую на стену повесила. А вопрос твой пусть пока при тебе останется.","lera":"Я в этих значениях не разбираюсь. Но картинка мне нравится.","asya":"Мне нравится инструкция. Не обещает, что за тебя всё уже решили.","marta":"Не обязательно сразу понять. Иногда потом что-нибудь увидишь — и вспомнишь картинку.","zhenya":"Я сначала думала, пропущу. А теперь тоже карту хочу. Дай инструкцию.","ulya":"Я тоже хочу. Сейчас только инструкцию прочитаю."}[week7_party_guest()])
    else:
        "Олег ещё раз смотрит на картинку, кладёт карту к остальным и поправляет край скатерти, чтобы тот не касался подсвечника."
    menu:
        "Пожалуй, сфотографирую на память.":
            $ week7_venue["oracle"]["kept"]="photo"
            "Олег снимает карту отдельно от инструкции. В кадре остаются звёзды, потёртая золотая рамка и немного края стола."
        "Оставлю здесь. Мне достаточно было посмотреть.":
            $ week7_venue["oracle"]["kept"]="left"
            "Карта возвращается в колоду. Подсвечник Олег сдвигает подальше от картонной коробочки."
    $ week7_event("oracle_card",week7_oracle_names[week7_venue["oracle"]["card"]],week7_party_guest())
    return
