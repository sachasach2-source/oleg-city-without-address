# Evening plates were designed with room for both standing interlocutors.
image bg w5 canal empty = Transform("images/week5/canal-night-v1.webp", xysize=(1600, 900))
image bg w5 books empty = Transform("images/week5/bookshop-night-v1.webp", xysize=(1600, 900))
image bg w5 album = Transform("images/week5/book-album-v1.webp", xysize=(1600, 900))
image bg w5 kiss nika = Transform("images/week5/nika-kiss-v1.webp", xysize=(1600, 900))
image bg w5 kiss lera = Transform("images/week5/lera-kiss-v1.webp", xysize=(1600, 900))
image bg w5 kiss asya = Transform("images/week5/asya-canal-step-axis-v2.webp", xysize=(1600, 900))

init -9 python:
    cast_assets[("asya", "coat")] = {"neutral":"images/week5/asya-coat-left-v2.webp"}
    cast_assets[("asya", "week5")] = dict(cast_assets[("asya", "")])
    for person in ("nika", "lera", "asya"):
        outdoor = "coat" if person == "asya" else "outdoor"
        indoor = {"nika":"standing", "lera":"indoor", "asya":"week5"}[person]
        for location, path, wardrobe in [
            ("canal", "images/week5/canal-night-v1.webp", outdoor),
            ("books", "images/week5/bookshop-night-v1.webp", indoor),
            ("home", "images/hotel-night.webp", indoor),
        ]:
            key = "w5 " + location + " " + person
            renpy.image("bg " + key, Transform(path, xysize=(1600, 900)))
            cast_stages[key] = (path, [("oleg", "outdoor" if location == "canal" else "indoor", 430, 55, 920),
                (person, wardrobe, 1250, 55, 920)], None, "night" if location == "canal" else "evening")
    cast_cues.update({
        ("nika", "Смотри. Я уже пришла."):"amused",
        ("nika", "В конце поспорили. Но уже после. Это считается."):"amused",
        ("lera", "Так. Хорошо. Пойдём, пока я ещё умею ходить."):"amused",
        ("lera", "Это у меня не получается придумать умную фразу."):"earnest",
        ("asya", "Поэтому я и согласилась."):"warm",
        ("oleg", "Я перед отправкой тоже. Раз шесть."):"amused",
        ("oleg", "Я тоже без неё пока."):"amused",
    })

init 50 python:
    _week5_cast_stage_data = cast_stage_data
    def cast_stage_data():
        stage = _week5_cast_stage_data()
        if stage and cast_background_key().startswith("w5 home "):
            path = "images/week5/hotel-dialogue-night-v1.webp" if week5_home.get("kind") == "hotel" else week5_home_path(True)
            return (path, stage[1], stage[2], stage[3])
        return stage
