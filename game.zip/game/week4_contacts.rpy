# Conversations preserve the actual last meeting; no universal apology reset.
label week4_choose_contact:
    $ week4_contact_options = [("Написать " + {"nika":"Нике", "asya":"Асе", "lera":"Лере", "varya":"Варе"}[p] + ".", p) for p in ("nika", "asya", "lera", "varya") if week4_relations[p]["known"] and p not in week4_contacted]
    $ week4_contact_options.append(("Сегодня без телефона.", "rest"))
    call screen chapter3_intentions("С кем мне сейчас хочется поговорить?", week4_contact_options)
    if _return == "rest":
        return
    $ week4_current = _return
    $ week4_contacted.append(week4_current)
    call week4_contact_history(week4_current)
    if _return == "stop":
        return
    call expression "week4_contact_" + week4_current
    call connections_after_contact(week4_current)
    return

label week4_contact_history(person):
    if week4_unresolved(person, True):
        if week4_relations[person]["last_status"] == "missed":
            $ week4_history_line = {"nika":"Я тебя тогда прождала. Давай сначала с этим разберёмся, а потом новый вечер выбирать.", "asya":"Я в прошлый раз под тебя время освободила. Ты так и не приехал.", "lera":"Слушай, ты в прошлый раз не доехал. Мне теперь опять весь вечер держать?", "varya":"А в этот раз ты точно придёшь? Я тогда тебя ждала вообще-то."}[person]
        else:
            $ week4_history_line = {"nika":"Я тогда на вечер рассчитывала. Пока не хочу опять придумывать, куда нам вместе, чтобы ты потом уехал.", "asya":"Я после твоего ухода так и не поняла, тебе вообще хотелось со мной побыть?", "lera":"Мне с тобой было хорошо. До момента, когда ты засобирался. Повторять эту часть не хочется.", "varya":"Только не как в выходные: я ещё половину показать не успела, а ты уже уходишь."}[person]
        $ week4_ack_reply = {"nika":"Прочитала. Давай без больших обещаний пока.", "asya":"Спасибо, что сказал. Я всё ещё расстроена, если честно.", "lera":"Ладно. Только я пока на час, а не опять освобождать всё.", "varya":"Ну вот. Я же не просто так тебя задержать пыталась."}[person]
        call week4_chat(person, "last_time", [(week4_names[person], week4_history_line)], [("ack", "Да. Я видел, что ты расстроилась, и всё равно свернул разговор. Прости.", [(week4_names[person], week4_ack_reply)]), ("dismiss", "Мы же нормально посидели. Чего опять возвращаться?", [(week4_names[person], "Тебе нормально было. Давай сегодня без планов.")]), ("space", "Понял. Не буду сейчас звать. Если захочешь поговорить, я здесь.", [(week4_names[person], "Хорошо.")])])
        if _return == "ack":
            $ week4_acknowledge(person)
            $ week4_plan_short = True
        else:
            if _return == "dismiss":
                $ week4_open_issue(person, "dismissed", "Отмахнулся от прошлого ухода")
            return "stop"
    if person == "nika" and week4_entry["tasks"].get("guitar") in ("pending", "deferred"):
        call week4_chat("nika", "riff", [("Ника", "Кстати. Кусок ты так и не прислал.")], [("send", "Помню. Сейчас запишу, пока опять не начал улучшать.", [("Ника", "Да мне черновик. Не альбом.")]), ("later", "Сейчас не вывожу. Не буду ещё один срок придумывать.", [("Ника", "Ладно. Захочешь — пришлёшь.")])])
        if _return == "send":
            "Олег достаёт гитару. Записывает сорок секунд и отправляет второй дубль: на первом в середине звякнул чайник."
            $ week4_event("nika", "riff_sent")
            $ week4_relations["nika"]["issues"] = [dict(item, status="resolved") if item["cause"] == "unsent_riff" else item for item in week4_relations["nika"]["issues"]]
    return "continue"

label week4_invite(person, incoming, yes, reply):
    if week4_thursday_free():
        call week4_chat(person, "invite", incoming, [("yes", yes, [(week4_names[person], reply)]), ("talk", "В четверг встречу не обещаю. Но поболтать сейчас рад.", [(week4_names[person], "Ладно. Тогда без договорённости.")])])
        if _return == "yes":
            $ week4_book(person, bool(week4_unresolved(person, True)))
    else:
        call week4_chat(person, "busy", incoming, [("honest", "В четверг уже договорился. Давай не буду обещать, что разорвусь.", [(week4_names[person], "Хорошо. Другой день тогда отдельно выберем.")]), ("brief", "У меня четверг занят. Но я не только ради встречи написал.", [(week4_names[person], "Это приятно. У меня тоже не каждый вечер свободный.")])])
    return

label week4_contact_nika:
    if week4_home.get("visit") == "thursday" and not week4_plan:
        $ week4_call_when = "сегодня" if week4_day == 2 else "в среду"
        call week4_chat("nika", "repair_plans", [("Ника", "Мы запись перенесли. Я обещала новый материал, а теперь даже не знаю, что им посылать.")], [("call", "В четверг жду мастера. Можем " + week4_call_when + " вечером созвониться? Минут на двадцать.", [("Ника", "Давай. В половине девятого я уже дома. Наушники найду.")]), ("later", "В четверг не смогу. Давай другой день, когда оба свободны.", [("Ника", "Хорошо. В пятницу узнаю про репетицию, напишу.")])])
        if _return == "call":
            $ week4_relations["nika"]["midweek_call"] = "planned"
            $ week4_event("nika", "call_agreed", "Среда 20:30; мастер в четверг остаётся")
        return
    call week4_invite("nika", [("Ника", "В четверг запись перенесли. У меня три начала и ни одной песни, которую хочу туда принести."), ("Ника", "Хочу куда-нибудь выйти. А то дома опять открою эти файлы.")], "Давай в четверг поедим. В семь, у метро Лиговский. Место я найду.", "Давай. Могу наушники взять, покажу, на чём застряла.")
    return

label week4_contact_asya:
    call week4_invite("asya", [("Ася", "Помнишь, я про четверг говорила? Музыканты перенесли."), ("Ася", "Я полдня правила афишу. Теперь у неё очень точная дата события, которого нет.")], "Я бы всё равно приехал. К семи, в галерею. Ты там?", "Да. Ещё подписи переделываю. Приходи к боковой двери, основной вход закрою.")
    return

label week4_contact_lera:
    if week4_thursday_free():
        $ week4_lera_offers = [("yes", "Поедим. В семь где тебе удобно?", [("Лера", "У меня рядом с домом есть пельмени. Скину точку. Потом, если захотим, ко мне. Соседка будет дома.")])]
        if not week4_unresolved("lera", True) and not week4_plan_short:
            $ week4_lera_offers.append(("music", "Поедим в семь? И потом хочу у тебя музыку послушать, если можно.", [("Лера", "Давай. Сначала в пельменной у меня рядом, потом ко мне. Соседку предупрежу.")]))
        $ week4_lera_offers.append(("talk", "В четверг встречу не обещаю. Но поболтать сейчас рад.", [("Лера", "Ладно. Тогда без договорённости.")]))
        call week4_chat("lera", "invite", [("Лера", "Мне за субботу оплатили половину. Вторую половину, видимо, тоже надо отыграть."), ("Лера", "Хочу в четверг просто поесть. Это пока не оплачивается, поэтому должно получиться.")], week4_lera_offers)
        if _return in ("yes", "music"):
            if _return == "music":
                $ week4_event("lera", "home_music_agreed", "После ужина вместе слушаем музыку у Леры")
            $ week4_book("lera", week4_plan_short or bool(week4_unresolved("lera", True)))
        return
    call week4_invite("lera", [("Лера", "Мне за субботу оплатили половину. Вторую половину, видимо, тоже надо отыграть."), ("Лера", "Хочу в четверг просто поесть. Это пока не оплачивается, поэтому должно получиться.")], "Поедим. В семь где тебе удобно?", "У меня рядом с домом есть пельмени. Скину точку. Потом, если захотим, ко мне. Соседка будет дома.")
    return

label week4_contact_varya:
    if week4_entry["tasks"].get("pdf") in ("pending", "deferred"):
        "Перед тем как писать Варе, Олег открывает её файл. На страницах двенадцать–тринадцать задерживается дольше остальных."
        call screen phone_thread([("Варя", "photo:varya_zine")], caption="Варя", past=week4_history.get("varya", [])[-2:])
        $ week4_event("varya", "zine_read")
        $ week4_relations["varya"]["issues"] = [dict(item, status="resolved") if item["cause"] == "unread_zine" else item for item in week4_relations["varya"]["issues"]]
    call week4_invite("varya", [("Варя", "Я тут одному человеку зин показала."), ("Варя", "Он написал «прикольно». Это вообще что значит?")], "Не знаю без самого человека. Давай в четверг покажешь? В семь, у печати.", "Давай. Я за новыми пробами как раз. Но не начинай сразу своим взрослым голосом.")
    return

label week4_cancel_plan(reason):
    $ week4_current = week4_plan
    call week4_chat(week4_current, "cancel", [], [("plain", "Я сам взял работу на четверг. Не успею приехать, хотя уже договорились. Прости.", [(week4_names[week4_current], "Ну вот. Я этот вечер уже освободила. Сегодня новый день выбирать не хочу.")]), ("hide", "Всё навалилось. В четверг никак.", [(week4_names[week4_current], "Понятно. Только это ты меня звал.")])])
    $ week4_open_issue(week4_current, "broken_plan", reason)
    $ week4_plan_status = "cancelled"
    return

label week4_marta_monday:
    if week4_work["report"] == "late" or week4_clock > 1110:
        call week4_chat("marta", "coffee_late", [("Марта", "Что у нас с кофе сегодня?")], [("move", "Я не успеваю. Сам набрал дел. Можно другой день? Не хочу, чтобы ты ждала.", [("Марта", "Сегодня я уже собралась. Другой день сейчас не выберу. Напиши позже.")]), ("cancel", "Сегодня не приеду. Прости, что так поздно говорю.", [("Марта", "Жаль. Я под это планы поменяла.")])])
        $ week4_open_issue("marta", "broken_plan", "Кофе в понедельник")
        $ week4_event("marta", "coffee_cancelled")
        return
    $ week4_stamp("Книжный на Ваське", 1110)
    scene bg ch4 lobby with fade
    "Они договорились взять кофе в книжном, где познакомились. До Марты Олег успевает стряхнуть зонт у входа и заказать себе чашку."
    scene bg ch4 bookshop with dissolve
    m "Здесь сегодня тихо. Давай у книжной стойки, там свет хороший."
    o "Мне подходит. Сегодня от слова «ход» немного дёргается глаз."
    m "Работа?"
    o "Да. В пятницу ошибся, сегодня разгребаем. А ты как?"
    m "Жду ответ про площадку. Хочу там вечером рисунки повесить. Мне сегодня должно прийти подтверждение."
    o "Они обещали?"
    m "Нет, но всё как-то складывается. Я сегодня даже автобус свой поймала."
    "Телефон на столе загорается. Марта читает и переворачивает его."
    m "Занято у них. До декабря."
    menu:
        "Блин. Ты давно это готовила?":
            m "Эскизы с августа. Но, наверное, меня туда и не надо было. Может, там что-нибудь сломается."
            o "Не знаю, что у них сломается. Рисунки жалко откладывать. Покажешь?"
            m "Да. Только это ещё не всё."
            m "Помнишь эти карточки? Я хочу рисунки отдельно напечатать, побольше. Не только за игровым столом показывать."
            scene bg ch4 gift with dissolve
            "Марта достаёт из папки ещё один экземпляр карточки. Олег берёт его за угол."
            o "Мне здесь на лавке посидеть хочется."
            m "Она в жизни шатается. На рисунке я её починила."
            "Олег возвращает карточку. Марта прячет её отдельно, под обложку."
            scene bg ch4 bookshop with dissolve
            $ week4_event("marta", "looked_at_work")
        "Ты же минуту назад говорила, что всё сложится.":
            m "Так оно и складывается. Просто я сначала не так поняла. От чего-то меня отвело."
            o "От чего?"
            m "Я откуда сейчас знаю? Не всё сразу становится понятно."
            "Марта придвигает к себе чашку обеими руками."
            $ week4_event("marta", "sign_disagreement")
    if week4_relations["marta"]["mode"] == "friendship":
        m "В следующий раз принесу бумажные. В телефоне цвет совсем другой."
    else:
        m "Спасибо, что приехал. Я после этого сообщения уже хотела свернуться."
    "У выхода она долго прячет папку под куртку. Олег держит дверь, пока застёгивается молния."
    $ week4_event("marta", "monday_coffee")
    $ week4_stamp("Дома", 1250)
    scene expression week4_home_bg() with fade
    return

label week4_friends(when):
    if when == "monday":
        call week4_optional_chat("friends", "monday", [("Саня", "Пробежал пять. На третьем хотел завернуть домой, но там работа."), ("Саша", "Я просто не выходил. Сэкономил на кроссовках.")], [("ask", "Сань, колено уже нормально? Ты же жаловался.", [("Саня", "Да, сбавил темп. Думал, позор, а оказалось — можно бежать и не ненавидеть всех."), ("Саша", "Про всех он приукрасил.")]), ("work", "Я сегодня сам себе пятничный привет на работе нашёл. Выходные были лучше.", [("Саня", "Бля. У меня тоже день, как будто выходных и не было."), ("Саша", "Поел хоть?")])])
        if _return == "work":
            o "Сейчас буду. Спасибо, мам."
            $ week4_history["friends"].append(("Олег", "Сейчас буду. Спасибо, мам."))
    else:
        $ week4_report_options = [("ask", "Саш, а ты как? Мы всё моё обсуждаем.", [("Саша", "Купил шторку в душ. На сорок сантиметров короче. Теперь у меня концептуальный мокрый пол."), ("Саня", "Покажи потом. Мне нужен повод не покупать свою.")]), ("work", "Рабочую дыру закрыли. Я четыре дня смотрел на одно слово «успешно».", [("Саня", "Ненавижу, когда работа проникает в матерный словарь."), ("Саша", "Выключай ноут. Завтра слово никуда не денется.")])]
        $ week4_current_fragment = week4_friend_fragment()
        if week4_current_fragment:
            $ week4_report_options.insert(0, ("date", week4_current_fragment[1], week4_current_fragment[2]))
        call week4_optional_chat("friends", "thursday", [("Саша", "Ты домой добрался?")], week4_report_options, completion=dict(person=week4_evening, fragment=week4_current_fragment[0]) if week4_current_fragment else None)
        if _return == "date":
            $ week4_relations[week4_evening]["facts"]["friends_fragment"] = week4_current_fragment[0]
    return
