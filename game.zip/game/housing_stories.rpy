# A lived-in home keeps its own history. No new defect or visit is inferred in old saves.
init python:
    def housing_story_kind():
        if week6_home.get("kind") == "hotel":
            return ""
        if week6_housing.get("move_due") and not week6_housing.get("moved"):
            return ""
        if week6_home.get("kind") in ("month", "whole"):
            return week6_home["kind"]
        return week6_home.get("actual_home") or week6_entry.get("home", {}).get("actual_home") or week5_entry.get("housing_home") or "quiet"

    def housing_story():
        # Accessing a hotel must not resurrect the previous apartment's story.
        if not housing_story_kind():
            return {}
        return week6_home.setdefault("story", dict(candidate=housing_story_kind(), events=[], told=[]))

    def housing_story_note(event, detail=""):
        story = housing_story()
        if not story:
            return
        story.setdefault("events", []).append(dict(event=event, detail=detail, day=week6_day, time=week6_clock))
        week6_event("housing_" + event, detail, "")

    def housing_story_guest_allowed():
        story = week6_home.get("story", {})
        return not story.get("owner_present")

    def housing_story_report():
        if week6_home.get("left_home"):
            return "Из квартиры съехал обратно в отель. Ключи сдал, расчёт ещё не закрыт. Искать сегодня не стал."
        story = week6_home.get("story", {})
        if not story.get("incident"):
            return "Ключи получил, сегодня вещи перевёз. Пока разбираюсь, как здесь жить." if week6_housing.get("moved") else "Пока остаюсь у себя. На выходных наконец вещи разобрал."
        if story.get("candidate") == "month" and not story.get("owner_present"):
            return "Хозяин хотел приехать на несколько ночей. Перенёс: попросил сначала согласовывать, а не просто сообщать. Пока остаюсь."
        return {
            "month":"Хозяин опять приезжал. Маленькая комната его, а чайник и кухня у нас оказались одни на двоих.",
            "whole":"Хозяин хотел снова оставить вещи. В этот раз договорились, что хранить их дальше он будет у себя.",
            "studio":"С общей машинкой разобрался. А сушилка у меня теперь занимает почти всю свободную комнату.",
            "central":"Чемодан на антресоль убрал. Ступени никуда не делись, зато в спальне наконец нормальный рабочий стол.",
            "modern":"В новом доме уже вечером окно открыл. Закрываешь — тише. Открываешь — снова вентиляция напротив.",
            "quiet":"Дома хорошо. Но после вечера в городе ещё надо добраться до этого хорошо. Вот с этим разбираюсь."
        }.get(story.get("candidate"), "Пока остаюсь у себя.")

label housing_story_seed:
    if not housing_story_kind() or housing_story().get("seed"):
        return
    $ housing_story()["seed"] = True
    $ housing_story_type = housing_story_kind()
    if housing_story_type == "month":
        if week6_home.get("boxes_gone"):
            "На освободившейся полке лежит зарядка. Из маленькой комнаты хозяин забрал коробки, но свой ключ оставил у себя."
        else:
            "Чужие вещи в маленькой комнате так и стоят у стены. Олег закрывает дверь: из большой они хотя бы не видны."
        "В договоре есть дата конца месяца. На календаре до неё ещё несколько недель."
    elif housing_story_type == "whole":
        "Олег открывает маленькую комнату и ставит туда пустой чемодан. Теперь обе комнаты сняты им; проверять, не приедет ли кто-нибудь ночевать, не нужно."
    elif housing_story_type == "studio":
        "До ноутбука от плиты два шага. Олег успевает помешать яйца, пока загружается рабочая таблица."
        "Разложенный диван он складывает уже после завтрака. Овощи на ужин достал из морозилки ещё вчера."
    elif housing_story_type == "central":
        "Чемодан стоит у края ступеней. За последние дни Олег трижды переставлял его, когда приходили с доставкой."
        "В спальне стол уже собран. Работать за ним приятно; чемодан из кресла на созвоне не виден."
    elif housing_story_type == "modern":
        if week6_day == 7 and week6_housing.get("moved"):
            "Олег закрывает окно и ставит на стол кружку. Вентиляторы за стеклом продолжают крутиться."
        else:
            "Олег закрывает окно перед первым созвоном. За стеклом продолжают крутиться вентиляторы; на столе перестаёт дрожать край бумажки."
    elif housing_story_type == "quiet":
        "Утром в кухне слышно, как щёлкает чайник. Олег садится с чашкой у окна и не открывает ноутбук ещё десять минут."
        "Вечером он смотрит маршрут к Лиговскому. Те самые сорок минут никуда не делись."
    $ housing_story_note("first_week", housing_story_type)
    return

label housing_story_incident:
    if not housing_story_kind() or housing_story().get("incident"):
        return
    # Mid-week saves enter here without inventing Monday's conversation.
    $ housing_story()["incident"] = True
    $ housing_story_type = housing_story_kind()
    if housing_story_type == "month":
        call week6_chat("owner", "home_arrival", [("Хозяин", "Сегодня приеду до понедельника. Часов в девять буду. В маленькой комнате постелю себе.")], [
            ("allow", "Хорошо. Только я работаю из дома, утром мне нужна кухня без разговоров рядом.", [("Хозяин", "Да я тихо. Мне только чайник иногда.")]),
            ("later", "Сегодня не хочу. Мы договаривались согласовывать приезды, а не просто сообщать. Можете в понедельник?", [("Хозяин", "Я рассчитывал уже сегодня. Ладно, переночую у брата. В понедельник тогда отдельно согласуем.")]),
            ("leave", "Я так весь месяц не хочу. Давайте я в воскресенье вывезу вещи. Как рассчитаемся?", [("Хозяин", "Сам этот месяц предлагал. Досрочно деньги сейчас не обещаю. Ключи в воскресенье заберу, по остатку отдельно посчитаем.")])])
        $ housing_story()["answer"] = _return
        if _return == "allow":
            $ housing_story()["arrival_due"] = True
        elif _return == "leave":
            call housing_story_notice
        else:
            "Олег перечитывает «в понедельник». Пока это просьба на будущую неделю, не согласованная ночёвка."
            $ housing_story()["next"] = "owner_monday_request"
    elif housing_story_type == "whole":
        call week6_chat("owner", "home_storage", [("Хозяин", "Я в городе сегодня. Можно до следующей недели сумку у вас оставлю? И маленькой комнатой на пару часов воспользуюсь.")], [
            ("door", "Сумку до воскресенья у двери могу оставить. Комнату я уже занял, её не дам.", [("Хозяин", "Ладно, только сумку. Вечером позвоню, без вас заходить не буду.")]),
            ("no", "Нет, я целиком снял. У меня там вещи и работа. Давайте больше ничего на хранение.", [("Хозяин", "Ясно. Тогда к брату отвезу.")]),
            ("leave", "Я не хочу каждый раз отбиваться от новых просьб. Буду съезжать. Давайте согласуем ключи и расчёт.", [("Хозяин", "А я думал, просто спросить можно. Хорошо, напишите, когда вещи вывезете.")])])
        $ housing_story()["answer"] = _return
        $ housing_story()["bag_due"] = _return == "door"
        if _return == "leave":
            call housing_story_notice
        else:
            "После сообщения Олег возвращается к работе. Маленькую комнату он не освобождает."
    elif housing_story_type == "studio":
        scene bg housing shared washer with dissolve
        if "washer" in housing_records.get("studio", {}).get("checks", []):
            "В расписании у общей машинки Олег находит своё время. Он ещё на просмотре сфотографировал этот листок."
        else:
            "Олег впервые спускает пакет к машинке в общей прихожей. На три студии здесь одна машинка; на дверце висит листок с часами."
        "В его строке поверх имени написано другое. Из соседней студии отвечают через дверь: «Я до шести думала. Она ещё полтора часа будет»."
        menu:
            "Тогда в воскресенье постираю. Сейчас запишусь, чтобы опять не заняли.":
                "Олег оставляет пакет у себя. На новом листке записывается на воскресное утро и просит соседку в следующий раз сначала спросить. Из-за двери отвечают: «Да, извини»."
                $ housing_story()["answer"] = "schedule"
            "Отнесу в прачечную. Сегодня не хочу ждать машинку.":
                "Олег находит приём белья у остановки. Сдаёт пакет, сохраняет квитанцию: забрать в субботу до обеда. Это отдельный расход, зато сушилка дома пока не нужна."
                $ housing_story()["answer"] = "service"
            "Не хочу вокруг этого строить быт. Начну съезжать.":
                call housing_story_notice
    elif housing_story_type == "central":
        scene expression city_background("images/housing/central-evening-v2.webp") with dissolve
        "Утром курьер просит помочь донести коробку со стулом. На третьем этаже Олег уже держит её снизу, курьер — сверху."
        "В прихожей коробка застревает на повороте у ступеней. Приходится вернуть её на площадку и распаковать там."
        scene expression home_keepsake_background(week6_home_path()) with dissolve
        "В спальне стул встаёт ровно к столу."
        menu:
            "Уберу чемодан наверх. Хочу здесь устроиться.":
                scene bg housing central loft with dissolve
                "Олег достаёт вещи, отдельно поднимает пустой чемодан по лестнице на антресоль. С тяжёлым он бы туда не полез."
                scene expression city_background("images/housing/central-evening-v2.webp") with dissolve
                "У оставшегося кресла появляется свободный проход. Ступени обходить всё равно придётся."
                $ housing_story()["answer"] = "settle"
            "В спальне хорошо, но таскать всё так я устал. Буду съезжать.":
                call housing_story_notice
    elif housing_story_type == "modern":
        "В комнате душно. Олег приоткрывает окно, и с улицы входит тот же низкий гул. Он закрывает створку, потом открывает снова."
        if housing_records.get("modern", {}).get("checks") or week6_housing.get("checked"):
            "На просмотре этот звук тоже был. Олег тогда больше смотрел на стол и ремонт. Теперь надо ещё как-то здесь спать."
        menu:
            "Проверю приток и настрою температуру. Сам дом мне нравится.":
                "Олег уменьшает нагрев и включает приток на панели. Кнопки доступны ему; менять настройки за хозяина по телефону не нужно."
                "Пока комната проветривается, он ставит чайник. С закрытым окном снова тихо. Ночью ещё придётся попробовать этот режим."
                $ housing_story()["answer"] = "climate_trial"
                $ housing_story()["next"] = "night_climate_trial"
            "Я хочу открывать окно. Эту квартиру оставлю.":
                call housing_story_notice
    elif housing_story_type == "quiet":
        "Доставка стоит у двери. Олег убирает продукты, потом замечает время: если сейчас ехать к Лиговскому, обратно придётся возвращаться почти сразу."
        "Он разувается и включает чайник. На столе есть где поставить тарелку; всё равно бесит, что опять никуда не выбрался."
        menu:
            "Попробую звать и сюда. Не только ездить к чужим дверям.":
                "Олег фотографирует свободную кухню. Пока никому не отправляет: сначала спросит, хочет ли человек приехать."
                $ housing_story()["answer"] = "invite_here"
            "Дом мне нравится. На встречи буду выезжать раньше.":
                "Он сохраняет путь до остановки. Позднее такси тоже придётся учитывать, если захочет остаться в городе."
                $ housing_story()["answer"] = "travel"
            "Мне сейчас важнее быть ближе к людям. Буду съезжать.":
                call housing_story_notice
    scene expression home_keepsake_background(week6_home_path(week6_clock >= 1080)) with dissolve
    $ housing_story_note("incident", housing_story().get("answer", ""))
    call housing_story_share
    return

label housing_story_notice:
    if housing_story_kind() == "month" and housing_story().get("owner_present"):
        call week6_chat("owner", "home_month_exit", [], [("notice", "Я сегодня всё-таки вывезу вещи. Не хочу дальше жить с общими приездами. Вы здесь, ключи вам передам. Пришлите потом расчёт.", [("Хозяин", "Хорошо. Только за остаток месяца сейчас не обещаю вернуть. Сначала посчитаю.")])])
    elif housing_story_kind() != "month" and week6_day >= 7:
        call week6_chat("owner", "home_late_exit", [], [("notice", "Я всё-таки не хочу здесь оставаться. Сегодня вывезу вещи в гостиницу. Как передать ключи и закрыть расчёт?", [("Хозяин", "Вечером подъеду принять. Расчёт отдельно пришлю, в договоре месяц предупреждения. Залог пока не возвращаю.")])])
    elif housing_story_kind() != "month":
        call week6_chat("owner", "home_notice", [], [("notice", "Хочу прекратить аренду. В воскресенье утром вещи вывезу. Пришлите расчёт и напишите, когда примете ключи.", [("Хозяин", "Вывезти можете. В договоре предупреждение за месяц, по деньгам сначала посчитаю. В воскресенье в восемь ключи заберу.")])])
    "Олег просит расчёт письменно. Возвращённые ключи сами по себе не вернут залог и не отменят оплату оставшегося срока."
    call week6_chat("agent", "hotel_pause", [], [("pause", "Я пока возвращаюсь в гостиницу. Новые просмотры на эти выходные не назначайте.", [("Агент", "Понял. Тогда напишите сами, когда вернётесь к поиску.")])])
    $ housing_story().update(answer="leave", move_out="now" if week6_day >= 7 else "sunday08", settlement="requested", next="settlement_and_search")
    $ week6_home["search"] = False
    $ housing_story_note("notice", housing_story_kind())
    return

label housing_story_share:
    $ housing_story_options = [("Пока сам разберусь. Не хочу сейчас переписываться.", "alone")]
    python:
        for p, name in [("nika", "Нике"), ("lera", "Лере"), ("asya", "Асе"), ("marta", "Марте")]:
            if week6_known(p):
                housing_story_options.append(("Расскажу " + name + ", что у меня с домом.", p))
    call screen chapter3_intentions("Телефон лежит рядом", housing_story_options)
    $ housing_story_person = _return
    if housing_story_person == "alone":
        return
    $ housing_story_message = {
        "month":"Хозяин сообщил, что приезжает ночевать. Маленькая комната по договору его, но я уже отвык делить с ним кухню.",
        "whole":"Хозяин хотел снова воспользоваться маленькой комнатой. Я её не отдал: теперь целиком снимаю.",
        "studio":"Стирать пошёл, а моё время в общей машинке заняли. В комнате потом ещё бельё надо где-то сушить.",
        "central":"Стул доставили. На третий этаж подняли, а в прихожую коробка не пролезла. Зато сейчас за нормальным столом сижу.",
        "modern":"Окно открыл и опять слушаю вентиляцию напротив. Внутри дом нравится, а с этим звуком пока не понимаю.",
        "quiet":"Дома тихо, кухня хорошая. А на вечер в город собрался и понял, что половину его опять в дороге проведу."
    }[housing_story_kind()]
    if housing_story().get("answer") == "leave":
        $ housing_story_message += " Сегодня возвращаюсь в отель. По деньгам с хозяином ещё не закончили." if week6_day >= 7 else " В воскресенье утром возвращаюсь в отель. По деньгам с хозяином ещё не закончили."
    elif housing_story_kind() == "month":
        $ housing_story_message += " Сегодня приедет, до понедельника." if housing_story().get("arrival_due") else " Сегодня не приедет. Попросил согласовать другой день."
    $ housing_story_reply = {
        "nika":"А тебе самому там ещё нравится? Не про него, про квартиру спрашиваю.",
        "lera":"Я когда коробку у него забирала, тоже думала: ну всё, последний раз. У тебя хоть своё теперь помещается?" if housing_story_kind() in ("month", "whole") else "Блин. А я как раз хотела, чтобы ты мне свой угол показал. Только не вместо твоего отдыха.",
        "asya":"А ты бы там остался, если бы сейчас никого не надо было звать в гости? Мне правда интересно.",
        "marta":"Я сначала хотела сказать, что дом тебя проверяет. Потом представила ещё один переезд. Не буду. Что сам хочешь?"
    }[housing_story_person]
    $ housing_story_companion = week6_housing.get("discussed_with") or housing_records.get(housing_story_kind(), {}).get("companion")
    if housing_story_companion == housing_story_person:
        if housing_story_person == "lera" and housing_story_kind() == "central":
            $ housing_story_reply = "Я тогда из-за спальни эти ступени простила бы. Но это ты туда стул тащил, не я. Тебе всё ещё нравится?"
        elif housing_story_person == "nika":
            $ housing_story_reply = "Мы тогда днём послушали и ушли. А ты уже пожил. Вечером как тебе там?"
        elif housing_story_person == "asya":
            $ housing_story_reply = "Я на просмотре на свет смотрела. А ты на проходы. Теперь понимаю, зачем. Сам что думаешь?"
    if week6_careful(housing_story_person):
        $ housing_story_reply = "Поняла. Про квартиру можешь рассказать, но приезжать к тебе сейчас я не готова."
    $ housing_story_plain = "Съеду и неделю про квартиры думать не буду. Хотя бы попробую." if housing_story().get("answer") == "leave" else "Пока поживу, посмотрю. Хотел тебе рассказать, а то с утра это в голове."
    $ housing_story_replies = [
        ("plain", housing_story_plain, [(week4_names[housing_story_person], {"nika":"Ладно. Я ещё на записи. Напиши потом, как у тебя.", "lera":"Давай. Я сейчас на площадку бегу, вечером дочитаю.", "asya":"Расскажи потом. Мне интересно, какое у тебя место получится.", "marta":"Напиши, когда разберёшься. Я до вечера за рисунками."}[housing_story_person])]),
        ("company", "Хочу потом тебе показать, как живу. Когда сам устроюсь, позову на чай.", [(week4_names[housing_story_person], {"nika":"Я бы зашла. Только не обещай сейчас день, сначала у себя разберись.", "lera":"Хочу посмотреть. Потом выберем день, я пока сама в разъездах.", "asya":"Давай потом. Я тоже хочу просто в гости, без осмотра с агентом.", "marta":"Чай хочу. Потом спроси ещё раз, когда уже будешь знать где."}[housing_story_person])])]
    if week6_careful(housing_story_person):
        $ housing_story_replies = [("plain", "Понял. Сейчас просто рассказал, как у меня дела. Про встречи не прошу забыть прошлый раз.", [(week4_names[housing_story_person], "Хорошо. Про квартиру потом расскажи.")])]
    if housing_story_kind() == "quiet" and housing_story().get("answer") == "invite_here" and not week6_careful(housing_story_person):
        $ housing_story_replies.append(("invite", "Хочешь во вторник в семь ко мне на ужин? Я приготовлю. Это на Ваське, от Лиговского около сорока минут с пересадкой. Точку сейчас пришлю.", [(week4_names[housing_story_person], {"nika":"Хочу. Во вторник могу. Только без большой готовки ради меня. Скинь точку.", "lera":"Давай! Во вторник в семь. Я после работы тогда сразу к тебе, без заезда домой.", "asya":"Приеду. Я как раз во вторник без вечернего. Только напиши, от какой остановки идти.", "marta":"Да. Во вторник в семь. Жду точку, сама доберусь."}[housing_story_person]), ("Олег", "Отправил точку у подъезда и путь от остановки.")]))
    call week6_chat(housing_story_person, "housing_story", [("Олег", housing_story_message), (week4_names[housing_story_person], housing_story_reply)], housing_story_replies)
    $ housing_story()["told"].append(housing_story_person)
    $ housing_story()["shared"] = _return
    if _return == "invite":
        $ housing_story()["dinner"] = dict(person=housing_story_person, day="chapter7_tuesday", time="19:00", agreed=True, played=False)
        $ week6_relations[housing_story_person].setdefault("promises", []).append("Ужин у Олега во вторник после шестой главы, 19:00")
        $ week6_relations[housing_story_person].setdefault("facts", {})["housing_dinner"] = copy.deepcopy(housing_story()["dinner"])
        $ week6_event("housing_dinner_agreed", "Следующий вторник, 19:00; визит не ночёвка", housing_story_person)
    $ week6_event("housing_shared", housing_story_kind(), housing_story_person)
    return

label housing_story_evening:
    if not housing_story_kind():
        return
    if housing_story().get("arrival_due") and not housing_story().get("owner_present"):
        $ week6_stamp("Дома · приезд хозяина", max(week6_clock, 1300))
        scene expression home_keepsake_background(week6_home_path(True)) with fade
        "У двери стоит чужая спортивная сумка. Хозяин уже позвонил, пока Олег поднимался, и теперь ждёт у порога."
        "Олег открывает. Хозяин проходит в маленькую комнату, возвращается за чайником. Пока вода греется, спрашивает, куда делась его большая кружка."
        o "В шкафу слева. Я свои спереди поставил."
        "Ночью через дверь слышно видео с телефона. Олег стучит и просит наушники. Звук выключается, но заснуть сразу уже не выходит."
        $ housing_story().update(owner_present=True, arrival_due=False)
        $ housing_story_note("owner_arrived", "До понедельника; кухня общая")
    elif housing_story().get("bag_due") and not housing_story().get("bag_delivered"):
        $ week6_stamp("Дома · сумка у двери", max(week6_clock, 1300))
        scene expression home_keepsake_background(week6_home_path(True)) with fade
        "Хозяин звонит снизу. Олег принимает сумку у двери и повторяет: до воскресенья. В комнаты тот не проходит."
        $ housing_story()["bag_delivered"] = True
        $ housing_story()["bag_due"] = False
        $ housing_story_note("bag_delivered", "Без доступа к комнатам")
    return

label housing_story_sunday:
    if not housing_story_kind():
        return
    if housing_story().get("move_out") in ("sunday08", "now"):
        $ housing_move_now = housing_story().get("move_out") == "now"
        if not housing_move_now:
            "К восьми чемодан собран. Олег ещё раз осматривает ванную и кухню: забыть зарядку он успел бы и за полчаса."
        else:
            "Олег достаёт чемодан и складывает вещи обратно. Перед машиной ещё придётся передать ключи хозяину."
        "Он фотографирует пустые полки, счётчики и ключи, которые передаёт хозяину. Тот подтверждает получение сообщением; расчёт остаётся открытым."
        $ housing_story_note("keys_returned", housing_story_kind())
        $ housing_left_record = copy.deepcopy(week6_home)
        $ week6_home.clear()
        $ week6_home.update(kind="hotel", hotel="same", keys_due="", left_home=housing_left_record, search=False, paid_until="chapter7_sunday")
        $ housing_home = ""
        $ housing_pending = ""
        $ week6_housing["returned_to_hotel"] = True
        $ week6_housing["moved"] = False
        $ week6_housing.pop("move_due", None)
        $ week6_stamp("Гостиница · снова с чемоданом", max(week6_clock + 50, 525), 7)
        scene expression home_keepsake_background(week6_home_path(week6_clock >= 1080)) with fade
        "На стойке есть свободный номер. Другой этаж, окно во двор. Олег оплачивает неделю и поднимается с картой в руке."
        "Чемодан снова стоит у гостиничного стола. Он достаёт зарядку и чистую футболку; фотографии для расчёта оставляет в телефоне."
        $ week6_event("returned_to_hotel", housing_left_record.get("story", {}).get("candidate", ""), "")
        return
    if housing_story().get("resolved"):
        return
    if not housing_story().get("incident"):
        return
    if housing_story_kind() == "month" and housing_story().get("owner_present"):
        "В кухне хозяин разговаривает по телефону. Олег ждёт, пока тот отойдёт от плиты, чтобы добраться до своей сковородки."
        menu:
            "На этом хватит. Сегодня перевезу вещи в отель.":
                call housing_story_notice
                jump housing_story_sunday
            "Доживу этот месяц. Продлевать с такими приездами не хочу.":
                o "После этой поездки я месяц доживу, но продлевать не буду. Дальше мне нужно своё жильё."
                "Хозяин спрашивает дату ещё раз и записывает её. Сегодня он всё ещё здесь; Олег уносит завтрак в свою комнату."
                $ housing_story().update(answer="finish_month", next="month_end_search")
    elif housing_story_kind() == "whole" and housing_story().get("bag_delivered"):
        "Хозяин забирает сумку у двери. Олег не предлагает оставить её ещё на неделю. Когда шаги стихают, ставит на освободившееся место свои ботинки."
        $ housing_story()["bag_delivered"] = False
    elif housing_story_kind() == "studio" and housing_story().get("answer") == "schedule":
        "Соседка освобождает машинку в записанное время. Олег запускает свою загрузку и возвращается на кухню. На этот раз ждать не пришлось."
        "Сушилку он ставит у окна. Со стулом теперь нужно протискиваться боком; стол остаётся на месте."
        $ housing_story()["next"] = "drying_space"
    elif housing_story_kind() == "central" and housing_story().get("answer") == "settle":
        scene expression city_background("images/housing/central-evening-v2.webp") with dissolve
        "Утром Олег проходит к кухне с кружкой и не задевает чемодан. Наверху за перилами видна его ручка. Спускаться за ним придётся только перед поездкой."
        scene expression home_keepsake_background(week6_home_path()) with dissolve
        $ housing_story()["next"] = "lived_in"
    elif housing_story_kind() == "quiet":
        "Перед выходом он проверяет, что взял обе перчатки. Возвращаться от остановки за забытой вещью не хочется. На обратный путь оставляет деньги на карте."
        $ housing_story()["next"] = "home_and_city"
    $ housing_story()["resolved"] = True
    $ housing_story_note("week_outcome", housing_story().get("answer", ""))
    return

label housing_story_saturday:
    if not housing_story_kind():
        return
    if housing_story_kind() == "studio" and housing_story().get("answer") == "service" and not housing_story().get("laundry_collected"):
        "До выхода Олег забирает бельё из прачечной. В пакете всё сухое, дома он сразу убирает футболки в шкаф. Квитанцию с суммой пока оставляет на столе."
        $ housing_story()["laundry_collected"] = True
        $ housing_story()["next"] = "paid_laundry_routine"
        $ housing_story_note("laundry_collected", "Сухое бельё, отдельный расход")
    return

label housing_story_date(person):
    $ housing_date_story = week6_home.get("left_home", {}).get("story", {}) if week6_home.get("left_home") else week6_home.get("story", {})
    if person not in housing_date_story.get("told", []) or housing_date_story.get("date_followup"):
        return
    $ housing_date_story["date_followup"] = person
    if housing_date_story.get("dinner", {}).get("person") == person:
        o "На вторник всё в силе. Я продукты в понедельник возьму."
        if person == "nika":
            n "Помню. Не покупай гору, я просто поесть приду."
        elif person == "lera":
            l "Я к семи. Ты только если домофон не работает, заранее скажи."
        elif person == "asya":
            a "Да. Хочу твою кухню увидеть. Ты про неё так рассказывал."
        else:
            m "Я записала. В этот раз без внезапного появления у подъезда."
        $ week6_event("housing_date_followup", "Ужин во вторник остаётся", person)
        return
    if week6_home.get("left_home"):
        o "Я уже в гостинице. Другой номер дали. Расчёт с хозяином пока жду."
    elif housing_date_story.get("move_out"):
        o "Завтра утром вещи вывезу. Номер в гостинице ещё надо взять."
    elif housing_date_story.get("owner_present"):
        o "Хозяин приехал. Вчера ночью ещё видео слушал, я просил выключить. До понедельника он там."
    else:
        o "С квартирой пока остаюсь. Хочу ещё пожить, а не после каждой неприятности коробки собирать."
    if week6_careful(person):
        "Она кивает. Про гостей разговор не продолжается; сегодняшняя встреча остаётся короткой, как договорились."
    elif person == "nika":
        n "Когда будешь сам знать, где у тебя что лежит, покажешь. Я хочу и твою гитару нормально послушать."
    elif person == "lera":
        l "Я свои коробки после переезда две недели не разбирала. Контроллер достала, остальное пусть живёт."
        o "А сейчас?"
        l "Одну так и не разобрала. Не спрашивай."
    elif person == "asya":
        if housing_date_story.get("candidate") == "central":
            a "Я бы из-за ступеней не съехала. Но я там не живу. Тебе после работы ещё за хлебом с них спускаться."
            o "Вот. А потом ещё обратно."
        else:
            a "Я бы после переезда ещё неделю коробки видеть не хотела. Но если там плохо, что делать."
            o "Да. Мне пока от одной мысли про чемодан уже тяжело."
    else:
        if week6_entry.get("marta", {}).get("home_clue") == "bakery_pin":
            m "Точку старую тогда не открываю. Если захочешь позвать, сам новую пришли."
        else:
            m "Если захочешь позвать, сам точку пришли. Я твой дом по воронам не найду."
        o "Хорошо. Пока встречаемся здесь."
    $ week6_event("housing_date_followup", housing_date_story.get("candidate", ""), person)
    return

label housing_story_first_night:
    if housing_story_kind() != "modern" or housing_story().get("incident"):
        return
    # The new flat was actually occupied this morning: this is its beginning, not an invented week.
    call housing_story_seed
    call housing_story_incident
    if housing_story().get("move_out") == "now":
        call housing_story_sunday
    return
