# Each insert has a different verb: pack/balance, recall, trace.
init -11 python:
    vignette_riff_phrases = ((0, 1, 0, 0), (1, 0, 1, 1, 0, 1))
    vignette_laundry_weights = (3, 4, 3, 5, 4, 1, 1, 1, 2, 3)
    vignette_laundry_types = ("shirt",) * 5 + ("sock",) * 3 + ("underwear", "boxers")
    vignette_laundry_count = len(vignette_laundry_types)
    vignette_laundry_limits = (17, 15)
    vignette_laundry_columns = 17
    vignette_laundry_cell_size = 36
    vignette_shadow_paths = (
        ("ВОЛНА", ((160, 335), (235, 310), (300, 230), (365, 205), (425, 275), (480, 325), (550, 300), (630, 220), (705, 210), (790, 275))),
        ("РЫБА", ((730, 295), (650, 230), (540, 185), (420, 195), (310, 255), (205, 205), (230, 295), (205, 385), (310, 335), (420, 390), (540, 400), (650, 355), (730, 295))),
        ("ЛАДОНЬ", ((355, 460), (345, 365), (285, 285), (280, 260), (295, 248), (315, 265), (360, 310), (330, 185), (338, 165), (355, 165), (370, 185), (395, 280), (390, 125), (405, 112), (420, 125), (430, 275), (450, 145), (468, 138), (480, 155), (470, 290), (505, 205), (525, 198), (538, 215), (500, 355), (485, 460))),
    )

    def vignette_best(kind):
        return persistent.vignette_records_v2.get(vignette_score_key(kind), 0)

    def vignette_score_key(kind):
        # Scores from different rules are kept, but never compared.
        if kind == "laundry":
            return "laundry_mixed_v6"
        return kind + "_distinct" if kind in ("laundry", "riff", "shadow") else kind

    def vignette_laundry_width(s, item):
        if vignette_laundry_types[item] == "sock":
            return 1
        if vignette_laundry_types[item] == "underwear":
            return 2
        if vignette_laundry_types[item] == "boxers":
            return 3
        return 2 if s["folded"][item] else 3

    def vignette_laundry_asset(s, item):
        kind = vignette_laundry_types[item]
        if kind == "shirt":
            return "shirt-folded-berserk-no-text" if s["folded"][item] else "shirt-open-berserk-no-text"
        return "sock-v1" if kind == "sock" else "boxers-plaid-v1" if kind == "boxers" else "underwear-v1"

    def vignette_laundry_position(s, item):
        place = s["places"].get(item)
        return (35 + place[1] * vignette_laundry_cell_size, 14 + place[0] * 180) if place else (18 + item * 92, 430)

    def vignette_laundry_problem(s, item, row, col):
        width = vignette_laundry_width(s, item)
        if row not in (0, 1) or col < 0 or col + width > vignette_laundry_limits[row]:
            return "Не хватает места у края. Выбери свободное место левее."
        for other, (r, c) in s["places"].items():
            if other == item or r != row:
                continue
            other_width = vignette_laundry_width(s, other)
            if col < c + other_width and c < col + width:
                return "Здесь уже вещь №%d. Выбери свободные клетки." % (other + 1)
            # One empty cell between wet sleeves, not just non-overlap.
            if not (col + width < c or c + other_width < col):
                gap = c - 1 if col + width == c else c + other_width
                return "Оставь клетку %d пустой рядом с вещью №%d — для воздуха." % (gap + 1, other + 1)
        return ""

    def vignette_laundry_can(s, item, row, col):
        return not vignette_laundry_problem(s, item, row, col)

    def vignette_laundry_focus(s):
        item = s["selected"]
        place = s["places"].get(item)
        if place:
            s["cursor"] = place[0] * vignette_laundry_columns + place[1]
        else:
            row, col = divmod(s["cursor"], vignette_laundry_columns)
            if not vignette_laundry_can(s, item, row, col):
                for r in range(2):
                    for c in range(vignette_laundry_limits[r]):
                        if vignette_laundry_can(s, item, r, c):
                            s["cursor"] = r * vignette_laundry_columns + c
                            return

    def vignette_laundry_cell(s, row, col):
        for item, (r, c) in s["places"].items():
            if r == row and c <= col < c + vignette_laundry_width(s, item):
                return "shirt"
        for item, (r, c) in s["places"].items():
            if r == row and col in (c - 1, c + vignette_laundry_width(s, item)):
                return "air"
        return "free"

    def vignette_laundry_balance(s):
        # The neighbour's towels occupy the right, so our wet clothes counter it.
        moment = 52.0
        for item, (row, col) in s["places"].items():
            centre = 35 + (col + vignette_laundry_width(s, item) / 2.0) * vignette_laundry_cell_size
            moment += vignette_laundry_weights[item] * (centre - 480) / 80.0
        return moment

    def vignette_laundry_score(s):
        points = len(s["places"]) * 200
        if len(s["places"]) == vignette_laundry_count:
            # Every stable layout earns full points, regardless of folding.
            points += max(0, round(600 - max(0, abs(vignette_laundry_balance(s)) - 3) * 40))
        return points

    def vignette_laundry_action(s, command, value):
        old_score = s["score"]
        if command == "laundry_select":
            s["selected"] = value
            vignette_laundry_focus(s)
        elif command == "laundry_cursor":
            row, col = divmod(s["cursor"], vignette_laundry_columns)
            row = max(0, min(1, row + value[1]))
            col = max(0, min(vignette_laundry_limits[row] - 1, col + value[0]))
            s["cursor"] = row * vignette_laundry_columns + col
        elif command == "fold":
            item = s["selected"]
            if vignette_laundry_types[item] != "shirt":
                s["note"] = "Мелочь уже компактная. Можно сразу вешать."
                return s
            s["folded"][item] = not s["folded"][item]
            place = s["places"].get(item)
            if place and not vignette_laundry_can(s, item, *place):
                s["folded"][item] = not s["folded"][item]
                s["note"] = "Для расправленной нужно три клетки. Сначала перенеси футболку."
            else:
                s["note"] = "Сложил вдвое: две клетки." if s["folded"][item] else "Расправил: три клетки."
            vignette_laundry_focus(s)
        elif command == "unhang":
            s["places"].pop(s["selected"] if value is None else value, None)
            s["note"] = "В корзину. Тут можно освободить место."
        elif command == "hang":
            item, row, col = value
            s["selected"] = item
            s["cursor"] = row * vignette_laundry_columns + col
            if vignette_laundry_can(s, item, row, col):
                s["places"][item] = (row, col)
                s["moves"] += 1
                s["note"] = "Держится. Между вещами есть воздух."
                remaining = [i for i in range(vignette_laundry_count) if i not in s["places"]]
                if remaining:
                    s["selected"] = remaining[0]
                    vignette_laundry_focus(s)
            else:
                s["note"] = vignette_laundry_problem(s, item, row, col)
                s["bumps"] += 1
        elif command == "laundry_finish":
            balance = abs(vignette_laundry_balance(s))
            if len(s["places"]) < vignette_laundry_count:
                s["note"] = "В корзине ещё остались вещи."
            elif balance > 10:
                s["note"] = "Перевешивает %s. Перенесу что-нибудь потяжелее %s." % (("вправо", "левее") if vignette_laundry_balance(s) > 0 else ("влево", "правее"))
            else:
                s["result"] = "smooth" if balance <= 3 else "funny"
        s["score"] = vignette_laundry_score(s)
        s["last_gain"] = max(0, s["score"] - old_score)
        s["feedback_id"] += 1
        return s

    def vignette_riff_action(s, command, value):
        phrase = vignette_riff_phrases[s["rounds"]]
        # A failed or repeated prefix must not display the previous award.
        s["last_gain"] = 0
        if command == "start":
            if s["riff_phase"] == "repeat":
                s["replays"] += 1
            s.update(riff_phase="listen", running=True, play_ticks=0, phrase_input=[])
            s["note"] = "Сначала послушай фразу целиком. Потом повтори в своём темпе."
        elif command == "pluck" and s["riff_phase"] == "repeat":
            index = len(s["phrase_input"])
            if value != phrase[index]:
                s["bumps"] += 1
                s["phrase_errors"] += 1
                s["combo"] = 0
                s["phrase_input"] = []
                s["note"] = "Другая нота. Попробуй с начала или послушай ещё раз."
            else:
                s["phrase_input"].append(value)
                if len(s["phrase_input"]) > s["prefix_best"]:
                    s["prefix_best"] = len(s["phrase_input"])
                    vignette_award(s, 100, True)
                s["note"] = "Да. А дальше?"
                if len(s["phrase_input"]) == len(phrase):
                    bonus = max(0, 500 - s["phrase_errors"] * 100 - s["replays"] * 50)
                    s["score"] += bonus
                    s["last_gain"] += bonus
                    s["rounds"] += 1
                    if s["rounds"] == len(vignette_riff_phrases):
                        s["result"] = "smooth" if s["bumps"] < 3 else "funny"
                    else:
                        s.update(riff_phase="ready", phrase_input=[], prefix_best=0, phrase_errors=0, replays=0)
                        s["note"] = ("Есть. Вторая фраза идёт в другом порядке. Послушай её." if s.get("context") in ("solo_recording", "solo_practice") else "Есть. Во второй фразе Ника поменяла порядок. Послушай её.")
        return s

    def vignette_riff_clock(s):
        if s["riff_phase"] == "listen":
            s["play_ticks"] += 1
            if s["play_ticks"] >= len(vignette_riff_phrases[s["rounds"]]) * 12 + 6:
                s.update(running=False, riff_phase="repeat")
                s["note"] = "Твоя очередь. Порядок важен; скорость нажатий — любая."
        return s

    def vignette_sample_path(points, spacing=12):
        sampled = []
        for a, b in zip(points, points[1:]):
            distance = vignette_math.hypot(b[0] - a[0], b[1] - a[1])
            steps = max(1, int(distance / spacing))
            sampled.extend((a[0] + (b[0] - a[0]) * i / steps, a[1] + (b[1] - a[1]) * i / steps) for i in range(steps))
        return sampled + list(points[-1:])

    def vignette_trace_quality(points, target):
        if len(points) < 2:
            return 0
        a, b = vignette_sample_path(points), vignette_sample_path(target)
        distance = lambda p, q: vignette_math.hypot(p[0] - q[0], p[1] - q[1])
        miss = sum(min(distance(p, q) for q in b) for p in a) / len(a)
        coverage = sum(min(distance(p, q) for q in a) for p in b) / len(b)
        length = lambda path: sum(distance(p, q) for p, q in zip(path, path[1:]))
        ratio = length(points) / max(1, length(target))
        ends = distance(points[0], target[0]) + distance(points[-1], target[-1])
        return max(0, min(100, round(100 - (miss + coverage) * .8 - abs(ratio - 1) * 35 - ends * .06)))

    def vignette_drop_laundry(drags, drop):
        drag = drags[0]
        item = int(drag.drag_name)
        row = int(round((drag.y - 14) / 180.0))
        col = int(round((drag.x - 35) / float(vignette_laundry_cell_size)))
        # Drag remembers its physical position even when a rejected move
        # leaves the saved layout unchanged. Always restore the logical origin;
        # an accepted placement gets its new coordinates from the next screen.
        drags[0].snap(*vignette_laundry_position(vignette_state, item), delay=0)
        if drop and drop.drag_name == "basket":
            renpy.end_interaction(("unhang", item))
        elif row in (0, 1) and 0 <= col < vignette_laundry_limits[row]:
            renpy.end_interaction(("hang", (item, row, col)))
        else:
            renpy.end_interaction(("laundry_select", item))
        return True
