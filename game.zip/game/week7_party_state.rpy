# Physical venue navigation and the public/private meaning of introductions.
default week7_public = {}
default week7_venue = {}

init python:
    def week7_party_guest():
        return "" if week7_party.get("guest_departed") else week7_guest

    def week7_close_history(person):
        r = week7_relations.get(person,{})
        return bool(week7_entry.get("dates",{}).get(person,{}).get("kiss") or r.get("facts",{}).get("kissed_chapter5"))

    def week7_can_agree_couple(person):
        # An invitation, costume pair, or kiss alone is never an agreement.
        return bool(person in ("nika","lera","asya","marta") and not week7_friend(person) and not week7_careful(person) and (week7_close_history(person) or week7_relations.get(person,{}).get("mode")=="interest"))

    def week7_public_record(person,label):
        week7_public[person] = dict(label=label,discussed=False,outcome="unspoken",couple_agreed=False,
            friendship_before=week7_friend(person),close_before=week7_close_history(person),
            couple_possible=week7_can_agree_couple(person),heard_by=["katya"],heard_label=label)
        week7_event("public_introduction",label,person)

    def week7_public_issue(person,cause,status="open"):
        issues=week7_relations[person].setdefault("issues",[])
        issue=next((x for x in issues if x.get("id")=="week7_public_introduction"),None)
        if issue is None:
            issues.append(dict(id="week7_public_introduction",cause=cause,status=status,chapter=7))
        elif status=="acknowledged":
            issue["status"]="acknowledged"
        week7_event("public_words_hurt",cause,person)

    def week7_expectation_result(person,outcome):
        info=week7_public[person]
        info.update(discussed=True,outcome=outcome,couple_agreed=outcome=="couple_agreed")
        # Keep existing friendship and all pre-existing issues. Mutual interest is explicit.
        if outcome in ("couple_agreed","dating_interest"):
            week7_relations[person]["mode"]="interest"
        elif outcome=="friendship_agreed":
            week7_relations[person]["mode"]="friendship"
        week7_relations[person].setdefault("facts",{})["chapter7_expectations"]=copy.deepcopy(info)
        week7_event("expectations_discussed",outcome,person)

    week7_venue_places = {
        "music":dict(title="Сцена",box=(738,42,235,126),duration=30,until=1275),
        "dance":dict(title="Танцпол",box=(355,202,335,148),duration=30,until=1350),
        "table":dict(title="Буфет",box=(160,42,360,105),duration=25,until=1350),
        "games":dict(title="Игровая",box=(70,473,275,141),duration=35,until=1350),
        "quiet":dict(title="Тихая комната",box=(725,473,275,141),duration=15,until=1350),
        "bluff":dict(title="Кости дьявола",duration=30,until=1350),
        "garden":dict(title="Тыквенный сад",duration=15,until=1350),
        "oracle":dict(title="Карты",duration=15,until=1350),
        "leave":dict(title="Прихожая",box=(395,538,250,82),duration=0,until=1350)
    }

    def week7_venue_prepare():
        # Colleague encounters can precede the map; don't treat that as a ready map.
        for key, value in (("visits",{}), ("route",[]), ("room","hall"), ("ending",False)):
            week7_venue.setdefault(key,value)
        week7_party.setdefault("activities",[])
        week7_party.setdefault("early",False)

    def week7_venue_title(key):
        visits=week7_venue.get("visits",{})
        if key=="games":
            return "Киноквиз" if week7_clock<1230 else "Две правды и ложь"
        if key=="bluff":return "Блеф и стаканчики"
        if key=="garden":return "Чай среди тыкв" if not visits.get(key) else "Ещё немного у стекла"
        if key=="oracle":return "Выбрать вопрос и карту"
        if key=="music":
            return "Сыграть с ребятами" if not visits.get(key) else "Послушать второй сет"
        if key=="dance":
            return "Танцы" if not visits.get(key) else "Ещё один трек"
        if key=="table":
            return "Еда и коллеги" if not visits.get(key) else "Чай у окна"
        if key=="quiet":
            p=week7_party_guest()
            return "Поговорить вдвоём" if p and not week7_public.get(p,{}).get("discussed") else "Немного тишины"
        return "На сегодня хватит"

    def week7_venue_location(key):
        # An activity and its physical room can have different names.
        return {"music":"Большой зал · сцена", "dance":"Танцпол", "table":"Буфет",
            "games":"Игровая", "quiet":"Тихая комната", "bluff":"Красная гостиная",
            "garden":"Оранжерея", "oracle":"Тихая комната"}.get(key,"Большой зал")

    def week7_venue_available(key):
        if key=="leave": return True
        visits=week7_venue.get("visits",{})
        if key=="games":
            if ("quiz" if week7_clock<1230 else "stories") in week7_venue.get("played_games",[]): return False
        elif key in ("bluff","oracle"):
            if visits.get(key):return False
        elif visits.get(key,0)>=2:
            return False
        info=week7_venue_places[key]
        deadline=1260 if week7_party_guest()=="lera" else 1350
        return week7_clock+info["duration"]<=min(deadline,info["until"])

    def week7_venue_description(key):
        if not key: return "Выбрать, куда пойти. Карту можно открыть снова после сцены."
        descriptions={
            "music":"У инструментов собираются Илья и музыканты. Можно попроситься на один номер или остаться послушать.",
            "dance":"В центре большого зала освободили пол. Отсюда видны и буфет, и сцена.",
            "table":"Под луной у дальней стены накрыт стол. Тут едят, знакомятся и разговаривают, пока музыка не слишком громкая.",
            "games":"Отдельная комната с дверью из зала. Катя объявила сначала киноквиз, после половины девятого — истории с угадыванием.",
            "quiet":"Тихая комната с отдельным входом из зала. Дверь приглушает музыку; можно спокойно услышать ответ.",
            "bluff":"В красной гостиной стучат стаканчики. По три кости у каждого: нужно угадать, где уверенная заявка, а где блеф. Три раунда, без денег.",
            "garden":"За правой дверью в зале — оранжерея: стекло, мокрый двор, растения и целая семья кривозубых тыкв. Внутри тепло, на шкафчике чай.",
            "oracle":"В тихой комнате на круглом столике у дивана лежит колода с петербургскими картинками. Можно выбрать вопрос, вытянуть карту и посмотреть, что она напомнит.",
            "leave":"Полноценная прихожая у входа. Здесь гардероб и дверь в санузел: можно забрать куртку и выйти. У спутницы есть собственные планы и право остаться или уехать."
        }
        text=descriptions[key]
        if key!="leave" and not week7_venue_available(key):
            if week7_party_guest()=="lera" and week7_clock+week7_venue_places[key]["duration"]>1260:
                reason="Лере скоро выезжать. На это вместе уже не успеть."
            elif week7_clock+week7_venue_places[key]["duration"]>1350:
                reason="Скоро закрытие. На это уже не хватит времени."
            elif key=="music" and week7_clock+week7_venue_places[key]["duration"]>1275:
                reason="Музыканты заканчивают в 21:15. На целый номер уже не успеть."
            elif key=="games":
                reason="В квиз уже сыграли. После половины девятого здесь будут истории." if week7_clock<1230 else "Историями уже обменялись. Можно выбрать другое место."
            else:
                reason="Здесь уже побывали. Хочется выбрать что-то другое."
            text+="\n\n"+reason
        return text
