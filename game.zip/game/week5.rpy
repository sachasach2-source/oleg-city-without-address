label week5_start:
    if not week4_finished:
        "Продолжение начинается после четвёртой главы. Здесь нужна история Олега к концу четверга."
        return
    $ week5_reset()
    $ city_chapter = "Я тебя зову"
    $ quick_menu = False
    scene expression week5_home_bg() with fade
    call screen chapter_card("Я тебя зову", "Глава пятая · пятница")
    $ quick_menu = True
    show screen scene_marker
    $ week5_stamp("Дома", 475, 0)
    $ set_soundscape("hotel_morning")
    "Олег просыпается до будильника. Смотрит на телефон, кладёт обратно. Потом всё-таки берёт."
    if week4_evening in ("nika", "lera", "asya") and week5_prior_kiss(week4_evening):
        "Вчерашнее прощание вспоминается раньше рабочего созвона. Он несколько секунд улыбается в подушку, пока телефон не падает ему на грудь."
    else:
        "В календаре после работы пусто. Обычно он оставляет это место на случай, если кто-нибудь позовёт."
    mind "Я сам хочу позвать."
    if week5_home.get("kind") == "hotel" and week5_home.get("keys_due") == "friday" and week5_home.get("paid_until") == "friday":
        "В полдень заканчивается оплаченный номер, а ключи от квартиры будут только после работы. Олег продлевает гостиницу до субботы: сейчас ещё нужно закончить рабочий день, потом спокойно перевезти вещи."
        $ week5_home["paid_until"] = "saturday"
        $ week5_event("hotel_extended_for_move")
    if week5_home.get("visit") == "friday":
        $ week5_stamp("Дома · мастер", 540)
        "В девять приходит мастер. Олег заранее снимает вещи с подоконника. Через час створка закрывается без щели. Хозяин подтверждает оплату по телефону."
        $ week5_home.update(repaired=True, visit="done")
        $ week5_event("friday_repair_done")
    $ week5_stamp("Рабочая пятница", 780)
    call vignette_laundry_care
    if week5_entry["work"].get("report") != "done":
        "До обеда Олег с Ильёй проходит оставшиеся спорные заказы. Олег отправляет итоговую версию с отдельным списком того, что ещё предстоит проверить на следующей неделе."
        $ week5_event("work_handoff", "Оставшиеся случаи перечислены, а не спрятаны")
    else:
        "После обеда Катя присылает короткое «сошлось». Олег отвечает и закрывает рабочий чат. Вечером у него будут свои дела."
    if any(x["event"] == "song_promised" for x in week5_entry["relations"].get("nika", {}).get("events", [])):
        "В перерыве он берёт гитару. Вчерашнюю песню приходится начать три раза; отправляет третий дубль, пока не придумал записать четвёртый."
        call week5_chat("nika", "promised_song", [], [("send", "Подобрал вчерашнюю из кафе. Скидываю как сыграл, конец ещё хромает.", [("Ника", "Слушаю. У тебя на конце теперь совсем другой ход."), ("Ника", "Мне нравится. Не переделывай его пока.")])])
        $ week5_event("promised_song_sent", "Boys Don't Cry; новая запись после четверга")
    if any("новый экземпляр" in x for x in week5_entry["relations"].get("varya", {}).get("promises", [])):
        "Перед тем как убрать телефон, Олег открывает Варин зин. Обещал посмотреть дома."
        scene bg ch3 zine detail with dissolve
        call week5_chat("varya", "zine_read", [], [("window", "Перелистал дома целиком. Разворот с бельём мне больше всего нравится. Сначала видишь двор, а потом понимаешь, что у кого-то там носки сохнут.", [("Варя", "Я эту верёвку чуть не убрала. Думала, будет мусорно."), ("Варя", "Хорошо. Оставлю.")]), ("cat", "Посмотрел дома. Кота с обложки не убирай, даже если кто-нибудь предложит сделать посерьёзнее.", [("Варя", "Он там и так самый серьёзный."), ("Варя", "Спасибо, что посмотрел.")])])
        scene expression week5_home_bg() with dissolve
        $ week5_event("zine_promise_kept")
    call rita_moderator_friday
    call connections_week5_followup
    call week5_marta_friday
    if week5_varya_known():
        call week5_varya_advice
    call week5_choose_date
    if not week5_person:
        call week5_logistics
        $ week5_result = "own_evening"
        jump week5_morning
    call week5_invitation
    if not week5_date["confirmed"]:
        call week5_logistics
        $ week5_result = "invitation_declined"
        jump week5_morning
    if week5_date["romantic"] and not week5_date["limited"]:
        menu:
            "Мне хочется, чтобы вечер продолжился у меня. Подготовлюсь.":
                "В списке покупок появляются кофе, что-нибудь к завтраку и презервативы. Олег перечитывает список и идёт за всем сразу."
                $ week5_prepared = True
                $ week5_event("prepared_for_guest")
            "Сегодня хочу сначала побыть с ней. Дальше решим вместе.":
                "Он проверяет адрес и заряжает телефон. Сообщение «я придумал ещё продолжение» пока не отправляет."
                $ week5_event("left_evening_open")
    call week5_logistics
    if week5_date["romantic"] and not week5_date["limited"]:
        call week5_prepare_home
    call week5_date_location
    call expression "week5_date_" + week5_person
    if week5_date["limited"] or week5_date["repair_only"]:
        $ week5_stamp("Пора домой", 1290)
        "Уговорённый час заканчивается. Олег убирает телефон после короткого сообщения о дороге и не предлагает ещё «буквально пять минут»."
        $ week5_result = "limited_evening" if week5_date["romantic"] or week5_date["repair_only"] else "friend_evening"
        jump week5_morning
    if not week5_date["romantic"]:
        $ week5_result = "friend_evening"
        jump week5_morning
    call week5_closer
    call week5_night_invitation
    jump week5_morning

label week5_choose_date:
    $ week5_options = []
    python:
        for person in ("nika", "lera", "asya"):
            relation = week5_relations.get(person, {})
            if relation.get("known"):
                words = {"nika":"Нику", "lera":"Леру", "asya":"Асю"}
                intention = "Хочу позвать " + words[person] + (" погулять." if relation.get("mode") == "friendship" else " на свидание.")
                week5_options.append((intention, person))
        week5_options.append(("Сегодня хочу вечер для себя. Позову, когда действительно захочу.", "alone"))
    call screen chapter3_intentions("Кого мне хочется увидеть?", week5_options)
    $ week5_person = "" if _return == "alone" else _return
    return

label week5_invitation:
    if week5_issues(week5_person):
        $ week5_date["repair_only"] = True
        $ week5_issue_text = {"nika":"Я помню, как у нас в прошлый раз получилось. Сначала хочу понять, что ты сейчас предлагаешь.", "lera":"Я не хочу опять сидеть и гадать, хотелось ли тебе вообще со мной быть.", "asya":"Я ещё не отошла от прошлого разговора. Не хочу сделать вид, что его не было."}[week5_person]
        if week5_person == "lera" and any(x["event"] == "explained_hesitation" for x in week5_entry["relations"]["lera"].get("events", [])):
            $ week5_issue_text = "Я прочитала твоё объяснение. Мне всё равно немного неловко после того вечера."
        call week5_chat(week5_person, "unfinished", [(week4_names[week5_person], week5_issue_text)], [("meet", "Хочу увидеть тебя. На час, без продолжения вечера. У Садовой в половине девятого? И поговорить о том, что осталось между нами.", [(week4_names[week5_person], "На час могу. Давай в половине девятого.")]), ("space", "Понял. Сегодня звать не буду. Я не забыл, что между нами осталось.", [(week4_names[week5_person], "Хорошо. Спасибо, что не торопишь.")])])
        if _return == "space":
            return
        $ week5_date.update(confirmed=True, limited=True, romantic=False)
        $ week5_event("limited_repair_agreed")
        return
    if week5_relations[week5_person].get("mode") == "friendship":
        call week5_chat(week5_person, "friends", [], [("walk", "Хочу сегодня прогуляться. В половине девятого у Садовой, потом к каналу? Если свободна.", [(week4_names[week5_person], "Давай. Ненадолго, я потом домой.")]), ("leave", "Хотел позвать, но сегодня сам уже выдохся. Лучше в другой раз нормально.", [(week4_names[week5_person], "Тогда отдыхай. Спишемся.")])])
        if _return == "walk":
            $ week5_date.update(confirmed=True, limited=True, romantic=False)
        return
    menu:
        "[week5_personal_intentions[week5_person]]":
            $ week5_plan = week5_personal_plans[week5_person]
            $ week5_offer = week5_personal_offers[week5_person]
        "Прогуляемся у Крюкова канала. Хочу побыть с ней без чужой программы.":
            $ week5_plan = "walk"
            $ week5_offer = "Хочу позвать тебя на свидание. Сегодня в половине девятого у Садовой? Я маршрут придумал, пойдём к Крюкову каналу."
        "Позову в маленький книжный. Потом можно пройтись вдоль воды.":
            $ week5_plan = "books"
            $ week5_offer = "Хочу позвать тебя на свидание. Сегодня в книжный? В половине девятого, у Садовой. Я узнал, до десяти открыт. Потом можно к воде пройтись."
    if week5_prior_kiss(week5_person):
        $ week5_offer += " Хочу продолжить вчерашний вечер."
    $ week5_reply = {"nika":"Давай. Я сегодня рано с репетиции ушла, успею ещё домой заскочить. В половине девятого буду.", "lera":"Да. Я сегодня без выступления. Вообще без выступления, даже разговорного. Хотя за последнее не ручаюсь.", "asya":"Хочу. Я заберу куртку из галереи и приеду."}[week5_person]
    if week5_plan == week5_personal_plans.get(week5_person):
        $ week5_reply = week5_personal_replies[week5_person]
    call week5_chat(week5_person, "invite", [], [("clear", week5_offer, [(week4_names[week5_person], week5_reply)]), ("short", "Хочу позвать тебя на свидание. Но сегодня у меня силы только на час. В половине девятого у Садовой, пройдёмся к каналу?", [(week4_names[week5_person], "Давай на час. Потом каждый домой.")]), ("cancel", "Начал придумывать вечер и понял, что сегодня всё-таки не соберусь. Лучше сейчас скажу.", [(week4_names[week5_person], "Ладно. Тогда сегодня своими делами займусь.")])])
    if _return == "cancel":
        return
    $ week5_date.update(confirmed=True, romantic=True, limited=(_return == "short"))
    if _return == "short":
        $ week5_plan = "walk"
    if week5_plan == "dumplings":
        "Получив согласие Аси, Олег записывает двоих на вечернее занятие и отправляет ей подтверждение."
    $ week5_event("date_agreed", week5_plan)
    return

label week5_logistics:
    if week5_home.get("keys_due") == "friday":
        if week5_laundry.get("where") == "lera":
            call week5_chat("lera", "laundry_move", [], [("ask", "Сегодня в половине седьмого за ключами. Можно вещи завтра после шести забрать? Напишу перед выездом.", [("Лера", "Можно. Я сниму с сушилки и сложу в пакет. Только напиши сначала.")])])
            $ week5_laundry["return"] = "saturday_after18"
        $ week5_stamp("За ключами", 1110)
        scene expression (housing_background(week5_home.get("candidate") or "central") + " establishing") with fade
        "Агент приезжает с договором и двумя связками. Олег проверяет ключи в обоих замках, фотографирует счётчики и забирает свой экземпляр договора."
        $ week5_home.update(kind="new", actual_home=week5_home.get("candidate") or "central", keys_due="done")
        $ housing_home = week5_home["actual_home"]
        $ housing_pending = ""
        $ week5_event("keys_collected", week5_home["actual_home"])
        "Из отеля он пока забирает рюкзак и гитару. Остальное можно перенести завтра; номер оплачен, сдавать его прямо сейчас не нужно."
    elif week5_laundry.get("where") == "lera":
        $ week5_stamp("Перед дорогой к Лере", 1070)
        call week5_chat("lera", "laundry_pickup", [], [("check", "Ты дома? Могу после шести забрать пакет, как договорились.", [("Лера", "Да. Напиши у подъезда, я вынесу.")])])
        $ week5_stamp("У дома Леры", 1100)
        scene bg w4 lera yard with dissolve
        $ set_soundscape("courtyard")
        if week5_laundry.get("drying_care") == "turned":
            "Лера приносит пакет раскрытым. Верхнюю футболку оставила отдельно, на плечиках."
            l "Вот эту утром перевернула. Проверь сгиб, прежде чем складывать."
            "Олег проводит пальцами по внутреннему шву. Сухо. Он снимает плечики, возвращает их Лере и сам укладывает футболку в пакет."
            o "Теперь все. Спасибо."
            $ week5_laundry["drying_care"] = "returned_after_turning"
        else:
            "Лера спускается с пакетом. На верхней футболке лежит один чужой носок. Она забирает его, смеётся и протягивает пакет обратно."
            l "Это не бонус. Соседкин."
            o "Я бы вернул. После экспертизы."
        if week5_person == "lera" and week5_date["confirmed"]:
            l "До вечера тогда. Я ещё домой, собраться."
        $ week5_laundry.update(where="home", status="clean", **{"return":"done"})
        $ week5_event("laundry_returned")
    $ week5_stamp("Дома", 1170)
    scene expression week5_home_bg(True) with fade
    $ set_soundscape("ch3_room")
    if not week5_person or not week5_date["confirmed"]:
        "Олег ставит на стол ужин и включает музыку. На третьей песне берёт гитару, потом сдвигает тарелку подальше от локтя."
        "Под знакомый припев вдруг находится другой ход. Олег выключает музыку и пробует его отдельно. Первый раз получается лучше, чем следующие четыре; он сердито проводит ладонью по струнам и начинает медленнее."
        "Еда остывает. Он всё-таки кладёт гитару, доедает и только потом включает запись на телефоне. В начале слышно, как скребёт по столу отодвинутая тарелка."
    return

label week5_prepare_home:
    if week5_home.get("kind") == "hotel":
        "На стойке Олег уточняет, можно ли сегодня прийти с гостьей и оставить её до утра. Можно; если решат остаться, надо будет зайти вдвоём."
        "В номере он убирает ноутбук со стола и проверяет, где чистая вторая чашка. На кровати лежит зарядка, с которой он спал три дня. Её тоже убирает."
        $ week5_private_ready = True
    else:
        "Олег собирает со стола рабочие бумаги, убирает лишнее с места для сидения. Сам садится на минуту, проверяя, не шатается ли оно."
        if week5_home.get("actual_home", week5_entry.get("housing_home")) == "studio":
            "С диваном ещё придётся повозиться. Пока он сложен: к холодильнику можно подойти."
        elif week5_home.get("kind") == "whole" and not week5_home.get("boxes_gone"):
            "За дверью по-прежнему остаются хозяйские коробки. Олег проверяет, свободен ли проход; собственный вечер не превращает эту квартиру в другую."
        "Чистое полотенце он оставляет в ванной. Потом ещё раз проходит до двери, выключая верхний свет там, где тот слишком резкий."
        $ week5_private_ready = True
    "До выхода ещё есть время. Олег открывает переписку, перечитывает своё приглашение и отправляет точку встречи."
    return
