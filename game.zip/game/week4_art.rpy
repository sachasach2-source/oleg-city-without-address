image bg w4 home new = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))
image bg w4 home old = Transform("images/cast/apartment-empty.webp", xysize=(1600, 900))
image bg w4 work hotel = Transform("images/week4/hotel-work-laptop-v2.webp", xysize=(1600, 900))
image bg w4 work detail = Transform(Transform("images/week4/hotel-work-laptop-v2.webp", xysize=(1600, 900)), crop=(640, 360, 940, 529), xysize=(1600, 900))
image bg w4 dinner = Transform("images/week4/lera-dinner-v1.webp", xysize=(1600, 900))
image bg w4 rain = Transform("images/week4/courtyard-rain-v1.webp", xysize=(1600, 900))
image bg w4 varya yard = Transform("images/week4/courtyard-rain-v1.webp", xysize=(1600, 900))
image bg w4 lera yard = Transform("images/week4/courtyard-rain-v1.webp", xysize=(1600, 900))
image bg w4 lera hall empty = Transform("images/week4/lera-hall-v1.webp", xysize=(1600, 900))
image bg w4 lera hall = Transform("images/week4/lera-hall-v1.webp", xysize=(1600, 900))
image bg w4 lera sofa = Transform("images/week4/lera-sofa-v1.webp", xysize=(1600, 900))
image bg w4 lera awkward = Transform("images/week4/lera-sofa-awkward-v1.webp", xysize=(1600, 900))
image bg w4 lera touch = Transform("images/week4/lera-sofa-touch-v1.webp", xysize=(1600, 900))
image bg w4 workshop = Transform("images/week4/workshop-pasha-v1.webp", xysize=(1600, 900))
image bg w4 theatre empty = Transform("images/week4/theatre-empty-v1.webp", xysize=(1600, 900))
image bg w4 rita introduction = Transform("images/week4/rita-introduction-v2.webp", xysize=(1600, 900))
image bg w4 rita = Transform("images/week4/theatre-delivered-v1.webp", xysize=(1600, 900))
image bg w4 gallery empty = Transform("images/cast/gallery-empty.webp", xysize=(1600, 900))
image bg w4 asya = Transform("images/cast/gallery-empty.webp", xysize=(1600, 900))
image bg w4 print empty = Transform("images/week4/print-evening-v1.webp", xysize=(1600, 900))
image bg w4 varya = Transform("images/week4/print-evening-v1.webp", xysize=(1600, 900))
image bg w4 cafe empty = Transform("images/chapter3/ch3-cafe-evening-empty-v1.webp", xysize=(1600, 900))
image bg w4 nika wait = Transform("images/chapter3/ch3-cafe-evening-empty-v1.webp", xysize=(1600, 900))
# Local jewellery insert: keep the accepted faces and composition untouched.
image bg w4 nika = Transform(Composite((1672, 941),
    (0, 0), "images/week4/nika-cafe-v2.webp",
    (1280, 630), Transform("images/week4/nika-ring-correction-v1.webp", xysize=(140, 120))), xysize=(1600, 900))
image bg w4 nika steps apart = Transform("images/week4/nika-steps-apart-v1.webp", xysize=(1600, 900))
image bg w4 nika steps close = Transform("images/week4/nika-steps-close-v1.webp", xysize=(1600, 900))
image bg w4 lera kiss = Transform("images/week4/lera-kiss-v1.webp", xysize=(1600, 900))
image bg w4 asya kiss = Transform("images/week4/asya-hands-v2.webp", crop=(370, 419, 928, 522), xysize=(1600, 900))

init -9 python:
    cast_assets[("rita", "theatre")] = {"neutral":"images/week4/rita-standing-v1.webp"}
    cast_stages.update({
        "w4 varya yard": ("images/week4/courtyard-rain-v1.webp", [("oleg", "outdoor", 430, 55, 920), ("varya", "", 1250, 55, 920)], None, "dusk"),
        "w4 lera yard": ("images/week4/courtyard-rain-v1.webp", [("oleg", "outdoor", 430, 55, 920), ("lera", "outdoor", 1250, 55, 920)], None, "dusk"),
        "w4 nika wait": ("images/chapter3/ch3-cafe-evening-empty-v1.webp", [("oleg", "indoor", 430, 55, 920), ("nika", "standing", 1250, 55, 920)], None, "evening"),
        "w4 lera hall": ("images/week4/lera-hall-v1.webp", [("oleg", "indoor", 470, 45, 970), ("lera", "indoor", 1200, 45, 950)], None, "evening"),
        "w4 asya": ("images/cast/gallery-empty.webp", [("oleg", "indoor", 430, 55, 920), ("asya", "", 1250, 55, 920)], None, "evening"),
        "w4 varya": ("images/week4/print-evening-v1.webp", [("oleg", "indoor", 430, 55, 920), ("varya", "weekend", 1250, 55, 920)], None, "evening"),
        # Rita's source reaches the knees; Oleg's ends at the hips. Match head/shoulder
        # scale in this shared camera plane, not the height of the source canvases.
        "w4 rita": ("images/week4/theatre-delivered-v1.webp", [("oleg", "indoor", 430, 55, 920), ("rita", "theatre", 1200, 105, 1340)], None, "evening"),
    })
    cast_cues.update({
        ("asya", "Я на тебя сразу наехала. Ты вообще не это говорил."): "skeptical",
        ("asya", "Да. Я тоже не сразу увидела."): "warm",
        ("lera", "Так сколько их всё-таки?"): "amused",
        ("varya", "Бесит, что ты говоришь нормально. Я хотела, чтобы ты тайный смысл нашёл."): "earnest",
        ("oleg", "Я просто хотел этот трек."): "amused",
    })
