# Browser downloads full illustrations on demand; no changes to desktop play.
init python:
    if renpy.emscripten:
        import os as web_asset_os
        import emscripten as web_asset_js
        web_asset_failed = {}
        _web_original_xhr = renpy.webloader.XMLHttpRequest
        class WebAssetRequest(_web_original_xhr):
            def __init__(self, filename):
                super(WebAssetRequest,self).__init__(filename)
                web_asset_js.run_script("RenPyWeb.dl_get(%d).timeout = 20000;" % self.id)
        renpy.webloader.XMLHttpRequest = WebAssetRequest
        config.image_cache_size_mb = 160
        config.predict_statements = 6
        _web_original_image_size = renpy.image_size
        def web_image_size(image):
            if isinstance(image,str) and image in web_asset_dimensions:
                return tuple(web_asset_dimensions[image])
            return _web_original_image_size(image)
        renpy.image_size = web_image_size

        _web_original_enqueue = renpy.webloader.enqueue
        def web_asset_enqueue(relpath, rtype, data):
            _web_original_enqueue(relpath, rtype, data)
            if rtype == "image":
                renpy.restart_interaction()
        renpy.webloader.enqueue = web_asset_enqueue

        def web_assets_pending():
            with renpy.webloader.queue_lock:
                return len(web_asset_failed) + sum(1 for request in renpy.webloader.queue if request.rtype == "image")

        _web_original_process = renpy.webloader.process_downloaded_resources
        def web_asset_process():
            # The engine processes completed requests, flushes placeholders and
            # releases downloaded files. Keep its memory lifecycle and errors.
            with renpy.webloader.queue_lock:
                for request in list(renpy.webloader.queue):
                    if request.rtype != "image" or not request.download_completed():
                        continue
                    filename = web_asset_os.path.join(config.gamedir,request.relpath)
                    if not web_asset_os.path.exists(filename):
                        if getattr(request,"oleg_retries",0)<2:
                            request.oleg_retries = getattr(request,"oleg_retries",0)+1
                            request.xhr = renpy.webloader.XMLHttpRequest(request.relpath)
                        else:
                            web_asset_failed[request.relpath] = (request.rtype,request.data)
                            renpy.webloader.queue.remove(request)
            _web_original_process()
        renpy.webloader.process_downloaded_resources = web_asset_process
        def web_asset_poll():
            web_asset_process()
            renpy.restart_interaction()
        def web_asset_retry():
            for filename,(rtype,data) in list(web_asset_failed.items()):
                _web_original_enqueue(filename,rtype,data)
                del web_asset_failed[filename]
            renpy.restart_interaction()
        def web_asset_gate_visible():
            return bool(web_assets_pending()) and not any(renpy.get_screen(name) for name in ("save","load","preferences","confirm","main_menu"))
        config.always_shown_screens.append("web_asset_loading")

screen web_asset_loading():
    zorder 1000
    modal (renpy.emscripten and web_asset_gate_visible())
    if renpy.emscripten and web_asset_gate_visible():
        add Solid("#08131a")
        vbox:
            xalign .5 yalign .5 spacing 18
            if web_asset_failed:
                text "Не удалось загрузить иллюстрацию" xalign .5 size 28 color "#eadbbf"
                text "Проверь соединение и попробуй ещё раз." xalign .5 size 19 color "#a9bbc3"
                textbutton "Повторить загрузку" action Function(web_asset_retry) xalign .5
                textbutton "Сохранить игру" action ShowMenu("save") xalign .5
            else:
                text "Загружаем иллюстрации…" xalign .5 size 28 color "#eadbbf"
                text "Следующий кадр появится в полном качестве." xalign .5 size 19 color "#a9bbc3"
        key "game_menu" action ShowMenu("save")
        timer .1 repeat True action Function(web_asset_poll)
