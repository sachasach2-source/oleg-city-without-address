# Browser-only work: demand loading, bounded failures and a lighter renderer.
default persistent.web_lite = False

init python:
    def web_lite_enabled():
        return bool(renpy.emscripten and getattr(persistent, "web_lite", False))

    def set_background_motion(enabled):
        persistent.city_motion = bool(enabled)
        if enabled:
            persistent.web_lite = False
        renpy.save_persistent()

    if renpy.emscripten:
        import os as web_asset_os
        import weakref as web_asset_weakref
        import emscripten as web_asset_js
        web_asset_failed = {}
        # Runtime-only ownership: save menus have their own context; rollback
        # and loading begin a fresh interaction. No download state enters saves.
        web_asset_contexts = web_asset_weakref.WeakKeyDictionary()
        def web_asset_required():
            return web_asset_contexts.setdefault(renpy.game.context(), set())
        def web_asset_new_interaction():
            web_asset_required().clear()
        config.start_interact_callbacks.append(web_asset_new_interaction)

        _web_original_xhr = renpy.webloader.XMLHttpRequest
        class WebAssetRequest(_web_original_xhr):
            def __init__(self, filename):
                super(WebAssetRequest,self).__init__(filename)
                web_asset_js.run_script("RenPyWeb.dl_get(%d).timeout = 20000;" % self.id)
        renpy.webloader.XMLHttpRequest = WebAssetRequest
        config.image_cache_size_mb = 160
        config.predict_statements = 6
        _web_original_image_size = renpy.image_size
        def web_image_size(image):
            if isinstance(image,str) and image in web_asset_dimensions:
                return tuple(web_asset_dimensions[image])
            return _web_original_image_size(image)
        renpy.image_size = web_image_size

        _web_original_enqueue = renpy.webloader.enqueue
        def web_asset_enqueue(relpath, rtype, data):
            if relpath not in web_asset_failed:
                _web_original_enqueue(relpath, rtype, data)
        renpy.webloader.enqueue = web_asset_enqueue

        def web_asset_mark_visible(files):
            files = set(files)
            required = web_asset_required()
            previous = set(required)
            with renpy.webloader.queue_lock:
                for request in renpy.webloader.queue:
                    if request.rtype == "image" and (request.relpath in files or request.data in files):
                        required.add(request.relpath)
                for filename, (rtype, data) in web_asset_failed.items():
                    if filename in files or data in files:
                        required.add(filename)
            if required != previous:
                renpy.restart_interaction()

        _web_original_image_render = renpy.display.im.ImageBase.render
        def web_asset_image_render(self, width, height, st, at):
            result = _web_original_image_render(self, width, height, st, at)
            if not renpy.display.predict.predicting:
                # This also sees placeholders already in the predictor's cache,
                # including the source files of composites and alpha masks.
                web_asset_mark_visible(self.get_oversampled_image().predict_files())
            return result
        renpy.display.im.ImageBase.render = web_asset_image_render

        def web_assets_pending():
            required = web_asset_required()
            with renpy.webloader.queue_lock:
                pending = {r.relpath for r in renpy.webloader.queue if r.rtype == "image" and r.relpath in required}
            return len(pending | (set(web_asset_failed) & required))
        def web_assets_failed_visible():
            return bool(set(web_asset_failed) & web_asset_required())

        _web_original_process = renpy.webloader.process_downloaded_resources
        def web_asset_process():
            before = (web_assets_pending(), web_assets_failed_visible())
            with renpy.webloader.queue_lock:
                for request in list(renpy.webloader.queue):
                    if request.rtype != "image" or not request.download_completed():
                        continue
                    filename = web_asset_os.path.join(config.gamedir,request.relpath)
                    if not web_asset_os.path.exists(filename):
                        if getattr(request,"oleg_retries",0)<2:
                            request.oleg_retries = getattr(request,"oleg_retries",0)+1
                            request.xhr = renpy.webloader.XMLHttpRequest(request.relpath)
                        else:
                            web_asset_failed[request.relpath] = (request.rtype,request.data)
                            renpy.webloader.queue.remove(request)
            _web_original_process()
            if before != (web_assets_pending(), web_assets_failed_visible()):
                renpy.restart_interaction()
        renpy.webloader.process_downloaded_resources = web_asset_process
        def web_asset_poll():
            web_asset_process()
        def web_asset_retry():
            for filename in list(set(web_asset_failed) & web_asset_required()):
                rtype, data = web_asset_failed.pop(filename)
                _web_original_enqueue(filename,rtype,data)
            renpy.restart_interaction()
        def web_asset_gate_visible():
            return bool(web_assets_pending()) and not any(renpy.get_screen(name) for name in ("save","load","preferences","confirm","main_menu","web_asset_prepare"))

        def web_asset_prepare_begin(paths):
            # Readiness is checked before initializing any mini-game clock.
            for path in paths:
                try:
                    with renpy.loader.load(path):
                        pass
                except renpy.webloader.DownloadNeeded as request:
                    web_asset_enqueue(request.relpath, "image", path)
                    web_asset_required().add(request.relpath)
        def web_asset_prepare_poll():
            web_asset_process()
            if not web_assets_pending():
                renpy.end_interaction(True)
        config.always_shown_screens.append("web_asset_loading")

label web_prepare_assets(paths):
    if renpy.emscripten:
        call screen web_asset_prepare(paths)
        python:
            for path in paths:
                renpy.load_image(path)
    return

screen web_asset_status():
    vbox:
        xalign .5 yalign .5 spacing 18
        if web_assets_failed_visible():
            text "Не удалось загрузить иллюстрацию" xalign .5 size 28 color "#eadbbf"
            text "Проверь соединение и попробуй ещё раз." xalign .5 size 19 color "#a9bbc3"
            textbutton "Повторить загрузку" action Function(web_asset_retry) xalign .5
            textbutton "Сохранить игру" action ShowMenu("save") xalign .5
        else:
            text "Загружаем иллюстрации…" xalign .5 size 28 color "#eadbbf"
            text "Следующий кадр появится в полном качестве." xalign .5 size 19 color "#a9bbc3"

screen web_asset_loading():
    zorder 1000
    modal (renpy.emscripten and web_asset_gate_visible())
    if renpy.emscripten and web_asset_gate_visible():
        add Solid("#08131a")
        use web_asset_status
        key "game_menu" action ShowMenu("save")
        # Function's automatic screen update must also be disabled: idle polls
        # must not rebuild every phone, button and background ten times a second.
        timer .2 repeat True action Function(web_asset_poll, _update_screens=False)

screen web_asset_prepare(paths):
    modal True
    on "show" action Function(web_asset_prepare_begin, paths)
    add Solid("#08131a")
    use web_asset_status
    key "game_menu" action ShowMenu("save")
    timer .2 repeat True action Function(web_asset_prepare_poll, _update_screens=False)
