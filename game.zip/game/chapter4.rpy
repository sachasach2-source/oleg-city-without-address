# Marta belongs to chapter 3. Legacy ch4 identifiers remain for existing saves.
define m = SpriteCharacter("Марта", color="#d5b7d8", sprite_key="marta")
image bg ch4 bookshop = Transform("images/chapter4/bookshop-empty-v1.webp", xysize=(1600, 900))
image bg ch4 lobby = Transform("images/chapter4/bookshop-empty-v1.webp", xysize=(1600, 900))
image bg ch4 table = Transform("images/chapter4/marta-table-v1.webp", xysize=(1600, 900))
image bg ch4 cards = Transform("images/chapter4/marta-cards-close-v1.webp", xysize=(1600, 900))
image bg ch4 gift = Transform("images/chapter4/marta-card-gift-v1.webp", xysize=(1600, 900))

default chapter4_clock = 1050
default chapter4_day = 0
default chapter4_commitments = []
default chapter4_entry_commitments = []
default chapter4_evening_was_busy = False
default chapter4_poster_seen = False
default chapter4_marta_seen = False
default chapter4_marta_contact = False
default chapter4_marta_interest = 0
default chapter4_marta_relation = ""
default chapter4_marta_plan = ""
default chapter4_result = ""
default chapter4_embedded = False
default chapter4_game_moment = ""
default chapter3_marta_checked = False
default chapter3_marta_can_visit = False
default chapter3_evening_checked_days = []

init python:
    import copy
    def chapter4_reset(clear_plans=False):
        global chapter4_embedded, chapter4_game_moment, chapter4_board
        global chapter4_clock, chapter4_day, chapter4_evening_was_busy
        global chapter4_poster_seen, chapter4_marta_seen, chapter4_marta_contact
        global chapter4_marta_interest, chapter4_marta_relation, chapter4_marta_plan, chapter4_result
        global chapter4_commitments, chapter4_entry_commitments, phone_reply_log
        chapter4_clock, chapter4_day = 1050, 0
        chapter4_evening_was_busy = False
        chapter4_poster_seen = chapter4_marta_seen = chapter4_marta_contact = False
        chapter4_marta_interest = 0
        chapter4_marta_relation = chapter4_marta_plan = chapter4_result = ""
        chapter4_embedded = False
        chapter4_game_moment = ""
        chapter4_board = None
        if clear_plans:
            chapter4_commitments, chapter4_entry_commitments = [], []
        phone_reply_log = {key:value for key,value in phone_reply_log.items() if not key[0].startswith("ch4_")}

    def chapter4_evening_free():
        if chapter4_evening_was_busy or chapter4_clock > 1110:
            return False
        for plan in chapter4_commitments:
            if plan["day"] != chapter4_day or plan.get("status", "confirmed") not in ("confirmed", "done", "missed"):
                continue
            start, end = plan.get("start"), plan.get("end")
            if start is None or end is None:
                return False
            # The whole evening, including travel and agreed continuations, must be free.
            if start - plan.get("travel_before", 0) < 1380 and end + plan.get("travel_after", 0) > 1080:
                return False
        return True

    def chapter4_reserve(ident, day, start, end, person=None, travel_before=30, travel_after=30):
        global chapter4_evening_was_busy
        chapter4_commitments.append({"id":ident, "day":day, "start":start, "end":end, "person":person,
                                     "travel_before":travel_before, "travel_after":travel_after, "status":"confirmed"})
        if day == chapter4_day and start - travel_before < 1380 and end + travel_after > 1080:
            chapter4_evening_was_busy = True

    def chapter4_known_people():
        return [person for person in ("nika", "asya", "lera", "varya")
                if person in chapter3_plans or chapter3_previous.get("route") == person]

    def chapter4_home_background(dusk=False):
        if chapter3_housing == "new" and housing_home:
            return housing_home_background(True)
        if chapter3_housing == "new":
            return "bg ch3 home evening" if dusk else "bg ch3 home night"
        if chapter3_housing in ("whole", "month"):
            return "bg ch3 old night"
        return "bg hotel dusk" if dusk else "bg hotel night"

    def chapter4_stamp(location):
        global place_name, save_name
        place_name = location + " · " + ("суббота" if chapter4_day == 0 else "воскресенье") + ", " + chapter3_time(chapter4_clock)
        save_name = "Глава 3 · " + location

    def chapter3_marta_evening_free():
        # Only a genuinely finished day opens an outing. Missed/cancelled dates
        # keep their consequences, but no longer occupy a fictional time slot.
        if chapter3_day not in (0, 1) or chapter3_day in chapter3_evening_checked_days or chapter4_marta_seen:
            return False
        if any(plan["day"] == chapter3_day and plan["status"] == "confirmed" for plan in chapter3_plans.values()):
            return False
        if chapter3_clock + chapter3_travel("vaska") > 1110:
            return False
        return True

    cast_cues.update({
        ("marta", "Можно. Но тебя выгонят."): "amused",
        ("marta", "Я стараюсь сохранять достоверность."): "amused",
        ("marta", "Да. Там пока не получается выиграть. Я жила в таком доме."): "amused",
        ("marta", "Это тоже. Но я вообще тебя позвать хотела."): "neutral",
        ("marta", "Хорошо. Сейчас уже не будет загадок. Только адрес."): "amused",
    })

label chapter4_direct:
    $ chapter4_reset(clear_plans=True)
    jump chapter4_start

# Called after the day's appointments, before the one evening chat with friends.
label ch3_marta_optional_evening:
    $ chapter4_reset(clear_plans=True)
    $ chapter4_embedded = True
    $ chapter4_day = chapter3_day
    $ chapter4_clock = max(1050, chapter3_clock + chapter3_travel("vaska"))
    $ city_chapter = "Глава 3 · тёплые выходные"
    jump ch4_free_evening

label chapter4_start:
    $ chapter4_entry_commitments = copy.deepcopy(chapter4_commitments)
    $ chapter4_reset()
    $ city_chapter = "Глава 3 · тёплые выходные"
    $ quick_menu = True
    scene expression chapter4_home_background(dusk=True) with fade
    $ set_soundscape("hotel_rest")
    $ chapter4_stamp("Свободный вечер")
    show screen scene_marker
    "К вечеру субботы Олег закрывает ноутбук. На сегодня можно больше ничего не организовывать. А можно выйти и посмотреть, куда занесёт."
    if not chapter4_evening_free():
        $ chapter4_evening_was_busy = True
        jump ch4_keep_plans
    call screen chapter4_prepare
    if _return == "home":
        $ chapter4_reserve("housing", 0, 1080, 1260, travel_before=0, travel_after=0)
        jump ch4_keep_plans
    if _return.startswith("person:"):
        $ chapter4_person = _return.split(":", 1)[1]
        call ch4_arrange_evening
        jump ch4_keep_plans
    jump ch4_free_evening

screen chapter4_prepare():
    $ options = []
    for person in chapter4_known_people():
        $ options.append(("Написать " + {"nika":"Нике", "asya":"Асе", "lera":"Лере", "varya":"Варе"}[person] + ". Хочу провести сегодняшний вечер вместе.", "person:" + person))
    $ options.extend([("Сегодня займусь жильём. Хочу закрыть эти дела.", "home"), ("Оставлю вечер свободным. Посмотрю, чего самому захочется.", "free")])
    use chapter3_intentions("До вечера ещё есть силы. Только в этот раз я сначала решу, кому и что обещаю.", options)

label ch4_arrange_evening:
    $ chapter4_reserve("meet_" + chapter4_person, 0, 1110, 1260, person=chapter4_person)
    $ chapter4_contact = {"nika":"Ника", "asya":"Ася", "lera":"Лера", "varya":"Варя"}[chapter4_person]
    call screen phone_thread([], caption=chapter4_contact, conversation="ch4_plan_" + chapter4_person, past=phone_contact_history("ch4_plan_" + chapter4_person, chapter4_contact))
    return

label ch4_keep_plans:
    $ chapter4_evening_was_busy = True
    "Олег проверяет время и закрывает остальные вкладки. Сегодня он уже выбрал, чем займётся."
    $ chapter4_person = next((item.get("person") for item in chapter4_commitments if item["day"] == 0 and item.get("person") in ("nika", "asya", "lera", "varya")), None)
    scene expression chapter4_home_background() with dissolve
    $ chapter4_clock = 1290
    $ chapter4_stamp("После своих планов")
    if chapter4_person:
        # This introduction module continues existing plans as a short evening recap.
        if chapter4_person == "nika":
            "У Ники послушали целый альбом. Когда сторона закончилась, она сказала, что обычно в этом месте он уже смотрит время. Сегодня не смотрел."
        elif chapter4_person == "asya":
            "С Асей допили чай и вернулись к разговору, который в прошлый раз оборвали у двери. Выставку для повода никто не искал."
        elif chapter4_person == "lera":
            "Лера включила песню, которую хотела показать ещё при прошлой встрече. Потом сама убрала телефон: звук сегодня обошёлся без сопровождения."
        else:
            "Варя показала готовые страницы. После зина разговор продолжился сам; пакеты в этот раз никто не таскал."
        $ chapter4_result = "Провёл вечер с " + {"nika":"Никой", "asya":"Асей", "lera":"Лерой", "varya":"Варей"}[chapter4_person] + ". Оставил время для разговора."
    else:
        "Вечер уходит на свои дела. Одно занимает больше времени, чем обещало, зато завтра ему уже не надо начинать с него."
        $ chapter4_result = "Оставил вечер для своих дел. Не добавлял обещаний на ходу."
    jump ch4_evening_end

label ch4_free_evening:
    if not chapter4_evening_free():
        jump ch4_keep_plans
    scene bg ch4 lobby with dissolve
    $ set_soundscape("ch2_cafe")
    $ chapter4_stamp("Книжный на Ваське")
    "Дневные дела закончились, а до вечера ещё есть время. Олег сворачивает к маленькому книжному, в котором всё собирался посмотреть полку про город. Внутри тепло; за окном синеет двор, у заднего стола горит лампа."
    menu:
        "Сегодня никто не ждёт его к назначенному часу."
        "Посмотреть афишу в книжном.":
            $ chapter4_poster_seen = True
            "Внутри на пробковой доске: «Сегодня в семь — вечер настолок. Можно без компании». Ниже от руки: «Прототипы тоже можно»."
            menu:
                "До семи ещё есть время."
                "Зайду. Хочу попробовать что-нибудь новое.":
                    jump ch4_marta_meeting
                "Сегодня лучше просто пройдусь.":
                    $ chapter4_result = "Посмотрел афишу и выбрал прогулку. Не стал превращать свободный вечер в обязанность."
                "Хочу домой. На сегодня хватит людей.":
                    $ chapter4_result = "Оставил вечер для отдыха. Даже интересная афиша не обязана становиться планом."
        "Пойду дальше гулять. Мне хорошо без плана.":
            $ chapter4_result = "Гулял после дневных дел без новых обещаний."
        "Вернусь домой. Хочу спокойно посидеть.":
            $ chapter4_result = "Провёл свободный вечер дома."
    jump ch4_evening_end

label ch4_marta_meeting:
    if not chapter4_evening_free():
        jump ch4_keep_plans
    $ chapter4_reserve("bookshop", chapter4_day, 1140, 1260)
    $ chapter4_marta_seen = True
    $ chapter4_clock = 1140
    $ chapter4_stamp("Книжный · вечер настолок")
    $ set_soundscape("ch2_cafe")
    scene bg ch4 bookshop with Dissolve(.6)
    "Вечер проходит в задней комнате книжного. Олег оставляет место у двери другим и подходит к маленькому столу: на карточках нарисованы арки, дворы и один особенно сердитый дворник."
    "Женщина в сливовом свитере раскладывает прототип. На сумке у стула — ворон. На скетчбуке — пятно, которому уже придали статус части оформления."
    menu:
        "Рисунки хочется рассмотреть поближе."
        "Ты сама это рисовала? Мне нравится этот двор.":
            $ chapter4_marta_interest += 1
            o "Ты сама это рисовала? Мне нравится этот двор."
            m "Да. Там пока не получается выиграть. Я жила в таком доме."
        "Здесь можно присоединиться? Я один.":
            o "Здесь можно присоединиться? Я один."
            m "Можно. Нас двое, и это уже достаточно для проверки правил."
    m "Я Марта. Это игра про дворы. Обычно люди спрашивают, зачем я придумала ключи, которые ничего не открывают."
    $ postcard_meet("marta")
    o "Олег. Я такие уже в реальной жизни встречал."
    scene bg ch4 table with Dissolve(.5)
    "Они садятся. Марта объясняет: каждый собирает маршрут, но соседний двор может закрыться прямо посреди хода."
    scene bg ch4 cards with Dissolve(.35)
    o "А сюда можно пройти?"
    m "Можно. Но тебя выгонят."
    o "Даже в настолке?"
    m "Я стараюсь сохранять достоверность."
    "Она улыбается, потом сверяется с листком у края стола."
    m "Секунду. Я сама иногда путаю, где уже поменяла правило, а где ещё собиралась."
    scene bg ch4 table with Dissolve(.35)
    menu:
        "У Олега пока один проход и два повода поспорить с дворником."
        "Предложить путь через арку.":
            $ chapter4_marta_interest += 1
            o "Я бы пошёл через эту арку. Если выгонят — хотя бы срежем половину пути."
            m "О, вот так никто ещё не пробовал. Сейчас посмотрим, насколько у тебя оптимистичный дворник."
            "Марта берёт карандаш и переворачивает пустой пробник."
        "Расспросить о рисунках.":
            $ chapter4_marta_interest += 1
            o "Этот дом ты тоже знаешь?"
            m "Знаю. В реальности там ещё провод через арку идёт. Я убрала, потому что все хотели на нём повесить дворника."
            m "Я сначала его с улицы рисовала. Всё пыталась поймать, как арка внутрь уходит, и ничего не выходило. Потом за человеком зашла, а там ещё один двор. И из него улицу вообще не слышно. Я, пока стояла, уже забыла, откуда вошла."
            m "Снаружи дом обычный. А внутри всё время хочется ещё за угол заглянуть. Я несколько раз туда возвращалась, думала, запомню. Всё равно потом на рисунке что-нибудь не сходится."
            "Она раскрывает набросок рядом с карточкой. Олег переводит взгляд с одного на другую."
        "Просто сыграть и уйти.":
            $ chapter4_marta_interest = 0
            "Олег перестаёт расспрашивать про рисунки и возвращается к маршруту."
    scene bg ch4 cards with dissolve
    "На обороте пробы Марта рисует проходы между дворами. Зелёную фишку ставит у входа."
    m "Давай последний кусок. Три хода до фонтана. Калитка сверху скоро закроется, остальные проходы без сюрпризов."
    call marta_route_game
    scene bg ch4 table with dissolve
    if chapter4_game_moment == "fountain":
        o "Вот. Фонтан. Даже без перелезания."
        m "Да, дошёл."
        "Марта проверяет путь пальцем, потом обводит сквозной двор."
        m "Этот проход оставлю. А то у меня тут все только запираются."
    elif chapter4_game_moment == "wrong_courtyard":
        o "Тут такая же арка."
        m "У этой решётка. Закрыта."
        "Она уже тянется за карандашом. Олег придерживает листок за свободный угол."
        o "Нет, погоди. Не меняй. Я сейчас как-нибудь сам отсюда выберусь."
        "Марта прячет лицо в ладонях; плечи у неё трясутся."
        o "Ну вот. Теперь я тут живу."
        m "Извини. Подожди. Мне надо это записать."
        "Она записывает «различить арки». Обратный путь находят уже вместе."
    elif chapter4_game_moment == "blocked_route":
        o "А тут хоть лавка есть?"
        m "Не нарисовала."
        "Она кладёт карандаш поперёк последнего прохода."
        m "Ладно, вот отсюда вышли бы. Но уже утром."
        o "Тогда дорисуй. Мне там ждать."
    else:
        "Марта подвигает листок к себе и проводит фишку через сквозной двор к фонтану."
        o "А я бы в эту арку свернул."
        m "Там тупик. Хорошо, что показала."
    $ chapter4_clock = 1260
    $ chapter4_stamp("Книжный · после партии")
    scene bg ch4 gift with Dissolve(.35)
    m "Вот эту можешь забрать. Пробник. Проход не открывается, зато двор красивый."
    if chapter4_marta_interest == 0:
        scene bg ch4 table with Dissolve(.35)
        m "Спасибо. Мне правда полезно, когда человек впервые это видит."
        o "А мне — когда дворник хотя бы нарисованный."
        $ chapter4_marta_relation = "acquaintance"
        $ chapter4_result = "Сыграл в прототип игры про дворы. Познакомился с Мартой, контактами не обменялись."
        jump ch4_evening_end
    scene bg ch4 bookshop with dissolve
    "Они вместе убирают карточки. Олег выравнивает стопку, Марта придерживает коробку. Теперь надо говорить уже без очередности хода."
    m "Его хорошо бы вдвоём проверить. Настоящий маршрут, по дворам."
    o "Чтобы один отвлекал дворника?"
    m "Это тоже. Но я вообще тебя позвать хотела."
    menu:
        "Марта смотрит на него, не на коробку."
        "Я хочу. В следующую субботу в два пройдём маршрут?":
            o "Я хочу. В следующую субботу в два пройдём маршрут?"
            m "Да. Пока согласен дворник, надо пользоваться."
            $ chapter4_marta_relation, chapter4_marta_plan = "interest", "walk"
        "Расскажи, что за прогулка. Мне интересно.":
            o "Расскажи, что за прогулка. Мне интересно."
            m "Три двора. Один я сама нормально не посмотрела. И я не только ради правил тебя зову."
            o "Тогда давай выберем день, а не фазу Луны."
            m "В следующую субботу в два?"
            o "Давай."
            $ chapter4_marta_relation, chapter4_marta_plan = "interest", "walk"
        "Давай сначала кофе. В понедельник после работы?":
            o "Давай сначала кофе. В понедельник после работы?"
            m "Хорошо. Сейчас уже не будет загадок. Только адрес."
            $ chapter4_marta_relation, chapter4_marta_plan = "interest", "coffee"
        "Мне было весело. Но пока хочу оставить это дружеским.":
            o "Мне было весело. Но пока хочу оставить это дружеским."
            m "Ладно. Я чуть иначе это представляла. Но спасибо, что сказал."
            "Она закрывает коробку. Потом снова поднимает глаза."
            m "Если захочешь ещё поиграть — напиши. Не надо будет каждый раз произносить отказ дворнику."
            $ chapter4_marta_relation, chapter4_marta_plan = "friendship", ""
    $ bonus_gallery_award("marta", 1)
    $ chapter4_marta_contact = True
    $ chapter4_result = "Познакомился с Мартой на настолках. " + ("Договорились о прогулке в следующую субботу." if chapter4_marta_plan == "walk" else "Договорились о кофе в понедельник." if chapter4_marta_plan == "coffee" else "Обменялись контактами, сохранили дружеское общение.")
    if chapter4_marta_plan:
        $ chapter4_reserve("marta_" + chapter4_marta_plan, 7 if chapter4_marta_plan == "walk" else 2, 840 if chapter4_marta_plan == "walk" else 1110, 960 if chapter4_marta_plan == "walk" else 1200, person="marta")
        call screen phone_thread([], caption="Марта", conversation="ch4_marta_" + chapter4_marta_plan, past=[])
    jump ch4_evening_end

label ch4_evening_end:
    scene expression chapter4_home_background() with dissolve
    $ chapter4_clock = max(chapter4_clock, 1290)
    $ chapter4_stamp("После вечера")
    $ set_soundscape("hotel_evening")
    if chapter4_marta_seen:
        "Олег снимает ботинки. В кармане остаётся маленькая карточка двора: Марта разрешила оставить неудачный пробник. Даже с закрытым проходом он ей нравился."
        $ home_keepsake_receive("marta_card")
        call home_keepsakes_unpack
    else:
        "Олег возвращается к своим вещам и ставит чайник. Сегодня больше никому не обещает приехать."
    $ diary_entries = [entry for entry in diary_entries if not entry.startswith(("Глава 3 · вечер:", "Глава 4:"))] + ["Глава 3 · вечер: " + chapter4_result]
    if chapter4_embedded:
        $ chapter3_clock = max(chapter3_clock, chapter4_clock)
        $ chapter3_area = "vaska"
        if chapter4_marta_seen:
            $ chapter3_notes.append("Марта: " + chapter4_result)
        else:
            $ chapter3_solo = chapter4_result
        return
    $ ending_title = "Своим ходом"
    $ ending_body = chapter4_result
    hide screen scene_marker
    call screen chapter4_ending
    if _return == "again":
        $ chapter4_commitments = copy.deepcopy(chapter4_entry_commitments)
        $ chapter4_reset()
        jump chapter4_start
    return

screen chapter4_ending():
    modal True
    add Solid("#09151bea")
    frame:
        xalign .5 yalign .5 xsize 1110 padding (44, 40) background Solid("#12232c")
        vbox:
            spacing 26
            text "ГЛАВА 3 · ВЫХОДНОЙ ВЕЧЕР" size 17 color "#d5b384" kerning 3
            text ending_title size 43
            text ending_body size 27 xmaximum 1000 line_spacing 6
            hbox:
                spacing 30
                textbutton "Пройти вечер иначе" action Return("again")
                textbutton "В главное меню" action Return("menu")

# The table CG keeps the hands and courtyard cards above the compact choices.
screen chapter4_table_choice(items):
    frame:
        xpos 54 ypos 854 yanchor 1.0 xsize 930 padding (2, 2) background None
        frame:
            xfill True padding (16, 14) background context_panel("choice")
            vbox:
                spacing 6 xfill True
                text "МОЙ ХОД" size 15 color "#e4c698" kerning 3
                for i in items:
                    button:
                        action i.action
                        xfill True padding (16, 9)
                        background context_panel("choice_button") hover_background context_panel("choice_button",True)
                        text i.caption size 22 color "#162536" hover_color "#101c29" xmaximum 850
