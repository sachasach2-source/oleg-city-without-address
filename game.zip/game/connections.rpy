# Optional introductions. Facts live with BOTH participants and travel with the
# actual fourth-chapter history. Old saves need no new relationship defaults.
init python:
    connection_people = {"asya_varya": ("asya", "varya"), "nika_lera": ("nika", "lera"), "marta_varya": ("marta", "varya")}

    def connection_get(pair, relations=None):
        relations = week4_relations if relations is None else relations
        first = connection_people[pair][0]
        return relations.get(first, {}).get("facts", {}).get("connections", {}).get(pair, {})

    def connection_set(pair, **changes):
        data = dict(connection_get(pair), **changes)
        for person in connection_people[pair]:
            week4_relations[person].setdefault("facts", {}).setdefault("connections", {})[pair] = copy.deepcopy(data)

    def connection_event(pair, event, detail=""):
        for person in connection_people[pair]:
            week4_event(person, "connection_" + event, pair + (": " + detail if detail else ""))
        if event == "meeting":
            postcard_connection_award(pair)

    def connection_available(pair):
        return all(week4_relations.get(p, {}).get("known") for p in connection_people[pair])

    def connection_can_group(pair, host):
        return (connection_available(pair) and connection_get(pair).get("introduced", False)
            and not any(week4_unresolved(p, True) for p in connection_people[pair])
            and (pair == "marta_varya" or (host in connection_people[pair]
                and week4_plan == host and week4_plan_status == "confirmed" and not week4_plan_short)))

    def connection_active():
        # A cancellation, shortened meeting, new clash or old-save state cannot
        # silently resurrect a replacement evening.
        if week4_work.get("evening") or week4_home.get("viewing") or week4_home.get("visit") == "thursday":
            return ""
        for pair in ("asya_varya", "nika_lera"):
            data = connection_get(pair)
            if data.get("group") and not data.get("scene_done") and data.get("host") == week4_plan and connection_can_group(pair, week4_plan):
                return pair
        return ""

label connections_after_contact(person):
    if person in ("nika", "lera"):
        call connection_offer("nika_lera", person)
    elif person in ("asya", "varya"):
        call connection_offer("asya_varya", person)
    return

label connection_offer(pair, host):
    if not connection_available(pair) or connection_get(pair).get("offered"):
        return False
    # Give an unresolved personal conversation its space. Even an acknowledged
    # hurt is still present; a new acquaintance does not repair it.
    if any(week4_unresolved(p, True) for p in connection_people[pair]):
        return False
    $ connection_set(pair, offered=True)
    if pair == "asya_varya":
        if week4_entry.get("tasks", {}).get("gallery_zine") in ("connect", "promise"):
            "Олег вспоминает: Ася хотела посмотреть Варин зин. Он тогда обещал сначала спросить саму Варю."
        else:
            "Ася работает с маленькими тиражами. Олег открывает Варин чат, прежде чем пересылать что-нибудь из него."
        call week4_chat("varya", "connect_asya", [], [("keep", "Как-нибудь отдельно расскажу тебе про галерею. Сейчас не буду отвлекать.", [("Варя", "Давай потом.")]), ("ask", "Есть знакомая куратор, Ася. Хочешь, познакомлю вас из-за зина? Ничего за тебя не обещал.", [("Варя", "Хочу. Только файл я сама ей отправлю. У меня там уже другая обложка."), ("Варя", "В четверг пробы забираю. Можно потом в галерею на полчаса, если она там.")])])
        if _return != "ask":
            return False
        $ connection_set(pair, first_consent=True)
        call week4_chat("asya", "connect_varya", [], [("later", "Есть одна авторка зина. Сначала ещё с ней обсужу, потом расскажу.", [("Ася", "Хорошо.")]), ("ask", "Варя делает зин с фотографиями дворов. Она хочет показать тебе сама. Можно дать ей твой контакт?", [("Ася", "Да, пусть пишет. В четверг после семи буду в галерее. Можно принести бумажный."), ("Ася", "За продажу пока не обещаю. Сначала посмотреть бы.")])])
    elif pair == "nika_lera":
        "Олег вспоминает, как по-разному Ника и Лера говорят о звуке. Интересно, что они услышат друг у друга."
        call week4_chat("nika", "connect_lera", [], [("keep", "Сейчас просто поесть важнее. Музыкальные идеи потом.", [("Ника", "Вот. Спасибо.")]), ("ask", "Хочу познакомить тебя с Лерой. Она играет электронную музыку. Можно дать ей твой контакт? Без рабочих просьб.", [("Ника", "Можно. Только не записывай меня никому в звукари."), ("Ника", "Послушать что-нибудь полчаса в четверг могу. И потом есть, я серьёзно.")])])
        if _return != "ask":
            return False
        $ connection_set(pair, first_consent=True)
        call week4_chat("lera", "connect_nika", [], [("later", "Потом хочу рассказать тебе про одну басистку. Сейчас не буду растягивать переписку.", [("Лера", "Давай.")]), ("ask", "Есть знакомая басистка Ника. Ей интересно послушать твоё. Можно вас познакомить? Ей сейчас без работы и организационных задач.", [("Лера", "Да! Я в четверг до семи смотрю маленький зал, бывший кинотеатр. Могу остаться до половины восьмого, включить пару кусков."), ("Лера", "И никому ничего отыгрывать не надо. Скинь ей мой контакт.")])])
    else:
        "Марта выбирает бумагу для карточек. У Вари после проб зина осталось несколько видов; Олег сам в них так и не разобрался."
        call week4_chat("marta", "connect_varya", [], [("keep", "Приду посмотреть твои пробы, если сегодня получится. Про знакомую потом расскажу.", [("Марта", "Хорошо.")]), ("ask", "Хочешь познакомлю тебя с Варей? Она фотографирует, сама печатает зин. Можно дать ей твой контакт?", [("Марта", "Да. Пусть напишет. Я сегодня в книжном с половины седьмого до семи, потом ухожу."), ("Марта", "Только готовой игры у меня ещё нет. Пробы покажу.")])])
        if _return != "ask":
            return False
        $ connection_set(pair, first_consent=True)
        call week4_chat("varya", "connect_marta", [], [("later", "Познакомлю тебя потом с авторкой одной настолки, когда обеим будет удобно.", [("Варя", "Давай.")]), ("ask", "Марта рисует дворы для настолки. Она согласна познакомиться. Хочешь её контакт?", [("Варя", "Да, пришли! У меня как раз пробы в рюкзаке."), ("Варя", "Сегодня к половине седьмого могу в книжный. До семи нормально.")])])
    if _return != "ask":
        return False
    $ connection_set(pair, second_consent=True, introduced=True)
    $ connection_event(pair, "introduced")
    "Получив оба ответа, Олег пересылает контакты. Дальше они пишут друг другу сами."
    if not connection_can_group(pair, host):
        return False
    if pair == "asya_varya":
        $ conn_private = "В четверг хочу оставить нашу встречу вдвоём. А вы отдельно договоритесь про зин."
        $ conn_shared = "Давай в четверг вместе посмотрим зин у Аси? Вместо обычной встречи. Потом останемся вдвоём."
        $ conn_reply = "Давай. В семь в галерее, Варя пробы по дороге заберёт. После половины восьмого уже вдвоём." if host == "asya" else "Давай. Я пробы по дороге заберу. В семь в галерее, а после половины восьмого вдвоём."
    elif pair == "nika_lera":
        $ conn_private = "В четверг хочу всё-таки поесть с тобой вдвоём. А музыку вы отдельно обсудите."
        $ conn_shared = "Хочу в четверг вместе послушать музыку в том зале. В семь, до половины восьмого. Потом поедим вдвоём?"
        $ conn_reply = "Давай. В семь в зале, в половине восьмого сворачиваемся и идём есть."
    else:
        $ conn_private = "Сегодня хочу зайти к тебе один. А с Варей потом отдельно спишетесь."
        $ conn_shared = "Давай сегодня втроём посмотрим пробы в книжном? К половине седьмого, как ты предложила."
        $ conn_reply = "Давай. Место на столе освобожу. До семи, я потом ухожу."
    call week4_chat(host, "group_" + pair, [], [("private", conn_private, [(week4_names[host], "Хорошо. Нашу встречу оставляем.")]), ("group", conn_shared, [(week4_names[host], conn_reply)])])
    if _return != "group":
        return False
    $ conn_other = next(p for p in connection_people[pair] if p != host)
    call week4_chat(conn_other, "group_confirm_" + pair, [], [("confirm", "Тогда встречаемся втроём в оговорённое время. Всё в силе?", [(week4_names[conn_other], "Да, буду. До половины восьмого." if pair != "marta_varya" else "Да, буду к половине седьмого. До семи.")])])
    $ connection_set(pair, group=True, host=host)
    $ connection_event(pair, "group_agreed")
    return True

label connections_pending_zine:
    if week4_entry.get("tasks", {}).get("gallery_zine") in ("connect", "promise"):
        call connection_offer("asya_varya", week4_plan if week4_plan in ("asya", "varya") else "asya")
    return

label connections_marta:
    call connection_offer("marta_varya", "marta")
    if _return:
        $ week4_event("marta", "midweek_invitation")
        call connection_cards
        return True
    return False

label connections_thursday:
    $ conn_pair = connection_active()
    if conn_pair == "asya_varya":
        call connection_gallery
    elif conn_pair == "nika_lera":
        call connection_music
    return
