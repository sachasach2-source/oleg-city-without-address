# Route memories and private follow-ups added only to chapters 3–4.
init python:
    def chapter3_tomorrow_plans():
        purposes = {"keys":"за ключами", "lera":"обед с Лерой", "varya":"встреча с Варей", "asya":"встреча с Асей", "nika":"с тобой встречаемся"}
        plans = [(p["time"], person) for person,p in chapter3_plans.items()
                 if p["status"] == "confirmed" and p["day"] == chapter3_day + 1 and p["time"] is not None]
        return ". Потом ".join(("В " if i == 0 else "в ") + chapter3_time(minute) + " " + purposes[person]
                               for i,(minute,person) in enumerate(sorted(plans))) + "." if plans else ""

init 10 python:
    # The source dialogue catalogue and all chapter1–2 nodes stay untouched.
    phone_dialogues["ch3_nika_home"] = {"start":{"messages":[], "options":[
        {"id":"home", "text":"Дома. Спасибо за вечер. Ты доехала?", "messages":[("Ника","Тоже дома. Чайник уже поставила."), ("Ника","Спокойной.")], "next":None},
        {"id":"warm", "text":"Добрался. Обратно опять мимо кофейни прошёл.", "messages":[("Ника","Я уже дома. И уже опять чай пью.")], "next":None}
    ]}}
    phone_dialogues["ch3_nika_home_song"] = {"start":{"messages":[("Олег","Доехал. И песня таиландская — Pixies, Here Comes Your Man."), ("Ника","Я тоже дома. Сейчас включу, пока чай делаю.")], "options":[{"id":"night","text":"Спокойной. До завтра.","messages":[("Ника","И тебе. Спасибо за вечер.")],"next":None}]}}
    phone_dialogues["ch3_lera_home"] = {"start":{"messages":[], "options":[
        {"id":"home", "text":"Я добрался. Ты хлеб целым донесла?", "messages":[("Лера","Половину. На кухне сразу вскрыли пакет."), ("Лера","И я дома, да. Хорошо погуляли.")], "next":None},
        {"id":"thanks", "text":"Дома. Хорошо было увидеться без рабочих звонков.", "messages":[("Лера","Я тоже рада. А звонок этот всё равно один пролез, зараза."), ("Лера","Отдыхай, я тоже уже дома.")], "next":None}
    ]}}
    import copy
    _buldak_found = copy.deepcopy(phone_dialogues["ch3_buldak_found"])
    for _node in _buldak_found.values():
        for _option in _node["options"]:
            _option["messages"] = [(sender, message.replace("Да, воды купил. Сижу на лавке.", "Да, жив. Воды купил, на лавке отсиделся. Теперь можно обратно в люди.")) for sender,message in _option.get("messages", [])]
    phone_dialogues["ch3_buldak_found"] = _buldak_found

label ch3_home_replies:
    if chapter3_tasks.get("nika_home_due", chapter3_tasks.get("nika_evening", -1)) == chapter3_day and chapter3_tasks.get("nika_home_sent", -1) != chapter3_day:
        "Ника просила написать. Олег достаёт телефон, пока не отвлёкся на общий чат."
        $ nika_home_chat = "ch3_nika_home_song" if chapter3_tasks.get("nika_evening_topic") == "song" else "ch3_nika_home"
        $ chapter3_chat_fresh(nika_home_chat)
        call screen phone_thread([], caption="Ника", conversation=nika_home_chat, past=phone_contact_history(nika_home_chat, "Ника"))
        $ chapter3_tasks["nika_home_sent"] = chapter3_day
    if chapter3_tasks.get("lera_home_due", chapter3_plans.get("lera", {}).get("day", -1) if chapter3_tasks.get("lera_private_walk") else -1) == chapter3_day and chapter3_tasks.get("lera_home_sent", -1) != chapter3_day:
        "Олег вспоминает про обещанное сообщение Лере."
        $ chapter3_chat_fresh("ch3_lera_home")
        call screen phone_thread([], caption="Лера", conversation="ch3_lera_home", past=phone_contact_history("ch3_lera_home", "Лера"))
        $ chapter3_tasks["lera_home_sent"] = chapter3_day
    return

label week4_nika_small_call:
    $ week4_stamp("Дома · звонок Нике", max(1230, week4_clock), 2)
    scene expression week4_home_bg() with dissolve
    call week4_chat("nika", "call_ready", [("Ника", "Я дома. Набираешь?")], [("yes", "Да. Сейчас наушники найду.", [("Ника", "Я без. Если чайник зашумит, это не репетиция.")]), ("postpone", "Прости. Я сегодня уже не вывожу разговор. Зря обещал это время.", [("Ника", "Я тебя ждала. В следующий раз давай сразу так и скажешь."), ("Ника", "Ладно. Отдыхай.")])])
    if _return == "postpone":
        $ week4_relations["nika"]["midweek_call"] = "missed"
        $ week4_open_issue("nika", "broken_plan", "Обещал звонок в среду, отменил в последний момент")
        return
    "В наушнике стукает кружка. Ника ставит телефон куда-то боком: пару секунд слышно только, как она устраивает его между книгами."
    n "Всё. Теперь слышно?"
    menu:
        "Можно выбрать, чем занять эти двадцать минут."
        "Спрошу про её новые записи.":
            o "Ты про новые начала писала. Что с ними?"
            n "С одним весь вечер сидела. Хотела голос дописать, а там как будто не я пою."
            o "В смысле?"
            n "Похоже на всё, что слушала на неделе. Пока записывала, радовалась: наконец-то есть мелодия, можно с ней что-то сделать."
            n "Потом пошла чай ставить, напеваю — и вспоминаю, откуда. Даже альбом открывать не надо."
            n "А если вообще ничего не слушать, у меня и в голове тишина. Я уже пробовала. Просто целый день не слушала музыку, и всё."
            "В трубке тихо щёлкают клавиши. Ника что-то включает и почти сразу выключает."
            n "Ладно, пока не буду. Хочу сама хотя бы понять, что показать."
            o "Давай. Тогда расскажи, что слушала."
            "Она называет альбом. Олег открывает его у себя; на третьем треке Ника просит вернуться на несколько секунд назад."
            $ nika_music["call_told"] = True
            $ week4_relations["nika"]["call_topic"] = "music_search"
        "Попросить сыграть тот переход, который у меня не выходит.":
            o "Ты можешь медленно? Не как «вот здесь просто», а прямо медленно."
            n "Могу. Подожди, акустику со шкафа сниму."
            "Она играет два аккорда и останавливается. Олег пробует повторить; первый раз выходит звонко и мимо."
            n "Ты руку уже переставил, а я ещё нет. Дождись меня."
            "Со второй попытки они попадают в переход вместе. Потом Ника нарочно играет ещё медленнее; Олег успевает возмутиться между аккордами."
            o "Завтра после мастера запишу. Скину без монтажа."
            n "Давай. Я свою медленную версию тоже сохраню."
            $ week4_relations["nika"]["call_topic"] = "guitar"
        "Рассказать, что в выходные осталось в голове.":
            if week4_entry["tasks"].get("nika_evening_topic"):
                o "Я до сих пор про картошку думаю. Вчера рис взял. По своей воле."
                n "Не пугай меня так. Я не готова за это отвечать."
            elif week4_relations["nika"]["last_status"] == "missed":
                o "Про то, как я не приехал. Я понимаю, что звонок это не исправляет."
                n "Не исправляет. Но мне лучше, что ты сейчас сам набрал."
            else:
                o "Я после выходных в понедельник ещё на телефоне время проверял. Будто опять куда-то собираться."
                n "Я один раз так на репетицию приехала в свой выходной. Даже обидно было, что дверь закрыта."
            "Ника рассказывает, как в ту поездку всё-таки купила себе завтрак и час просидела с ним на лестнице у студии. Олег сначала спрашивает про еду, потом они забывают про часы."
            $ week4_relations["nika"]["call_topic"] = "weekend"
    $ week4_clock += 20
    n "Чайник, кстати, давно вскипел. Я его так и не налила."
    o "Тогда отпускаю."
    n "Угу. Спасибо, что позвонил."
    $ week4_relations["nika"]["midweek_call"] = "done"
    $ week4_event("nika", "small_call_completed", week4_relations["nika"]["call_topic"])
    return
