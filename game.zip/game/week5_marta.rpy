init python:
    def week5_marta_known():
        return bool(week5_entry.get("marta", {}).get("contact") or week5_relations.get("marta", {}).get("known"))

    def week5_marta_state():
        for key,value in dict(plan="", limited=False, scene_done=False, tone="", next="", issue_acknowledged=False).items():
            week5_marta.setdefault(key,value)
        if week5_marta_known() and not week5_relations["marta"].get("known"):
            # Old chapter-select fixtures can contain a contact outside relations.
            week5_relations["marta"].update(known=True, mode=week5_entry.get("marta", {}).get("relation") or "uncertain")
        return week5_marta

    def week5_marta_events():
        return {x["event"] for x in week5_entry.get("relations", {}).get("marta", {}).get("events", [])}

    def week5_marta_record(event, detail=""):
        week5_event(event, detail, person="marta")
        week5_relations["marta"].setdefault("facts", {})["chapter5_marta"] = copy.deepcopy(week5_marta)

label week5_marta_friday:
    if not week5_marta_known():
        return
    $ week5_marta_state()
    if week5_entry.get("marta", {}).get("plan") == "walk":
        call week5_chat("marta", "saturday_walk", [("Марта", "Сегодня досдаю сканы, весь вечер за ними. А завтра гуляем? Мы же на эту субботу договаривались."), ("Марта", "photo:marta_route")], [("confirm", "Да. Давай в два у «Василеостровской»? Дальше пешком.", [("Марта", "Давай. Я как раз карточки из книжного заберу. Покажу, что хочу проверить.")]), ("cancel", "Я всё-таки не готов завтра обещать прогулку. Прости, что затянул с ответом.", [("Марта", "Жаль. Я этот день держала свободным."), ("Марта", "Ладно. Тогда пока не договариваемся.")])])
        if _return == "confirm":
            $ week5_marta.update(plan="saturday14", limited=bool(week5_issues("marta")))
            $ week5_promise = "marta_saturday_14"
        else:
            $ week5_marta["plan"] = "cancelled"
            $ week5_promise = "marta_cancelled"
        $ week5_marta_record(week5_promise)
    elif week5_issues("marta"):
        if "midweek_meeting" in week5_marta_events():
            "После короткой встречи в среду хочется увидеть Марту снова. Олег открывает переписку."
            $ week5_marta_retry = "Рад, что в среду увиделись. Хочешь завтра в два встретиться у «Василеостровской»? Пройдёмся без коробок."
        else:
            "Олег открывает Мартину переписку. Последнее сообщение всё ещё про кофе, на который он не приехал."
            $ week5_marta_retry = "Я сорвал наш кофе в понедельник и потом замолчал. Прости. Хочешь завтра в два встретиться у «Василеостровской»?"
        call week5_chat("marta", "missed_coffee", [], [("repair", week5_marta_retry, [("Марта", "Я в два буду из книжного выходить. Можем пройтись минут сорок пять. Потом у меня свои дела."), ("Олег", "Договорились. В два, на сорок пять минут.")]), ("space", "Я пока не буду звать ещё куда-то, если сам не уверен, что соберусь.", [("Марта", "Ладно. Тогда без новых договорённостей.")])])
        if _return == "repair":
            $ week5_marta.update(plan="saturday14", limited=True, issue_acknowledged=True)
            $ week5_promise = "marta_saturday_14"
            $ week5_relations["marta"]["issues"] = [dict(x,status="acknowledged") if x["status"] != "resolved" else x for x in week5_relations["marta"]["issues"]]
            $ week5_marta_record("marta_retry_agreed")
        else:
            $ week5_marta["plan"] = "space"
            $ week5_marta_record("marta_given_space")
    else:
        if "midweek_meeting" in week5_marta_events():
            $ week5_marta_incoming = "Привет. Забрала те, что в среду выбирали. Сегодня досдаю сканы, весь вечер за ними. Пока пришлю фото прежней раскладки, чтобы вспомнить маршрут."
        elif "monday_coffee" in week5_marta_events():
            $ week5_marta_incoming = "Привет. Помнишь карточки из понедельника? Сегодня досдаю сканы. Нашла фото их раскладки на столе."
        else:
            $ week5_marta_incoming = "Привет. Перерисовала часть карточек. Сегодня досдаю сканы, уже весь вечер под них отвела. Пока покажу прежнюю раскладку на столе, новые ещё не отсканировала."
        call week5_chat("marta", "new_cards", [("Марта", week5_marta_incoming), ("Марта", "photo:marta_route")], [("invite", "Хочу завтра пройтись с тобой. В два у «Василеостровской»? Покажешь эти дворы вживую.", [("Марта", "Да. Я как раз из книжного буду выходить. Заберу экземпляры и встретимся.")]), ("work", "На карточке справа лавка под деревом выглядит подозрительно удобной. В жизни такая же?", [("Марта", "В жизни она мокрая. У меня авторский произвол."), ("Марта", "Ладно, вернусь к сканам, а то они сами себя не отправят.")]), ("later", "Хочу спокойно рассмотреть. Сегодня вечером не обещаю, напишу, когда посмотрю.", [("Марта", "Хорошо. Я сегодня тоже до ночи со сканером, быстрый ответ не жду.")])])
        if _return == "invite":
            $ week5_marta["plan"] = "saturday14"
            $ week5_promise = "marta_saturday_14"
            $ week5_marta_record("marta_walk_invited")
        elif _return == "later":
            $ week5_relations["marta"]["promises"].append("Рассмотреть фото карточек и написать")
            $ week5_marta_record("marta_scan_reply_promised")
        else:
            $ week5_marta_record("marta_cards_discussed")
    call week5_marta_share_neighbourhood
    return

label week5_marta_saturday:
    if not week5_marta_known():
        return
    $ week5_marta_state()
    # The promise string is retained for saves made before this continuation.
    if week5_promise == "marta_saturday_14" and not week5_marta["plan"]:
        $ week5_marta["plan"] = "saturday14"
        $ week5_marta["limited"] = bool(week5_issues("marta"))
    if week5_marta["plan"] != "saturday14" or week5_marta["scene_done"]:
        return
    $ week5_stamp("Перед прогулкой", 780, 1)
    scene expression week5_home_bg() with fade
    "До выхода ещё есть время. Олег ест, проверяет дорогу и пишет Марте, что встретит её у метро, как договорились."
    call week5_marta_doorstep
    if _return:
        return
    $ week5_stamp("Линии Васьки", 840, 1)
    $ set_soundscape("ch3_outside")
    scene bg w5 marta yard empty with fade
    if week5_marta.get("doorstep_seen") or week5_marta.get("bakery_response") == "welcome":
        "От «Василеостровской» они идут вдоль Среднего, потом сворачивают в арку: на Мартиной карточке отсюда можно пройти ещё через два двора."
    elif week5_marta.get("bakery_seen"):
        "У «Василеостровской» Олег догоняет Марту. Она уже доела булку и достала папку из книжного; от метро они идут вдоль Среднего к первой арке на её маршруте."
    else:
        "Марта встречает его у «Василеостровской» с папкой из книжного. Они идут вдоль Среднего, потом сворачивают в арку: на её карточке отсюда можно пройти ещё через два двора."
    if week5_marta.get("bakery_response") == "welcome":
        "По дороге Марта доедает булку, выбрасывает обёртку в урну и достаёт из сумки блокнот с карточками."
    "Первая же калитка закрыта. За прутьями видно следующий двор. Рядом с замком прикручен новый домофон."
    scene bg w5 marta yard with dissolve
    m "Ага."
    o "Это мы уже проиграли?"
    m "Нет, пока только я. Я там проход нарисовала."
    "Она заглядывает в папку, затем снова смотрит на калитку."
    m "Можно дождаться кого-нибудь с ключом. Или вынесут вперёд ногами — тогда тоже откроют."
    "Олег смотрит через решётку. Марта уже достала карандаш."
    o "В правила не пиши."
    m "Это ты ещё другие карточки не видел."
    o "Новый домофон. Наверное, недавно закрыли."
    m "Угу. Допишу: «Останься на месте и послушай, как тебе не открывают»."
    if week5_marta["limited"]:
        m "Я про сорок пять минут помню. В половине третьего начну собираться обратно."
        o "Да. Я тоже помню."
    elif "sign_disagreement" in week5_marta_events():
        m "Только про площадку сегодня не будем. Я твой вопрос с понедельника помню."
        o "Хорошо. Не будем."
    elif "looked_at_work" in week5_marta_events():
        m "Рисунки, которые показывала в понедельник, тоже пересканила. Когда увеличиваешь, все мои исправления вылезают."
        o "Лавку опять чинила?"
        m "В этот раз дереву ветку вернула. Увлеклась уборкой."
    menu:
        "Мне нравится с ней это придумывать. Предложить обход.":
            o "Давай с улицы обойдём? Посмотрим, где можно сделать второй вход в твоей игре."
            m "Давай. Только ты пока запоминай, куда идём. Я сейчас начну смотреть на окна и забуду."
            $ week5_marta["tone"] = "shared_work"
        "Я хочу узнать, как у неё прошла неделя. Не только про карточки.":
            o "Как ты вообще? Всю неделю со сканером?"
            m "Почти. Вчера на каждом скане розовую полосу выдавал. Я сначала думала — подсветка такая."
            o "Разобралась?"
            m "Да. Теперь у меня чистое стекло и рукав в разводах. Сегодня его трогать не буду, выходной."
            $ week5_marta["tone"] = "personal"
    "Они выходят обратно к улице и огибают дом. Через следующий проход попадают во двор без фонтана, зато с длинной верёвкой белья между окнами. Марта какое-то время просто смотрит наверх."
    if week5_marta["tone"] == "personal":
        o "Что там?"
        m "Подоконник похож на мой в детстве. Мне на такой однажды ворона рисунок принесла."
        o "Как это?"
        m "Я альбом потеряла. Несколько дней его искала, уже думала — всё."
        m "Потом слышу: в окно стучат. Подошла — ворона сидит. А рядом на подоконнике мой лист. Не какой-то похожий, мой. Именно тот, которым я гордилась."
        m "Я ведь даже не видела, как она его положила. Только стук услышала."
        "Олег поднимает глаза к окнам. Марта проводит пальцем по краю папки."
        m "Альбом потом так и не нашёлся. Наверное, можно как-нибудь объяснить, откуда он взялся. Но я тогда так обрадовалась. И лист до сих пор храню. Мне нравится думать, что она его вернула."
        o "Я бы тоже сохранил."
        "Марта ещё раз смотрит на подоконник и возвращается к верёвке между окнами."
    # The return to the gate is explicit, so the plate does not stand in for the new yard.
    "Обратной дорогой они снова останавливаются перед той же калиткой. Марта отмечает обход в блокноте."
    if not week5_marta["limited"]:
        if week5_relations["marta"]["mode"] == "friendship":
            m "Хорошо, что вместе прошли. Я бы одна ещё полчаса караулила чьи-нибудь ключи."
            o "А я бы просто пошёл дальше и не заметил бельё."
            m "Вот его я и нарисую. У меня там пока одни парадные дворы, как будто люди только ходят и ничего не стирают."
            $ week5_marta["next"] = "friendship"
        else:
            if week5_relations["marta"].get("facts", {}).get("midweek_interest"):
                m "В следующий раз папку дома оставлю. А то опять весь город по работе обошла."
            else:
                m "Я когда тебя звала, не только проходы проверять хотела."
            menu:
                "Я тоже хотел увидеть тебя. Давай следующий раз устроим свидание?":
                    o "Я тоже хотел увидеть тебя. Давай в следующий раз без проверки маршрута? На свидание."
                    if "midweek_meeting" in week5_marta_events():
                        m "Да. Я хотела ещё в среду тебя спросить."
                    else:
                        m "Да. Я хотела сегодня тебя спросить."
                    "Она прикрывает блокнот ладонью, немного смеётся."
                    "Марта убирает блокнот в папку. Олег делает шаг к выходу из двора; она остаётся рядом."
                    m "Только давай без маршрута в следующий раз. Я уже другой день представила и опять начала дворы перебирать."
                    o "Я напишу тебе, придумаем день?"
                    m "Напиши. Только сначала день, потом я начинаю искать, что он значит."
                    $ week5_marta["next"] = "mutual_date_interest"
                    $ week5_marta_record("marta_mutual_date_interest")
                "Мне хорошо с ней дружить. Скажу прямо.":
                    o "Мне хорошо с тобой гулять. Но я сейчас хочу общаться по-дружески. Не хочу, чтобы ты гадала."
                    m "Жаль. Я всё-таки надеялась."
                    "Она разглаживает пальцем загнутый угол папки."
                    m "Давай пока просто допойдём? Я не готова сейчас сразу переключиться."
                    o "Давай."
                    $ week5_marta["next"] = "friendship_requested"
                    $ week5_relations["marta"]["mode"] = "friendship"
                    $ week5_marta_record("marta_friendship_named")
    else:
        m "Мне пора обратно. Спасибо, что сегодня всё-таки пришёл."
        o "Спасибо, что согласилась."
        m "Я пока новых встреч не обещаю. Потом спишемся."
        $ week5_marta["next"] = "cautious"
    call week5_marta_attention_after_walk
    $ week5_stamp("После прогулки с Мартой", 885 if week5_marta["limited"] else 915, 1)
    if week5_marta.get("walk_home"):
        scene bg w5 marta doorstep with fade
        "Они возвращаются к дому Олега. У пекарни Марта останавливается сама."
        m "Дальше не провожаю. Мне ещё коробки забирать."
        if week5_marta.get("next") == "mutual_date_interest":
            "Она говорит это, но ещё не поворачивается уходить. Олег слышит, как под её пальцами поскрипывает ручка сумки. После всей прогулки эта короткая пауза почему-то смущает сильнее разговора о свидании."
        o "Напишешь, как добралась?"
        m "Напишу. Сама. У ворон сегодня выходной."
        $ week5_stamp("У дома после прогулки", 955, 1)
    else:
        "Они прощаются у поворота к книжному. Марта уходит со своей папкой; Олег ещё раз смотрит на двор с закрытым проходом и выходит к Среднему."
    $ week5_marta["scene_done"] = True
    $ week5_relations["marta"]["promises"] = [x for x in week5_relations["marta"]["promises"] if "Прогулка в следующую субботу" not in x]
    $ week5_marta_record("marta_saturday_walk", week5_marta["next"])
    return

image bg w5 marta yard empty = Transform("images/week5/marta-yard-gate-v1.webp", xysize=(1600,900))
image bg w5 marta yard = Transform("images/week5/marta-yard-gate-v1.webp", xysize=(1600,900))
init -9 python:
    cast_assets[("marta", "week5")] = {"neutral":"images/week5/marta-outdoor-left-v1.webp"}
    cast_stages["w5 marta yard"] = ("images/week5/marta-yard-gate-v1.webp", [("oleg","outdoor",420,55,920),("marta","week5",1240,35,1280)], None, "shade")
init python:
    phone_media["photo:marta_route"] = {"path":"images/chapter4/marta-cards-close-v1.webp", "title":"Марта · карточки дворов", "caption":"Карточки дворов · фото на столе"}
