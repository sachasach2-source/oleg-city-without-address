init -6 python:
    ui_focus_screens = ("chapter_card","ending_card","chapter3_ending","chapter4_ending","week4_ending","week5_ending","week6_ending","week6_draft_end","week7_ending","chapter4_prepare","phone_thread","week5_incoming_call","vignette_board","vignette_done","shawarma_game","marta_route","week7_party_map","week7_devils_dice","week7_oracle_pick","week7_oracle_result")
    ui_own_controls = ("chapter_card","ending_card","chapter3_ending","chapter4_ending","week4_ending","week5_ending","week6_ending","week6_draft_end","week7_ending","chapter4_prepare","phone_thread","week5_incoming_call","vignette_board","vignette_done","shawarma_game","marta_route","week7_party_map")
    ui_focus_screens += ("week7_phone_inbox", "messenger_browser", "messenger_session_list", "messenger_topic_picker")
    ui_own_controls += ("week7_phone_inbox", "messenger_browser", "messenger_session_list", "messenger_topic_picker")
    ui_media_screens = ("phone_photo_viewer","phone_voice_viewer","week7_attachment_archive")
    ui_focus_screens += ui_media_screens
    ui_own_controls += ui_media_screens+("week7_devils_dice","week7_oracle_pick","week7_oracle_result")
    ui_story_choice_screens = ("choice","chapter3_intentions","chapter3_planner","chapter3_revise_plans","chapter3_day_agenda","chapter3_reschedule","chapter4_prepare")
    ui_focus_screens = tuple(name for name in ui_focus_screens if name!="chapter4_prepare")
    ui_own_controls = tuple(name for name in ui_own_controls if name!="chapter4_prepare")

    def ui_in_menu():
        return main_menu or renpy.context()._menu

    def ui_dialogue_visible():
        return not ui_in_menu() and not any(renpy.get_screen(name) for name in ui_focus_screens+ui_story_choice_screens+("confirm",))

    def ui_quick_visible():
        return quick_menu and not ui_in_menu() and not any(renpy.get_screen(name) for name in ui_own_controls+("confirm",))

    def ui_choice_prompt():
        say = renpy.get_screen("say")
        if not say: return ""
        who,what = say.scope.get("who"),say.scope.get("what","")
        return (str(who)+": " if who else "")+what

    def ui_options_geometry(options,width,size,prompt):
        text_width = width-102
        heights = [int(renpy.render(Text(caption,size=size,line_spacing=2,xmaximum=text_width),text_width,2000,0,0).get_size()[1])+24 for caption,action in options]
        content = sum(heights)+10*max(0,len(options)-1)
        prompt_h = int(renpy.render(Text(prompt,size=story_text_size(22),line_spacing=3,xmaximum=width-44),width-44,2000,0,0).get_size()[1]) if prompt else 0
        limit = max(100,600-100-prompt_h)
        # Start and finish on complete rows; a clipped answer looks disabled.
        visible = 0
        for height in heights:
            next_height = visible+(10 if visible else 0)+height
            if next_height > limit and visible:
                break
            visible = next_height
        visible = min(visible,limit)
        return int(visible),int(content)

style ui_primary_button is button:
    background DynamicDisplayable(lambda st,at:(context_panel("choice_button"),None))
    hover_background DynamicDisplayable(lambda st,at:(context_panel("choice_button",True),None))
style ui_primary_button_text is button_text:
    color "#192b30"
    hover_color "#101c24"

screen ui_story_options(heading,options,prompt="",width=1000,left=54,bottom=840,size=24):
    $ reading_size = story_text_size(size)
    default option_scroll = ui.adjustment()
    $ visible,content = ui_options_geometry(options,width,reading_size,prompt)
    frame:
        xpos left ypos bottom yanchor 1.0 xsize width padding (22,18)
        background context_panel("choice")
        vbox:
            spacing 12 xfill True
            text heading size 15 color "#e4c698" kerning 2
            if prompt:
                text prompt size story_text_size(22) line_spacing 3 xmaximum width-44
            hbox:
                spacing 10
                viewport:
                    id "story_option_list"
                    xsize width-62 ysize visible
                    yadjustment option_scroll
                    mousewheel True draggable True
                    vbox:
                        spacing 10 xsize width-62
                        for caption,action in options:
                            button:
                                action action
                                xfill True padding (20,12)
                                background context_panel("choice_button") hover_background context_panel("choice_button",True)
                                text caption size reading_size line_spacing 2 color "#162536" hover_color "#101c29" xmaximum width-102
                if content>visible:
                    vbar adjustment option_scroll style "vscrollbar" xsize 8 ysize visible
            if content>visible:
                text "Прокрути, чтобы увидеть остальные варианты ↓" size 15 color "#c8b793"
