# A single playable fragment of Marta's prototype, inside the chapter-three meeting.
default chapter4_board = None

init python:
    marta_route_nodes = (
        ("Вход", 120, 340), ("Арка", 380, 195), ("Двор с деревом", 380, 485),
        ("Сквозной двор", 650, 195), ("Двор-колодец", 650, 485),
        ("Фонтан", 920, 195), ("Соседняя арка", 920, 485),
    )
    marta_route_links = ((1, 2), (0, 3, 5), (0, 4), (1, 4, 5), (2, 3, 6), (1, 3), (4,))

    def marta_route_start():
        return dict(path=[0], result="", score=0, line="Три хода до фонтана. Зелёная фишка твоя. Выбирай соседний двор — по линии.")

    def marta_route_options(state):
        if state["result"]:
            return []
        position = state["path"][-1]
        return [node for node in marta_route_links[position]
                if not (len(state["path"]) > 1 and {position, node} == {1, 5})]

    def marta_route_step(state, node):
        # Replace the whole value: screen re-evaluation, saves and rollback must not
        # mutate a previous turn's path or apply a move twice.
        if state["result"]:
            return state
        if node == "skip":
            return dict(path=list(state["path"]), result="watched_route", score=state.get("score", 0), line="Марта подвигает листок к себе и показывает оставшийся путь.")
        if node not in marta_route_options(state):
            return state
        path = list(state["path"]) + [node]
        result = "fountain" if node == 5 else "wrong_courtyard" if node == 6 else "blocked_route" if len(path) == 4 else ""
        if result == "fountain":
            line = "Да, это мой фонтан. Дошёл! А я хотела ещё дворника сюда поставить."
        elif result == "wrong_courtyard":
            line = "Стой. Это соседняя арка. Ты пришёл в другой двор."
        elif result:
            line = "Три хода. Всё, дворник запирает ворота. Фонтан пока без нас."
        elif len(path) == 2:
            line = "А теперь калитка закрылась. Вот эта, от арки к фонтану. Придётся обходить."
        elif node == 3:
            line = "Тут сквозной проход. Фонтан уже видно — только не сверни снова в колодец."
        elif node == 4:
            line = "Там тоже арка. Погоди, я сама посмотрю… Нет, играй. Не буду подсказывать."
        else:
            line = "Вернулся ко входу? Можно. Но потраченный ход не возвращается."
        return dict(path=path, result=result, score=100 * len(set(path[1:])) + (700 if result == "fountain" else 0), line=line)

transform marta_route_slide(old_x, old_y, new_x, new_y):
    xpos old_x ypos old_y
    ease .22 xpos new_x ypos new_y

screen marta_route(state, finished=False):
    modal True
    zorder 80
    add Solid("#17100caa")
    add "images/chapter4/marta-route-paper.svg" xpos 38 ypos 105
    text "ДОЙТИ ДО ФОНТАНА" xpos 86 ypos 137 size 27 color "#403b31" kerning 2
    $ turns = len(state["path"]) - 1
    text ("Ход %d из 3" % min(turns + 1, 3) if not state["result"] else "У фонтана" if state["result"] == "fountain" else "Конец партии") xpos 88 ypos 180 size 20 color "#726554"
    $ possible = marta_route_options(state)
    $ position = state["path"][-1]
    for node, (title, nx, ny) in enumerate(marta_route_nodes):
        $ active = node in possible and not finished
        button:
            xpos nx + 38 - 88 ypos ny + 105 - 61
            xysize (176, 122)
            padding (0, 0)
            background Solid("#f8edce00")
            hover_background Solid("#d3ad6950")
            sensitive active
            action Return(node)
            selected node == position
            focus_mask None
            tooltip title
            if active:
                add "images/chapter4/marta-route-focus.svg"
            text title xalign .5 ypos 101 size 18 color ("#304c3a" if active else "#514739")
        if node == position:
            $ previous = marta_route_nodes[state["path"][-2] if len(state["path"]) > 1 else position]
            add "images/chapter4/marta-route-pawn.svg" at marta_route_slide(previous[1] + 21, previous[2] + 75, nx + 21, ny + 75)
        elif node in state["path"]:
            text "·" xpos nx + 38 - 9 ypos ny + 105 - 24 size 44 color "#487455"
    if turns:
        frame:
            xpos 631 ypos 177 padding (10, 5) background Solid("#f0dfbd")
            text "×  КАЛИТКА ЗАКРЫТА" color "#8e493d" size 17
    else:
        text "калитка" xpos 705 ypos 183 size 17 color "#786a55"
    frame:
        xpos 1197 ypos 138 xsize 352 padding (25, 25)
        background mini_surface("marta")
        vbox:
            spacing 18
            text ("%04d ОЧКОВ" % state.get("score", 0)) color "#566f4b" size 32
            text "МАРТА" color "#7a725a" size 19 kerning 2
            text state["line"] color "#3e5140" size 25 line_spacing 5
            null height 12
            text "Зелёным обведены дворы, куда можно пойти. Нажми на один из них." color "#7a725a" size 19
    if not finished:
        textbutton "Пропустить партию":
            properties mini_button("marta")
            xpos 1200 ypos 735 xsize 350
            text_size 20
            action Return("skip")
    else:
        timer .7 action Return("done")
    text "Марта набросала проходы на обороте пробы." xpos 86 ypos 795 size 19 color "#e3d2b6"
    use minigame_system("marta")
    key "game_menu" action ShowMenu()
    key "rollback" action Rollback()

label marta_route_game:
    $ chapter4_board = marta_route_start()
    window hide
    while not chapter4_board["result"]:
        call screen marta_route(chapter4_board)
        $ chapter4_board = marta_route_step(chapter4_board, _return)
    if chapter4_board["result"] != "watched_route":
        call screen marta_route(chapter4_board, finished=True)
    if chapter4_board["result"] != "watched_route":
        $ vignette_record_score("marta", chapter4_board["score"])
    $ chapter4_game_moment = chapter4_board["result"]
    return
