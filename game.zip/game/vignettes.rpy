# One-scene interactions. Choices and relationship outcomes belong to the story.
default vignette_state = None
default vignette_history = {}
default persistent.vignette_records_v2 = {}

init -12 python:
    import copy as vignette_copy
    import math as vignette_math
    import os as vignette_os

    vignette_titles = {
        "photo": ("РУИНЫ РАБОЧЕГО ДНЯ", "Варя · третья глава", "Снять кадр", "Убрать камеру"),
        "riff": ("ЕЩЁ ОДИН КРУГ", "Ника · третья глава", "Послушать фразу", "Просто сыграть вместе"),
        "studio": ("ОЧЕНЬ КАМЕРНО", "Просмотр студии · третья глава", "Собрать план", "Оставить как есть"),
        "hum": ("ОТКУДА ГУДИТ", "Лера · третья глава", "Послушать", "Дать Лере закончить"),
        "laundry": ("ПЯТЬ ОДИНАКОВЫХ", "У Леры · четвёртая глава", "Проверить сушилку", "Развесить без спешки"),
        "box": ("НЕ КАНТОВАТЬ. НАВЕРНОЕ", "Сашина посылка · четвёртая глава", "Пойти", "Перехватить и донести"),
        "shadow": ("МОРЕ ПО ЛОКОТЬ", "Уля · шестая глава", "Замри!", "Посмотреть на волну"),
        "balloons": ("ВЫШЕ КРЫШ", "Двое · пятая глава", "Полетели", "Остаться за кадром"),
    }
    vignette_instructions = {
        "photo": "Перетащи рамку. + / − меняют крупность, Q / E — горизонт. Стрелки тоже двигают рамку. Три снимка; Варя подскажет, что ищет.",
        "riff": "Послушай фразу Ники и запомни порядок нот. Повтори кнопками A / D в любом темпе. Можно послушать ещё раз; очки зависят от ошибок и повторных прослушиваний.",
        "studio": "Сдвигай мебель в свободные клетки, как в пятнашках. Собери расстановку с образца справа. Выбери предмет и нажми стрелку; можно перетащить на соседнюю клетку.",
        "hum": "Найди вход для плеера. Убери гудящий возврат, сохрани слышимую музыку. Ползунки можно двигать мышью и стрелками после выбора.",
        "laundry": "Развесь 10 вещей. R складывает футболку: 3 клетки → 2. Носок: 1, тёмные трусы: 2, боксеры: 3. Между вещами — пустая клетка.",
        "box": "← / → или две кнопки подправляют хват. Наклон начинает разгоняться — перехватывай заранее. Нужно дойти до театра, не заглядывая внутрь.",
        "shadow": "Зажми мышь у золотой точки и обведи светлый контур одним движением. Отпусти у кольца. Олег повторит жест перед проектором. Скорость не важна — важна форма.",
        "balloons": "Держи пробел или кнопку, чтобы твой шар поднимался; отпускай, чтобы остывал. Второй шар ловит свой ветер. Попробуйте лететь рядом. Спешка тут смешнее пользы.",
    }
    vignette_colours = {"photo":"#d8bb86", "riff":"#b3b8ef", "studio":"#7dc6bf", "hum":"#e9a269", "laundry":"#b1cfa9", "box":"#d9b482", "shadow":"#83d9df", "balloons":"#ecb4c6"}
    vignette_opening_notes = {"photo":"Варя ждёт первый снимок.", "riff":"Сначала слушаешь, потом играешь. Спешить не нужно.", "studio":"Начни со стула: слева от него свободная клетка. Затем выбирай другие предметы.", "hum":"Лера держит сигнальный провод.", "laundry":'Носками можно занять узкие места. Складывать футболки необязательно.', "box":"Паша заклеил коробку на совесть.", "shadow":"Начни у золотой точки. Мышь можно вести медленно.", "balloons":"Свет остался внизу."}
    vignette_photo_targets = ((535, 255, .7, "Арка целиком. И табличка «Офис» — чтобы руины не притворялись древними."), (729, 114, 1.55, "Теперь табличку крупнее. Только целиком, вместе с последней буквой."), (278, 365, 1.25, "И зелёный стул у двери. Кто-то вышел обедать в наши руины."))
    vignette_shadow_targets = ((270, 220, .85), (650, 300, 1.25), (480, 160, 1.0))
    # Compact sliding furniture puzzle. The plan is a paper thought experiment,
    # not a change to the actual studio's sofa/fridge constraints.
    vignette_furniture = (
        ("ДИВАН", 2, 2, "#b98167", "sofa"),
        ("СТОЛ", 2, 1, "#d5b67c", "desk"),
        ("ШКАФ", 1, 2, "#799898", "wardrobe"),
        ("ХОЛОД.", 1, 1, "#bac7b5", "fridge"),
        ("ПОЛКА", 1, 1, "#af997a", "shelf"),
        ("СТУЛ", 1, 1, "#b3ad77", "chair"),
        ("ГИТАРА", 1, 1, "#a88ba8", "guitar"),
    )
    vignette_studio_goal = ((0, 0), (2, 0), (3, 1), (2, 1), (0, 2), (1, 2), (0, 3))
    vignette_studio_scramble = ((5, (1, 0)), (2, (0, 1)), (5, (0, 1)), (5, (-1, 0)), (3, (0, 1)), (4, (1, 0)), (3, (0, 1)), (4, (1, 0)), (5, (0, -1)), (4, (0, -1)), (5, (0, 1)), (6, (0, -1)), (2, (0, -1)), (6, (0, 1)), (4, (0, 1)), (0, (0, 1)), (1, (-1, 0)), (1, (-1, 0)), (3, (1, 0)), (4, (0, -1)), (5, (1, 0)), (1, (1, 0)), (4, (0, 1)), (6, (1, 0)), (4, (0, -1)), (1, (-1, 0)), (4, (0, 1)), (6, (-1, 0)))

    def vignette_studio_can(layout, item, delta):
        x, y = layout[item]
        x, y = x + delta[0], y + delta[1]
        w, h = vignette_furniture[item][1:3]
        if x < 0 or y < 0 or x + w > 4 or y + h > 4:
            return False
        cells = {(x + dx, y + dy) for dx in range(w) for dy in range(h)}
        for other, (ox, oy) in enumerate(layout):
            if other == item:
                continue
            ow, oh = vignette_furniture[other][1:3]
            if cells.intersection((ox + dx, oy + dy) for dx in range(ow) for dy in range(oh)):
                return False
        return True

    def vignette_studio_layout():
        layout = list(vignette_studio_goal)
        for item, delta in vignette_studio_scramble:
            x, y = layout[item]
            layout[item] = (x + delta[0], y + delta[1])
        return layout

    def vignette_studio_matches(s):
        return sum(tuple(pos) == target for pos, target in zip(s["layout"], vignette_studio_goal))

    def vignette_award(s, points, perfect=False):
        s["combo"] = s["combo"] + 1 if perfect else 0
        s["best_combo"] = max(s["best_combo"], s["combo"])
        multiplier = 1 + min(4, max(0, s["combo"] - 1)) * .25
        gain = int(round(points * multiplier))
        s["score"] += gain
        s["last_gain"] = gain
        s["feedback_id"] += 1
        return gain

    def vignette_record_score(kind, score, synthetic=False):
        # Author-selected reactions and automatic solvers are not personal bests.
        if synthetic or vignette_os.environ.get("OLEG_QA_REPORT_DIR"):
            return False
        key = vignette_score_key(kind)
        previous = persistent.vignette_records_v2.get(key, 0)
        if score > previous:
            persistent.vignette_records_v2[key] = score
            postcard_game_reward(key, score)
            return True
        return False

    def vignette_start(kind):
        state = dict(kind=kind, result="", ticks=0, running=False, note=vignette_opening_notes[kind],
            version=(6 if kind == "laundry" else 3), folded=[False] * (vignette_laundry_count if kind == "laundry" else 5), cursor=0, riff_phase="ready", phrase_input=[], prefix_best=0, play_ticks=0, replays=0, phrase_errors=0, trace_points=[], combo=0, best_combo=0, last_gain=0, feedback_id=0, moves=0, layout=vignette_studio_layout(), layouts=[],
            score=0, rounds=0, grades=[], x=480, y=300, zoom=1.0, angle=0,
            bumps=0, selected=0,
            source=0, level=70, feedback=75, attempts=0, places={},
            lean=-.2, velocity=.015, sway=0.0, pump=False, height=.35, together=0, squeaks=0, judged=[])
        if kind == "studio":
            state["selected"] = 5
            state["score"] = vignette_studio_matches(state) * 100
        return state

    def vignette_hum(state):
        noise = min(1.0, state["feedback"] / 100.0 * .8 + (.55 if state["source"] != 1 else 0))
        music = state["level"] / 100.0 if state["source"] == 1 else .15
        return noise, music

    def vignette_grade(state, quality, final=False):
        quality = max(0, min(100, int(round(quality))))
        state["grades"].append(quality)
        vignette_award(state, quality * 10, quality >= 85)
        state["rounds"] += 1
        if final:
            state["result"] = "smooth" if sum(state["grades"]) / len(state["grades"]) >= 65 else "funny"
        return quality

    def vignette_step(previous, action):
        state = vignette_copy.deepcopy(previous)
        if state["result"] or not action:
            return state
        command = action[0] if isinstance(action, (tuple, list)) else action
        value = action[1] if isinstance(action, (tuple, list)) and len(action) > 1 else None
        kind = state["kind"]
        if kind == "laundry" and command in ("laundry_select", "laundry_cursor", "fold", "unhang", "hang", "laundry_finish"):
            return vignette_laundry_action(state, command, value)
        if kind == "riff" and command in ("start", "pluck"):
            return vignette_riff_action(state, command, value)
        if kind == "shadow" and command == "trace":
            quality = vignette_trace_quality(value, vignette_shadow_paths[state["rounds"]][1])
            state["trace_points"] = list(value)
            grade = vignette_grade(state, quality, state["rounds"] == 2)
            state["note"] = "Силуэт узнаётся!" if grade >= 70 else "Волна получилась с характером. Следующий дубль."
            return state
        if command == "reset" and kind == "studio":
            return vignette_start(kind)
        if command == "skip":
            state["result"] = "skipped"
            state["pump"] = False
            return state
        if command == "start" and kind in ("box", "balloons"):
            state["running"] = True
            state["note"] = "К театру. Коробка закрыта, телефон в кармане." if kind == "box" else "У каждого свой ветер."
        elif command == "move":
            state["x"] = max(150, min(810, state["x"] + value[0]))
            state["y"] = max(100, min(450, state["y"] + value[1]))
        elif command == "position":
            state["x"], state["y"] = max(150, min(810, value[0])), max(100, min(450, value[1]))
        elif command == "zoom":
            state["zoom"] = max(.65, min(1.8, round(state["zoom"] + value, 2)))
        elif command == "angle":
            state["angle"] = max(-12, min(12, state["angle"] + value))
        elif command == "capture" and kind == "photo":
            state.setdefault("shots", []).append({key:state[key] for key in ("x", "y", "zoom", "angle")})
            targets = vignette_photo_targets if kind == "photo" else vignette_shadow_targets
            tx, ty, tz = targets[state["rounds"]][:3]
            distance = vignette_math.hypot(state["x"] - tx, state["y"] - ty)
            quality = max(0, 100 - distance * .24 - abs(state["zoom"] - tz) * 60 - (abs(state["angle"]) * 2 if kind == "photo" else 0))
            grade = vignette_grade(state, quality, state["rounds"] == 2)
            state["note"] = ("Есть. Вот это оставим." if grade >= 78 else "Не ровно, зато видно, что мы тут были." if grade >= 45 else "Погоди. Это уже соседний сюжет.") if kind == "photo" else ("Да! Пальцы в пене." if grade >= 78 else "Волна убежала. Этот тоже сохраним.")
        elif command == "furniture" and kind == "studio":
            state["selected"] = value
            state["note"] = "Выбран: %s. Сдвинь в свободную клетку." % vignette_furniture[value][0].lower()
        elif command in ("slide", "undo") and kind == "studio":
            if command == "undo":
                if state["layouts"]:
                    state["layout"] = state["layouts"].pop()
                    state["moves"] += 1
            else:
                item, delta = value
                state["selected"] = item
                if vignette_studio_can(state["layout"], item, delta):
                    state["layouts"].append(list(state["layout"]))
                    x, y = state["layout"][item]
                    state["layout"][item] = (x + delta[0], y + delta[1])
                    state["moves"] += 1
                    state["note"] = "Предметов на месте: %d из 7." % vignette_studio_matches(state)
                else:
                    state["bumps"] += 1
                    state["note"] = "Тут занято. Сначала освободи соседнюю клетку."
            old_score = state["score"]
            matched = vignette_studio_matches(state)
            state["score"] = matched * 100
            if matched == 7:
                state["score"] += max(0, 600 - state["moves"] * 8 - state["bumps"] * 15)
                state["result"] = "smooth" if state["moves"] <= 55 and state["bumps"] < 6 else "funny"
            state["last_gain"] = max(0, state["score"] - old_score)
            state["feedback_id"] += 1
        elif command == "source" and kind == "hum":
            state["source"] = value
        elif command == "listen" and kind == "hum":
            state["attempts"] += 1
            noise, music = vignette_hum(state)
            before_score = state["score"]
            grade = vignette_grade(state, 100 - noise * 100 - max(0, .35 - music) * 180 - max(0, music - .8) * 100)
            state["score"] = max(state["grades"]) * 10 + (max(0, 600 - state["attempts"] * 200) if grade >= 85 else 0)
            state["last_gain"] = max(0, state["score"] - before_score)
            state["note"] = "Тихо. И музыка осталась." if grade >= 85 else "Гул остался в возврате." if noise > .2 else "Вместе с гулом пропала и музыка."
            if grade >= 85 or state["attempts"] >= 3:
                state["result"] = "smooth" if grade >= 85 else "funny"
        elif command == "steady" and kind == "box" and state["running"]:
            state["velocity"] += value * .017
            state["lean"] = max(-1, min(1, state["lean"] + value * .10))
        return state

    def vignette_clock_step(previous):
        state = vignette_copy.deepcopy(previous)
        if state["result"] or not state["running"]:
            return state
        state["ticks"] += 1
        t = state["ticks"] * .05
        if state["kind"] == "riff":
            vignette_riff_clock(state)
        elif state["kind"] == "box":
            state["velocity"] = state["velocity"] * .96 + (.6 + vignette_math.sin(t * 1.4) + .7 * vignette_math.sin(t * 2.7)) * .0016
            state["lean"] += state["velocity"]
            state["sway"] += abs(state["lean"])
            if abs(state["lean"]) > 1:
                state["bumps"] += 1
                state["lean"] *= .35
                state["velocity"] *= -.2
                state["score"] = max(0, state["score"] - 150)
                state["combo"] = 0
                state["note"] = "Перехватил. Скотч целый; дальше медленнее."
            if state["ticks"] % 10 == 0:
                vignette_award(state, max(0, round(50 * (1 - abs(state["lean"])))), abs(state["lean"]) < .15)
            if t >= 18:
                state["result"] = "smooth" if state["bumps"] == 0 else "funny"
        elif state["kind"] == "balloons":
            target = vignette_balloon_target(state)
            state["height"] = max(.08, min(.92, state["height"] + (.010 if state["pump"] else -.006)))
            if abs(state["height"] - target) < .15:
                state["together"] += 1
                if state["ticks"] % 5 == 0:
                    vignette_award(state, 25, abs(state["height"] - target) < .06)
            elif state["ticks"] % 5 == 0:
                state["combo"] = 0
            if state["height"] >= .9 and state["ticks"] % 25 == 0:
                state["squeaks"] += 1
                state["note"] = "Из-за облака недовольно гудит утка."
            if t >= 16:
                state["result"] = "smooth" if state["together"] >= 110 else "funny"
                state["pump"] = False
        return state

    def vignette_balloon_target(state):
        t = state["ticks"] * .05
        return .48 + .20 * vignette_math.sin(t * .7) + .06 * vignette_math.sin(t * 1.9)

    def vignette_tick():
        # The clock lives in saved state. Menus pause it; loading resumes that tick.
        global vignette_state
        vignette_state = vignette_clock_step(vignette_state)
        if vignette_state["kind"] == "riff" and vignette_state["riff_phase"] == "listen":
            tick = vignette_state["play_ticks"]
            phrase = vignette_riff_phrases[vignette_state["rounds"]]
            if tick % 12 == 1 and tick // 12 < len(phrase):
                lane = phrase[tick // 12]
                renpy.music.play("audio/gimmicks/note-low.wav" if lane == 0 else "audio/gimmicks/note-high.wav", channel="vignette_backing")
        renpy.retain_after_load()
        if vignette_state["result"]:
            renpy.end_interaction(("clock_done", None))
        else:
            renpy.restart_interaction()

    def vignette_live_action(command, value):
        # Continuous play stays in one interaction: rapid input must not restart
        # the screen timer and let a player freeze the journey or the music.
        global vignette_state
        before_score = vignette_state["score"]
        vignette_state = vignette_step(vignette_state, (command, value))
        if command == "hang" and vignette_state["score"] > before_score:
            renpy.sound.play("audio/gimmicks/note-high.wav")
        if command == "pluck":
            renpy.sound.play("audio/gimmicks/note-low.wav" if value == 0 else "audio/gimmicks/note-high.wav")
        renpy.retain_after_load()
        if vignette_state["result"]:
            renpy.end_interaction(("clock_done", None))
        else:
            renpy.restart_interaction()

    def vignette_pump(held):
        if vignette_state and vignette_state["kind"] == "balloons":
            vignette_state["pump"] = held
            renpy.retain_after_load()

    def vignette_release_after_load():
        # A physical held key cannot be restored by loading a save.
        if vignette_state:
            vignette_state["pump"] = False
            vignette_clear_trace()
            if vignette_state["kind"] == "laundry" and vignette_state.get("version") in (3, 4, 5) and not vignette_state["result"]:
                old_version = vignette_state["version"]
                row, col = divmod(vignette_state["cursor"], {3:8, 4:11, 5:14}[old_version])
                # Version 5 had underwear at index 7; index 7 is now the odd sock.
                if old_version == 5 and 7 in vignette_state["places"]:
                    vignette_state["places"][8] = vignette_state["places"].pop(7)
                if old_version == 5 and vignette_state["selected"] == 7:
                    vignette_state["selected"] = 8
                vignette_state.update(version=6, cursor=row * vignette_laundry_columns + col)
                vignette_state["folded"] += [False] * (vignette_laundry_count - len(vignette_state["folded"]))
                vignette_state["score"] = vignette_laundry_score(vignette_state)
                renpy.retain_after_load()
            if vignette_state.get("version", 1) < (3 if vignette_state["kind"] in ("laundry", "riff", "shadow") else 2):
                vignette_state.update(vignette_start(vignette_state["kind"]))

    def vignette_drag_position(drags, drop):
        drag = drags[0]
        renpy.end_interaction(("position", (drag.x + drag.w / 2, drag.y + drag.h / 2)))
        return True

    def vignette_summary(state):
        if state["result"] == "skipped":
            return "Продолжим сцену"
        if state.get("context") in ("solo_recording", "solo_practice"):
            return "Фраза вспомнилась" if state["result"] == "smooth" else "Можно записать помедленнее"
        return {
            "photo": "Три кадра для Вари" if state["result"] == "smooth" else "У двора нашёлся неожиданный ракурс",
            "riff": "Попали в один круг" if state["result"] == "smooth" else "Живая запись. Очень живая",
            "studio": "Вещи поместились. Квадратных метров не прибавилось",
            "hum": "Гул ушёл, музыка осталась" if state["result"] == "smooth" else "Лера подхватила последний поворот",
            "laundry": "Всё развешено. Сушилка стоит ровно" if state["result"] == "smooth" else "Всё на месте. Край ещё перевешивает",
            "box": "Коробка доехала закрытой",
            "shadow": "Тень тоже побывала на море",
            "balloons": "Полетели рядом" if state["result"] == "smooth" else "Ветер оказался с характером",
        }[state["kind"]]

init python:
    config.after_load_callbacks.append(vignette_release_after_load)
    renpy.music.register_channel("vignette_backing", "sfx", loop=False)

label vignette_play(kind, context=""):
    $ vignette_state = vignette_start(kind)
    $ vignette_state["context"] = context
    $ vignette_clear_trace()
    window hide
    while not vignette_state["result"]:
        call screen vignette_board
        $ vignette_state = vignette_step(vignette_state, _return)
        if isinstance(_return, (tuple, list)) and _return[0] in ("capture", "slide"):
            play sound "audio/gimmicks/note-high.wav"
        if kind == "hum" and isinstance(_return, (tuple, list)) and _return[0] == "listen":
            play sound ("audio/gimmicks/quiet-loop.wav" if vignette_state["result"] == "smooth" else "audio/gimmicks/hum-loop.wav")
    $ vignette_state["pump"] = False
    $ vignette_state["scene_effect"] = vignette_scene_effect(vignette_state)
    $ vignette_history[kind] = vignette_copy.deepcopy(vignette_state)
    if vignette_state["result"] != "skipped":
        $ vignette_state["new_record"] = vignette_record_score(kind, vignette_state["score"], vignette_state.get("qa_forced", False))
    call screen vignette_done
    stop sound fadeout .2
    $ renpy.music.stop(channel="vignette_backing", fadeout=.2)
    return vignette_copy.deepcopy(vignette_state)
