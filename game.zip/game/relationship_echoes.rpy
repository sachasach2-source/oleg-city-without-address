# Small changes in the next actual meeting, based only on imported goodbyes.
# This presentation never resolves an issue or grants consent to touch.
label week4_previous_goodbye(person):
    $ goodbye = week4_relations[person].get("last_departure", {})
    $ goodbye_guarded = goodbye.get("reaction") in ("hurt", "disappointed") and any(issue["cause"] == "early_departure" for issue in week4_unresolved(person))
    if goodbye_guarded:
        if person == "nika":
            "Ника кладёт куртку на соседний стул. Раньше, чем меню, достаёт телефон и проверяет время."
            n "Я сначала поем. Демки потом, если захочется."
            o "Давай. Я тоже голодный."
        elif person == "asya":
            "Ася освобождает Олегу край стола, а свою стопку подписей оставляет перед собой."
            a "Я сейчас эту допишу. Ты пока посмотри, что там поменялось."
            "Олег остаётся у соседней работы. Ася оборачивается к нему только после того, как откладывает ручку."
        elif person == "lera":
            "Лера подтягивает к себе миску и смотрит на Олега."
            l "Я только уточню. Поесть мы точно успеем? Без внезапного «меня уже ждут»?"
            o "На ужин у меня время есть. Спешить не буду."
            "Она кивает. Олег снимает с края стола лишнее меню, чтобы освободить место для локтя."
        elif person == "varya":
            v "Ты если ненадолго, сразу скажи. Я тут ещё разворот хочу показать."
            o "Я не спешу. Показывай."
            v "Ну всё. Тогда смотри."
        $ week4_event(person, "guarded_reunion", goodbye.get("choice", ""))
    elif goodbye.get("reaction") == "warm":
        if person == "nika":
            n "Я рада, что выбрались. Заходи, тут потише."
            "Она отодвигает стул напротив себя, пропуская Олега к столу."
        elif person == "asya":
            a "Я тебе стул оставила. Только шарф сдвинь, я опять всё на него сложила."
        elif person == "lera":
            l "Я тебе сметану оставила. Себе острого взяла."
        elif person == "varya":
            v "Иди сюда. Я нашла, что тебе сначала показать."
        $ week4_event(person, "easy_reunion", goodbye.get("choice", ""))
    return
