# Friends stay in Moscow. Updates arrive between outings, after quiet scenes end.
default chapter3_buldak_stage = 0
default chapter3_friends_reported = []
default chapter3_friend_history = []
default chapter3_result_chat = "ch3_date_result"
default chapter3_buldak_chat = "ch3_buldak"

init python:
    chapter3_buldak_chats = ("ch3_buldak_eat", "ch3_buldak_search", "ch3_buldak_found", "ch3_buldak_home")
    chapter3_buldak_parts = [
        [("Саня", "Взял бульдак в Москве у дома. БЛЯДЬ, вкусно. Нос течёт, язык горит, но остановиться не могу."),
         ("Саша", "Я половину соуса кладу. Ты смотри там.")],
        [("Саня", "Так. Ищу туалет. В первой кофейне только для посетителей. Я сейчас СТАНУ посетителем очень надолго."),
         ("Саня", "Ключ у менеджера. Менеджер ушёл. БЛЯДЬ. Жопа уже принимает решения без меня.")],
        [("Саня", "НАШЁЛ. Я думал, обосрусь, пока дверь закрывал. Смывал три раза. Унитаз, прости, ты вообще не участвовал в выборе лапши."),
         ("Саша", "Сань, только без фото. Я ещё ем."),
         ("Саня", "Сижу теперь на лавке. Вспотел, как на пятёрке. Только медаль почему-то не дали.")],
        [("Саня", "Я дома. Жопа ещё возмущается, но уже без права голоса."),
         ("Саня", "Но бульдак ОХУЕННЫЙ. Надо ещё взять. В этот раз половину соуса. Я всё понял."),
         ("Саня", "И весь этот забег тоже понравился. Блядь, чувствую себя живым. Давно так за своё будущее не боролся."),
         ("Саша", "Сохранили. Особенно последнее предложение.")],
    ]

    def chapter3_friend_mood(conversation, messages, dialogue=None):
        _, decisions, _ = phone_conversation_state(conversation, messages, dialogue)
        if not decisions:
            return "calm"
        node, reply = decisions[-1]
        option = next(item for item in (phone_dialogues[conversation] if dialogue is None else dialogue)[node]["options"] if item["id"] == reply)
        return option.get("mood", "calm")

    def chapter3_friends_result_chat(person):
        result = chapter3_results.get(person, "")
        if chapter3_plans[person]["status"] == "missed":
            return "ch3_after_missed"
        if chapter3_departures.get(person, {}).get("reaction") in ("hurt", "disappointed"):
            return "ch3_after_" + person + "_departure"
        if person == "nika":
            return "ch3_after_nika_" + ("friend" if chapter3_previous["origin"] == "friendship" else "close" if "остались вдвоём" in result else "invite" if "отдельный вечер" in result else "bye")
        if person == "asya":
            return "ch3_after_asya_" + ("postpone" if "перенесли" in result else "date" if "свиданием" in result else "talk")
        if person == "lera":
            return "ch3_after_lera_" + ("awkward" if "неловко" in result else "work" if "чужую смену" in result else "close")
        return "ch3_after_varya_" + ("walk" if chapter3_plans[person]["kind"] == "walk" else "print")

    def chapter3_buldak_updates(include_final=False):
        global chapter3_buldak_stage
        if chapter3_day != 0:
            return []
        due = min(4 if include_final else 3, sum(chapter3_clock >= minute for minute in (650, 780, 800, 1140)))
        messages = []
        while chapter3_buldak_stage < due:
            messages.extend(chapter3_buldak_parts[chapter3_buldak_stage])
            chapter3_buldak_stage += 1
        return messages

    def chapter3_remember_friends(messages, conversation, dialogue=None):
        global chapter3_friend_history
        transcript = phone_conversation_state(conversation, messages, dialogue)[0]
        chapter3_friend_history = (chapter3_friend_history + transcript)[-12:]

    def chapter3_friends_choices():
        messages = [("Олег", chapter3_live_summary())]
        comments = {
            "nika": ("Саня", "О, с Никой. Уже получается просто договориться, а не готовиться к одному сообщению весь вечер."),
            "asya": ("Саша", "В галерее хотя бы понятно, на что смотреть, пока собираешься с мыслями. Мне бы пригодилось."),
            "lera": ("Саня", "С Лерой поесть — хорошо. После её сета я бы тоже хотел, чтобы меня никуда не тащили."),
            "varya": ("Саша", "У Вари хоть понятная причина срочно написать: бумага кончилась. Мне иногда тоже такой причины не хватает."),
        }
        person = chapter3_shared_person()
        if person == "asya" and chapter3_plans[person]["kind"] == "market":
            messages.append(("Саша", "Покажи потом, если найдёте что-нибудь. Я на барахолке однажды купил рамку. Всё ещё пустая."))
        elif person == "varya" and chapter3_plans[person]["kind"] == "walk":
            messages.append(("Саша", "С человеком, который снимает, интереснее гулять. Сам бы мимо прошёл и не заметил."))
        elif person:
            messages.append(comments[person])
        return messages

    def chapter3_friends_result_base(person):
        result = chapter3_results.get(person, '')
        activity = result.split(';')[0]
        if chapter3_plans[person]['status'] == 'missed':
            return [('Олег', 'С ' + {'nika': 'Никой', 'asya': 'Асей', 'lera': 'Лерой', 'varya': 'Варей'}[person] + ' сегодня не встретились. Опоздал, она уже ушла по своим делам.')]
        if person == 'nika':
            if chapter3_previous['origin'] == 'friendship':
                return [('Олег', 'С Никой ' + activity + '. У неё завтра свидание с басистом, помогал придумать сообщение.')]
            if 'остались вдвоём' in result:
                return [('Олег', 'С Никой ' + activity + '. Не стал опять бежать по делам.')]
            if 'отдельный вечер' in result:
                return [('Олег', 'С Никой ' + activity + '. Хочу увидеться ещё, уже без беготни.')]
            return [('Олег', 'С Никой ' + activity + '. На сегодня разошлись.')]
        if person == 'asya':
            if 'перенесли' in result:
                return [('Олег', 'С Асей только поговорили у входа. Встречу перенесли.')]
            if 'свиданием' in result:
                return [('Олег', 'С Асей ' + activity + '. Прямо сказал, что позвал на свидание.')]
            return [('Олег', 'С Асей ' + activity + '. ' + ('Договорились ещё поговорить.' if 'продолжить' in result else 'На сегодня попрощались.'))]
        if person == 'lera':
            if chapter3_tasks.get('lera_private_walk'):
                return [('Олег', 'С Лерой всё-таки погуляли вдвоём. Оказалось, я почти ничего о её выходных не знал.')]
            if 'неловко' in result:
                return [('Олег', 'С Лерой уехали помогать на мероприятие. Увлёкся, и встреча закончилась неловко.')]
            if 'чужую смену' in result:
                return [('Олег', 'С Лерой помогли со звуком. Потом я устал и сказал, что пора заканчивать.')]
            return [('Олег', 'С Лерой ' + ('починили звук и всё-таки ушли вдвоём' if 'починили' in result else 'поели и погуляли у Садовой') + '. Хорошо было рядом.')]
        varya_report = {'нашли кадры для следующего зина': 'Гуляли с Варей по дворам. Нашли кадры для её следующего зина.', 'сняли другого кота и новый двор': 'С Варей нашли двор, снимали кота. Она довольна, кот — не очень.', 'дождались целого тиража': 'Помогал Варе с печатью. Дождались всего тиража, теперь я немного курьер.', 'унёс готовую часть тиража': 'С Варей забрали часть тиража. Остальное она дождётся сама.', 'проверили пробник, печать перенесли': 'С Варей поправили пробник. Саму печать отложили.', 'помог с готовыми экземплярами и уехал вовремя': 'Помог Варе забрать готовые зины. Успел уехать по своим делам.', 'собрали чёрно-белый тираж': 'С Варей сделали чёрно-белый тираж. Даже лучше получилось.', 'помог оплатить несколько обложек': 'Помог Варе оплатить несколько обложек. Кота на них она выбрала сама.'}[result.split(";", 1)[0]]
        return [('Олег', varya_report)]

label ch3_buldak_update:
    $ chapter3_friend_messages = chapter3_buldak_updates()
    if chapter3_friend_messages:
        "В чате новая серия Саниных московских приключений. Олег отвечает на ходу."
        $ chapter3_buldak_chat = chapter3_buldak_chats[chapter3_buldak_stage - 1]
        $ chapter3_chat_fresh(chapter3_buldak_chat)
        call screen phone_thread(chapter3_friend_messages, conversation=chapter3_buldak_chat, past=chapter3_friend_history[-2:])
        $ chapter3_remember_friends(chapter3_friend_messages, chapter3_buldak_chat)
        $ set_oleg_mood("ch3_buldak_" + str(chapter3_buldak_stage), chapter3_friend_mood(chapter3_buldak_chat, chapter3_friend_messages))
    return

label ch3_after_outing:
    if chapter3_current == "nika" and "nika_evening" in chapter3_tasks:
        scene bg ch3 cafe exit with dissolve
        $ chapter3_stamp("После прощания с Никой")
    else:
        scene bg ch3 alone with dissolve
        $ chapter3_stamp("На улице")
    $ set_soundscape("ch3_outside")
    call ch3_buldak_update
    return

label ch3_saturday_friends:
    call ch3_evening_friends
    return
