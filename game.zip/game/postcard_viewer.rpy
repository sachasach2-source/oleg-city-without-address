init python:
    def postcard_viewer_area(controls=True):
        return (75,100,1450,650) if controls else (0,0,1600,900)

    def postcard_viewer_zoom(value,absolute=False,point=None):
        screen = renpy.get_screen("bonus_gallery_viewer")
        if not screen: return
        scope = screen.scope
        art = postcard_art(scope["current_id"])
        if not postcard_accessible(art): return
        old = scope["zoom_level"]
        level = max(1.0,min(4.0,value if absolute else old+value))
        if level==old: return
        x,y,w,h = postcard_viewer_area(scope["controls"])
        px,py = point or (x+w*.5,y+h*.5)
        px,py = max(0,min(w,px-x)),max(0,min(h,py-y))
        iw,ih = renpy.image_size(art["path"])
        fit = min(float(w)/iw,float(h)/ih)
        for adjustment,extent,pixel,dimension in ((scope["view_x"],w,px,iw),(scope["view_y"],h,py,ih)):
            before,after = dimension*fit*old,dimension*fit*level
            fraction = max(0,min(1,(pixel+adjustment.value-max(0,(extent-before)*.5))/before))
            adjustment.range = max(0,int(after)-extent)
            adjustment.change(max(0,min(adjustment.range,fraction*after+max(0,(extent-after)*.5)-pixel)))
        renpy.set_screen_variable("zoom_level",level,screen="bonus_gallery_viewer")
        renpy.restart_interaction()

    def postcard_viewer_reset():
        screen = renpy.get_screen("bonus_gallery_viewer")
        if not screen: return
        renpy.set_screen_variable("zoom_level",1.0,screen="bonus_gallery_viewer")
        for key in ("view_x","view_y"):
            screen.scope[key].change(0)
        screen.scope["image_input"].last_click = None
        renpy.restart_interaction()

    class PostcardImageInput(renpy.Displayable):
        """Wheel zoom and double-click; single clicks and drags reach the viewport."""
        def __init__(self,**kwargs):
            super(PostcardImageInput,self).__init__(**kwargs)
            self.last_click = None

        def render(self,width,height,st,at):
            return renpy.Render(width,height)

        def event(self,ev,x,y,st):
            screen = renpy.get_screen("bonus_gallery_viewer")
            if not screen or not postcard_accessible(postcard_art(screen.scope["current_id"])): return
            rx,ry,rw,rh = postcard_viewer_area(screen.scope["controls"])
            if not (rx<=x<rx+rw and ry<=y<ry+rh): return
            if renpy.map_event(ev,"mousedown_4") or renpy.map_event(ev,"mousedown_5"):
                postcard_viewer_zoom(.25 if renpy.map_event(ev,"mousedown_4") else -.25,point=(x,y))
                raise renpy.IgnoreEvent()
            if ev.type==renpy.pygame.MOUSEMOTION and self.last_click:
                if abs(x-self.last_click[1])+abs(y-self.last_click[2])>12:
                    self.last_click = None
            if ev.type==renpy.pygame.MOUSEBUTTONDOWN and ev.button==1:
                previous = self.last_click
                self.last_click = (st,x,y)
                if previous and st-previous[0]<.35 and abs(x-previous[1])+abs(y-previous[2])<12:
                    self.last_click = None
                    postcard_viewer_zoom(1.0 if screen.scope["zoom_level"]>1.0 else 2.0,absolute=True,point=(x,y))
                    raise renpy.IgnoreEvent()

screen bonus_gallery_viewer(art_id,sequence=None):
    modal True
    zorder 220
    default current_id = postcard_art(art_id)["id"] if postcard_art(art_id) else art_id
    default viewer_ids = postcard_viewer_ids(art_id,sequence)
    default zoom_level = 1.0
    default controls = True
    default view_x = ui.adjustment()
    default view_y = ui.adjustment()
    default image_input = PostcardImageInput()
    $ zoomed = zoom_level>1.0
    key "game_menu" action (Function(postcard_viewer_zoom,1.0,absolute=True) if zoomed else Hide("bonus_gallery_viewer"))
    add Solid("#050e16")
    $ art = postcard_art(current_id)
    if postcard_accessible(art) and postcard_owned(current_id) and current_id in viewer_ids:
        if postcard_is_new(current_id):
            timer .3 action Function(postcard_seen,current_id)
        $ index = viewer_ids.index(current_id)
        $ previous = [SetScreenVariable("current_id",viewer_ids[(index-1)%len(viewer_ids)]),Function(postcard_viewer_reset)]
        $ following = [SetScreenVariable("current_id",viewer_ids[(index+1)%len(viewer_ids)]),Function(postcard_viewer_reset)]
        if len(viewer_ids)>1:
            key "K_LEFT" action previous
            key "K_RIGHT" action following
        key "K_h" action [ToggleScreenVariable("controls"),Function(postcard_viewer_reset)]
        key "K_EQUALS" action Function(postcard_viewer_zoom,.25)
        key "K_MINUS" action Function(postcard_viewer_zoom,-.25)
        $ area_x,area_y,area_w,area_h = postcard_viewer_area(controls)
        $ image_w,image_h = renpy.image_size(art["path"])
        $ scale = min(float(area_w)/image_w,float(area_h)/image_h)*zoom_level
        $ detail_size = (int(image_w*scale),int(image_h*scale))
        if zoomed:
            viewport:
                id "gallery_detail"
                xpos area_x ypos area_y xsize area_w ysize area_h
                draggable True mousewheel False
                xadjustment view_x yadjustment view_y
                child_size (max(area_w,detail_size[0]),max(area_h,detail_size[1]))
                fixed:
                    xysize (max(area_w,detail_size[0]),max(area_h,detail_size[1]))
                    add Transform(art["path"],xysize=detail_size) xalign .5 yalign .5
        else:
            fixed:
                xpos area_x ypos area_y xsize area_w ysize area_h
                add bonus_gallery_picture(art["path"],area_w,area_h) xalign .5 yalign .5
        if controls:
            textbutton "← Предыдущая" id "gallery_previous" action previous sensitive len(viewer_ids)>1 xpos 75 ypos 24 style "postcard_small_button"
            textbutton "Следующая →" id "gallery_next" action following sensitive len(viewer_ids)>1 xpos 270 ypos 24 style "postcard_small_button"
            text "[index+1] / [len(viewer_ids)]" xpos 450 ypos 34 size 21 color "#c1d0cf"
            textbutton "Скрыть панели · H" id "gallery_hide_ui" action [SetScreenVariable("controls",False),Function(postcard_viewer_reset)] xpos 600 ypos 24 style "postcard_small_button"
            textbutton "−" id "gallery_zoom_out" action Function(postcard_viewer_zoom,-.25) sensitive zoomed xpos 865 ypos 24 style "postcard_small_button"
            $ zoom_caption = ("Целиком · %d%%"%int(zoom_level*100)) if zoomed else "Увеличить ×2"
            textbutton zoom_caption id "gallery_zoom" action Function(postcard_viewer_zoom,1.0 if zoomed else 2.0,absolute=True) xpos 920 ypos 24 style "postcard_small_button"
            textbutton "+" id "gallery_zoom_in" action Function(postcard_viewer_zoom,.25) sensitive zoom_level<4.0 xpos 1145 ypos 24 style "postcard_small_button"
            textbutton "× Закрыть" action Hide("bonus_gallery_viewer") xpos 1320 ypos 24 style "postcard_small_button"
            text "Колесо — масштаб · Двойной клик — приблизить / вписать · Перетаскивание — детали" xalign .5 ypos 755 size 17 color "#99b0b7"
            $ caption = art["name"]+" · "+art["title"]
            text caption xalign .5 ypos 785 size 24 color "#eadbbf"
            $ receipt = postcard_state()["opened"].get(current_id,{"source":"Из прежней коллекции"})
            text receipt["source"] xalign .5 ypos 824 size 18 color "#99b0b7"
            textbutton "В избранное" action Function(postcard_like,current_id) selected current_id in postcard_state()["favorites"] xpos 90 ypos 830 style "postcard_button"
        add image_input
    else:
        text "Альбом пока закрыт. Сначала познакомься с героиней в игре." xalign .5 yalign .5 size 27 color "#c1d0cf"
        textbutton "× Закрыть" action Hide("bonus_gallery_viewer") xpos 1320 ypos 24 style "postcard_button"
