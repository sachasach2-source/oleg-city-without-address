# Delivered episodes wait in a contact list. Reading never invents an earlier reply.
default week7_inbox = []
default week7_phone_active = ""
default week7_phone_batch = []
default week7_phone_deferred = False
default week7_phone_notified = []
default week7_phone_window_opened = False

init python:
    week7_received_messages = {'floor_photo': [('Саша', 'У нас команду перевезли, а мои вещи остались на старом этаже. Сейчас забираю.'),
                     ('Саша', 'Пакет с котом зарядками набил. Кружка пока не влезла.'),
                     ('Саша', 'Свет за спиной загорается. Передо мной темно. Очень удобно.'),
                     ('Саша', 'photo:w7_office_corridor_mon')],
     'lift_voice': [('Саша', 'voice:w7_sasha_lift'),
                    ('Саша', 'Вышел. Кружку забыл. Ну её.'),
                    ('Саня', 'Пусть отвечает за свет.')],
     'ordinary_plans': [('Саня', 'Я в воскресенье пять километров бегу. Уже заявил, теперь неудобно не прийти.'),
                        ('Саша', 'А я в кино. Там хотя бы свет по расписанию выключают.')],
     'excerpt': [('Саша', 'Переслушал своё голосовое. В конце голос слышно.'),
                 ('Саша', 'voice:w7_sasha_lift_excerpt'),
                 ('Саня', 'Сейчас, включу.'),
                 ('Саша', 'Вот в конце. Как будто «подержи дверь».')],
     'friday_plan': [('Саша', 'В пятницу всё равно за кружкой. И старые пропуска до конца недели сдать надо.'),
                     ('Саня', 'Я с тобой. Ты потом скажешь, что кружка сама шла следом.'),
                     ('Саша', 'Договорились. Около семи.')],
     'breather': [('Саня', 'Сегодня три километра пробежал. На пятом этаже после этого всё равно лифт вызвал.'),
                  ('Саша', 'Я завтра тот же пакет беру. Кружка в него влезет.')],
     'friday_arrival': [('Саша', 'Я на этаже.'),
                        ('Саша', 'photo:w7_office_corridor_fri'),
                        ('Саня', 'Кружку нашли. Без потерь.'),
                        ('Саша', 'Ты уже у лифта?'),
                        ('Саня', 'Да, жду тебя здесь.'),
                        ('Саша', 'Ты сейчас просил дверь подержать?'),
                        ('Саня', 'Нет. Я тут стою.'),
                        ('Саша', 'voice:w7_sasha_meeting_room')],
     'outside': [('Саша', 'Мы у охраны.'), ('Саша', 'Вышли.'), ('Саша', 'voice:w7_sasha_outside')],
     'already_outside': [('Саша', 'Мы у охраны.'), ('Саша', 'Вышли.'), ('Саша', 'voice:w7_sasha_outside')],
     'coffee': [('Саша', 'photo:w7_after_office_coffee'),
                ('Саня', 'Он пять минут пакет на свободный стул усаживал.'),
                ('Саша', 'Кружка внутри. Пусть посидит.')],
     'explanation': [('Саша',
                      'Администратор ответил. Соседний блок работает, между нами служебный проход. Датчики '
                      'старые, с задержкой. Дверь доводчик тянет.'),
                     ('Саня', 'Ну свет ладно. Кто говорил-то?'),
                     ('Саша', 'Вот этого она не знает.')],
     'third': [('Саша', 'Охранник ещё сказал: вас же трое заходило.'),
               ('Саня', 'Ты спросил, кого он третьим видел?'),
               ('Саша', 'Спросил. Сказал, не помнит, мог перепутать.')],
     'sunday': [('Саня', 'Пять километров. Добежал. Время не рекордное, зато ни разу не перешёл на шаг.'),
                ('Саша',
                 'А я в кино сходил. По дороге в зал коридор длинный, свет за спиной. Хотел тебе снять и '
                 'передумал.')],
     'varya_costume': [('Варя',
                        'Я на корпоративе буду охотницей за привидениями. Комбинезон уже есть. Фонарик папа '
                        'нашёл, мама сказала батарейки проверить.'),
                       ('Варя', 'С работы меня в нём ещё не видели. Пока.')]}
    week7_inbox_specs = {
        "monday": ("friends", 0, ("floor_photo", "lift_voice", "ordinary_plans"), "Саша прислал фото со старого этажа"),
        "wednesday": ("friends", 2, ("excerpt", "friday_plan"), "Саша переслушал голосовое"),
        "thursday": ("friends", 3, ("breather",), "Саня написал после пробежки"),
        "friday": ("friends", 4, ("friday_arrival",), "Саша и Саня в старом офисе"),
        "coffee": ("friends", 4, ("coffee",), "Фото из кафе"),
        "saturday": ("friends", 5, ("explanation", "third"), "Саша получил ответ администратора"),
        "sunday": ("friends", 6, ("sunday",), "Саня добежал до финиша"),
        "varya": ("varya", 3, ("varya_costume",), "Варя придумала костюм"),
        "guest_sunday": ("", 6, (), "Написать после пятницы"),
    }

    def week7_inbox_deliver(key):
        if any(item["key"] == key for item in week7_inbox):
            return
        person, day, segments, preview = week7_inbox_specs[key]
        person = week7_guest if key == "guest_sunday" else person
        if not person:
            return
        # Capture the receipt, not the time at which the player opens the phone.
        if key == "coffee":
            friday = next((item for item in week7_inbox if item["key"] == "friday"), None)
            if friday and not friday["done"]:
                friday["messages"] += [message for message in week7_received_messages["outside"] if message not in friday["messages"]]
        messages = [message for part in segments for message in week7_received_messages[part]]
        week7_inbox.append(dict(key=key, person=person, day=week7_day, time=week7_clock,
            messages=messages, preview=preview, done=False, seen=False, turns={}))
        attachments = messages + (week7_received_messages["outside"] if key == "coffee" else [])
        for sender, message in attachments:
            if phone_media_item(message) and message not in [x["token"] for x in week7_attachments]:
                week7_attachments.append(dict(token=message, sender=sender, day=week7_day,
                    time=week7_fixed_times.get(message, week7_clock)))

    def week7_inbox_pending(person=None):
        return [item for item in week7_inbox if not item["done"] and (person is None or item["person"] == person)]

    def week7_inbox_unread():
        return list(dict.fromkeys(item["person"] for item in week7_inbox_pending() if item["messages"] and not item.get("seen")))

    def week7_inbox_new():
        return any(item["messages"] and item["key"] not in week7_phone_notified for item in week7_inbox_pending())

    def week7_phone_caption(person):
        return week4_names.get(person, person)

    def week7_saved_threads(chapter=None):
        # Timestamp records contain full, actually chosen transcripts, while the
        # chapter-local history lists are deliberately only short context tails.
        groups = {}
        for (token, position), (sender, message, stamp) in phone_message_times.items():
            if chapter is not None and isinstance(token, str) and any(token.startswith(prefix) and number > chapter for prefix,number in (("w7_",7),("w6_",6),("w5_",5),("w4_",4),("ch4_",3),("ch3_",3),("ch2_",2))):
                continue
            caption = phone_thread_contacts.get(token)
            if caption and caption != "Переписка Вари":
                caption = "Агент" if caption == "Просмотр квартиры" else caption
                groups.setdefault(token, dict(caption=caption, rows=[]))["rows"].append((position, sender, message, stamp))
        result = {}
        for group in groups.values():
            result.setdefault(group["caption"], []).extend((sender, message, stamp) for position, sender, message, stamp in sorted(group["rows"]))
        # Legacy saves may have no per-message records for their imported tail.
        # Keep only the actual stored tail; never reconstruct unchosen answers.
        fallback = week7_history if chapter is None or chapter == 7 else {4:week4_history,5:week5_history,6:week6_history}.get(chapter,{})
        for person, history in fallback.items():
            caption = week7_phone_caption(person)
            if history and caption not in result:
                result[caption] = [(sender, message, "") for sender, message in history]
        return result

    def week7_phone_records(person):
        return week7_saved_threads().get(week7_phone_caption(person), [])

    def week7_inbox_contacts(threads=None):
        names = {caption: person for person, caption in week4_names.items()}
        contacts = [item["person"] for item in week7_inbox]
        contacts += [names.get(caption, caption) for caption in (week7_saved_threads() if threads is None else threads)]
        if messenger_enabled():
            contacts += [names.get(caption, caption) for caption in messenger_known_contacts(7)]
        return list(dict.fromkeys(contacts))

    def week7_phone_retire_drafts():
        # A late batch replaces unanswered old turns, keeping their received
        # messages in the new chronological batch, without duplicating them.
        for item in week7_inbox:
            if item["key"] not in week7_phone_batch:
                continue
            for turn in item.get("turns", {}).values():
                if turn.get("done"):
                    continue
                token = turn["token"]
                for key in list(phone_message_times):
                    if key[0] == token:
                        del phone_message_times[key]
    def week7_phone_delivery():
        return next((item for item in week7_inbox if item["key"] == week7_phone_active), {})

    def week7_phone_time(sender, message):
        deliveries = [item for item in week7_inbox if item["key"] in week7_phone_batch]
        receipt = next((item for item in deliveries if (sender, message) in item["messages"]), None)
        minute = week7_fixed_times.get(message, receipt["time"] if receipt else week7_clock)
        day = receipt["day"] if receipt else week7_day
        return day, minute

    def week7_phone_backlog():
        items = [item for item in week7_inbox if item["key"] in week7_phone_batch]
        committed = [entry for item in items for turn in item.get("turns", {}).values()
            if turn.get("done") for entry in turn.get("incoming", [])]
        return [message for item in items for message in item["messages"] if message not in committed]

label week7_phone_pause(line):
    $ week7_phone_window_opened = False
    show screen week7_phone_button
    "[line]"
    hide screen week7_phone_button
    if not week7_phone_window_opened and week7_inbox_new():
        call week7_phone
    return

label week7_phone(initial_selection=None, return_after_task=False):
    $ week7_phone_window_opened = True
    $ week7_phone_notified = list(dict.fromkeys(week7_phone_notified + [item["key"] for item in week7_inbox]))
    while True:
        if initial_selection is not None:
            $ week7_phone_selection = initial_selection
            $ initial_selection = None
        else:
            call screen week7_phone_inbox
            if _return == "__close__":
                return
            $ week7_phone_selection = _return
        if week7_phone_selection[0] == "history":
            $ week7_archive_rows = week7_phone_records(week7_phone_selection[1])
            call screen phone_thread([(sender, message) for sender, message, stamp in week7_archive_rows], caption=week7_phone_caption(week7_phone_selection[1]), past=[], instant=True, inbox_mode=True, archive_times=[stamp for sender, message, stamp in week7_archive_rows])
        else:
            $ week7_phone_active = week7_phone_selection[1]
            $ week7_phone_deferred = False
            $ week7_phone_batch = [item["key"] for item in week7_inbox_pending(week7_phone_delivery()["person"])]
            python:
                for item in week7_inbox:
                    if item["key"] in week7_phone_batch:
                        item["seen"] = True
            if week7_phone_active == "varya":
                call week7_phone_varya
            elif week7_phone_active == "guest_sunday":
                call week7_phone_guest_sunday
            elif week7_phone_active == "friday" and week7_day == 4:
                if len(week7_phone_batch) > 1:
                    $ week7_phone_retire_drafts()
                call week7_friends_friday
            elif week7_phone_delivery()["day"] < week7_day or len(week7_phone_batch) > 1:
                $ week7_phone_retire_drafts()
                call week7_friends_catchup
            else:
                call expression "week7_friends_" + week7_phone_active
            python:
                for item in week7_inbox:
                    if item["key"] in week7_phone_batch and not week7_phone_deferred:
                        item["done"] = True
                week7_phone_active, week7_phone_batch = "", []
        if return_after_task:
            return
    return

label week7_friends_catchup:
    $ week7_catchup_messages = week7_phone_backlog()
    $ week7_catchup_options = [("how", "Только добрался до сообщений. Как вы сейчас?", [("Саша", "Я дома. Вещи разобрал наконец."), ("Саня", "У меня работа, потом пробегусь, если силы останутся.")])]
    if week7_phone_active == "monday":
        $ week7_catchup_options = [("things", "Саш, только сейчас прочитал про переезд. Как вы там устроились?", [("Саша", "Стол собрал. Зарядку только долго искал, хотя сам её в пакет положил.")]), ("run", "Сань, а как ты к этим пяти километрам готовился?", [("Саня", "Несколько недель. Сначала больше ходил, чем бежал. Сейчас уже нормально.")])]
    elif week7_phone_active == "wednesday":
        $ week7_catchup_options = [("ask", "Вы после этой записи ещё что-нибудь выяснили?", [("Саша", "Кто говорил — так и непонятно. Про свет и соседний блок уже спрашивал."), ("Саня", "Я бы тоже хотел понять.")]), ("feel", "Саш, ты сам как после этого?", [("Саша", "Уже нормально. Но эту запись перед сном больше не включаю.")])]
    elif week7_phone_active == "friday":
        $ week7_catchup_messages = week7_catchup_messages + [message for message in week7_received_messages["already_outside"] if message not in week7_catchup_messages]
        $ week7_friends["friday_read"] = True
        $ week7_friends["live"] = False
        $ week7_catchup_options = [("safe", "Только прочитал, что у вас там было. Как вы после этого?", [("Саша", "Нормально уже. Хорошо, что Саня со мной пошёл."), ("Саня", "Мне тоже было не по себе, если честно.")]), ("voice", "А про голос потом что-нибудь выяснилось?", [("Саша", "Нет. По свету объяснили, а кто там говорил — не знаю.")])]
    elif week7_phone_active == "coffee":
        $ week7_catchup_options = [("coffee", "Только увидел фото. Хорошо, что вы потом вместе посидели. Полегче стало?", [("Саня", "Да. Уже в лифте начали смеяться, а в кафе совсем отпустило."), ("Саша", "И кружку домой довёз.")])]
        if "friday" in week7_phone_batch:
            $ week7_catchup_options.append(("voice", "Вы так и не поняли, кто просил дверь подержать?", [("Саша", "Нет. Я решил, что Саня сзади идёт, и держал."), ("Саня", "А я у лифта стоял. Он потом ко мне пришёл."), ("Саша", "Я запись ещё раз включил. Там слышно. А кто сказал — не знаю.")]))
    elif week7_phone_active == "thursday":
        $ week7_catchup_options = [("run", "Сань, ты после пробежки быстро восстанавливаешься? У меня на следующий день ноги обычно деревянные.", [("Саня", "Если спокойно бегу, нормально. А когда пытаюсь за кем-нибудь угнаться — потом по лестнице боком.")]), ("sasha", "Саш, а переезд у вас на работе как вообще прошёл?", [("Саша", "Дольше, чем обещали. Мы ещё несколько дней друг у друга провода одалживали.")])]
    elif week7_phone_active == "saturday":
        $ week7_catchup_options = [("rest", "Вчера так и не ответил. Как вы, удалось отдохнуть?", [("Саша", "Да. Даже ноутбук не включал."), ("Саня", "Я пораньше лёг. Хотел выспаться перед стартом.")])]
    call week7_chat("friends", "catchup_" + week7_phone_active, week7_catchup_messages, week7_catchup_options)
    if week7_phone_deferred:
        return
    if "friday" in week7_phone_batch:
        $ week7_friends["friday_read"] = True
        $ week7_friends["live"] = False
        $ week7_event("friends_friday", "late", "friends")
    $ week7_event("friends_caught_up", week7_phone_active, "friends")
    return

screen week7_phone_button():
    zorder 90
    if not any(renpy.get_screen(name) for name in ui_focus_screens + ("week7_phone_inbox",)):
        textbutton ("Телефон · новые чаты: " + str(len(week7_inbox_unread())) if week7_inbox_unread() else "Телефон"):
            id "week7_open_phone"
            xpos 1140 ypos 35 xsize 400
            text_size 20
            action Call("week7_phone")

screen week7_phone_inbox():
    $ saved_threads = week7_saved_threads()
    modal True
    on "show" action Function(soundscape_reading, True)
    on "hide" action Function(soundscape_reading, False)
    zorder 110
    add Solid("#071019a8")
    add phone_shell() xpos 1050 ypos 26
    fixed:
        xpos 1050 ypos 26 xsize 500 ysize 844
        text "Сообщения" xpos 29 ypos 65 size 30 color "#e4e8e7"
        textbutton "×":
            id "week7_close_phone"
            xpos 428 ypos 57 padding (8,4) text_size 28
            action Return("__close__")
        text "Чаты" xpos 30 ypos 115 size 16 color "#8fa6b3"
        viewport:
            xpos 25 ypos 155 xsize 452 ysize 620
            mousewheel True draggable True scrollbars "vertical"
            vscrollbar_xsize 12 side_spacing 10
            vscrollbar_unscrollable "hide"
            vbox:
                spacing 12 xsize 420
                for person in week7_inbox_contacts(saved_threads):
                    $ pending = week7_inbox_pending(person)
                    $ history = saved_threads.get(week7_phone_caption(person), [])
                    frame:
                        xsize 420 padding (14,12)
                        background phone_round("#152b38" if pending else "#11232d", 12)
                        vbox:
                            spacing 6
                            textbutton (week7_phone_caption(person) + ("  · новое" if any(item["messages"] and not item.get("seen") for item in pending) else "")):
                                id ("week7_contact_" + person)
                                background None hover_background None padding (0,3)
                                text_size 23 text_color ("#f0d3a1" if pending else "#e4e8e7")
                                action Return(("task", pending[-1]["key"]) if pending else ("history", person))
                            text (pending[-1]["preview"] if pending and not all(item.get("seen") for item in pending) else "Можно ответить" if pending else phone_message_label(history[-1][1]) if history else "") size 16 color "#9eb2bf" xmaximum 380
                            if pending and history:
                                textbutton "Прочитанное":
                                    text_size 15 text_color "#91b8d5" padding (0,2)
                                    background None hover_background None
                                    action Return(("history", person))
                if not week7_inbox_contacts(saved_threads):
                    text "Пока нет переписок." size 20 color "#9eb2bf"
    key "game_menu" action Return("__close__")

label week7_phone_varya:
    if week7_day > 4:
        call week7_chat("varya", "costume_late", week7_received_messages['varya_costume'], [
            ("photos", "Так и не успел тогда ответить. Как тебе вечер, фотографии получились?", [("Варя", "Да! Только половину ещё не разобрала. Там Максим на каждой второй в кадр лезет.")]),
            ("weekend", "Привет! Как выходные, отдохнула после пятницы?", [("Варя", "Да, выспалась. Сегодня хочу выбраться куда-нибудь без камеры.")])])
        if week7_phone_deferred:
            return
        return
    call week7_chat("varya", "costume", week7_received_messages['varya_costume'], [
        ("day","Как ты вообще? Получается отдохнуть среди учёбы и работы?",[("Варя","Да нормально. Сегодня после пар гуляли, я даже ноут не открывала. Правда, потом всё равно начала фотографии разбирать.")]),
        ("ask","А ты чего сама от вечера хочешь?",[("Варя","Фотографии хорошие. И потанцевать. Я с ребятами уже договорилась, после корпоратива ещё встретимся.")]),
        ("photo","Буду рад паре фотографий. Только сначала сама повеселись.",[("Варя","Я специально ремешок длинный взяла. Можно и танцевать, и камеру не потерять.")])])
    if week7_phone_deferred:
        return
    return

label week7_phone_guest_sunday:
    call week7_chat(week7_guest, "sunday", [], [("ask","Как у тебя выходной? Я сегодня дома разбираюсь.",[(week4_names[week7_guest],{"nika":"Погуляла с собаками. Одна всё время выбирала самую глубокую лужу. Сейчас сушу кроссовки.","lera":"Спала до обеда. Потом рис замочила. Хочу нормально поесть, а не очередную булку на бегу.","asya":"Бабушке позвонила. Собираюсь на стрельбу из лука, если автобус не пропущу.","marta":"Рисую. Мама телевизор смотрит, я пока в наушниках. Сегодня краска хорошо ложится.","zhenya":"Квартиру убрала. Вечером игру продолжу, там как раз решение, которое я вчера отложила.","ulya":"Брат старую камеру нашёл. Теперь весь день шлёт, что мы на неё снимали. Я между этим стираю."}[week7_guest])])])
    if week7_phone_deferred:
        return
    return
