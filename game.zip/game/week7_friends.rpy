label week7_friends_monday:
    call week7_chat("friends", "floor_photo", week7_received_messages["floor_photo"] + week7_received_messages["lift_voice"] + week7_received_messages["ordinary_plans"], [
        ("move", "Саш, а новое место как, нравится?", [("Саша", "Светлее. Зато за кофе теперь через весь этаж идти. Я ещё по старой памяти не туда сворачиваю.")]),
        ("run", "Сань, как подготовка? Уже получается все пять без остановки?", [("Саня", "Пока четыре. По утрам бегаю, потихоньку добавляю. Хочу в воскресенье все пять без остановки.")]),
        ("cinema", "Саш, а что смотреть собрался?", [("Саша", "Старый триллер повторно показывают. Название дома кину, сейчас руки заняты.")]),
        ("day", "А как вообще день? Кроме пакетов и темноты.", [("Саня", "Клиент наконец оплатил. Я сегодня даже на почту отвечаю доброжелательно."), ("Саша", "У меня половина дня на переезд ушла. Сейчас доеду и поем нормально.")]),
        ("costume", "У нас в пятницу корпоратив с костюмами. Я пока выбираю, кем пугать коллег.", [("Саня", "Надень отпуск. Их это напугает."), ("Саша", "Аналитик, который говорит «я не знаю». Дорого делать костюм?")])])
    if week7_day == 0:
        $ week7_friends["heard_monday"] = phone_voice_knows("voice:w7_sasha_lift")
    if week7_phone_deferred:
        return
    $ week7_event("friends_monday", _return, "friends")
    return

label week7_friends_wednesday:
    $ week7_heard = phone_voice_knows("voice:w7_sasha_lift_excerpt") or phone_voice_knows("voice:w7_sasha_lift")
    $ week7_friends_options = [("feel","Саш, тебя эта запись сильно зацепила?",[("Саша","Да. Вроде уже дома сижу, а всё равно хочется ещё раз проверить, что там слышно.")]), ("neighbor","Там за стеклом кто-то ещё работает?",[("Саша","Соседний блок не наш. На плане проход есть, я им не пользовался.")]),("later","Я пока не могу послушать. Ты сам нормально?",[("Саша","Да. Дома я. Просто в понедельник даже не заметил.")])]
    if week7_heard:
        $ week7_friends_options.insert(0,("voice","Я в пустом офисе сам вслух разговариваю. Но тут голос вроде другой. Ты его совсем не помнишь?",[("Саша","Я говорил про лифт. Эту фразу не помню."),("Саня","Я только последнее слово разобрал. И теперь сижу в наушниках в тишине, спасибо.")]))
    if week7_friends.get("heard_monday"):
        $ week7_friends_options.insert(0,("early","Я ещё в понедельник в конце это слышал. Решил, кто-то рядом.",[("Саша","А я мимо ушей пропустил. Потом в тишине включил и завис.")]))
    if phone_media_viewed.get("photo:w7_office_corridor_mon"):
        $ week7_friends_options.append(("coat","Справа в конце что висит? На снимке не разобрать.",[("Саша","Куртка, кажется. Там хозяйственная ниша. Не ходил смотреть.")]))
    call week7_chat("friends", "relisten_answer", week7_received_messages["excerpt"] + week7_received_messages["friday_plan"], week7_friends_options)
    if week7_phone_deferred:
        return
    return

label week7_friends_thursday:
    if week7_party.get("answer") == "yes" and not week7_friends.get("photo_decided"):
        menu:
            "Покажу друзьям готовый костюм.":
                $ week7_friends["photo_decided"] = True
                $ week7_event("costume_photo_shared",week7_costume,"friends")
                call week7_chat("friends", "costume_photo", [("Олег","photo:w7_costume_"+week7_costume)], [])
                if week7_phone_deferred:
                    return
            "Пока оставлю сюрпризом. Потом расскажу.":
                pass
    $ week7_friends["photo_decided"] = True
    call week7_chat("friends", "breather", week7_received_messages['breather'], [
        ("costume",("У меня костюм готов. " + week7_costume_names[week7_costume].capitalize() + ".") if week7_party.get("answer")=="yes" else "Я корпоратив пропускаю. Вы завтра за кружкой вместе идите.",[("Саня",{"vampire":"Кровь из коллег пил и до этого, теперь хоть честно.","scientist":"У нас так один директор на аудит ходил. Без халата.","scarecrow":"Солому домой вытряхни, пока квартиру не засеял.","horns":"Вот это я понимаю: собрался, не опаздывая."}[week7_costume] if week7_party.get("answer")=="yes" else "Договорились. Завтра вместе пойдём."),("Саша","Потом расскажи, как прошло. У нас к семи кружечный поход." if week7_party.get("answer")=="yes" else "Я утром ещё напишу, во сколько освобожусь.")]),
        ("sasha","Саш, ты с переездом-то сильно устал?",[("Саша","Больше, чем рассчитывал. Работу никто не отменял, я сегодня ещё отчёт добивал.")]),
        ("run","После забега напиши, как ноги. Я утром загляну.",[("Саня","Напишу. Уже номер положил к кроссовкам, чтобы не забыть.")]),
        ("home","Я сегодня дома собираюсь. А вы завтра во сколько встречаетесь?",[("Саня","К семи. Я после работы сразу к нему, вместе зайдём.")])])
    if week7_phone_deferred:
        return
    return

label week7_friends_friday:
    $ week7_friends["friday_read"] = True
    $ week7_friends["live"] = week7_day == 4 and week7_clock < 1161
    call week7_chat("friends", "friday_arrival", week7_phone_backlog() if week7_phone_active == "friday" and len(week7_phone_batch) > 1 else week7_received_messages['friday_arrival'], [])
    if week7_phone_deferred:
        return
    if week7_friends["live"]:
        $ week7_friends_options = [("call","Могу на пару минут позвонить. Вы рядом друг с другом?",[("Саня","Я к нему вернулся. Набирай."),("Саша","Сейчас. Мы уже к лифту идём.")]),("guard","Может, пока вместе вниз к охране? Уже потом выясните, что там было.",[("Саня","Да. Мы уже рядом. Не хочу тут ничего выяснять.")]),("joke","Я бы там уже всяких ужастиков себе напридумывал. Вы как держитесь?",[("Саша","Не очень, если честно. Уже хочется на улицу."),("Саня","Мы сворачиваем спектакль и идём вниз.")]),("busy","Я не могу говорить. Напишите, когда выйдете. Вы вместе?",[("Саня","Вместе. Всё, идём.")])]
        if phone_media_viewed.get("photo:w7_office_corridor_fri"):
            $ week7_friends_options.append(("glass","Дверь слева на фото открыта. Там кто-то сидит?",[("Саша","Это наша переговорка. Я туда за кружкой заходил. Мы сейчас уйдём, потом спрошу на вахте.")]))
        call week7_chat("friends", "live_answer", [], week7_friends_options)
        if week7_phone_deferred:
            return
        $ week7_friends["response"] = _return
        if _return == "call":
            "Олег набирает Сашу. В динамике щёлкает дверь, Саня совсем рядом просит придержать пакет. Саша отвечает ему, не Олегу: «Держу»."
            o "Я здесь. Вы до лифта дошли?"
            "«Да, едем уже», — говорит Саша. Потом связь на несколько секунд пропадает."
            $ week7_event("friends_called", person="friends")
        $ week7_stamp("Перерыв", 1162)
        call week7_chat("friends", "outside", week7_received_messages['outside'], [])
        if week7_phone_deferred:
            return
    else:
        call week7_chat("friends", "already_outside", week7_received_messages['already_outside'], [
            ("safe","Только прочитал. Хорошо, что уже вышли. Вы как?",[("Саня","В кафе сидим. Он кружку на стол поставил. Свою."),("Саша","Чтобы не забыть, зачем вообще ходили.")]),
            ("ask","Саш, а охрана что сказала?",[("Саша","Что в соседнем блоке работают. И что я пакет с пропусками не отдал. Отдал уже.")]),
            ("joke","Кружку забрали, офис пусть сами закрывают.",[("Саня","Мы так и решили. Ещё раз обратно не пойду.")])])
        if week7_phone_deferred:
            return
    $ week7_event("friends_friday", week7_friends.get("response", "late"), "friends")
    return

label week7_friends_coffee:
    $ week7_stamp("Поздний вечер", max(week7_clock, 1285))
    call week7_chat("friends", "coffee", week7_received_messages['coffee'], [
        ("evening","Как вы сейчас? Получилось спокойно посидеть?",[("Саша","Да. Поели наконец."),("Саня","Уже нормально. Он мне весь переезд пересказал, не только этот этаж.")]),
        ("relief","Вот теперь нормальный вечер. Я за вас уже дёрнулся.",[("Саня","Я тоже. В лифте уже начал смеяться, а до того вообще не смешно было.")]),
        ("cup","Саш, кружка хоть целая доехала? Столько приключений ради неё.",[("Саша","Целая. Я её уже в кафе доставал проверять. Официант смотрел, зачем мне своя кружка.")])])
    if week7_phone_deferred:
        return
    return

label week7_friends_saturday:
    call week7_chat("friends", "explanation", week7_received_messages['explanation'], [
        ("both","Вы оба фразу слышали?",[("Саня","Я только «дверь». Саша ко мне потом пришёл."),("Саша","Я всю. Поэтому и стоял, держал.")]),
        ("sleep","Спали-то нормально?",[("Саша","Холодильник ночью щёлкнул. Я проснулся и лежал злился на себя."),("Саня","Я нормально. Устал, пока туда-сюда ходили.")]),
        ("coffee","Кофе вчера хотя бы хороший был?",[("Саня","Очень. Я второй взял. Уже просто сидели, не обсуждали этот этаж.")])])
    if week7_phone_deferred:
        return
    $ week7_guard_reply = "Может, мой голос из телефона посчитал? Я же с вами говорил." if week7_friends.get("response") == "call" else "Мог с соседним блоком перепутать. Не факт, что он вообще на вас смотрел."
    call week7_chat("friends", "third", week7_received_messages['third'], [("ordinary",week7_guard_reply,[("Саша","Мог. Я его дальше не допрашивал. Не хочу ещё неделю там всё проверять.")]),("enough","Наверное, он правда перепутал. Хорошо, что вы уже дома.",[("Саня","Да. У меня завтра старт, а я тут ночной аудит делаю.")])])
    if week7_phone_deferred:
        return
    return

label week7_friends_sunday:
    call week7_chat("friends", "sunday", week7_received_messages['sunday'], [
        ("run","Сань, ну ты красавчик. Последний километр как?",[("Саня","Думал, кончусь. Потом увидел финиш и ещё ускорился. Теперь сижу довольный, шнурки развязать лень.")]),
        ("movie","Саш, фильм-то понравился? Какой в итоге?",[("Саша","«Нечто». Пересмотрел. Но больше всего напрягся, когда кассир сказал: пройдите в конец коридора."),("Саня","Это ты ещё не бегал пять километров в конец коридора.")]),
        ("party","Я " + ("на корпоративе всё-таки сыграл один номер." if "music" in week7_party.get("activities",[]) else "на корпоратив сходил. Немного танцевал." if "dance" in week7_party.get("activities",[]) else "на корпоратив ненадолго выбрался." if week7_party.get("attended") else "пятницу дома провёл. Рад, что никуда не надо было ехать."),[("Саня","Как раз на следующей неделе вспомним, что у нас было кроме работы."),("Саша","Я кружку уже отмыл. Всё, официально дома.")])])
    if week7_phone_deferred:
        return
    $ week7_event("friends_sunday", _return, "friends")
    return
