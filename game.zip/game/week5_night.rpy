label week5_night_invitation:
    scene expression "bg w5 canal " + week5_person with dissolve
    menu:
        "Я хочу провести с тобой ночь. Хочешь поехать ко мне?":
            $ week5_date["invited_home"] = True
            $ week5_event("night_proposed")
            if week5_night_welcome() and week5_private_ready:
                if week5_person == "nika":
                    n "Хочу."
                    "Она не сразу убирает руку с его рукава."
                    n "И завтра я не встаю в семь. Я тебя заранее предупреждаю."
                    o "У меня даже кофе есть."
                    n "Сначала доедем."
                elif week5_person == "lera":
                    l "Да. Только я сейчас начну тупить, ты не пугайся."
                    o "Я тоже не образец собранности."
                    l "Заметила. Хорошо. Поехали."
                else:
                    a "Да. Я думала, ты сегодня опять уедешь, пока я придумываю, как спросить."
                    o "Не хочу уезжать от тебя."
                    a "Тогда вызовем машину. Я замёрзла."
                $ week5_date["night_answer"] = "yes"
                $ week5_event("mutual_night_agreed")
                call week5_home_together
                return
            else:
                if week5_person == "nika":
                    n "Я хочу тебя целовать. Но домой сегодня поеду к себе. Не хочу сейчас быстрее."
                elif week5_person == "lera":
                    l "Мне очень хочется с тобой. Но ночь сегодня не обещаю. Я ещё привыкаю."
                else:
                    a "Сегодня нет. Мне хорошо, но я пока не хочу оставаться у тебя."
                $ week5_date["night_answer"] = "not_tonight"
                $ week5_event("night_declined", "На сегодняшний вечер; не отказ от отношений")
                menu:
                    "Хорошо. Я всё равно рад, что позвал тебя.":
                        if week5_person == "nika":
                            n "Я тоже. Пойдём до метро?"
                        elif week5_person == "lera":
                            l "Тогда в следующий раз тоже сам зови. Мне понравилось."
                        else:
                            a "И я рада, что пришла."
                        $ week5_date["continuation"] = "accepted_pace"
                        $ week5_result = "warm_goodbye"
                    "Я расстроился. Дай минуту, я сам не ожидал, насколько.":
                        if week5_person == "nika":
                            n "Дам. Только я тебя не дразнила этим вечером."
                        elif week5_person == "lera":
                            l "Я не соглашалась на ночь, когда согласилась прийти."
                        else:
                            a "Мне важно, чтобы я могла сказать тебе «не сегодня»."
                        o "Да. Можешь. Я сейчас с собой разбираюсь."
                        $ week5_date["continuation"] = "named_disappointment"
                        $ week5_result = "awkward_goodbye"
                        $ week5_event("accepted_no_with_disappointment")
        "Проводить её. Этот вечер хочется сохранить вот так.":
            o "Пойдём? Я тебя до метро провожу."
            if week5_person == "nika":
                n "Пойдём. Напиши завтра сам, ладно?"
            elif week5_person == "lera":
                if week5_plan == "roof":
                    l "Пойдём. Только давай ещё кружок пешком, я уже согрелась."
                elif week5_plan == "pinball":
                    l "Давай. Только следующий рекорд уже мой. Я предупреждаю."
                elif week5_plan == "books":
                    l "Давай. А я дома выложу эту книгу. Она, оказывается, тяжёлая."
                else:
                    l "Давай. У меня в сумке со вчера половина аппаратуры, я уже сама её ненавижу."
            else:
                if week5_plan == "dumplings":
                    a "Давай. В следующий раз попробую меньше начинки. Хотя было вкусно."
                elif week5_plan == "books":
                    a "Давай. У меня ещё твоя собака из книги в голове."
                else:
                    a "Давай. Я ещё думаю, куда везут столько листьев."
            $ week5_result = "warm_goodbye"
            $ week5_event("chose_goodbye")
    scene expression "bg w5 canal " + week5_person with dissolve
    if week5_date["kiss"]:
        "Они отходят от воды только после того, как договариваются, с какой стороны обходить последнюю лужу. Она остаётся рядом с ним до поворота к метро."
    else:
        "Олег не ищет ещё одного повода задержать её. Они доходят до метро и прощаются у входа."
    return

label week5_home_together:
    $ week5_stamp("Дорога домой", 1380)
    if not week5_prepared:
        "Перед машиной Олег предлагает зайти в аптеку. Она идёт с ним; у кассы он неожиданно вспоминает, что забыл купить воду."
        $ week5_prepared = True
        $ week5_event("prepared_together")
    scene bg w5 canal empty with dissolve
    if week5_person == "nika":
        "По дороге к машине Ника протягивает Олегу ладонь. Он берёт её за руку; она переплетает их пальцы и слегка тянет его к себе, обходя лужу."
        "Металл кольца касается его пальца. Через несколько шагов ладони согреваются; Ника легко сжимает его руку, когда он подстраивается под её шаг."
    elif week5_person == "lera":
        "Олег протягивает Лере руку. Она вкладывает в неё свою, смотрит на их пальцы и улыбается. До машины идёт совсем рядом, иногда задевая его плечом."
        "Вначале её пальцы прохладные и чуть напряжённые. Потом хватка становится свободнее. Олег чувствует, как её большой палец один раз скользит по его руке и остаётся на месте."
    else:
        "Ася касается пальцами ладони Олега. Он разворачивает руку навстречу; она берётся крепче. У машины они на мгновение мешают друг другу открыть дверь и только тогда разжимают пальцы."
        "Холодный воздух сразу касается согретой ладони. Олег ещё секунду держит руку раскрытой, пока Ася садится в машину."
    $ week5_event("held_hands_on_way_home")
    $ set_soundscape("ch3_evening")
    if week5_home.get("kind") == "hotel":
        scene bg hotel night with fade
        "В гостинице они сначала подходят к стойке, как Олег уточнил днём. В номер поднимаются уже без вопросов."
    else:
        scene expression week5_home_bg(True) with fade
        "Олег открывает дверь своим ключом, отступает, пропуская её, и нащупывает выключатель. Ключи оставляет на полке рядом с дверью."
    $ week5_stamp("Дома", 1400)
    "Они оставляют куртки у входа. Олег убирает телефон на зарядку."
    scene expression "bg w5 home " + week5_person with dissolve
    if week5_person == "nika":
        n "Ты правда готовился."
        o "Да. Хотел тебя позвать. Но не был уверен, что решусь."
        n "А я решилась. Я пока остаюсь."
    elif week5_person == "lera":
        l "Я сейчас скажу что-нибудь совершенно не к месту."
        o "Можешь."
        l "У тебя полотенце аккуратно лежит. Вот. Сказала."
    else:
        a "Я бы чай всё-таки попила."
        o "Я тоже."
        a "Только ты не делай вид, что я теперь согласилась исключительно на чай."
        o "Не буду."
    if week5_person == "nika":
        "Ника остаётся рядом с Олегом у стола. Телефон на зарядке наконец гаснет."
        n "Вот сейчас хорошо."
        o "Я пока даже чайник не включил."
        n "Успеешь. Я больше никуда не собираюсь."
        if week5_plan == "records":
            n "Только пластинки сейчас не ищи. Завтра обменяемся, как договорились."
            "Она кладёт телефон рядом с его телефоном, экраном вниз."
        else:
            "Он тихо напевает две ноты с прогулки. Ника узнаёт их и смеётся."
            n "Всё. До завтра репетиция закрыта."
        o "Я согласен."
    elif week5_person == "lera":
        "Лера стоит у стола, теребя край рукава. Олег отодвигает от неё рабочие бумаги и сам остаётся рядом."
        if week5_plan == "roof":
            l "У тебя тихо. Я после крыши всё ещё ветер слышу."
            o "Окно закрыто. Сейчас пройдёт."
            l "Я не жалуюсь. Мне понравилось там."
        elif week5_plan == "pinball":
            l "Я всё ещё шарик вижу, когда моргаю."
            o "Здесь автоматов нет."
            l "Хорошо. А то я бы опять полезла."
        l "Я обычно в гостях сразу на кухню лезу. Что-нибудь найти, помочь."
        o "У меня кофе нашла бы. Остальное я сам ещё ищу."
        l "Не подбивай. Я сейчас начну."
        o "Кофе утром найдём."
        "Она смотрит на него, опускает глаза и снова поднимает."
        l "Ага. Утром."
    else:
        "Олег заваривает чай и ставит на стол две чашки. Ася ждёт, пока осядут чаинки."
        "Ася делает глоток и подвигает чашку к Олегу. Он пробует, возвращает ей."
        a "Нормальный. Я уже хотела сказать, что крепкий."
        o "Ещё можешь. У тебя своя чашка."
        a "Нет. Мне сейчас такой нравится."
        "Она ставит чашку на стол, освобождая место для его чашки. Несколько минут они пьют чай."
        if week5_plan == "dumplings":
            a "После наших пельменей я теперь чай особенно ценю. Он хотя бы ниоткуда не вылезает."
            o "Ты чашку не сжимай."
            "Ася смеётся и ставит её на стол."
        elif week5_plan == "books":
            a "Я теперь и правда хочу собаку на той фотографии ещё раз рассмотреть."
            o "Ты её оттуда уже не забудешь."
        else:
            a "Интересно, куда эти листья всё-таки везли."
            o "Мы в другую сторону свернули."
            a "Да. Хорошо свернули."
    call week5_home_affection
    menu:
        "Хочу остаться с ней. Убрать телефон до утра.":
            if week5_person == "nika":
                "Ника снова тянется к Олегу. Он отвечает на поцелуй, обнимая её крепче."
            elif week5_person == "lera":
                "Олег целует Леру. Она перестаёт прятать улыбку, притягивает его за плечи и остаётся вплотную, когда он отстраняется вдохнуть."
            else:
                "Олег целует Асю. Она отвечает, обнимает его обеими руками и на этот раз сама сокращает расстояние между ними."
            "На этот раз никуда не нужно уходить."
            scene expression "bg w5 home " + week5_person with dissolve
            call week5_varya_call(True)
            if not _return:
                call week5_shared_night
        "Я всё-таки не хочу сегодня секса. Можно просто побыть вместе?":
            scene expression "bg w5 home " + week5_person with dissolve
            "Олег немного отстраняется. Она отпускает его, оставаясь рядом."
            o "Мне с тобой хорошо. Но сейчас я не хочу дальше."
            if week5_person == "nika":
                n "Можно. Я не собираюсь сейчас тебя переубеждать. Только скажи, хочешь, чтобы я осталась?"
            elif week5_person == "lera":
                l "Можно. Я уже растерялась, если честно. Мне лучше, когда ты словами говоришь."
            else:
                a "Конечно. Я тоже могу передумать. Давай пока чай."
            menu:
                "Останься. Просто поспим вместе.":
                    o "Хочу, чтобы ты осталась. Просто поспим."
                    $ week5_date["continuation"] = "sleep_only"
                    $ week5_result = "sleep_together"
                    $ week5_event("sleep_only_agreed")
                    "Олег ставит на стол две чашки."
                    call week5_varya_call(False, True)
                    if not _return:
                        scene black with dissolve
                        "Позже они выключают свет."
                "Я сегодня лучше один. Помогу тебе добраться домой.":
                    o "Я лучше один. Не хочу сейчас удерживать тебя, пока сам ничего не понимаю."
                    $ week5_date["continuation"] = "left_home"
                    $ week5_result = "paused_at_home"
                    $ week5_event("stopped_at_home")
                    "Они спокойно собираются. Олег ждёт с ней машину у входа; прощание выходит немного неловким."
                    scene black with dissolve
    return

label week5_morning:
    if week5_varya_known() and not week5_varya_state()["call_done"]:
        # Short/friendly/solo evenings still have a Friday night before Saturday.
        scene expression week5_home_bg(True) with fade
        $ set_soundscape("ch3_room")
        "Позже, уже дома, Олег ставит телефон на зарядку и идёт за водой."
        call week5_varya_call(False)
    $ week5_stamp("Суббота дома", 560, 1)
    scene expression week5_home_bg() with fade
    $ set_soundscape("hotel_morning")
    if week5_varya.get("partner_response") == "parted_together":
        $ week5_message = {"nika":"Я досыпала. Когда обратно ехали, даже кофе уже не помогал. Как ты?", "lera":"Я дома. Вчера даже куртку не повесила. Давай в следующий раз всё-таки вдвоём погуляем.", "asya":"Выспалась. Получилась длинная поездка. На следующее свидание я всё-таки рассчитываю без машины."}[week5_person]
        call week5_chat(week5_person, "after_joint_trip", [(week4_names[week5_person], week5_message)], [("reply", "Я тоже выспался. Спасибо, что поехала со мной. Хочу снова тебя увидеть — вдвоём.", [(week4_names[week5_person], "И я. Давай позже созвонимся, решим когда.")])])
    elif week5_varya.get("partner_response") in ("left", "declined_company", "dismissed"):
        call week5_interrupted_morning
    elif week5_result in ("shared_night", "sleep_together"):
        if week5_date.get("night_metaphor", {}).get("scene_effect") == "water_break":
            "Полотенце со вчерашней воды ещё лежит у стола. Олег относит его сушиться, прежде чем наливать кофе. Второй стакан на этот раз ставит в середину стола."
        "Утром приходится искать вторую ложку. Олег точно помнит, куда положил полотенце, а ложку не помнит. За завтраком она находит её первой."
        "После завтрака она собирается домой. У двери они договариваются написать позже; после её ухода в раковине остаются две чашки."
        $ week5_stamp("Суббота дома", 620)
        $ week5_message = {"nika":"Доехала. Кофе у тебя оказался нормальный. А вот вторую чашку всё-таки заведи побольше.", "lera":"Я дома. Сижу и тупо улыбаюсь. Хорошего тебе утра.", "asya":"Добралась. Ты ложку только опять не потеряй. Я ещё приду за чаем."}[week5_person]
        call week5_chat(week5_person, "after_together", [(week4_names[week5_person], week5_message)], [("warm", "Я рад, что ты осталась. Хочу ещё тебя увидеть.", [(week4_names[week5_person], "Я тоже. Напиши, когда освободишься.")]), ("specific", "Я убирал чашки и подумал, что мне нравится, когда их две.", [(week4_names[week5_person], "Одну пока не убирай далеко.")])])
    elif week5_person and week5_date["confirmed"]:
        if week5_date["repair_only"]:
            $ week5_message = "Я вчера не всё смогла сказать. Давай пока так и оставим, не будем сейчас решать за следующий вечер."
        elif week5_result == "limited_evening":
            $ week5_message = "Спасибо за вчера. Хорошо, что увиделись, пусть всего на час."
        elif week5_result == "awkward_goodbye":
            $ week5_message = "Я вчера немного напряглась. Мне хочется, чтобы можно было гулять с тобой и решать по ходу."
        elif week5_result in ("paused_after_yes", "paused_at_home"):
            $ week5_message = "Как ты сегодня? Я немного растерялась вчера. Но хорошо, что ты сказал, а не стал терпеть."
        else:
            $ week5_message = "Я дома. Уже утро, да. Вчера пришла и уснула. Хорошо было пройтись."
        if week5_date["repair_only"]:
            call week5_chat(week5_person, "after_repair", [(week4_names[week5_person], week5_message)], [("answer", "Хорошо. Я рад, что мы вчера всё-таки увиделись. Не буду сейчас дожимать следующий вечер.", [(week4_names[week5_person], "Ладно. Спишемся.")])])
        elif week5_result == "awkward_goodbye":
            call week5_chat(week5_person, "after_awkward", [(week4_names[week5_person], week5_message)], [("answer", "Да. Я вчера сам себе напридумывал. К тебе вопросов нет. Давай пока спокойно переписываться.", [(week4_names[week5_person], "Давай. Доброе утро.")])])
        else:
            call week5_chat(week5_person, "after_date", [(week4_names[week5_person], week5_message)], [("reply", "Доброе утро. Я тоже рад, что увиделись. Напишу позже?", [(week4_names[week5_person], "Напиши.")]), ("honest", "Доброе. Вчера мне было важно самому тебя позвать. Сегодня я тоже хочу с тобой общаться.", [(week4_names[week5_person], "Тогда общайся. Я здесь.")])])
    else:
        "Олег открывает окно на пару минут и возвращается к завтраку. На столе лежит гитарный медиатор. Он убирает его с тарелки и идёт за хлебом."
    if week5_varya_known():
        call week5_varya_followup
    if week5_laundry.get("return") == "saturday_after18":
        "Вечером нужно забрать футболки у Леры. Олег ставит напоминание сначала ей написать."
    if week5_promise == "marta_saturday_14":
        "В два он встречает Марту. До выхода ещё есть время; менять эту договорённость за неё он не собирается."
    menu:
        "Напишу московским. У них-то что за пятница была?":
            $ week5_friend_options = [("ask", "Сань, а результат какой? Или ты теперь только атмосферу замеряешь?", [("Саня", "Пять за двадцать восемь. Вообще доволен. Сегодня ноги, конечно, отдельного мнения."), ("Саша", "Я вчера собрал стул. На этом мои спортивные новости всё.")])]
            if week5_date["confirmed"] and week5_date["romantic"]:
                $ week5_friend_options.append(("date", "Я вчера сам позвал на свидание. Придумал, куда пойти. И не передумал за час до выхода.", week5_friend_date_replies()))
            elif week5_date["confirmed"]:
                $ week5_friend_options.append(("walk", "Я вчера сам позвал погулять. Ненадолго, но хоть увиделись.", [("Саня", "Хорош. Я тоже сегодня хочу куда-нибудь выбраться."), ("Саша", "И я вчера из дома выбрался. За этим стулом. До сих пор руки болят.")]))
            elif week5_varya.get("help") in ("solo", "together"):
                $ week5_friend_options.append(("home", "Ночью ездил за знакомой. Не дождалась человека, растерялась. Сам ещё сплю на ходу.", [("Саня", "Доехали нормально?"), ("Олег", "Да, довёз домой."), ("Саша", "Тогда досыпай. Стул я тебе пока не предлагаю.")]))
            else:
                $ week5_friend_options.append(("home", "Я вчера дома остался. Поел нормально, музыку послушал. Сегодня бодрее.", [("Саня", "Ты это сказал как будто с повинной пришёл. Нормальная пятница."), ("Саша", "Стул собирать только не начинай. Я ещё не закончил, если честно.")]))
            call week5_chat("friends", "saturday", [("Саня", "Вчера пробежал без музыки. Оказывается, я и без неё на третьем километре матерюсь."), ("Саша", "Я на третьем километре уже домой хочу. Я даже бегать не начинал.")], week5_friend_options)
        "Оставлю телефон. Хочется спокойно допить кофе.":
            "Олег ставит телефон экраном вниз. За окном разгружают машину, и кто-то очень уверенно спорит с навигатором."
    call week5_marta_saturday
    if week5_person:
        $ week5_relations[week5_person]["facts"]["chapter5"] = {"confirmed":week5_date["confirmed"], "result":week5_result, "kiss":week5_date["kiss"], "invited_home":week5_date["invited_home"], "night_answer":week5_date["night_answer"], "night":week5_date["night"], "continuation":week5_date["continuation"]}
        if week5_date["confirmed"]:
            $ week5_relations[week5_person]["outcome"] = "unfinished" if week5_date["repair_only"] else "awkward" if week5_result in ("awkward_goodbye", "paused_after_yes", "paused_at_home", "interrupted_separate") else "warm"
    $ week5_finished = True
    $ bonus_gallery_sync(True)
    $ quick_menu = False
    hide screen scene_marker
    call screen week5_ending
    return

label week5_shared_night:
    $ week5_date["night"] = True
    $ week5_date["continuation"] = "together"
    $ week5_result = "shared_night"
    $ week5_event("shared_night", "Взаимное решение; интимная сцена за затемнением")
    scene black with Dissolve(1.2)
    "Свет в прихожей гаснет. Телефон остаётся на столе."
    call vignette_balloons_scene
    return

screen week5_ending():
    modal True
    add Solid("#09151bea")
    frame:
        xalign .5 yalign .5 xsize 1100 padding (50, 40) background Solid("#12232c")
        vbox:
            spacing 24
            text "КОНЕЦ ПЯТОЙ ГЛАВЫ" size 18 color "#d5b384" kerning 3
            text "Я тебя зову" size 48
            text ("Суббота продолжается." if week5_marta.get("scene_done") else "Суббота только начинается.") size 27
            textbutton "Сохранить продолжение" action ShowMenu("save")
            textbutton "Продолжить · глава шестая (черновик)" action Jump("week6_start")
            textbutton "В главное меню" action Return()
