# Each activity has its own materials. These surfaces contain no story state,
# random draws, or input; the existing game boards keep their hit boxes.
init -8 python:
    import math as mini_math

    mini_skins = {
        "photo": dict(bg="#1c2021", panel="#eee5d2", stage="#292d2d", ink="#302d28", muted="#686052", accent="#a44a2e", title="#f0e6d0", edge="#c1ab80", button="#ab4d30", button_ink="#fff3df", hover="#c7613d", motif="film", label="КОНТАКТНЫЙ ЛИСТ"),
        "riff": dict(bg="#181a21", panel="#252731", stage="#292831", ink="#eee5d5", muted="#b2acb7", accent="#ecc179", title="#f3dfb7", edge="#70616c", button="#d4a05b", button_ink="#251d20", hover="#f1c47f", motif="amp", label="ЗАПИСЬ · ОЧКИ"),
        "studio": dict(bg="#d9ded6", panel="#f2eddd", stage="#eeead9", ink="#294d5b", muted="#5d7374", accent="#326879", title="#294d5b", edge="#829c9a", button="#38697a", button_ink="#f5f0de", hover="#4d8392", motif="plan", label="ПЛАН · ОЧКИ"),
        "hum": dict(bg="#171e21", panel="#2b3537", stage="#354144", ink="#ebeee0", muted="#b4c3bd", accent="#b7dd87", title="#e0e8ce", edge="#738781", button="#dca668", button_ink="#25291f", hover="#efc18c", motif="rack", label="СИГНАЛ · ОЧКИ"),
        "laundry": dict(bg="#e5ddd0", panel="#f6eddd", stage="#b3c8be", ink="#354e49", muted="#6b7770", accent="#a14f48", title="#354e49", edge="#aab9a6", button="#557f78", button_ink="#fff3df", hover="#709990", motif="cloth", label="СУШИЛКА · ОЧКИ"),
        "box": dict(bg="#514b40", panel="#dcccaa", stage="#b29b76", ink="#3c352b", muted="#6d5b46", accent="#963e30", title="#f2e2bd", edge="#907854", button="#984a35", button_ink="#fff0ce", hover="#b45c40", motif="parcel", label="ДОСТАВКА · ОЧКИ"),
        "shadow": dict(bg="#103f4b", panel="#e0eee4", stage="#badbd2", ink="#234e57", muted="#557c7e", accent="#b94f3f", title="#e0f4e6", edge="#8cbeb5", button="#2f7880", button_ink="#f1f5df", hover="#43959a", motif="wave", label="ДУБЛЬ · ОЧКИ"),
        "balloons": dict(bg="#201d3b", panel="#302943", stage="#39304c", ink="#f1e5e7", muted="#c1acc9", accent="#f0c49b", title="#f1d9db", edge="#8e6e94", button="#d4a6b6", button_ink="#35233e", hover="#f0c9d3", motif="stars", label="РЯДОМ"),
        "marta": dict(bg="#312c22", panel="#eee0bd", stage="#d7c59c", ink="#3e5140", muted="#7a725a", accent="#566f4b", title="#eddfbf", edge="#a99b73", button="#587453", button_ink="#fff1d0", hover="#759164", motif="route", label="ПАРТИЯ НА ЛИСТКЕ"),
        "shawarma": dict(bg="#301b34", panel="#45283e", stage="#624056", ink="#fff0df", muted="#d9b2cc", accent="#ffc590", title="#fff0df", edge="#ba778e", button="#ffc08f", button_ink="#4c243d", hover="#ffdab0", motif="diner", label="СОЧНЫЙ УКУС"),
        "dice": dict(bg="#24151d", panel="#3c222a", stage="#51313a", ink="#f5e3c3", muted="#cbb99c", accent="#e3b975", title="#ffe0aa", edge="#9b7451", button="#d0a15f", button_ink="#38212a", hover="#f0ca86", motif="felt", label="КОСТИ ДЬЯВОЛА"),
        "oracle": dict(bg="#211c31", panel="#eaddbd", stage="#463448", ink="#4d394b", muted="#776072", accent="#8c4f5c", title="#ead7af", edge="#b99769", button="#69465d", button_ink="#fff0cf", hover="#89627a", motif="oracle", label="КАРТА НА ВЕЧЕР"),
    }

    class MiniInk:
        # Canvas primitives replace pixels. Preblend the material marks so they
        # cannot punch translucent holes through a solid panel.
        def __init__(self,canvas,base):
            self.canvas,self.base=canvas,base
        def __getattr__(self,name):
            def draw(colour,*args):
                return getattr(self.canvas,name)(context_ink_mix(self.base,colour),*args)
            return draw
        def lines(self,colour,closed,points,width=1):
            points=list(points)
            for a,b in zip(points,points[1:]+(points[:1] if closed else [])):
                self.line(colour,a,b,width)

    class MiniSurface(renpy.Displayable):
        def __init__(self, kind, role="panel", active=False, muted=False, **kwargs):
            super(MiniSurface,self).__init__(**kwargs)
            self.kind,self.role,self.active,self.muted=kind,role,active,muted

        def render(self,width,height,st,at):
            w,h=max(1,int(width)),max(1,int(height))
            p=mini_skins[self.kind]
            role,motif=self.role,p["motif"]
            button=role in ("button","secondary","key")
            r=renpy.Render(w,h)
            smooth=UiSmoothCanvas(w,h) if button else None
            c=smooth if button else r.canvas()
            paper=role in ("panel","score","result")
            fill=p["bg"] if role in ("backdrop","footer") else p["panel"] if paper else p["stage"]
            if paper and self.active:fill=context_ink_mix(fill,p["accent"]+"35")
            if button:
                fill=p["hover"] if self.active else p["button"]
                if role=="secondary":fill=p["panel"]
                if self.muted:fill=p["stage"]
            c=MiniInk(c,fill)
            edge=p["accent"] if button and self.active else p["edge"]
            if role=="backdrop":
                c.rect(fill,(0,0,w,h))
                # Decoration is restricted to the unoccupied gutters.
                if motif=="plan":
                    for x in range(0,w,32):c.line("#718e8b20",(x,0),(x,h),1)
                    for y in range(0,h,32):c.line("#718e8b20",(0,y),(w,y),1)
                elif motif=="cloth":
                    for y in range(0,h,7):c.line("#7c8a7710",(0,y),(w,y),1)
                    for x in range(0,w,9):c.line("#fff9df25",(x,0),(x,h),1)
                elif motif=="amp":
                    for y in range(10,h,9):
                        for x in range(12,40,9):c.circle("#75657455",(x,y),1)
                    c.line(edge,(46,26),(46,h-70),2)
                elif motif=="rack":
                    for y in range(26,h-90,22):c.rect("#778b8340",(16,y,12,5))
                elif motif=="film":
                    for x in range(14,w,36):
                        c.rect("#7e7c6d",(x,8,17,8));c.rect("#7e7c6d",(x,h-12,17,6))
                elif motif in ("stars","oracle"):
                    for i in range(42):
                        x,y=18+(i*173)%(w-36),16+(i*61)%112
                        c.circle("#f2cfaa80",(x,y),1 if i%4 else 2)
                elif motif=="wave":
                    for y in (22,130,h-70):
                        points=[(x,y+int(4*mini_math.sin(x/58.))) for x in range(0,w+8,8)]
                        c.lines("#85c7c350",False,points,2)
                elif motif=="parcel":
                    c.polygon("#a0885555",[(0,0),(310,0),(0,115)])
                    for i in range(10):c.line("#d9c59355",(20+i*17,0),(0,20+i*17),3)
                return r
            if role=="footer":
                c.rect(fill,(0,0,w,h))
                c.line(edge,(46,0),(w-46,0),1)
                return r
            # Physical switches have bevels; sea/night actions are softer pills.
            cut=({"amp":4,"rack":3,"plan":2,"film":4,"cloth":10,"parcel":3,"route":3}.get(motif,12) if button else 12)
            if w<30 or h<25:cut=2
            rounded=button and motif in ("wave","stars","diner")
            if rounded:
                radius=min(h//2-1,w//2-1)
                c.circle(edge,(radius,h//2),radius)
                c.circle(edge,(w-radius-1,h//2),radius)
                c.rect(edge,(radius,1,max(1,w-radius*2),h-2))
                c.circle(fill,(radius,h//2),radius-1)
                c.circle(fill,(w-radius-1,h//2),radius-1)
                c.rect(fill,(radius,2,max(1,w-radius*2),h-4))
            else:
                c.polygon(fill,[(cut,0),(w-cut,0),(w,cut),(w,h-cut),(w-cut,h),(cut,h),(0,h-cut),(0,cut)])
                c.lines(edge,True,[(cut,1),(w-cut,1),(w-1,cut),(w-1,h-cut),(w-cut,h-1),(cut,h-1),(1,h-cut),(1,cut)],1)
            if button:
                if motif in ("amp","rack","felt"):
                    c.line(p["button_ink"]+"50",(14,4),(w-14,4),1)
                    c.line(p["bg"]+"70",(12,h-5),(w-12,h-5),2)
                if motif in ("cloth","route"):
                    for x in range(10,w-10,10):
                        c.line(edge,(x,h-7),(x+4,h-7),1)
                    if motif=="cloth":c.circle(edge,(7,h//2),2)
                elif motif=="parcel":
                    c.line("#f5dfac80",(7,10),(7,h-10),2)
                elif motif in ("felt","oracle"):
                    for x in (8,w-8):c.polygon(edge,[(x,h//2-3),(x+3,h//2),(x,h//2+3),(x-3,h//2)])
                return smooth.finish()
            # Fine material marks live at the edge, away from the labels.
            if motif in ("amp","rack"):
                for x in (10,w-10):
                    for y in (10,h-10):
                        c.circle("#10171b",(x,y),4)
                        c.line(edge,(x-2,y),(x+2,y),1)
                if motif=="rack":
                    for y in range(26,h-24,13):c.line("#b1bfb212",(3,y),(w-3,y),1)
                else:
                    for y in range(24,h-22,8):c.line("#b6a29545",(5,y),(12,y),1)
            elif motif=="plan":
                for x in range(20,w-14,12):c.line(edge,(x,h-7),(x,h-(15 if x%60==20 else 10)),1)
                c.line("#a3bbb0",(14,16),(14,h-17),1)
            elif motif=="cloth":
                for x in range(14,w-12,10):
                    c.line(edge,(x,9),(x+5,9),1);c.line(edge,(x,h-10),(x+5,h-10),1)
                for y in range(20,h-14,10):
                    c.line(edge,(9,y),(9,y+4),1);c.line(edge,(w-10,y),(w-10,y+4),1)
            elif motif=="film":
                for y in range(24,h-20,30):
                    c.rect("#81735c",(5,y,6,12));c.rect("#81735c",(w-11,y,6,12))
                if role!="score":c.line(p["accent"],(22,h-12),(min(w-22,97),h-12),3)
            elif motif=="parcel":
                c.polygon("#bca36d90",[(w-90,0),(w-18,0),(w-4,17),(w-77,17)])
                if role!="score":
                    for x in range(22,min(w-22,136),4):c.rect(p["ink"]+"90",(x,h-17,1+x%3,8))
                c.line(p["accent"],(6,28),(6,h-28),3)
            elif motif=="route":
                for y in range(50,h-18,28):c.line("#827a4b18",(16,y),(w-16,y),1)
                for x,y in ((10,10),(w-10,h-10)):c.circle(p["accent"],(x,y),3)
            elif motif in ("stars","oracle","felt"):
                c.lines(edge,False,[(18,32),(18,17),(40,17)],1)
                c.lines(edge,False,[(w-40,h-17),(w-18,h-17),(w-18,h-32)],1)
                for x,y in ((w-17,17),(17,h-17)):
                    c.line(edge,(x-4,y),(x+4,y),1);c.line(edge,(x,y-4),(x,y+4),1)
            elif motif=="wave":
                for y in (8,h-9):
                    points=[(x,y+int(2*mini_math.sin(x/18.))) for x in range(14,w-12,4)]
                    if len(points)>1:c.lines(edge,False,points,1)
            elif motif=="diner":
                for x in range(12,w-12,16):
                    c.rect(edge,(x,5,7,3));c.rect(edge,(x,h-8,7,3))
            return r

    _mini_surfaces = {}
    def mini_surface(kind,role="panel",active=False,muted=False):
        key=(kind,role,active,muted)
        if key not in _mini_surfaces:_mini_surfaces[key]=MiniSurface(*key)
        return _mini_surfaces[key]

    def mini_button(kind,small=False,secondary=False):
        p=mini_skins[kind]
        role="secondary" if secondary else "button"
        return dict(background=mini_surface(kind,role),hover_background=mini_surface(kind,role,True),
            selected_background=mini_surface(kind,role,True),insensitive_background=mini_surface(kind,role,muted=True),
            padding=(14,8) if small else (18,12),text_size=19 if small else 23,
            text_color=p["ink"] if secondary else p["button_ink"],
            text_hover_color=p["ink"] if secondary else p["button_ink"],
            text_selected_color=p["button_ink"],text_insensitive_color=p["muted"])

    class MiniFader(renpy.Displayable):
        def render(self,width,height,st,at):
            r=renpy.Render(22,24);c=r.canvas()
            c.rect("#111b1e",(2,1,20,23))
            c.polygon("#d9d5b9",[(3,0),(17,0),(20,3),(20,19),(17,22),(3,22),(0,19),(0,3)])
            c.line("#ffffe6",(3,2),(16,2),1)
            for y in (7,10,13,16):c.line("#737966",(4,y),(15,y),1)
            return r

style dice_game_button is button:
    background mini_surface("dice","button")
    hover_background mini_surface("dice","button",True)
    insensitive_background mini_surface("dice","button",muted=True)
style dice_game_button_text is button_text:
    color "#38212a"
    hover_color "#38212a"
    insensitive_color "#cbb99c"

screen minigame_system(kind,stop_vignette=False):
    add mini_surface(kind,"footer") ypos 838 xysize (1600,62)
    hbox:
        xalign .5 ypos 851 spacing 12
        for caption,act in [("Назад",Rollback()),("Сохранить",ShowMenu("save")),("Загрузить",ShowMenu("load")),("Настройки",ShowMenu("preferences"))]:
            textbutton caption:
                properties mini_button(kind,small=True,secondary=True)
                text_size 16 padding (18,8)
                action ([Function(vignette_pump,False),Function(vignette_clear_trace),act] if stop_vignette else act)
