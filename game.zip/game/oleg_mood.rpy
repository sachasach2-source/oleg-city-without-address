# Tone choices are saved and rolled back with the story, independently of routes.
default oleg_mood = "calm"
default oleg_mood_choices = {}
default mood_menu = False

init python:
    def oleg_mood_expression():
        return {"playful": "amused", "tense": "earnest"}.get(oleg_mood, "neutral")

    def set_oleg_mood(moment, mood):
        global oleg_mood, cast_state_scene
        oleg_mood = mood
        oleg_mood_choices[moment] = mood
        cast_state_scene = cast_background_key()
        cast_emotions["oleg"] = oleg_mood_expression()

    def reset_oleg_mood(chapter=None):
        global oleg_mood, oleg_mood_choices, mood_menu
        oleg_mood = "calm"
        mood_menu = False
        if chapter in (2, 3):
            oleg_mood_choices = {k: v for k, v in oleg_mood_choices.items() if not k.startswith("ch{}_".format(chapter))}
        else:
            oleg_mood_choices = {}
        cast_emotions.pop("oleg", None)

label mood_hotel_morning:
    $ mood_menu = True
    menu:
        mind "До первого сообщения ещё есть минутка."
        "Потренькать что-нибудь бодрое на гитаре.":
            $ set_oleg_mood("ch1_morning", "playful")
            "Олег тихо играет вступление. На третьем повторе из соседнего номера кашляют в ритм."
            mind "Контакт с аудиторией установлен."
        "Допить кофе у окна. Без телефона.":
            $ set_oleg_mood("ch1_morning", "calm")
            "Он ставит чашку на подоконник и отогревает об неё пальцы. Рабочий чат пока может подождать."
        "Проверить объявления. Вдруг за ночь появилось нормальное.":
            $ set_oleg_mood("ch1_morning", "tense")
            "В избранном снова «уже сдано». Олег закрывает вкладку раньше, чем успевает открыть ещё десять."
            mind "Ладно. Сегодня уже есть просмотр."
    $ mood_menu = False
    return

label mood_courtyard_wait:
    $ mood_menu = True
    menu:
        mind "Двадцать пять минут у домофона."
        "Мысленно назначить голубя агентом.":
            $ set_oleg_mood("ch1_wait", "playful")
            mind "Комиссия — батон. Зато точно местный."
            "Голубь смотрит на него с профессиональным отсутствием обязательств."
        "Поскроллить время. Да где он там?":
            $ set_oleg_mood("ch1_wait", "tense")
            "Олег открывает часы, закрывает, снова открывает. Телефон от этого быстрее не звонит."
        "Разглядеть двор. Раз уж застрял.":
            $ set_oleg_mood("ch1_wait", "engaged")
            "На втором этаже к форточке приделана кошачья лесенка. Олег пытается понять, куда она ведёт."
            mind "У кота отдельный вход. Есть к чему стремиться."
    $ mood_menu = False
    return

label mood_concert_listen:
    $ mood_menu = True
    menu:
        mind "Ника рядом. Можно пока просто слушать."
        "Поймать ритм и перестать стоять столбом.":
            $ set_oleg_mood("ch1_concert", "playful")
            "Олег начинает отбивать ритм ногой. В припеве уже кивает всей головой."
        "Прислушаться к басу. Интересно, как он здесь звучит.":
            $ set_oleg_mood("ch1_concert", "engaged")
            "Бас идёт чуть вразрез с гитарой. Олег раньше этого не замечал. Теперь интересно дослушать."
        "Выдохнуть. Мне не надо сейчас её впечатлять.":
            $ set_oleg_mood("ch1_concert", "calm")
            "Он разжимает плечи. На несколько минут никто не ждёт от него ни знакомства, ни шутки. Хорошо."
    $ mood_menu = False
    return

label mood_ch2_morning:
    $ mood_menu = True
    menu:
        mind "Просмотр и выставка в один день."
        "Так. Сегодня я хотя бы выйду из номера.":
            $ set_oleg_mood("ch2_morning", "playful")
            mind "Просмотр, выставка. Поесть бы ещё где-нибудь между ними успеть."
        "Хочу посмотреть, что там за выставка.":
            $ set_oleg_mood("ch2_morning", "engaged")
            "Олег увеличивает фотографию в афише. Что-то там висит на стуле. Уже есть первый вопрос."
        "Только бы просмотр опять не съел весь день.":
            $ set_oleg_mood("ch2_morning", "tense")
            "Он проверяет время встречи и дорогу до галереи. Между ними остаётся достаточно времени, даже если агент снова опоздает."
    $ mood_menu = False
    return

label mood_varya_age:
    $ mood_menu = True
    menu:
        mind "Кажется, меня только что датировали по компакт-диску."
        "Ладно, скуф так скуф. Зато с дискографией.":
            $ set_oleg_mood("ch2_varya", "playful")
            o "Если найдём диск, устрою экскурсию в древние технологии."
            v "С аудиогидом от очевидца?"
            o "Лично проведу."
        "Прикольно, что мы слушаем одно и то же.":
            $ set_oleg_mood("ch2_varya", "engaged")
            mind "Надо потом спросить, какой альбом ей больше нравится."
            "Олег улыбается: хотя бы здесь не надо объяснять, что за группа."
        "Эй, мне всего тридцать три. Это задело.":
            $ set_oleg_mood("ch2_varya", "tense")
            "Он собирается перечислить ещё несколько групп, потом ловит себя на этом."
            mind "Не надо защищать диплом по собственной молодости. Она просто шутит."
    $ mood_menu = False
    return

label mood_gallery_chair:
    $ mood_menu = True
    menu:
        mind "Стул с шарфом. Ну, здравствуй, искусство."
        "Найти смешную подпись. Хотя бы для себя.":
            $ set_oleg_mood("ch2_gallery", "playful")
            mind "«Место занято». Смешанная техника, очередь в поликлинике."
        "Рассмотреть поближе. Вдруг зацепит.":
            $ set_oleg_mood("ch2_gallery", "engaged")
            "На шарфе одна петля вытянута сильнее остальных. Олег наклоняется: вещь выглядит слишком знакомо для постамента."
        "Можно ничего пока не понимать. Просто походить.":
            $ set_oleg_mood("ch2_gallery", "calm")
            "Он читает подпись ещё раз и отступает на шаг. За соседний экспонат никто не ставит оценок."
    $ mood_menu = False
    return

label mood_ch2_tea:
    $ mood_menu = True
    menu:
        mind "Чай ещё горячий. До сна есть пять минут."
        "Прокрутить смешные моменты дня.":
            $ set_oleg_mood("ch2_tea", "playful")
            mind "Человек с жалобой на медь. Вот кому точно нельзя предлагать залог за квартиру."
            "Олег улыбается над кружкой. Завтра надо рассказать Сане голосом."
        "Запомнить одну мелочь, которая понравилась.":
            $ set_oleg_mood("ch2_tea", "engaged")
            "Он вспоминает кота на Варином рисунке. Крохотный, а первым бросается в глаза. Надо будет посмотреть готовый зин."
        "Не подводить итоги. Просто попить чай.":
            $ set_oleg_mood("ch2_tea", "calm")
            "Олег убирает ноутбук подальше от кружки. Теперь можно вытянуть ноги."
    $ mood_menu = False
    return
