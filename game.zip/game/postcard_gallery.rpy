default persistent.bonus_gallery_unlocked = []
default persistent.postcards_state = None
default persistent.postcard_grid = 8
default persistent.gallery_cheat_unlocked = False
default persistent.gallery_cheat_favorites = []

init python:
    import json as postcard_json
    import hashlib as postcard_hashlib
    import postcard_core
    bonus_gallery_people = [("nika","Ника"),("lera","Лера"),("asya","Ася"),("marta","Марта"),("zhenya","Женя"),("ulya","Уля"),("varya","Варя"),("rita","Рита")]
    bonus_gallery_items = postcard_json.load(renpy.file("postcard_legacy.json"))
    postcard_catalog = postcard_json.load(renpy.file("postcard_catalog.json"))
    postcard_story_catalog = postcard_json.load(renpy.file("postcard_story_catalog.json"))
    postcard_catalog += postcard_story_catalog
    postcard_series = postcard_json.load(renpy.file("postcard_series.json"))
    postcard_envelopes = postcard_json.load(renpy.file("postcard_envelopes.json"))
    postcard_rarity = {"standard":"Открытка","rare":"Редкая","collection":"Коллекционная","special":"Особая","archive":"Из прежнего альбома"}
    postcard_colors = {"standard":"#a8c3c5","rare":"#91b7d4","collection":"#dfbb79","special":"#dca6aa","archive":"#b7ad9c"}
    bonus_gallery_retired_stages = {"nika-2":("nika",2),"nika-3":("nika",3),"asya-2":("asya",2),"asya-3":("asya",3)}
    # Catalog metadata is fixed at init; player ownership stays outside this index.
    postcard_catalog_aliases = {a.get("legacy_alias") for a in postcard_catalog}
    postcard_art_index = {}
    for a in postcard_catalog:
        postcard_art_index.setdefault(a["id"], a)
        if a.get("legacy_alias") is not None:
            postcard_art_index.setdefault(a["legacy_alias"], a)

    class PostcardOpenViewer(Show):
        def predict(self):
            # A page of eight thumbnails must not decode eight full-size cards
            # in the browser. The visible viewer uses the normal demand gate.
            if not renpy.emscripten:
                super(PostcardOpenViewer, self).predict()

    def gallery_code_apply(code):
        value = (code or "").strip().lower()
        if value not in ("for_nikita", "closealbum"):
            renpy.set_screen_variable("error", "Код не подошёл.", screen="gallery_code")
            renpy.restart_interaction()
            return
        persistent.gallery_cheat_unlocked = value == "for_nikita"
        renpy.save_persistent()
        if renpy.get_screen("bonus_gallery"):
            for key,value in (("status","all"),("group",""),("favorites",False),("gallery_page",0)):
                renpy.set_screen_variable(key,value,screen="bonus_gallery")
        renpy.hide_screen("gallery_code")
        renpy.notify("Вся галерея открыта для просмотра." if persistent.gallery_cheat_unlocked else "Обычный режим галереи восстановлен.")
        renpy.restart_interaction()
        return

    def postcard_real_owned(key):
        return key in (persistent.postcards_state or {}).get("opened",{}) or key in (persistent.bonus_gallery_unlocked or [])

    def postcard_favorites(state=None):
        result = set((postcard_state() if state is None else state)["favorites"])
        if persistent.gallery_cheat_unlocked:
            result.update(persistent.gallery_cheat_favorites or [])
        return result

    def postcard_state():
        s = postcard_core.rebalance(persistent.postcards_state)
        unlocked = set(persistent.bonus_gallery_unlocked or [])
        if not unlocked:
            return s
        for a in postcard_catalog:
            if a.get("legacy_alias") in unlocked:
                if a["id"] not in s["opened"]:
                    s["opened"][a["id"]] = {"source":"Из прежней коллекции","number":0}
                    s["viewed"].append(a["id"])
        aliases = postcard_catalog_aliases
        for key,owner,stage,title,path in bonus_gallery_items:
            if key in unlocked and key not in aliases and key not in s["opened"]:
                s["opened"][key] = {"source":"Из прежней коллекции","number":0}
                s["viewed"].append(key)
        return s

    def postcard_commit(s):
        if s != persistent.postcards_state:
            persistent.postcards_state = s
            renpy.save_persistent()

    def postcard_people(state=None):
        if persistent.gallery_cheat_unlocked: return list(bonus_gallery_people)
        known = set((postcard_state() if state is None else state)["met"])
        known.update(a[1] for a in bonus_gallery_items if a[0] in (persistent.bonus_gallery_unlocked or []))
        return [(key,name) for key,name in bonus_gallery_people if key in known]

    def postcard_meet(person):
        if person not in dict(bonus_gallery_people): return
        s = postcard_state()
        if person not in s["met"]:
            s["met"].append(person)
            postcard_commit(s)

    def postcard_accessible(art):
        return postcard_core.accessible(art,dict(postcard_people()))

    def postcard_viewer_ids(art_id, sequence=None):
        art = postcard_art(art_id)
        known = dict(postcard_people())
        if not postcard_core.accessible(art,known) or not postcard_owned(art["id"]): return []
        cards = postcard_cards() if sequence is None else [postcard_art(key) for key in sequence]
        participants = set(postcard_core.participants(art))
        result = [a["id"] for a in cards if postcard_core.accessible(a,known) and postcard_owned(a["id"]) and (sequence is not None or set(postcard_core.participants(a)) & participants)]
        return result if art["id"] in result else [art["id"]]

    def postcard_cards():
        aliases = postcard_catalog_aliases
        cards = list(postcard_catalog)
        for key,owner,stage,title,path in bonus_gallery_items:
            if key in (persistent.bonus_gallery_unlocked or []) and key not in aliases:
                cards.append(dict(id=key,person=owner,name=dict(bonus_gallery_people)[owner],series="pinup",series_name="Пинап",title=title,path=path,thumb=path,rarity="archive",exclusive=False))
        return cards

    def postcard_owned(key):
        return bool(persistent.gallery_cheat_unlocked) or postcard_real_owned(key)

    def postcard_art(key):
        if key in postcard_art_index:
            return postcard_art_index[key]
        # Only unlocked unmatched legacy cards are appended by postcard_cards.
        return next((a for a in postcard_cards() if a["id"]==key or a.get("legacy_alias")==key),None)

    def postcard_filtered(mode="person",group="nika",favorites=False,status="all",order="catalog"):
        s = postcard_state()
        known = dict(postcard_people(s))
        liked = postcard_favorites(s) if favorites else set()
        owned = set(s["opened"]) | set(persistent.bonus_gallery_unlocked or [])
        viewed = set(s["viewed"])
        if persistent.gallery_cheat_unlocked:
            all_keys = {a["id"] for a in postcard_cards()}
            viewed.update(all_keys-owned)
            owned.update(all_keys)
        cards = [a for a in postcard_cards() if postcard_core.accessible(a,known) and (not group or (group in postcard_core.participants(a) if mode=="person" else a["series"]==group)) and (not favorites or a["id"] in liked)]
        cards = [a for a in cards if status=="all" or (status=="owned" and a["id"] in owned) or (status=="sealed" and a["id"] not in owned) or (status=="new" and a["id"] in owned and a["id"] not in viewed)]
        if order=="recent": cards.sort(key=lambda a:s["opened"].get(a["id"],{}).get("number",-1),reverse=True)
        return cards

    def postcard_is_new(key):
        return postcard_real_owned(key) and key not in postcard_state()["viewed"]

    def postcard_seen(key):
        if persistent.gallery_cheat_unlocked and not postcard_real_owned(key): return
        art = postcard_art(key)
        if postcard_accessible(art) and postcard_owned(art["id"]):
            s = postcard_state()
            s["opened"].setdefault(art["id"],{"source":"Из прежней коллекции","number":0})
            postcard_commit(postcard_core.viewed(s,art["id"]))

    def postcard_groups(mode):
        if mode=="person": return postcard_people()
        available = {a["series"] for a in postcard_filtered(group="")}
        return [(g["id"],g["name"]) for g in postcard_series if g["id"] in available]

    def postcard_count(cards):
        return "%d / %d"%(sum(postcard_owned(a["id"]) for a in cards),len(cards))

    def bonus_gallery_picture(path,width,height):
        w,h = renpy.image_size(path)
        return Transform(path,zoom=min(float(width)/w,float(height)/h))

    def postcard_envelope_style(art):
        # The card owns its stationery, including after closing a pending reveal.
        series = art.get("series", "pinup")
        variants = [e for e in postcard_envelopes if e["series"] == series]
        if not variants:
            variants = [e for e in postcard_envelopes if e["series"] == "pinup"]
        index = int(postcard_hashlib.sha256(art["id"].encode("utf-8")).hexdigest()[:8],16) % len(variants)
        return variants[index]

    def postcard_envelope_layer(envelope, layer):
        return "images/ui/postcards/envelopes/" + envelope["id"] + "-" + layer + ".webp"

    def postcard_envelope_picture(envelope, layer):
        return Image(postcard_envelope_layer(envelope,layer),oversample=2)

    def postcard_reveal_geometry(art):
        width,height = renpy.image_size(art["path"])
        fit = min(1064.0/width,634.0/height)
        picture = (max(1,int(width*fit)),max(1,int(height*fit)))
        frame = (picture[0]+36,picture[1]+36)
        return dict(picture=picture,frame=frame,mini_scale=min(500.0/frame[0],320.0/frame[1]))

    def bonus_gallery_page(person,page):
        items = postcard_filtered(group=person)
        pages = max(1,(len(items)+3)//4)
        page = max(0,min(page,pages-1))
        return items[page*4:(page+1)*4],pages

    def bonus_gallery_award(person,stage,notify=True):
        if person not in dict(bonus_gallery_people): return False
        s,count,special = postcard_state(),0,None
        for level in range(1,int(stage)+1):
            key = "milestone:%s:%d"%(person,level)
            amount = postcard_core.reward_amount(key)
            s,added = postcard_core.grant(s,key,person,amount)
            count += amount if added else 0
        if stage>=3:
            special = next((a for a in postcard_catalog if a["person"]==person and a["exclusive"] and not a.get("unlock_event") and a["id"] not in s["opened"]),None)
            if special:
                s["serial"] += 1
                s["opened"][special["id"]] = {"source":"Завершённая история · "+dict(bonus_gallery_people)[person],"number":s["serial"]}
        postcard_commit(s)
        if notify and (count or special):
            renpy.show_screen("bonus_gallery_unlocked",person_name=dict(bonus_gallery_people)[person],count=count,special=bool(special))
            renpy.restart_interaction()
        return bool(count or special)

    def bonus_gallery_event(person,event,chapter,notify=True):
        if chapter==4 and person=="rita" and event=="theatre_contact": bonus_gallery_award(person,1,notify)
        if chapter==6 and ((person=="zhenya" and event=="food_after_concert") or (person=="ulya" and event=="exhibition_closing")): bonus_gallery_award(person,1,notify)
        if chapter==4 and event in ("mutual_time","monday_coffee","midweek_meeting"): bonus_gallery_award(person,1 if event=="monday_coffee" else 2,notify)
        if chapter==5 and person=="marta" and event=="marta_saturday_walk": bonus_gallery_award(person,3,notify)

    def postcard_connection_award(pair=None,notify=True):
        histories = (week4_relations,week5_relations,week6_relations,week7_relations)
        events = postcard_core.connection_events(histories,connection_people)
        if pair is not None:
            events = [e for e in events if e=="connection:"+pair+":meeting"]
        s,added = postcard_core.unlock_story(postcard_state(),postcard_story_catalog)
        for event in events:
            s,new = postcard_core.unlock_story(s,postcard_story_catalog,event)
            added.extend(new)
        postcard_commit(s)
        if notify and added:
            names = ", ".join(postcard_art(key)["name"] for key in added)
            renpy.notify("Новый совместный арт: "+names)
        return added

    def bonus_gallery_sync(notify=False):
        # Migrate actual encounters from old saves, including a meeting without contacts.
        for relations in (week4_relations, week5_relations, week6_relations):
            for person,relation in relations.items():
                if relation.get("known"): postcard_meet(person)
        if chapter4_marta_seen: postcard_meet("marta")
        if persistent.endings_seen: postcard_meet("nika")
        if week4_package == "delivered": postcard_meet("rita")
        if persistent.chapter2_seen:
            for person in ("nika","lera","asya","varya"): postcard_meet(person)
        owned = set(persistent.bonus_gallery_unlocked or [])
        for person,name in bonus_gallery_people:
            earned = max([a[2] for a in bonus_gallery_items if a[1]==person and a[0] in owned]+[v[1] for k,v in bonus_gallery_retired_stages.items() if v[0]==person and k in owned]+[0])
            if earned: bonus_gallery_award(person,earned,notify)
        for result in persistent.chapter2_seen or []: bonus_gallery_award(result.split("_")[0],1,notify)
        if persistent.chapter2_seen: bonus_gallery_award("varya",1,notify)
        if week4_rita_contact or week5_entry.get("rita_contact"): bonus_gallery_award("rita",1,notify)
        for chapter,events in ((4,list(week4_events)+list(week5_entry.get("events",[]))),(5,week5_events),(6,week6_events)):
            for e in events: bonus_gallery_event(e.get("person"),e.get("event"),chapter,notify)
        if week5_finished and week5_person in ("nika","lera","asya") and week5_date.get("confirmed") and not week5_date.get("repair_only") and week5_relations.get(week5_person,{}).get("outcome")=="warm": bonus_gallery_award(week5_person,3,notify)
        for kind,score in persistent.vignette_records_v2.items(): postcard_game_reward(kind,score,False)
        postcard_connection_award(notify=notify)
        postcard_commit(postcard_state())

    def postcard_game_reward(kind,score,notify=True):
        s = postcard_state()
        if score>=800:
            s,added = postcard_core.grant(s,"game:"+kind,amount=5)
            if added:
                postcard_commit(s)
                if notify: renpy.show_screen("bonus_gallery_unlocked",person_name="Отличный результат",count=5)

    def postcard_open(person=None,target=None,count=1):
        current = postcard_state()
        if current["batch"]:
            renpy.hide_screen("postcard_mail")
            renpy.hide_screen("postcard_target")
            renpy.show_screen("postcard_batch")
            return
        if count>1 and not current["pending"]:
            s,keys = postcard_core.open_batch(current,postcard_catalog,dict(postcard_people()),person,count)
            if keys:
                postcard_commit(s)
                renpy.hide_screen("postcard_mail")
                renpy.show_screen("postcard_batch")
                renpy.restart_interaction()
            return
        s,key = postcard_core.open_pack(postcard_state(),postcard_catalog,dict(postcard_people()),person,target)
        if key:
            postcard_commit(s)
            renpy.hide_screen("postcard_target")
            renpy.hide_screen("postcard_mail")
            renpy.show_screen("postcard_reveal",art_id=key)
            renpy.restart_interaction()

    def postcard_complete(next_envelope=False):
        s = postcard_state()
        person = s["pending_person"]
        if s["pending"]: postcard_seen(s["pending"])
        postcard_commit(postcard_core.complete(postcard_state()))
        renpy.hide_screen("postcard_reveal")
        if next_envelope: postcard_open(person)
        renpy.restart_interaction()

    def postcard_batch_complete():
        postcard_commit(postcard_core.complete_batch(postcard_state()))
        renpy.hide_screen("postcard_batch")
        renpy.restart_interaction()

    def postcard_batch_next():
        person = postcard_state()["pending_person"]
        postcard_batch_complete()
        postcard_open(person,count=5)

    def postcard_like(key):
        if persistent.gallery_cheat_unlocked and not postcard_real_owned(key):
            favorites = list(persistent.gallery_cheat_favorites or [])
            if key in favorites: favorites.remove(key)
            else: favorites.append(key)
            persistent.gallery_cheat_favorites = favorites
            renpy.save_persistent()
            return
        s = postcard_state()
        if key in (persistent.bonus_gallery_unlocked or []): s["opened"].setdefault(key,{"source":"Из прежней коллекции","number":0})
        postcard_commit(postcard_core.favorite(s,key))

style postcard_button is button:
    background Solid("#253c46")
    hover_background Solid("#3a5660")
    selected_background Solid("#bda375")
    insensitive_background Solid("#172a32")
    padding (18,12)
style postcard_button_text is button_text:
    size 21
    color "#eee0c9"
    hover_color "#ffffff"
    selected_color "#12242d"
    insensitive_color "#67777b"

style postcard_small_button is postcard_button:
    padding (12, 8)
style postcard_small_button_text is postcard_button_text:
    size 18

screen bonus_gallery():
    tag menu
    default person = "nika"
    default mode = "person"
    default group = ""
    default gallery_page = 0
    default favorites = False
    default status = "all"
    default order = "catalog"
    default group_scroll = ui.adjustment()
    on "show" action Function(bonus_gallery_sync)
    $ per_page = persistent.postcard_grid if persistent.postcard_grid in (8,12) else 8
    add "images/ui/postcards/album-bg.svg"
    text "Письма из города" xpos 70 ypos 35 size 39 color "#ebddc4"
    text "Альбом открыток · бонусные образы вне сюжетной хронологии" xpos 72 ypos 88 size 18 color "#a1b4ba"
    textbutton "← Вернуться" action Return() xpos 1330 ypos 38 style "postcard_button"
    hbox:
        xpos 72 ypos 140 spacing 12
        textbutton "Героини" action [SetScreenVariable("mode","person"),SetScreenVariable("group",""),SetScreenVariable("gallery_page",0)] selected mode=="person" style "postcard_button"
        textbutton "Серии" action [SetScreenVariable("mode","series"),SetScreenVariable("group",""),SetScreenVariable("gallery_page",0)] selected mode=="series" style "postcard_button"
        textbutton "Избранное" action [ToggleScreenVariable("favorites"),SetScreenVariable("gallery_page",0)] selected favorites style "postcard_button"
    $ total_text = postcard_count(postcard_filtered(group=""))
    $ mail_count = postcard_state()["credits"]
    text "Открыто [total_text]" xpos 827 ypos 156 size 21 color "#c4d0ce"
    textbutton "Конверты · [mail_count]" action Show("postcard_mail") sensitive not persistent.gallery_cheat_unlocked xpos 1220 ypos 140 style "postcard_button"
    viewport:
        xpos 72 ypos 220 xsize 284 ysize 570 yadjustment group_scroll
        mousewheel True draggable True
        vbox:
            spacing 8
            textbutton ("Все знакомые" if mode=="person" else "Все серии") action [SetScreenVariable("group",""),SetScreenVariable("gallery_page",0)] selected not group style "postcard_button" xsize 278
            for key,name in postcard_groups(mode):
                $ album = postcard_filtered(mode,key)
                $ received = sum(postcard_owned(a["id"]) for a in album)
                $ counter = postcard_count(album)
                $ finished = bool(album) and received==len(album)
                vbox:
                    spacing 3
                    textbutton (name+"  "+counter+("  ✓" if finished else "")):
                        action [SetScreenVariable("group",key),SetScreenVariable("person",key if mode=="person" else person),SetScreenVariable("gallery_page",0)]
                        selected group==key style "postcard_button" xsize 278 text_size 19
                    fixed:
                        xsize 278 ysize 4
                        add Solid("#29434d")
                        if received:
                            add Solid("#dfbb79") xsize int(278.0*received/len(album)) ysize 4
            if mode=="person":
                for key,name in bonus_gallery_people:
                    if key not in dict(postcard_people()):
                        textbutton "Закрыто · не знакомы" action NullAction() sensitive False style "postcard_button" xsize 278 text_size 18
    vbar adjustment group_scroll xpos 366 ypos 220 xsize 8 ysize 570 unscrollable "hide"
    $ new_count = len(postcard_filtered(mode,group,favorites,"new"))
    hbox:
        xpos 404 ypos 205 spacing 7
        for value,caption in [("all","Все"),("owned","Полученные"),("sealed","Запечатанные"),("new","Новые · %d"%new_count)]:
            textbutton caption id ("filter_"+value) action [SetScreenVariable("status",value),SetScreenVariable("gallery_page",0)] selected status==value style "postcard_small_button"
        textbutton "Последние открытия" id "sort_recent" action [SetScreenVariable("order","catalog" if order=="recent" else "recent"),SetScreenVariable("gallery_page",0)] selected order=="recent" style "postcard_small_button"
    hbox:
        xpos 1355 ypos 205 spacing 6
        for count in (8,12):
            textbutton str(count) id ("grid_"+str(count)) action [SetField(persistent,"postcard_grid",count),Function(renpy.save_persistent),SetScreenVariable("gallery_page",0)] selected per_page==count style "postcard_small_button" tooltip "Открыток на странице"
    text "На странице" xpos 1225 ypos 215 size 16 color "#a1b4ba"
    $ filtered = postcard_filtered(mode,group,favorites,status,order)
    $ pages = max(1,(len(filtered)+per_page-1)//per_page)
    $ current_page = max(0,min(gallery_page,pages-1))
    $ page_cards = filtered[current_page*per_page:(current_page+1)*per_page]
    $ viewer_sequence = [a["id"] for a in filtered if postcard_owned(a["id"])]
    fixed:
        xpos 404 ypos 260 xsize 1110 ysize 530
        for index,art in enumerate(page_cards):
            fixed:
                xpos (index%4)*282 ypos (index//4)*(268 if per_page==8 else 178)
                xsize 264 ysize (260 if per_page==8 else 170)
                use postcard_card(art,viewer_sequence,per_page==12)
    if not page_cards:
        text ("Отметь понравившиеся открытки сердцем." if favorites else "Познакомься с героинями в игре, чтобы открыть их альбомы." if not postcard_people() else "В этой подборке пока нет открыток.") xpos 435 ypos 425 xmaximum 1030 size 27 color "#b1c1c3"
    hbox:
        xpos 404 ypos 804 spacing 24
        textbutton "← Предыдущие" action SetScreenVariable("gallery_page",current_page-1) sensitive current_page>0 style "postcard_small_button"
        text "[current_page+1] / [pages]" yalign .5 size 22 color "#c7d0cc"
        textbutton "Следующие →" action SetScreenVariable("gallery_page",current_page+1) sensitive current_page<pages-1 style "postcard_small_button"
    text ("Вся галерея открыта по коду. Сюжетный прогресс сохранён отдельно." if persistent.gallery_cheat_unlocked else "Новые альбомы появляются после знакомства. Полученные открытки остаются с тобой.") xpos 72 ypos 862 size 17 color "#829da6"
    textbutton "Ввести код" id "gallery_code_button" action Show("gallery_code") xpos 1330 ypos 847 style "postcard_small_button"

screen gallery_code():
    modal True
    zorder 230
    default code = ""
    default error = ""
    key "game_menu" action Hide("gallery_code")
    key "K_RETURN" action Function(gallery_code_apply,code)
    add Solid("#030d15ed")
    frame:
        xalign .5 yalign .5 xsize 720 padding (38,32) background Solid("#203640")
        vbox:
            spacing 20
            text "Код для галереи" size 34 color "#ebddc4"
            text "Открывает просмотр всех открыток, включая сюжетные. Прохождение и награды не меняются." size 21 xmaximum 644 color "#b8c8c9"
            frame:
                xfill True padding (16,12) background Solid("#10242d")
                input id "gallery_code_input" value ScreenVariableInputValue("code") length 40 size 27 color "#f0e2cd"
            if error:
                text error size 20 color "#e8aa9a"
            hbox:
                spacing 16
                textbutton "Применить" id "gallery_code_apply" action Function(gallery_code_apply,code) style "postcard_button"
                textbutton "Закрыть" action Hide("gallery_code") style "postcard_button"
            if persistent.gallery_cheat_unlocked:
                textbutton "Вернуть обычный режим" id "gallery_code_disable" action Function(gallery_code_apply,"closealbum") style "postcard_small_button"


screen postcard_card(art,sequence,compact=False):
    $ owned = postcard_owned(art["id"])
    $ liked = art["id"] in postcard_favorites()
    $ preview_w,preview_h = (100,154) if compact else (248,180)
    frame:
        xsize 264 ysize (170 if compact else 260) padding (8,8) background Solid("#20353eea")
        fixed:
            button:
                id ("card_"+art["id"])
                xsize preview_w ysize preview_h padding (4,4) background Solid("#e3d6bc") hover_background Solid("#ffe4aa")
                action (PostcardOpenViewer("bonus_gallery_viewer",art_id=art["id"],sequence=sequence) if owned else Show("postcard_target",art_id=art["id"]))
                if owned:
                    add bonus_gallery_picture(art["thumb"],preview_w-8,preview_h-8) xalign .5 yalign .5
                else:
                    add Solid("#23353b")
                    add Transform(bonus_gallery_picture(art["thumb"],preview_w-8,preview_h-8),blur=45.0,alpha=.38) xalign .5 yalign .5
                    text ("ЗАКРЫТО" if compact else "ЗАПЕЧАТАНО") xalign .5 yalign .5 size (12 if compact else 17) color "#e3d6bc"
            if postcard_is_new(art["id"]):
                frame:
                    xpos 4 ypos 4 padding (5,3) background Solid("#dfbb79")
                    text "НОВАЯ" size 12 color "#162b32"
            if owned:
                textbutton ("♥" if liked else "♡"):
                    id ("like_"+art["id"])
                    action Function(postcard_like,art["id"]) selected liked
                    xpos 210 ypos 0
                    xsize 38 ysize 38 padding (0,0) text_size 29 text_xalign .5 text_yalign .5
                    background Solid("#122934ed") hover_background Solid("#4d5154")
                    text_color ("#edb49e" if liked else "#eee0c9")
                    tooltip ("Убрать из избранного" if liked else "В избранное")
            text art["name"] xpos (112 if compact else 0) ypos (5 if compact else 185) size 18 color "#f0e2cd"
            text art["title"] xpos (112 if compact else 0) ypos (40 if compact else 210) xmaximum (132 if compact else 248) ymaximum (70 if compact else 36) size 16 color "#b1c1c3"
            $ rarity_label = postcard_rarity[art["rarity"]]
            if compact:
                text rarity_label xpos 112 ypos 126 size 13 color postcard_colors[art["rarity"]]
            else:
                frame:
                    xpos 4 ypos 156 padding (4,2) background Solid("#162b32df")
                    text rarity_label size 12 color postcard_colors[art["rarity"]]

screen postcard_mail():
    modal True
    zorder 210
    key "game_menu" action Hide("postcard_mail")
    add Solid("#030d15ee")
    $ s = postcard_state()
    $ credits = s["credits"]
    $ unfinished = bool(s["pending"] or s["batch"])
    default mail_scroll = ui.adjustment()
    frame:
        xalign .5 yalign .5 xsize 1040 ysize 830 padding (36,28) background Solid("#1d333e")
        vbox:
            spacing 14
            text "Почта без адреса" size 38 color "#eddfc6"
            text "Конвертов: [credits]" size 26 color "#dfbf85"
            text "В каждом конверте — новая открытка. Можно раскрыть одну или сразу несколько." size 20 color "#b8c8c9" xmaximum 960
            if unfinished:
                textbutton "Продолжить открытие" id "mail_resume" action Function(postcard_open) style "postcard_button"
            hbox:
                spacing 10
                viewport:
                    xsize 944 ysize (350 if unfinished else 408) mousewheel True draggable True yadjustment mail_scroll
                    vbox:
                        spacing 6
                        for key,name in [(None,"Любая знакомая героиня")]+postcard_people():
                            $ left = len(postcard_core.candidates(s,postcard_catalog,dict(postcard_people()),key))
                            $ batch_count = min(5,credits,left)
                            hbox:
                                spacing 12
                                fixed:
                                    xsize 440 ysize 40
                                    text (name+" · ещё %d"%left) yalign .5 size 21 color "#c4d2cf"
                                textbutton "Открыть один" id ("mail_one_"+(key or "all")) action Function(postcard_open,key) sensitive not unfinished and credits>0 and left>0 style "postcard_small_button"
                                textbutton ("Открыть %d"%max(2,batch_count)) id ("mail_five_"+(key or "all")) action Function(postcard_open,key,count=5) sensitive not unfinished and batch_count>1 style "postcard_small_button"
                vbar adjustment mail_scroll style "vscrollbar" xsize 8 ysize (350 if unfinished else 408) unscrollable "hide"
            text "За сюжетную награду — 10 конвертов, за отличный результат в каждой мини-игре — ещё 5. Каждое достижение награждается один раз." size 18 color "#95aeb6" xmaximum 960
            text "После четырёх обычных находок следующая будет редкой, если такая осталась в выбранном альбоме." size 17 color "#95aeb6" xmaximum 960
            textbutton "Закрыть почту" action Hide("postcard_mail") style "postcard_button"

screen postcard_batch():
    modal True
    zorder 215
    key "game_menu" action Function(postcard_batch_complete)
    add "images/ui/postcards/album-bg.svg"
    $ keys = [key for key in postcard_state()["batch"] if postcard_accessible(postcard_art(key)) and postcard_owned(key)]
    text "Открыто конвертов: [len(keys)]" xalign .5 ypos 115 size 40 color "#ebddc4"
    text "Все открытки уже в альбоме. Нажми на любую, чтобы рассмотреть." xalign .5 ypos 188 size 23 color "#b8c8c9"
    hbox:
        xalign .5 ypos 300 spacing 10
        for key in keys:
            use postcard_card(postcard_art(key),keys)
    $ s = postcard_state()
    $ left = len(postcard_core.candidates(s,postcard_catalog,dict(postcard_people()),s["pending_person"]))
    $ next_count = min(5,s["credits"],left)
    hbox:
        xalign .5 ypos 685 spacing 20
        if next_count>1:
            textbutton "Открыть ещё [next_count]" id "batch_next" action Function(postcard_batch_next) style "postcard_button"
        textbutton "Оставить в альбоме" id "batch_done" action Function(postcard_batch_complete) style "postcard_button"

screen postcard_target(art_id):
    modal True
    zorder 215
    key "game_menu" action Hide("postcard_target")
    add Solid("#030d15ed")
    $ art = postcard_art(art_id)
    frame:
        xalign .5 yalign .5 xsize 680 padding (38,34) background Solid("#203640")
        vbox:
            spacing 22
            if not postcard_accessible(art):
                text "Альбом пока закрыт" size 35 color "#e7d7b7"
                text "Сначала познакомься с героиней в игре." size 22 color "#c1d0cf"
            else:
                text art["name"] size 35 color "#e7d7b7"
                text art["title"] size 25 color "#c1d0cf"
            if postcard_accessible(art) and art.get("unlock_event"):
                text art["unlock_hint"] size 22 xmaximum 600 color "#dca6aa"
                text "Открывается только в истории. В конвертах не встречается." size 20 xmaximum 600 color "#c1d0cf"
            elif postcard_accessible(art) and art["exclusive"]:
                text "Особая открытка за завершённую тёплую встречу с этой героиней. Дружеский и романтический путь подходят." size 22 xmaximum 600 color "#dca6aa"
            elif postcard_accessible(art):
                text "Можно дождаться находки в конверте или выбрать эту открытку за 3 конверта." size 22 xmaximum 600 color "#c1d0cf"
                textbutton "Выбрать эту · 3 конверта" action Function(postcard_open,art["person"],art_id) sensitive postcard_state()["credits"]>=3 and not postcard_state()["pending"] style "postcard_button"
            textbutton "Вернуться к альбому" action Hide("postcard_target") style "postcard_button"

transform postcard_flap_open(foreground_seal=False):
    pos (300,0) anchor (.5,0.0) transform_anchor True
    parallel:
        yzoom 1.0
        pause .30
        ease .24 yzoom .02
        ease .32 yzoom -1.0
    parallel:
        alpha 1.0
        pause .54
        alpha (0.0 if foreground_seal else 1.0)
transform postcard_slide_out(mini_scale):
    pos (800,535) anchor (.5,.5) transform_anchor True
    alpha 0.0 zoom mini_scale rotate 0
    pause .55
    linear .05 alpha 1.0
    ease .75 ypos 245
    pause .28
    ease .42 ypos 390 zoom 1.0
transform postcard_envelope_enter:
    pos (800, 535) anchor (.5, .5) rotate_pad False
    alpha 0.0 yoffset 35 rotate -3
    ease .3 alpha 1.0 yoffset 0 rotate 0
    pause 1.05
    ease .28 alpha 0.0 yoffset 45
transform postcard_final_enter:
    pos (800,390) anchor (.5,.5)
transform postcard_opening_caption:
    alpha 1.0
    pause .6
    ease .2 alpha 0.0
transform postcard_dust(delay,drift):
    alpha 0.0 yoffset 40
    pause delay
    parallel:
        ease 1.6 yoffset -110 xoffset drift
    parallel:
        linear .3 alpha .7
        pause .6
        linear .7 alpha 0.0

screen postcard_envelope_print(envelope,opening=False):
    add postcard_envelope_picture(envelope,"front")
    if opening:
        add postcard_envelope_picture(envelope,"seal") at postcard_flap_open(True)
    else:
        add postcard_envelope_picture(envelope,"seal")

screen postcard_reveal_face(art,geometry):
    frame:
        id "postcard_face"
        xysize geometry["frame"] padding (18,18) background Solid("#e6d9bf")
        add Transform(art["path"],xysize=geometry["picture"])

screen postcard_reveal(art_id):
    modal True
    zorder 230
    default revealed = False
    $ art = postcard_art(art_id)
    $ geometry = postcard_reveal_geometry(art) if postcard_accessible(art) else None
    $ envelope = postcard_envelope_style(art) if art else None
    key "game_menu" action (Function(postcard_complete) if revealed else Hide("postcard_reveal"))
    add "images/ui/postcards/album-bg.svg"
    if not postcard_accessible(art):
        text "Альбом пока закрыт" xalign .5 yalign .5 size 32 color "#eadbbf"
        textbutton "Закрыть" action Hide("postcard_reveal") xalign .5 ypos 700 style "postcard_button"
    elif not revealed:
        on "show" action Play("sound","audio/postcards/paper.wav")
        timer 2.08 action [SetScreenVariable("revealed",True),Play("sound","audio/postcards/reveal.wav")]
        text "Тебе письмо" xalign .5 ypos 90 size 38 color "#e6d7b8" at postcard_opening_caption
        fixed:
            xsize 600 ysize 350
            at postcard_envelope_enter
            add postcard_envelope_picture(envelope,"back")
            add postcard_envelope_picture(envelope,"flap") at postcard_flap_open
        fixed:
            xysize geometry["frame"]
            at postcard_slide_out(geometry["mini_scale"])
            use postcard_reveal_face(art,geometry)
        fixed:
            xsize 600 ysize 350
            at postcard_envelope_enter
            use postcard_envelope_print(envelope,opening=True)
        textbutton "Раскрыть сразу" action [SetScreenVariable("revealed",True),Play("sound","audio/postcards/reveal.wav")] xalign .5 ypos 795 style "postcard_button"
    else:
        if postcard_is_new(art_id):
            timer .3 action Function(postcard_seen,art_id)
        for index in range(18):
            add Solid(postcard_colors[art["rarity"]],xsize=3,ysize=3) xpos (250+(index*83)%1100) ypos (250+(index*61)%460) at postcard_dust(index*.035,(-50 if index%2 else 50))
        fixed:
            xysize geometry["frame"]
            at postcard_final_enter
            use postcard_reveal_face(art,geometry)
        $ rarity_label = postcard_rarity[art["rarity"]]
        $ person_name = art["name"]
        text "[rarity_label] · [person_name]" xalign .5 ypos 745 size 28 color postcard_colors[art["rarity"]]
        text art["title"] xalign .5 ypos 785 size 20 color "#bbc9c7"
        hbox:
            xalign .5 ypos 826 spacing 20
            textbutton "В избранное" action Function(postcard_like,art_id) selected art_id in postcard_state()["favorites"] style "postcard_button"
            if postcard_state()["credits"]>0 and postcard_core.candidates(postcard_state(),postcard_catalog,dict(postcard_people()),postcard_state()["pending_person"]):
                textbutton "Следующий конверт" id "reveal_next" action Function(postcard_complete,True) style "postcard_button"
            textbutton "Оставить в альбоме" action Function(postcard_complete) style "postcard_button"

transform bonus_gallery_toast_enter:
    alpha 0.0 yoffset -12
    ease .25 alpha 1.0 yoffset 0
screen bonus_gallery_unlocked(person_name,count=1,special=False):
    zorder 180
    timer 4.0 action Hide("bonus_gallery_unlocked")
    frame:
        xanchor 1.0 xpos .98 ypos 24 xsize 360 padding (20,14) background Solid("#1d3540f5")
        at bonus_gallery_toast_enter
        vbox:
            spacing 6
            if count:
                text "Новое письмо · +[count]" size 23 color "#e4c18c"
            if special:
                text "Особая открытка в альбоме" size 21 color "#dca6aa"
            text "[person_name] · Галерея" size 18 color "#c2d0cf"
