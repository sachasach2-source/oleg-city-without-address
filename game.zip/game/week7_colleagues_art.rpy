image bg w7 colleague detail dasha = Composite((1600,900),
    (0,0),Transform("images/week7/party-hall-v7.webp",xysize=(1600,900)),
    (365,0),Transform("images/week7/dasha-party-v1.webp",zoom=.85))

init -9 python:
    for colleague in ("ilya", "maxim", "dasha"):
        cast_assets[("w7_"+colleague, "party")] = {"neutral":"images/week7/"+colleague+"-party-v1.webp"}
    for room, background in (("hall","party-hall-v7.webp"), ("games","games-room-v4.webp"), ("quiet","quiet-room-v5.webp"), ("garden","pumpkin-garden-v3.webp")):
        for costume in ("vampire", "scientist", "scarecrow", "horns"):
            for colleague in ("ilya", "maxim", "dasha"):
                for guest in ("", "nika", "lera", "asya", "marta", "zhenya", "ulya"):
                    key = "w7 coworker "+room+" "+costume+" "+colleague+(" "+guest if guest else "")
                    actors = [("oleg","w7_"+costume,290 if guest else 370,45,950 if guest else 1000),
                        ("w7_"+colleague,"party",790 if guest else 1230,65 if guest else 45,950 if guest else 1050)]
                    if guest:
                        actors.append((guest,"halloween",1280,65,970))
                    path = "images/week7/"+background
                    cast_stages[key] = (path,actors,None,"evening")
                    renpy.image("bg "+key,Transform(path,xysize=(1600,900)))
