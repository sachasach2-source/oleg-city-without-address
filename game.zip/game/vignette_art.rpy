# The illustrations carry the objects; selection and controls stay separate.
init -11 python:
    def vignette_art(name):
        return "images/gimmicks/vignettes/art-v1/" + name + ".webp"

    def vignette_prop(name, width, height):
        # Preserve each object's proportions inside its logical drag footprint.
        return Transform(vignette_art(name), xysize=(width, height), fit="contain")
