# The illustrations carry the objects; selection and controls stay separate.
init -11 python:
    def vignette_art(name):
        return "images/gimmicks/vignettes/art-v1/" + name + ".webp"

    def vignette_prop(name, width, height):
        # Preserve each object's proportions inside its logical drag footprint.
        return Transform(vignette_art(name), xysize=(width, height), fit="contain")

    def vignette_web_assets(kind):
        # Preload only this activity, including props used after its start.
        names = dict(photo=["courtyard-board"], riff=["riff-board"], studio=["plan-board"],
            hum=["mixer-board"], laundry=["laundry-board", "clothespin"],
            box=["parcel"], shadow=["sea-board", "duck"],
            balloons=["night-board", "balloon-blue", "balloon-coral"])[kind][:]
        if kind == "studio":
            names += ["furniture-" + item[4] for item in vignette_furniture]
        if kind == "laundry":
            for folded in (False, True):
                state = dict(folded=[folded] * vignette_laundry_count)
                names += [vignette_laundry_asset(state, item) for item in range(vignette_laundry_count)]
        return [vignette_art(name) for name in sorted(set(names))]
