# Serialized gameplay data has its own version, independent of release numbers.
# Zero identifies saves made before versioned migrations were introduced.
default save_data_version = 0

init 100 python:
    SAVE_DATA_VERSION = 1

    def save_compat_phone_views(views, contacts):
        changed = False
        for token, saved in views.items():
            if not isinstance(saved, dict):
                continue
            contact = saved.get("contact")
            active = contacts.get(token)
            if contact and active and saved.get("view") == "archive" and messenger_caption(contact) == messenger_caption(active):
                saved["view"] = "thread"
                changed = True
        return changed

    def save_compat_new_game():
        global save_data_version
        save_data_version = SAVE_DATA_VERSION

    def save_compat_after_load():
        global save_data_version
        # Never downgrade a schema written by a newer game. Engine-level
        # incompatibilities are left to Ren'Py, rather than resetting the story.
        if save_data_version > SAVE_DATA_VERSION:
            return
        if save_data_version < 1:
            save_compat_phone_views(messenger_views, phone_thread_contacts)
            save_data_version = 1
            # Prevent rollback into the pre-migration representation. The saved
            # slot itself is never overwritten; a new save remains explicit.
            renpy.block_rollback()

    def save_compat_metadata(data):
        data["oleg_save_schema"] = save_data_version
        data["oleg_writer_version"] = config.version
        data["oleg_story_origin"] = _version

    config.start_callbacks.append(save_compat_new_game)
    config.after_load_callbacks.append(save_compat_after_load)
    config.save_json_callbacks.append(save_compat_metadata)
