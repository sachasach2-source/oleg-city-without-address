# The ordinary rotating Ren'Py autosave ring is also accessible from Load.
# Only a settled story interaction can trigger a stage checkpoint.
default recent_autosave_stage = ""
default recent_autosave_resume = False

init python:
    def recent_stage_autosave():
        global recent_autosave_stage, recent_autosave_resume
        if main_menu or not config.has_autosave or not _autosave or not ui_dialogue_visible() or not renpy.get_screen("say") or renpy.in_rollback() or renpy.game.after_rollback:
            return
        if renpy.emscripten and web_asset_gate_visible():
            return
        if recent_autosave_resume:
            # Ren'Py can replay the current statement after after_load callbacks.
            # Settle on the visible stage without writing another slot on load.
            recent_autosave_stage = save_name
            recent_autosave_resume = False
            return
        if not save_name or save_name == recent_autosave_stage:
            return
        if not renpy.loadsave.autosave_not_running.is_set():
            return
        recent_autosave_stage = save_name
        # Complete the checkpoint before the next story action can mutate it.
        # This also matches the synchronous save path used by the web engine.
        renpy.force_autosave(take_screenshot=True, block=True)

    def recent_autosave_after_load():
        global recent_autosave_resume
        # Loading itself must never rotate away the slot the player just opened.
        recent_autosave_resume = True

    config.after_load_callbacks.append(recent_autosave_after_load)
