init python:
    def week5_sample(profile):
        """Chapter-select fixtures only. Continued saves bypass this function."""
        global week4_finished, week4_evening, week4_day, week4_clock, housing_home
        person = profile.split("_")[0]
        base = person if person in ("nika", "lera", "asya") else "quiet"
        week4_sample(base)
        week4_reset()
        week4_day, week4_clock = 3, 1390
        week4_work["report"] = "done"
        week4_laundry.update(method="hotel", status="clean", where="home")
        housing_home = ""
        if person in ("nika", "lera", "asya"):
            relation = week4_relations[person]
            relation.update(known=True, mode="interest", outcome="warm", invited=True, issues=[])
            week4_evening = person
            if profile.endswith("_kiss") or profile in ("keys", "repair"):
                relation["new_touch"] = "kiss"
                relation["facts"]["kissed_chapter4"] = True
            if profile.endswith("_friend"):
                relation["mode"] = "friendship"
                relation["previous_touch"] = ""
            if profile.endswith("_hurt"):
                relation["outcome"] = "unfinished"
                week4_open_issue(person, "early_departure", "Ушёл из встречи, хотя ждали продолжения")
            if profile.endswith("_space"):
                relation["previous_touch"] = "space"
                relation["new_touch"] = ""
        if profile == "keys":
            week4_relations["nika"].update(known=True, mode="interest", outcome="warm", new_touch="kiss", issues=[])
            week4_home.update(kind="hotel", candidate="central", keys_due="friday", paid_until="friday")
            week4_laundry.update(method="lera", status="drying", where="lera", **{"return":"friday"})
        elif profile == "repair":
            week4_relations["nika"].update(known=True, mode="interest", outcome="warm", new_touch="kiss", issues=[])
            week4_home.update(kind="new", visit="friday")
            housing_home = "studio"
        week4_finished = True
        diary_entries.append("Быстрый вход в главу 5: выбранная готовая предыстория.")

label week5_quick:
    $ week5_sample(week5_entry_profile)
    jump week5_start

screen week5_select():
    tag menu
    default profiles_scroll = ui.adjustment()
    use menu_shell("Я тебя зову · глава пятая"):
        vbox:
            xpos 100 ypos 145 xsize 1350 spacing 18
            text "Продолжение своей истории — из сохранения в конце четвёртой главы.\nНиже готовые предыстории: они не заменяют твоё прохождение." size 23 color "#bfc6c9"
            hbox:
                spacing 24
                viewport:
                    id "week5_profiles"
                    mousewheel True draggable True xsize 1200 ysize 440 yadjustment profiles_scroll
                    vbox:
                        spacing 8
                        for profile, title in [("nika_kiss", "Ника · вчера поцеловались"), ("lera_kiss", "Лера · вчера поцеловались"), ("asya_kiss", "Ася · вчера поцеловались"), ("nika_first", "Ника · интерес есть, поцелуя ещё не было"), ("nika_friend", "Ника · дружба и музыка"), ("lera_hurt", "Лера · после обидного ухода"), ("asya_hurt", "Ася · не всё закончилось хорошо"), ("lera_space", "Лера · раньше попросил не торопиться"), ("keys", "Пятница · забрать ключи от снятой квартиры"), ("repair", "Пятница · мастер с утра, студия уже своя"), ("quiet", "Свободная пятница · без близких отношений")]:
                            textbutton title id ("week5_profile_" + profile) action [SetVariable("week5_entry_profile", profile), Start("week5_quick")] xsize 1200 ysize 50 padding (20, 9)
                vbar adjustment profiles_scroll style "vscrollbar" xsize 8 ysize 440
            textbutton "Настроить свою историю…" id "history_customize" action ShowMenu("chapter_history_builder", 5) xsize 1200 padding (20, 8)
            text ("Ещё предыстории ниже · прокрути список ↓" if profiles_scroll.value<profiles_scroll.range else "Начало списка выше · прокрути вверх ↑") size 16 color "#acbfc6"
