(()=>{
 if(window.OlegRhythm)return;
 let active=null;
 function close(){if(active){clearTimeout(active.timeout);active.root.remove();active=null;}document.querySelector('canvas')?.focus();}
 function open(person,token,snapshot,settings){
  close();
  if(!window.OLEG_RHYTHM_BASE)return false;
  const root=document.createElement('div');root.id='oleg-rhythm';root.style.cssText='position:fixed;inset:0;z-index:2147483000;background:#15131d;display:flex;flex-direction:column';
  const bar=document.createElement('div');bar.style.cssText='display:flex;gap:12px;padding:8px;color:#eee;background:#18232c;font:14px system-ui;flex-wrap:wrap';root.append(bar);
  const status=document.createElement('span');status.textContent='Подготавливаем игру…';bar.append(status);
  const frame=document.createElement('iframe');frame.title='Общая волна';frame.allow='autoplay';frame.style.cssText='flex:1;border:0;width:100%;background:#15131d';
  frame.src=new URL(window.OLEG_RHYTHM_BASE+(person==='lera'?'vinyl/index.html?':'index.html?game='+encodeURIComponent(person)+'&')+'token='+encodeURIComponent(token),document.baseURI).href;
  active={root,frame,token,snapshot,settings,command:null,ready:false};
  for(const [label,command] of [['Сохранить','save'],['Шары','fallback'],['Оставить за кадром','skip']]){
   const button=document.createElement('button');button.textContent=label;button.style.cssText='padding:7px 12px;cursor:pointer';
   button.onclick=()=>{if(!active)return;if(command==='save'&&active.ready)frame.contentWindow.postMessage({token,command},location.origin);else active.command=command;};bar.append(button);
  }
  const retry=document.createElement('button');retry.textContent='Повторить загрузку';retry.style.cssText='padding:7px 12px;cursor:pointer';retry.hidden=true;
  retry.onclick=()=>{if(active)open(person,token,active.snapshot,settings);};bar.append(retry);
  root.append(frame);document.body.append(root);
  let attempts=0;
  const watchdog=()=>{
   if(active?.token!==token||active.ready)return;
   if(attempts<2){status.textContent='Повторяем загрузку…';const url=new URL(frame.src);url.searchParams.set('retry',String(++attempts));frame.src=url.href;active.timeout=setTimeout(watchdog,15000);}
   else{status.textContent='Не удалось загрузить игру. Можно повторить, сохранить или выбрать шары.';retry.hidden=false;}
  };
  active.timeout=setTimeout(watchdog,15000);
  return true;
 }
 addEventListener('message',e=>{
  if(!active||e.origin!==location.origin||e.source!==active.frame.contentWindow||e.data?.rhythm!==1||e.data.token!==active.token)return;
  const data=e.data;
  if(data.command==='ready'){
   active.ready=true;active.root.querySelector('span').textContent='Общая волна';
   active.frame.contentWindow.postMessage({token:active.token,command:'configure',settings:active.settings||{}},location.origin);
   if(active.snapshot)active.frame.contentWindow.postMessage({token:active.token,command:'restore',snapshot:active.snapshot},location.origin);
  }else if(data.snapshot&&JSON.stringify(data.snapshot).length<200000){
   active.snapshot=data.snapshot;
   if(['done','save'].includes(data.command))active.command=data.command;
  }
 });
 window.OlegRhythm={open,close,poll:()=>JSON.stringify(active?{snapshot:active.snapshot,command:active.command}:{command:'fallback'})};
})();
