# Explicit ready-made histories for chapter selection. Normal continuation
# still enters week6_start/week7_start directly and preserves the played save.
default late_chapter_profile = "nika"

init python:
    def late_chapter_sample(chapter, profile):
        global week5_person, week5_result, week5_finished, week6_finished
        global week7_started, week7_finished
        week7_started = week7_finished = False
        rita_moderation_reset()
        week5_sample("nika_friend" if profile == "friends" else
            profile + "_kiss" if profile in ("nika", "lera", "asya") else "quiet")
        week5_reset()
        if profile in ("nika", "lera", "asya"):
            week5_person, week5_result = profile, "warm_goodbye"
            week5_date.update(confirmed=True, romantic=True, kiss=True)
            week5_event("mutual_kiss")
        elif profile == "friends":
            week5_person, week5_result = "nika", "friend_evening"
            week5_date.update(confirmed=True)
        else:
            week5_person, week5_result = "", "own_evening"
        week5_finished = True
        week6_reset()
        if chapter == 7:
            # A quiet intervening week: no invented nights, promises, gifts,
            # apartment moves or message transcripts.
            week6_finished = True
            week7_reset()
        diary_entries.append("Быстрый вход в главу {}: готовая предыстория.".format(chapter))

label week6_quick:
    $ late_chapter_sample(6, late_chapter_profile)
    jump week6_start

label week7_quick:
    $ late_chapter_sample(7, late_chapter_profile)
    jump week7_start

screen week6_select():
    tag menu
    use late_chapter_select(6, "До тебя доехать")

screen week7_select():
    tag menu
    use late_chapter_select(7, "Кем нарядиться")

screen late_chapter_select(chapter, title):
    use menu_shell(title + (" · глава шестая" if chapter == 6 else " · глава седьмая")):
        vbox:
            xpos 100 ypos 155 xsize 1300 spacing 18
            text "Можно начать сразу с готовой предысторией.\nЧтобы сохранить свои решения из прошлых глав, загрузи своё сохранение." size 23 color "#bfc6c9"
            text "Олег живёт в гостинице. В выбранной романтической линии уже был поцелуй; совместной ночи ещё не было." size 21 color "#bfc6c9" xmaximum 1200
            for profile, caption in [("nika", "Сближаемся с Никой"), ("lera", "Сближаемся с Лерой"), ("asya", "Сближаемся с Асей"), ("friends", "С Никой дружим · без романтики"), ("quiet", "Без близких отношений")]:
                textbutton caption:
                    id ("late_profile_" + profile)
                    action [SetVariable("late_chapter_profile", profile), Start("week6_quick" if chapter == 6 else "week7_quick")]
                    xsize 1200 padding (20, 12)
            textbutton "Настроить предысторию…" id "history_customize" action ShowMenu("late_chapter_builder", chapter) xsize 1200 padding (20, 12)

# A compact, explicit chapter-select constructor; never called by save loading.
default late_chapter_draft = {}

init python:
    late_history_states = [("none", "Не знакомы"), ("friend", "Дружим"), ("interest", "Интерес"), ("kiss", "Поцелуй"), ("night", "Общая ночь"), ("space", "Не спешим"), ("hurt", "Обида")]
    late_history_names = dict(nika="Ника", lera="Лера", asya="Ася", marta="Марта", zhenya="Женя", ulya="Уля")

    def late_history_people(chapter):
        return ("nika", "lera", "asya", "marta") + (("zhenya", "ulya") if chapter == 7 else ())

    def late_history_allowed(chapter, person):
        if person in ("zhenya", "ulya"):
            return ("none", "friend", "interest")
        if person == "marta":
            return ("none", "friend", "interest", "hurt") + (("kiss", "space") if chapter == 7 else ())
        return tuple(key for key, title in late_history_states)

    def late_history_homes(chapter):
        return [("hotel", "Гостиница"), ("studio", "Снял студию"), ("month", "Старый фонд · хозяин иногда приезжает"), ("whole", "Старый фонд · квартира целиком"), ("central", "Старый фонд · отдельная спальня")] + ([("modern", "Новый дом с гулом")] if chapter == 7 else [])

    def late_history_normalize(chapter, draft):
        d = copy.deepcopy(draft)
        d["relations"] = {p: d.get("relations", {}).get(p, "none") for p in late_history_people(chapter)}
        for p, state in list(d["relations"].items()):
            if state not in late_history_allowed(chapter, p):
                d["relations"][p] = "none"
        nights = [p for p, state in d["relations"].items() if state == "night"]
        for p in nights[1:]:
            d["relations"][p] = "kiss"
        if nights:
            d["friday"] = nights[0]
        elif d.get("friday") not in ("nika", "lera", "asya") or d["relations"].get(d.get("friday")) in ("none", "hurt"):
            d["friday"] = ""
        if d.get("home") not in dict(late_history_homes(chapter)):
            d["home"] = "hotel"
        if d.get("rita") not in ("none", "contact", "moderator"):
            d["rita"] = "none"
        dinner = d.get("dinner", "")
        if chapter != 7 or d["home"] == "hotel" or dinner not in ("nika", "lera", "asya", "marta") or d["relations"].get(dinner, "none") in ("none", "hurt"):
            d["dinner"] = ""
        return d

    def late_history_template(chapter, profile):
        relations = {p: "none" for p in late_history_people(chapter)}
        if profile in ("nika", "lera", "asya"):
            relations[profile] = "kiss"
        elif profile == "friends":
            relations["nika"] = "friend"
        return late_history_normalize(chapter, dict(relations=relations, home="hotel", rita="none", friday="nika" if profile == "friends" else profile if profile in ("nika", "lera", "asya") else "", dinner=""))

    def late_history_pick(chapter, draft, field, value, person=None):
        d = copy.deepcopy(draft)
        if person:
            if value == "night":
                for p, state in list(d["relations"].items()):
                    if state == "night":
                        d["relations"][p] = "kiss"
            d["relations"][person] = value
        else:
            d[field] = value
        return late_history_normalize(chapter, d)

    def late_history_summary(chapter, draft):
        d = late_history_normalize(chapter, draft)
        words = dict(none="не знакомы", friend="дружим", interest="есть взаимный интерес", kiss="уже целовались", night="были поцелуй и общая ночь", space="решили не торопиться с прикосновениями", hurt="осталась обида после сорванной встречи")
        lines = [late_history_names[p] + ": " + ("осталась обида после отменённой прогулки" if p == "marta" else "осталась обида после ухода без объяснения") + "." if d["relations"][p] == "hurt" else late_history_names[p] + ": " + words[d["relations"][p]] + "." for p in late_history_people(chapter)]
        lines += ["Варя — друг и коллега.", dict(late_history_homes(chapter))[d["home"]] + "."]
        lines.append("Вечер пятой главы: " + (late_history_names[d["friday"]] if d["friday"] else "провёл один") + ".")
        lines.append({"none":"С Ритой не обменивались контактами.", "contact":"С Ритой общаемся; от модерации отказался.", "moderator":"Помогаю Рите с организационным чатом; встреча ещё не организована."}[d["rita"]])
        if d["dinner"]:
            lines.append("Во вторник в 19:00 у Олега ужин с " + dict(nika="Никой", lera="Лерой", asya="Асей", marta="Мартой")[d["dinner"]] + ".")
        return lines

    def late_chapter_custom(chapter, draft):
        global week4_rita_contact, week4_package, week5_person, week5_result, week5_finished
        global week6_finished, week7_started, week7_finished, housing_home
        global home_keepsakes, home_keepsakes_unpacked
        home_keepsakes, home_keepsakes_unpacked = {}, []
        d = late_history_normalize(chapter, draft)
        # Build from the existing chapter boundary, then replace every selectable
        # relation. No messages or physical keepsakes are inferred from a contact.
        week5_sample("quiet")
        for p, r in week4_relations.items():
            r.update(known=p == "varya", mode="friendship" if p == "varya" else "uncertain", previous_touch="", new_touch="", issues=[], events=[], promises=[], facts={}, outcome="", invited=False, last_meeting="", last_status="", last_departure={})
        week4_history.clear()
        week4_rita_contact = d["rita"] != "none"
        week4_package = "delivered" if week4_rita_contact else "none"
        rita_moderation.update(invited=week4_rita_contact, joined=d["rita"] == "moderator", active=d["rita"] == "moderator")
        for p in ("nika", "lera", "asya", "marta"):
            state = d["relations"][p]
            r = week4_relations[p]
            r.update(known=state != "none", mode="friendship" if state == "friend" else "interest" if state != "none" else "uncertain")
            if state in ("kiss", "night") and p != "marta":
                r["new_touch"] = "kiss"
                r["facts"]["kissed_chapter4"] = True
            if state == "space":
                r["previous_touch"] = "space"
            if state == "hurt":
                r["issues"] = [dict(cause="early_departure" if p != "marta" else "cancelled_walk", status="open", detail="Ушёл со встречи без объяснения" if p != "marta" else "Отменил согласованную прогулку")]
                r["outcome"] = "unfinished"
        week4_entry["marta"] = dict(contact=d["relations"]["marta"] != "none", relation=week4_relations["marta"]["mode"], plan="")
        home = d["home"]
        week4_home.update(kind=home if home in ("hotel", "month", "whole") else "new", actual_home=home if home not in ("hotel", "month", "whole") else "", keys_due="done", visit="", search=False)
        housing_home = home if home in ("studio", "central", "modern") else ""
        week5_reset()
        week5_person = d["friday"]
        week5_result = "own_evening"
        if week5_person:
            state = d["relations"][week5_person]
            week5_date.update(confirmed=True, romantic=state != "friend", kiss=state in ("kiss", "night"), night=state == "night", invited_home=state == "night", night_answer="yes" if state == "night" else "")
            week5_result = "shared_night" if state == "night" else "friend_evening" if state == "friend" else "warm_goodbye"
            if week5_date["kiss"]:
                week5_event("mutual_kiss", person=week5_person)
            week5_relations[week5_person]["facts"]["chapter5"] = dict(confirmed=True, result=week5_result, kiss=week5_date["kiss"], invited_home=week5_date["invited_home"], night_answer=week5_date["night_answer"], night=week5_date["night"], continuation="")
        state = d["relations"]["marta"]
        if state != "none":
            week5_marta.update(scene_done=state != "hurt", plan="cancelled" if state == "hurt" else "saturday14", next="friendship" if state == "friend" else "cautious" if state == "hurt" else "mutual_date_interest")
        week5_finished = True
        week5_laundry.update(method="hotel" if home == "hotel" else "home", where="home", status="clean", **{"return":""})
        week6_reset()
        week7_started = week7_finished = False
        if chapter == 7:
            for p in ("zhenya", "ulya"):
                state = d["relations"][p]
                if state != "none":
                    week6_exchange(p, "friendship" if state == "friend" else "interest")
            if d["relations"]["marta"] == "kiss":
                week6_stamp("Прогулка с Мартой", 840, 6)
                week6_date_make("marta", 6, 840)
                week6_dates["marta"].update(played=True, kiss=True, touch=True, result="mutual_kiss")
                week6_relations["marta"]["new_touch"] = "kiss"
                week6_relations["marta"]["facts"]["kissed_chapter6"] = True
                week6_event("mutual_kiss", "Отдельно предложен и принят", "marta")
            if d["dinner"]:
                person = d["dinner"]
                dinner = dict(person=person, agreed=True, played=False, day="chapter7_tuesday", time="19:00")
                housing_story()["dinner"] = copy.deepcopy(dinner)
                week6_relations[person]["facts"]["housing_dinner"] = copy.deepcopy(dinner)
                week6_relations[person]["promises"].append("Ужин у Олега во вторник после шестой главы, 19:00")
            week6_finished = True
            week7_reset()
        diary_entries.append("Готовая предыстория к главе {}: ".format(chapter) + " ".join(late_history_summary(chapter, d)))

label week6_custom:
    $ late_chapter_custom(6, late_chapter_draft)
    jump week6_start

label week7_custom:
    $ late_chapter_custom(7, late_chapter_draft)
    jump week7_start

screen late_chapter_builder(chapter):
    tag menu
    default step = 0
    default draft = late_history_template(chapter, late_chapter_profile)
    use menu_shell("Своя предыстория · глава " + str(chapter)):
        vbox:
            xpos 100 ypos 145 xsize 1350 spacing 17
            hbox:
                spacing 16
                for index, name in enumerate(("1 · Отношения", "2 · Быт и дела", "3 · Готово")):
                    textbutton name action SetScreenVariable("step", index) selected step == index text_size 23 padding (22, 10)
            if step == 0:
                text "Отметь только то, что важно. Остальное можно оставить как есть." size 23 color "#bfc6c9"
                for person in late_history_people(chapter):
                    hbox:
                        spacing 7
                        fixed:
                            xsize 120 ysize 53
                            text late_history_names[person] size 24 yalign .5
                        for state, caption in late_history_states:
                            if state in late_history_allowed(chapter, person):
                                textbutton caption:
                                    id ("history_" + person + "_" + state)
                                    xsize 148 ysize 53 padding (5, 6) text_size 18 text_xalign .5
                                    selected draft["relations"][person] == state
                                    action SetScreenVariable("draft", late_history_pick(chapter, draft, "relations", state, person))
                            else:
                                null width 148 height 53
                text "Варя — друг и коллега. Общая ночь возможна с одной девушкой.\n«Обида»: Олег ушёл без объяснения; с Мартой — отменил согласованную прогулку." size 19 color "#bfc6c9"
            elif step == 1:
                text "Где живёт Олег?" size 25
                hbox:
                    spacing 25
                    vbox:
                        spacing 5
                        for value, caption in late_history_homes(chapter):
                            textbutton caption:
                                id ("history_home_" + value)
                                xsize 590 padding (14, 8) text_size 21 selected draft["home"] == value
                                action SetScreenVariable("draft", late_history_pick(chapter, draft, "home", value))
                    vbox:
                        spacing 8 xsize 620
                        text "Вечер пятой главы" size 24
                        if "night" in draft["relations"].values():
                            text ("Провели ночь вместе: " + late_history_names[draft["friday"]]) size 21 color "#d5b384"
                        else:
                            for person in ("", "nika", "lera", "asya"):
                                if not person or draft["relations"][person] not in ("none", "hurt"):
                                    textbutton ("Вечер для себя" if not person else "Встреча: " + late_history_names[person]):
                                        id ("history_friday_" + (person or "alone"))
                                        selected draft["friday"] == person text_size 21 padding (14, 6)
                                        action SetScreenVariable("draft", late_history_pick(chapter, draft, "friday", person))
                        text "Рита и её чат" size 24
                        for value, caption in [("none", "Не обменивались контактами"), ("contact", "Общаемся, без модерации"), ("moderator", "Помогаю с организацией")]:
                            textbutton caption:
                                id ("history_rita_" + value)
                                selected draft["rita"] == value text_size 21 padding (14, 6)
                                action SetScreenVariable("draft", late_history_pick(chapter, draft, "rita", value))
                if chapter == 7 and draft["home"] != "hotel":
                    hbox:
                        spacing 10
                        text "Ужин во вторник, 19:00:" size 21 yalign .5
                        for person in ("", "nika", "lera", "asya", "marta"):
                            if not person or draft["relations"][person] not in ("none", "hurt"):
                                textbutton (late_history_names[person] if person else "Не обещал"):
                                    id ("history_dinner_" + (person or "none"))
                                    selected draft["dinner"] == person text_size 20 padding (10, 8)
                                    action SetScreenVariable("draft", late_history_pick(chapter, draft, "dinner", person))
            else:
                text "С этой историей начнётся глава" size 25 color "#d5b384"
                viewport:
                    xsize 1290 ysize 445 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 10
                        for line in late_history_summary(chapter, draft):
                            text line size 23 xmaximum 1210
                text "Это отдельный старт. Чтобы продолжить своё прохождение, загрузи сохранение." size 20 color "#bfc6c9"
        hbox:
            xpos 100 ypos 785 spacing 24
            if step:
                textbutton "← Назад" action SetScreenVariable("step", step - 1) text_size 23
            if step < 2:
                textbutton "Дальше →" id "history_next" action SetScreenVariable("step", step + 1) text_size 23
            else:
                textbutton "Начать главу":
                    id "history_start"
                    action [SetVariable("late_chapter_draft", copy.deepcopy(draft)), Start("week6_custom" if chapter == 6 else "week7_custom")]
                    text_size 25
