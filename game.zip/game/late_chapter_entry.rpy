# Explicit ready-made histories for chapter selection. Normal continuation
# still enters week6_start/week7_start directly and preserves the played save.
default late_chapter_profile = "nika"

init python:
    def late_chapter_sample(chapter, profile):
        # Quick presets use the same validated route as the constructor.
        late_chapter_custom(chapter, late_history_template(chapter, profile))

label week6_quick:
    $ late_chapter_sample(6, late_chapter_profile)
    jump week6_start

label week7_quick:
    $ late_chapter_sample(7, late_chapter_profile)
    jump week7_start

screen week6_select():
    tag menu
    use late_chapter_select(6, "До тебя доехать")

screen week7_select():
    tag menu
    use late_chapter_select(7, "Кем нарядиться")

screen late_chapter_select(chapter, title):
    use menu_shell(title + (" · глава шестая" if chapter == 6 else " · глава седьмая")):
        vbox:
            xpos 100 ypos 155 xsize 1300 spacing 18
            text "Можно начать сразу с готовой предысторией.\nЧтобы сохранить свои решения из прошлых глав, загрузи своё сохранение." size 23 color "#bfc6c9"
            text "Олег живёт в гостинице. В выбранной романтической линии уже был поцелуй; совместной ночи ещё не было." size 21 color "#bfc6c9" xmaximum 1200
            for profile, caption in [("nika", "Сближаемся с Никой"), ("lera", "Сближаемся с Лерой"), ("asya", "Сближаемся с Асей"), ("friends", "С Никой дружим · без романтики"), ("quiet", "Без близких отношений")]:
                textbutton caption:
                    id ("late_profile_" + profile)
                    action [SetVariable("late_chapter_profile", profile), Start("week6_quick" if chapter == 6 else "week7_quick")]
                    xsize 1200 padding (20, 12)
            textbutton "Настроить предысторию…" id "history_customize" action ShowMenu("late_chapter_builder", chapter) xsize 1200 padding (20, 12)

# A compact, explicit chapter-select constructor; never called by save loading.
default late_chapter_draft = {}

init python:
    late_history_states = [("none", "Не знакомы"), ("friend", "Дружим"), ("interest", "Интерес"), ("kiss", "Поцелуй"), ("night", "Общая ночь"), ("space", "Не спешим"), ("hurt", "Обида")]
    late_history_names = dict(nika="Ника", lera="Лера", asya="Ася", marta="Марта", zhenya="Женя", ulya="Уля")

    def late_history_people(chapter):
        return ("nika", "lera", "asya", "marta") + (("zhenya", "ulya") if chapter == 7 else ())

    def late_history_allowed(chapter, person):
        if person == "ulya":
            return ("none", "contact")
        if person == "zhenya":
            return ("none", "contact", "friend", "interest")
        if person == "marta":
            return ("none", "friend", "interest", "hurt") + (("kiss",) if chapter == 7 else ())
        if person in ("lera", "asya"):
            return ("known", "interest", "kiss", "night", "space", "hurt")
        return tuple(key for key, title in late_history_states)

    def late_history_columns(person):
        if person == "ulya":
            return ("none", "contact")
        if person == "zhenya":
            return ("none", "contact", "friend", "interest")
        return ("known" if person in ("lera", "asya") else "none", "friend", "interest", "kiss", "night", "space", "hurt")

    def late_history_caption(person, state):
        if state in ("known", "contact"):
            return "Общаемся"
        if state == "none" and person in ("nika", "zhenya", "ulya"):
            return "Нет контакта"
        return dict(late_history_states)[state]

    def late_history_schedule(chapter, draft):
        """A witness for the finite kissing slots in the shipping script.

        Chapter 4: one evening. Chapter 5: one Friday. Its shared night
        requires a prior chapter-4 kiss with that SAME person. Chapter 6:
        one main weekend outing plus the separately promised Marta Saturday.
        """
        relations = draft.get("relations", {})
        close = {p for p in ("nika", "lera", "asya") if relations.get(p) in ("kiss", "night")}
        nights = [p for p in close if relations[p] == "night"]
        friday = draft.get("friday", "")
        if len(nights) > 1 or (nights and friday != nights[0]):
            return None
        fifth = friday if friday in close else ""
        fourths = nights if nights else [p for p in ("nika", "lera", "asya") if p in close] + [""]
        for fourth in fourths:
            rest = close - {fourth, fifth}
            if len(rest) > (1 if chapter == 7 else 0):
                continue
            main = next(iter(rest), "")
            return dict(chapter4=fourth, chapter5=fifth, chapter6_main=main,
                chapter6_marta=chapter == 7 and relations.get("marta") == "kiss")
        return None

    def late_history_problem(chapter, draft):
        for person in late_history_people(chapter):
            if draft.get("relations", {}).get(person) not in late_history_allowed(chapter, person):
                return "Такого состояния этой линии к выбранной главе ещё нет."
        if draft.get("friday") and draft["relations"].get(draft["friday"]) not in ("friend", "interest", "kiss", "night", "space"):
            return "Вечер пятой главы требует действующего общения с этой девушкой."
        if draft.get("home") not in dict(late_history_homes(chapter)):
            return "Эту квартиру ещё нельзя снять к выбранной главе."
        if draft.get("dinner"):
            return "Обещанный ужин доступен только в линии тихой квартиры; этот маршрут пока не открыт."
        if late_history_schedule(chapter, draft) is None:
            if "night" in draft["relations"].values():
                return "Для общей ночи нужны оба вечера — поцелуй в четвёртой главе и встреча с той же девушкой в пятой."
            return "Не хватает доступных встреч: один вечер в четвёртой главе, один в пятой" + (" и одна основная прогулка в шестой." if chapter == 7 else ".")
        return ""

    def late_history_candidate(chapter, draft, field, value, person=None):
        d = copy.deepcopy(draft)
        if person:
            d["relations"][person] = value
            if value == "night" and not any(p != person and state == "night" for p, state in d["relations"].items()):
                d["friday"] = person
            elif value == "kiss" and not d.get("friday") and not d.get("friday_explicit") and late_history_schedule(chapter, d) is None:
                d["friday"] = person
        else:
            d[field] = value
            if field == "friday":
                d["friday_explicit"] = True
        return late_history_normalize(chapter, d)

    def late_history_pick_problem(chapter, draft, field, value, person=None):
        return late_history_problem(chapter, late_history_candidate(chapter, draft, field, value, person))

    def late_history_homes(chapter):
        return [("hotel", "Гостиница"), ("studio", "Снял студию"), ("month", "Старый фонд · хозяин иногда приезжает"), ("whole", "Старый фонд · квартира целиком"), ("central", "Старый фонд · отдельная спальня")] + ([("modern", "Новый дом с гулом")] if chapter == 7 else [])

    def late_history_normalize(chapter, draft):
        d = copy.deepcopy(draft)
        d["relations"] = {p: d.get("relations", {}).get(p, "known" if p in ("lera", "asya") else "none") for p in late_history_people(chapter)}
        for p, state in list(d["relations"].items()):
            if state not in late_history_allowed(chapter, p):
                d["relations"][p] = "known" if p in ("lera", "asya") else "contact" if p == "ulya" and state in ("friend", "interest") else "none"
        if d.get("friday") not in ("nika", "lera", "asya") or d["relations"].get(d.get("friday")) not in ("friend", "interest", "kiss", "night", "space"):
            d["friday"] = ""
        if d.get("home") not in dict(late_history_homes(chapter)):
            d["home"] = "hotel"
        if d.get("rita") not in ("none", "contact", "moderator"):
            d["rita"] = "none"
        # No currently reachable home can produce the quiet-home dinner promise.
        d["dinner"] = ""
        return d

    def late_history_template(chapter, profile):
        relations = {p: "known" if p in ("lera", "asya") else "none" for p in late_history_people(chapter)}
        if profile in ("nika", "lera", "asya"):
            relations[profile] = "kiss"
        elif profile == "friends":
            relations["nika"] = "friend"
        return late_history_normalize(chapter, dict(relations=relations, home="hotel", rita="none", friday="nika" if profile == "friends" else profile if profile in ("nika", "lera", "asya") else "", dinner=""))

    def late_history_pick(chapter, draft, field, value, person=None):
        d = late_history_candidate(chapter, draft, field, value, person)
        return copy.deepcopy(draft) if late_history_problem(chapter, d) else d

    def late_history_focus(chapter, draft, profile):
        d = late_history_template(chapter, profile)
        for field in ("home", "rita"):
            d[field] = draft[field]
        return late_history_normalize(chapter, d)

    def late_history_summary(chapter, draft):
        d = late_history_normalize(chapter, draft)
        words = dict(known="знакомы, без романтического сближения", contact="общаемся о творчестве", none="нет контакта", friend="дружим", interest="есть взаимный интерес", kiss="уже целовались", night="были поцелуй и общая ночь", space="решили не торопиться с прикосновениями", hurt="осталась обида после сорванной встречи")
        lines = [late_history_names[p] + ": " + ("осталась обида после отменённой прогулки" if p == "marta" else "осталась обида после ухода без объяснения") + "." if d["relations"][p] == "hurt" else late_history_names[p] + ": " + words[d["relations"][p]] + "." for p in late_history_people(chapter)]
        lines += ["Варя — друг и коллега.", dict(late_history_homes(chapter))[d["home"]] + "."]
        lines.append("Вечер пятой главы: " + (late_history_names[d["friday"]] if d["friday"] else "провёл один") + ".")
        lines.append({"none":"С Ритой не обменивались контактами.", "contact":"С Ритой общаемся; от модерации отказался.", "moderator":("Помог Рите организовать встречу; она состоялась." if chapter == 7 else "Помогаю Рите с организационным чатом; встреча ещё не организована.")}[d["rita"]])
        if d["dinner"]:
            lines.append("Во вторник в 19:00 у Олега ужин с " + dict(nika="Никой", lera="Лерой", asya="Асей", marta="Мартой")[d["dinner"]] + ".")
        return lines

    def late_chapter_custom(chapter, draft):
        global chapter_history_building, history_entry_chapter
        previous = chapter_history_building
        chapter_history_building = True
        history_entry_chapter = chapter
        try:
            late_chapter_custom_events(chapter, draft)
        finally:
            chapter_history_building = previous

    def late_chapter_custom_events(chapter, draft):
        global week4_rita_contact, week4_package, week5_person, week5_result, week5_finished
        global week6_finished, week6_stage, week6_day, week6_clock, week7_started, week7_finished, housing_home
        global home_keepsakes, home_keepsakes_unpacked
        d = late_history_normalize(chapter, draft)
        problem = late_history_problem(chapter, d)
        if problem:
            raise ValueError(problem)
        messenger_reset_optional_history()
        route = late_history_schedule(chapter, d)
        home_keepsakes, home_keepsakes_unpacked = {}, []
        # Build from the existing chapter boundary, then replace every selectable
        # relation. No messages or physical keepsakes are inferred from a contact.
        week5_sample("nika_friend" if d["relations"]["nika"] == "friend" else "nika_first" if d["relations"]["nika"] != "none" else "quiet")
        for p, r in week4_relations.items():
            r.update(known=p == "varya", mode="friendship" if p == "varya" else "uncertain", previous_touch="", new_touch="", issues=[], events=[], promises=[], facts={}, outcome="", invited=False, last_meeting="", last_status="", last_departure={})
        week4_history.clear()
        week4_rita_contact = d["rita"] != "none"
        week4_package = "delivered" if week4_rita_contact else "none"
        rita_moderation.update(invited=week4_rita_contact, joined=d["rita"] == "moderator", active=d["rita"] == "moderator")
        for p in ("nika", "lera", "asya", "marta"):
            state = d["relations"][p]
            r = week4_relations[p]
            r.update(known=state != "none", mode="friendship" if state == "friend" else "interest" if state not in ("none", "known") else "uncertain")
            if state == "space":
                r["previous_touch"] = "space"
            if state == "hurt":
                r["issues"] = [dict(cause="early_departure" if p != "marta" else "cancelled_walk", status="open", detail="Ушёл со встречи без объяснения" if p != "marta" else "Отменил согласованную прогулку")]
                r["outcome"] = "unfinished"
        week4_entry["marta"] = dict(contact=d["relations"]["marta"] != "none", relation=week4_relations["marta"]["mode"], plan="")
        if route["chapter4"]:
            person = route["chapter4"]
            week4_relations[person]["invited"] = True
            week4_event(person, "mutual_time")
            week4_complete_evening(person, "warm")
            assert week4_can_kiss(person)
            week4_remember_kiss(person, "Взаимный поцелуй после встречи")
        home = d["home"]
        previous_home = "hotel" if home in ("central", "modern") else home
        week4_home.update(kind=previous_home if previous_home in ("hotel", "month", "whole") else "new", actual_home=previous_home if previous_home not in ("hotel", "month", "whole") else "", keys_due="done", visit="", search=False)
        if home == "central":
            week4_home.update(candidate="central", keys_due="friday")
        housing_home = "studio" if previous_home == "studio" else ""
        week5_reset()
        if home == "central":
            week5_home.update(kind="new", actual_home="central", keys_due="done")
            housing_home = "central"
        week5_person = d["friday"]
        week5_result = "own_evening"
        if week5_person:
            state = d["relations"][week5_person]
            week5_date.update(confirmed=True, romantic=state != "friend", mutual_time=True, kiss=state in ("kiss", "night"), night=state == "night", invited_home=state == "night", night_answer="yes" if state == "night" else "")
            week5_result = "shared_night" if state == "night" else "friend_evening" if state == "friend" else "warm_goodbye"
            if week5_date["kiss"]:
                assert week5_can_kiss()
                week5_event("mutual_kiss", person=week5_person)
            if state == "night":
                assert week5_night_welcome()
                week5_event("mutual_night_agreed")
                week5_event("shared_night", "Взаимное решение; интимная сцена за затемнением")
            week5_relations[week5_person]["facts"]["chapter5"] = dict(confirmed=True, result=week5_result, kiss=week5_date["kiss"], invited_home=week5_date["invited_home"], night_answer=week5_date["night_answer"], night=week5_date["night"], continuation="")
        state = d["relations"]["marta"]
        if state != "none":
            week5_marta.update(scene_done=state != "hurt", plan="cancelled" if state == "hurt" else "saturday14", next="friendship" if state == "friend" else "cautious" if state == "hurt" else "mutual_date_interest")
        week5_finished = True
        week5_laundry.update(method="hotel" if home == "hotel" else "home", where="home", status="clean", **{"return":""})
        week6_reset()
        week7_started = week7_finished = False
        if chapter == 7:
            if home == "modern":
                week6_home.update(kind="new", actual_home="modern", keys_due="done")
                week6_housing.update(previous_home=copy.deepcopy(week6_entry["home"]), candidate="modern", decision="accepted", moved=True, move_due="sunday_morning")
                housing_home = "modern"
                week6_stamp("Переезд", 550, 7)
                week6_event("moved_home", "modern")
            for p in ("ulya", "zhenya"):
                state = d["relations"][p]
                if state != "none":
                    if p == "zhenya":
                        week6_varya.update(role="audience", concert_day="friday", start=1140, number=1170, rehearsal=False, rehearsal_time=1140, rehearsal_end=1200)
                        week6_concert.update(guest="", zhenya_food=dict(done=True, guest=""))
                        week6_stamp("После концерта", 1320, 5)
                    else:
                        week6_exhibition.update(visited=True, day=3)
                        week6_stamp("Выставка", 1110, 3)
                    week6_exchange(p, "creative" if p == "ulya" else "friendship" if state == "friend" else "interest" if state == "interest" else "uncertain")
                    if p == "zhenya" and state == "interest":
                        week6_relations[p]["facts"]["personal_interest_chapter6"] = True
            if route["chapter6_marta"]:
                week6_relations["marta"]["facts"]["chapter6_saturday"] = "14:00"
            for person in (["marta"] if route["chapter6_marta"] else []) + ([route["chapter6_main"]] if route["chapter6_main"] else []):
                day, minute = dict(marta=(6,840), lera=(6,1170), nika=(7,720), asya=(7,600))[person]
                week6_stamp("Планы на выходные", 1320, 5)
                week6_date_make(person, day, minute)
                week6_stamp("Прогулка", minute, day)
                assert week6_can_touch(person)
                week6_dates[person].update(played=True, kiss=True, touch=True, result="mutual_kiss")
                week6_relations[person]["new_touch"] = "kiss"
                week6_relations[person]["facts"]["kissed_chapter6"] = True
                week6_event("mutual_kiss", "Отдельно предложен и принят", person)
            if d["rita"] == "moderator":
                week6_rita["puzzle"] = dict(stage=2, status="completed", completed=True, resolution="ready_room", confirmed=["rita", "ira", "lesha", "denis", "agent"])
                week6_stamp("Вечер воскресенья", 1320, 7)
                week6_event("moderation_completed", "Оплаченные условия, 15–18 и уборка соблюдены", "rita")
            week6_events.sort(key=lambda event: (event["day"], event["time"]))
            week6_stage, week6_day, week6_clock = "finished", 7, 1320
            week6_finished = True
            week7_reset()
        diary_entries[:] = diary_history_opening(chapter, d)

label week6_custom:
    $ late_chapter_custom(6, late_chapter_draft)
    jump week6_start

label week7_custom:
    $ late_chapter_custom(7, late_chapter_draft)
    jump week7_start

screen late_chapter_builder(chapter):
    tag menu
    default step = 0
    default details = False
    default focus = late_chapter_profile
    default draft = late_history_template(chapter, late_chapter_profile)
    use menu_shell("Своя предыстория · глава " + str(chapter)):
        vbox:
            xpos 100 ypos 145 xsize 1350 spacing 17
            hbox:
                spacing 16
                for index, name in enumerate(("1 · Отношения", "2 · Быт и дела", "3 · Готово")):
                    textbutton name action SetScreenVariable("step", index) selected step == index text_size 23 padding (22, 10)
            if step == 0:
                if not details:
                    text "С кем был вечер пятой главы? Можно выбрать основу и сразу начать." size 23 color "#bfc6c9"
                    hbox:
                        spacing 10
                        for profile, caption in [("nika", "Ника"), ("lera", "Лера"), ("asya", "Ася"), ("friends", "Дружба с Никой"), ("quiet", "Вечер для себя")]:
                            textbutton caption:
                                id ("history_focus_" + profile)
                                action [SetScreenVariable("focus", profile), SetScreenVariable("draft", late_history_focus(chapter, draft, profile))]
                                selected focus == profile text_size 22 padding (18, 12)
                    if focus in ("nika", "lera", "asya"):
                        text "Как закончился ваш вечер?" size 25
                        hbox:
                            spacing 10
                            for state, caption in [("interest", "Без поцелуя"), ("kiss", "Поцеловались"), ("night", "Ночь вместе"), ("space", "Решили не спешить")]:
                                textbutton caption:
                                    id ("history_" + focus + "_" + state)
                                    sensitive not late_history_pick_problem(chapter, draft, "relations", state, focus)
                                    tooltip late_history_pick_problem(chapter, draft, "relations", state, focus)
                                    action SetScreenVariable("draft", late_history_pick(chapter, draft, "relations", state, focus))
                                    selected draft["relations"][focus] == state text_size 21 padding (16, 10)
                textbutton ("← К быстрой настройке" if details else "Настроить остальные знакомства…") id "history_details" action ToggleScreenVariable("details") text_size 23
                if details:
                    for person in late_history_people(chapter):
                        hbox:
                            spacing 7
                            fixed:
                                xsize 120 ysize 53
                                text late_history_names[person] size 24 yalign .5
                            for state in late_history_columns(person):
                                if state in late_history_allowed(chapter, person):
                                    $ caption = late_history_caption(person, state)
                                    textbutton caption:
                                        id ("history_" + person + "_" + state)
                                        xsize 148 ysize 53 padding (5, 6) text_size 18 text_xalign .5
                                        text_insensitive_color "#69746e"
                                        sensitive not late_history_pick_problem(chapter, draft, "relations", state, person)
                                        tooltip late_history_pick_problem(chapter, draft, "relations", state, person)
                                        selected draft["relations"][person] == state
                                        action SetScreenVariable("draft", late_history_pick(chapter, draft, "relations", state, person))
                                else:
                                    null width 148 height 53
                    text (late_history_problem(chapter, draft) or "Варя — друг и коллега. Недоступные сочетания затемнены: учитываются реальные встречи каждой главы.") size 19 color "#bfc6c9"
            elif step == 1:
                text "Где живёт Олег?" size 25
                hbox:
                    spacing 25
                    vbox:
                        spacing 5
                        for value, caption in late_history_homes(chapter):
                            textbutton caption:
                                id ("history_home_" + value)
                                xsize 590 padding (14, 8) text_size 21 selected draft["home"] == value
                                action SetScreenVariable("draft", late_history_pick(chapter, draft, "home", value))
                    vbox:
                        spacing 8 xsize 620
                        text "Вечер пятой главы" size 24
                        if "night" in draft["relations"].values():
                            text ("Провели ночь вместе: " + late_history_names[draft["friday"]]) size 21 color "#d5b384"
                        else:
                            for person in ("", "nika", "lera", "asya"):
                                if not person or draft["relations"][person] in ("friend", "interest", "kiss", "night", "space"):
                                    textbutton ("Вечер для себя" if not person else "Встреча: " + late_history_names[person]):
                                        id ("history_friday_" + (person or "alone"))
                                        sensitive not late_history_pick_problem(chapter, draft, "friday", person)
                                        selected draft["friday"] == person text_size 21 padding (14, 6)
                                        action SetScreenVariable("draft", late_history_pick(chapter, draft, "friday", person))
                        text "Рита и её чат" size 24
                        for value, caption in [("none", "Не обменивались контактами"), ("contact", "Общаемся, без модерации"), ("moderator", "Помогаю с организацией")]:
                            textbutton caption:
                                id ("history_rita_" + value)
                                selected draft["rita"] == value text_size 21 padding (14, 6)
                                action SetScreenVariable("draft", late_history_pick(chapter, draft, "rita", value))
            else:
                text "С этой историей начнётся глава" size 25 color "#d5b384"
                viewport:
                    xsize 1290 ysize 445 mousewheel True draggable True scrollbars "vertical"
                    vbox:
                        spacing 10
                        for line in late_history_summary(chapter, draft):
                            text line size 23 xmaximum 1210
                text "Это отдельный старт. Чтобы продолжить своё прохождение, загрузи сохранение." size 20 color "#bfc6c9"
        hbox:
            xpos 100 ypos 785 spacing 24
            if step:
                textbutton "← Назад" action SetScreenVariable("step", step - 1) text_size 23
            if step < 2:
                textbutton "Дальше →" id "history_next" action SetScreenVariable("step", step + 1) text_size 23
            textbutton "Начать главу":
                id "history_start"
                sensitive not late_history_problem(chapter, draft)
                action [SetVariable("late_chapter_draft", copy.deepcopy(draft)), Start("week6_custom" if chapter == 6 else "week7_custom")]
                text_size 25
