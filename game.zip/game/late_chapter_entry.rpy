# Explicit ready-made histories for chapter selection. Normal continuation
# still enters week6_start/week7_start directly and preserves the played save.
default late_chapter_profile = "nika"

init python:
    def late_chapter_sample(chapter, profile):
        global week5_person, week5_result, week5_finished, week6_finished
        global week7_started, week7_finished
        week7_started = week7_finished = False
        rita_moderation_reset()
        week5_sample("nika_friend" if profile == "friends" else
            profile + "_kiss" if profile in ("nika", "lera", "asya") else "quiet")
        week5_reset()
        if profile in ("nika", "lera", "asya"):
            week5_person, week5_result = profile, "warm_goodbye"
            week5_date.update(confirmed=True, romantic=True, kiss=True)
            week5_event("mutual_kiss")
        elif profile == "friends":
            week5_person, week5_result = "nika", "friend_evening"
            week5_date.update(confirmed=True)
        else:
            week5_person, week5_result = "", "own_evening"
        week5_finished = True
        week6_reset()
        if chapter == 7:
            # A quiet intervening week: no invented nights, promises, gifts,
            # apartment moves or message transcripts.
            week6_finished = True
            week7_reset()
        diary_entries.append("Быстрый вход в главу {}: готовая предыстория.".format(chapter))

label week6_quick:
    $ late_chapter_sample(6, late_chapter_profile)
    jump week6_start

label week7_quick:
    $ late_chapter_sample(7, late_chapter_profile)
    jump week7_start

screen week6_select():
    tag menu
    use late_chapter_select(6, "До тебя доехать")

screen week7_select():
    tag menu
    use late_chapter_select(7, "Кем нарядиться")

screen late_chapter_select(chapter, title):
    use menu_shell(title + (" · глава шестая" if chapter == 6 else " · глава седьмая")):
        vbox:
            xpos 100 ypos 155 xsize 1300 spacing 18
            text "Можно начать сразу с готовой предысторией.\nЧтобы сохранить свои решения из прошлых глав, загрузи своё сохранение." size 23 color "#bfc6c9"
            text "Олег живёт в гостинице. В выбранной романтической линии уже был поцелуй; совместной ночи ещё не было." size 21 color "#bfc6c9" xmaximum 1200
            for profile, caption in [("nika", "Сближаемся с Никой"), ("lera", "Сближаемся с Лерой"), ("asya", "Сближаемся с Асей"), ("friends", "С Никой дружим · без романтики"), ("quiet", "Без близких отношений")]:
                textbutton caption:
                    id ("late_profile_" + profile)
                    action [SetVariable("late_chapter_profile", profile), Start("week6_quick" if chapter == 6 else "week7_quick")]
                    xsize 1200 padding (20, 12)
