# Local movement inside the existing painted plates. Sprites, object inserts
# and contact CGs keep their original geometry and sharpness.
init -6 python:
    city_motion_assets.update({
        "images/hotel-morning.webp": "city.window_rain",
        "images/hotel-night.webp": "city.window_night",
        "images/chapter3/ch3-cafe-evening-empty-v1.webp": "city.coffee_steam",
        "images/housing/studio-v2.webp": "city.curtain",
        "images/week6/exhibition-hammock-v3.webp": "city.projected_sea",
        "images/week6/exhibition-closing-on-v1.webp": "city.projected_sea",
        "images/week6/exhibition-off-v1.webp": "city.gallery_snow",
        "images/week6/port-winter-v1.webp": "city.port_water",
        "images/gimmicks/vignettes/art-v1/courtyard-board.webp": "city.autumn",
        "images/gimmicks/vignettes/art-v1/sea-board.webp": "city.board_sea",
        "images/gimmicks/vignettes/art-v1/night-board.webp": "city.board_sky",
    })
    for names, filename in [
        (["bg hotel morning"], "images/hotel-morning.webp"),
        (["bg hotel night"], "images/hotel-night.webp"),
        (["bg ch3 cafe evening", "bg ch3 cafe exit", "bg ch3 cafe asya", "bg w4 cafe empty"], "images/chapter3/ch3-cafe-evening-empty-v1.webp"),
        (["bg housing studio establishing", "bg housing studio", "bg housing studio home"], "images/housing/studio-v2.webp"),
        (["bg w6 exhibition asya", "bg w6 exhibition empty", "bg w6 exhibition ulya", "bg w6 exhibition group"], "images/week6/exhibition-hammock-v3.webp"),
        (["bg w6 closing empty", "bg w6 closing ulya"], "images/week6/exhibition-closing-on-v1.webp"),
        (["bg w6 exhibition off", "bg w6 exhibition off ulya"], "images/week6/exhibition-off-v1.webp"),
        (["bg w6 port empty", "bg w6 port nika"], "images/week6/port-winter-v1.webp"),
    ]:
        for name in names:
            city_motion_bindings[name] = filename

    city_register_motion("city.window_rain", """
        // Four drops travel down separate panes; wooden mullions and the
        // whole room are outside the mask. Existing painted rain stays sharp.
        float panes = city_glass(p);
        float drops = city_window_drop(p, 0.431, fract(u_city_time / 12.0 + 0.11))
            + city_window_drop(p, 0.474, fract(u_city_time / 15.0 + 0.43))
            + city_window_drop(p, 0.551, fract(u_city_time / 12.0 + 0.67))
            + city_window_drop(p, 0.614, fract(u_city_time / 20.0 + 0.29));
        gl_FragColor.rgb += vec3(0.18, 0.20, 0.21) * drops * panes;
    """, functions="""
        float city_glass(vec2 p) {
            float left = smoothstep(0.395, 0.399, p.x) * (1.0 - smoothstep(0.489, 0.493, p.x));
            float right = smoothstep(0.518, 0.522, p.x) * (1.0 - smoothstep(0.641, 0.645, p.x));
            float top = smoothstep(0.017, 0.023, p.y) * (1.0 - smoothstep(0.181, 0.187, p.y));
            float bottom = smoothstep(0.226, 0.232, p.y) * (1.0 - smoothstep(0.474, 0.480, p.y));
            return max(left, right) * max(top, bottom);
        }
        float city_window_drop(vec2 p, float x, float cycle) {
            float y = 0.035 + cycle * cycle * 0.48;
            float dx = abs(p.x - x - sin(cycle * 8.0) * 0.0006);
            float head = (1.0 - smoothstep(0.0005, 0.0015, dx))
                * (1.0 - smoothstep(0.0015, 0.0045, abs(p.y - y)));
            float trail = (1.0 - smoothstep(0.0001, 0.0007, dx))
                * smoothstep(y - 0.032, y - 0.003, p.y) * (1.0 - smoothstep(y - 0.001, y, p.y));
            return (head + trail * 0.30) * smoothstep(0.0, 0.06, cycle)
                * (1.0 - smoothstep(0.88, 1.0, cycle));
        }
    """)

    city_register_motion("city.window_night", """
        // A passing car lights the courtyard behind the glass. No movement
        // or exposure changes in the bedroom, lamps or window frame.
        float left = smoothstep(0.395, 0.399, p.x) * (1.0 - smoothstep(0.489, 0.493, p.x));
        float right = smoothstep(0.518, 0.522, p.x) * (1.0 - smoothstep(0.638, 0.645, p.x));
        float panes = max(left, right) * smoothstep(0.235, 0.25, p.y)
            * (1.0 - smoothstep(0.471, 0.48, p.y));
        float cycle = fract(u_city_time / 20.0 + 0.13);
        float pass = smoothstep(0.03, 0.14, cycle) * (1.0 - smoothstep(0.28, 0.42, cycle));
        float light = exp(-pow((p.x - (0.38 + cycle * 0.7)) / 0.09, 2.0));
        gl_FragColor.rgb += vec3(0.13, 0.11, 0.065) * panes * pass * light;
    """)

    city_register_motion("city.coffee_steam", """
        // Thin steam above the espresso machine, behind every character.
        float steam = city_steam(p, 0.595, fract(u_city_time / 4.0))
            + city_steam(p, 0.615, fract(u_city_time / 4.0 + 0.50));
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.94, 0.90, 0.81), steam * 0.24);
        float flame = 1.0 - smoothstep(0.003, 0.011,
            length((p - vec2(0.980, 0.504)) * vec2(1.0, 0.65)));
        gl_FragColor.rgb *= 1.0 + flame * (sin(t * 137.0) * 0.065 + sin(t * 193.0) * 0.035);
    """, functions="""
        float city_steam(vec2 p, float x, float cycle) {
            float y = 0.267 - cycle * 0.080;
            float curl = sin((p.y - y) * 85.0 + cycle * 5.0) * 0.0035;
            float width = 0.0018 + cycle * 0.003;
            float wisp = 1.0 - smoothstep(width * 0.35, width, abs(p.x - x - curl));
            float height = 1.0 - smoothstep(0.008, 0.024, abs(p.y - y));
            return wisp * height * smoothstep(0.0, 0.14, cycle) * (1.0 - smoothstep(0.55, 1.0, cycle));
        }
    """)

    city_register_motion("city.curtain", """
        // Only the translucent fabric folds: the fridge, frame, plants,
        // laptop and all furniture remain fixed. Maximum shift is 2 pixels.
        float fabric = smoothstep(0.414, 0.420, p.x) * (1.0 - smoothstep(0.463, 0.470, p.x))
            * smoothstep(0.04, 0.09, p.y) * (1.0 - smoothstep(0.600, 0.618, p.y));
        float sway = sin(t * 10.0 + p.y * 3.5) * 0.00125 * smoothstep(0.04, 0.58, p.y);
        vec4 cloth = texture2D(tex0, p + vec2(sway * fabric, 0.0));
        gl_FragColor = mix(gl_FragColor, cloth, fabric);
    """)

    city_gallery_snow_functions = """
        float city_snow_layer(vec2 p, vec2 scale, vec2 velocity, float radius, float seconds) {
            vec2 grid = p * scale - velocity * seconds;
            vec2 cell = mod(floor(grid), 20.0);
            float seed = fract(sin(dot(cell, vec2(127.1, 311.7))) * 43758.5453);
            vec2 center = vec2(0.2 + seed * 0.6,
                0.2 + fract(seed * 17.31) * 0.6);
            vec2 q = fract(grid) - center;
            q.x += sin(seconds * 0.5235988 + seed * 6.2831853) * 0.075;
            float flake = 1.0 - smoothstep(radius * 0.38, radius, length(q));
            return flake * step(0.28, seed);
        }
        float city_gallery_snow(vec2 p, float seconds) {
            // Snow is behind the glass, not on the frame or inside the room.
            float window = smoothstep(0.017, 0.023, p.x)
                * (1.0 - smoothstep(0.208, 0.217, p.x))
                * smoothstep(0.008 + p.x * 0.63, 0.018 + p.x * 0.63, p.y)
                * (1.0 - smoothstep(0.625 - p.x * 0.38, 0.638 - p.x * 0.38, p.y));
            float far = city_snow_layer(p, vec2(32.0, 18.0), vec2(1.0 / 6.0, 2.0 / 3.0), 0.026, seconds);
            float near = city_snow_layer(p + vec2(0.117, 0.071), vec2(20.0, 11.25), vec2(0.5, 4.0 / 3.0), 0.032, seconds);
            return window * (far * 0.48 + near * 0.72);
        }
    """

    city_register_motion("city.gallery_snow", """
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.88, 0.93, 1.0), city_gallery_snow(p, u_city_time));
    """, functions=city_gallery_snow_functions)

    city_register_motion("city.projected_sea", """
        // The projector actually plays moving sea footage. Palm trunks,
        // hammock, wall and projector never bend with the water.
        float cloth = 0.390 - abs(p.x - 0.565) * 0.56;
        float sea = smoothstep(0.412, 0.424, p.x) * (1.0 - smoothstep(0.707, 0.719, p.x))
            * smoothstep(0.239, 0.248, p.y) * (1.0 - smoothstep(cloth - 0.012, cloth, p.y));
        float phase = p.y * 210.0 - t * 33.0 + p.x * 13.0;
        vec2 offset = vec2(sin(phase) * 0.0025, sin(phase * 1.6 - t * 17.0) * 0.0012);
        vec4 water = texture2D(tex0, p + offset * sea);
        water.rgb *= 1.0 + sin(phase) * 0.055 * sea;
        gl_FragColor = mix(gl_FragColor, water, sea);
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.88, 0.93, 1.0), city_gallery_snow(p, u_city_time));
    """, functions=city_gallery_snow_functions)

    city_register_motion("city.port_water", """
        float shoreline = 0.475 + p.x * 0.39;
        float sea = smoothstep(0.27, 0.30, p.x) * smoothstep(0.442, 0.452, p.y)
            * (1.0 - smoothstep(shoreline - 0.028, shoreline - 0.012, p.y));
        float depth = max(p.y - 0.425, 0.015);
        float phase = log(depth) * 30.0 - t * 37.0 + p.x * 8.0;
        vec2 offset = vec2(sin(phase) * 0.0028, sin(phase * 1.4 - t * 19.0) * 0.0012);
        vec4 water = texture2D(tex0, p + offset * sea);
        water.rgb *= 1.0 + sin(phase) * 0.065 * sea;
        gl_FragColor = mix(gl_FragColor, water, sea);
    """)

    city_register_motion("city.board_sea", """
        // Board guides and the traced hand are independent screen layers.
        float sea = smoothstep(0.30, 0.32, p.y) * (1.0 - smoothstep(0.55, 0.58, p.y));
        float blue = smoothstep(0.04, 0.16, gl_FragColor.b - gl_FragColor.r);
        sea *= blue;
        float phase = p.y * 130.0 - t * 29.0 + p.x * 11.0;
        vec4 water = texture2D(tex0, p + vec2(sin(phase) * 0.0022, sin(phase * 1.5 - t * 13.0) * 0.001));
        water.rgb *= 1.0 + sin(phase) * 0.06 * sea;
        gl_FragColor = mix(gl_FragColor, water, sea);
    """)

    city_register_motion("city.board_sky", """
        // Constant rightward wind at 1.04 virtual pixels/second. Mirrored
        // texture borders supply the incoming sky without a clock reset.
        float sky = smoothstep(0.03, 0.08, p.x) * (1.0 - smoothstep(0.72, 0.79, p.x))
            * (1.0 - smoothstep(0.48, 0.56, p.y));
        vec2 sky_uv = vec2(p.x - u_city_time * 0.00065, p.y);
        sky_uv.x = 1.0 - abs(mod(sky_uv.x, 2.0) - 1.0);
        vec4 cloud = texture2D(tex0, sky_uv);
        // Exclude bright stars at both coordinates, so only clouds drift.
        sky *= (1.0 - smoothstep(0.45, 0.65, max(gl_FragColor.r, max(gl_FragColor.g, gl_FragColor.b))))
            * (1.0 - smoothstep(0.45, 0.65, max(cloud.r, max(cloud.g, cloud.b))));
        gl_FragColor = mix(gl_FragColor, cloud, sky);
    """)
