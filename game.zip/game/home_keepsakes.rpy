# Owned objects follow the played history, including a return to the hotel.
default home_keepsakes = {}
default home_keepsakes_unpacked = []
default home_keepsakes_version = 0

init -5 python:
    home_keepsake_assets = {
        "asya_tin": ("images/home-keepsakes/asya-tram-tin-v1.webp", (108,402,1043,617)),
        "marta_card": ("images/home-keepsakes/marta-courtyard-card-v1.webp", (53,269,1153,766)),
        "varya_zine": ("images/home-keepsakes/varya-zine-v1.webp", (226,52,851,1167)),
    }
    # Coordinates refer to the 1600x900 room, never to the current window size.
    # Each entry: (left, supporting surface/bottom, visible width).
    home_keepsake_layouts = {
        "hotel": {"asya_tin":(795,461,52), "marta_card":(873,460,57), "varya_zine":(963,461,57)},
        "hotel_reverse": {"asya_tin":(757,387,42), "marta_card":(822,387,47), "varya_zine":(899,387,47)},
        "hotel_work": {"asya_tin":(914,460,52), "marta_card":(992,460,57), "varya_zine":(1082,460,57)},
        "old": {"asya_tin":(435,493,41), "marta_card":(475,491,45), "varya_zine":(527,489,38)},
        "quiet": {"asya_tin":(707,416,48), "marta_card":(790,416,52), "varya_zine":(875,416,52)},
        "studio": {"asya_tin":(821,414,30), "marta_card":(1000,391,35), "varya_zine":(831,390,36)},
        "central": {"asya_tin":(354,466,29), "marta_card":(432,466,25), "varya_zine":(371,466,29)},
        "modern": {"asya_tin":(795,418,47), "marta_card":(871,418,52), "varya_zine":(953,418,52)},
    }
    home_keepsake_rooms = {
        "images/hotel.webp":("hotel","dusk"),
        "images/hotel-morning.webp":("hotel","day"),
        "images/hotel-night.webp":("hotel","night"),
        "images/week5/hotel-dialogue-night-v1.webp":("hotel_reverse","night"),
        "images/week4/hotel-work-laptop-v2.webp":("hotel_work","day"),
        "images/cast/apartment-empty.webp":("old","day"),
        "images/chapter3/old-rental-night-v1.webp":("old","evening"),
        "images/chapter3/ch3-rental-day-v2.webp":("quiet","day"),
        "images/chapter3/ch3-rental-evening-v2.webp":("quiet","evening"),
        "images/chapter3/ch3-rental-night-v2.webp":("quiet","night"),
        "images/housing/studio-v2.webp":("studio","day"),
        "images/housing/studio-night-v2.webp":("studio","evening"),
        "images/housing/central-bedroom-v1.webp":("central","day"),
        "images/housing/central-bedroom-evening-v2.webp":("central","evening"),
        "images/housing/modern-evening-v2.webp":("modern","evening"),
        "images/week6/modern-day-v1.webp":("modern","day"),
        "images/week6/modern-night-v1.webp":("modern","night"),
    }

    def home_keepsake_receive(key):
        global home_keepsakes_version
        if key not in home_keepsake_assets:
            raise ValueError("Unknown home keepsake: " + key)
        for old in home_keepsake_owned():
            home_keepsakes[old] = True
        home_keepsakes_version = 1
        home_keepsakes[key] = True

    def home_keepsake_owned():
        owned = set(k for k,v in home_keepsakes.items() if v and k in home_keepsake_assets)
        if home_keepsakes_version:
            return owned
        # Exact positive evidence also works in older saves. Knowing a girl,
        # a warm outcome, a digital photo or a chapter number are not evidence.
        if chapter3_tasks.get("asya_gift") == "tram_tin":
            owned.add("asya_tin")
        if any(e.get("event") == "mutual_time" for e in week4_relations.get("varya", {}).get("events", [])):
            owned.add("varya_zine")
        if chapter4_marta_seen and any(e.startswith("Глава 3 · вечер: ") and "Познакомился с Мартой" in e for e in diary_entries):
            owned.add("marta_card")
        return owned

    def home_keepsake_layout(path, owned=None):
        room = home_keepsake_rooms.get(path)
        if not room:
            return []
        owned = home_keepsake_owned() if owned is None else owned
        result=[]
        for key in ("varya_zine","marta_card","asya_tin"):
            if key not in owned:
                continue
            left,bottom,width=home_keepsake_layouts[room[0]][key]
            asset,crop=home_keepsake_assets[key]
            height=int(round(width*crop[3]/float(crop[2])))
            result.append(dict(key=key,asset=asset,crop=crop,x=left,y=bottom-height,width=width,height=height,tone=room[1]))
        return result

    def home_keepsake_background(path):
        # Explicit home call sites only. A viewing may use exactly the same
        # empty plate but must never display Oleg's already-owned possessions.
        base=city_background(path)
        parts=[(0,0),base]
        for p in home_keepsake_layout(path):
            tone = {"day":TintMatrix("#eeeeef"), "dusk":TintMatrix("#d7bda2"),
                "evening":TintMatrix("#d9b58e"), "night":TintMatrix("#736c66")}[p["tone"]]
            prop=Transform(Crop(p["crop"],p["asset"]),xysize=(p["width"],p["height"]),matrixcolor=tone)
            parts.extend([(p["x"],p["y"]),prop])
        if home_keepsake_rooms.get(path, (None,))[0] == "studio":
            # The zine is on the sill behind the laptop, never pasted over it.
            parts.extend([(854,366),Crop((854,366,78,45),Transform(path,xysize=(1600,900)))])
        return Composite((1600,900),*parts)

    def home_keepsake_cast_home():
        key=cast_background_key()
        return key.startswith(("w5 home ","w7 home "))

    def home_keepsake_plate(st,at,path):
        return home_keepsake_background(path),None

    def home_keepsake_work_detail(st,at):
        return Transform(home_keepsake_background("images/week4/hotel-work-laptop-v2.webp"),crop=(640,360,940,529),xysize=(1600,900)),None

# Named plates support chapters 1–4 and their old save-compatible image tags.
# Viewing tags such as "ch3 old rental" and "housing studio" stay untouched.
init 520 python:
    import functools
    for key,path in {
        "hotel":"images/hotel.webp", "hotel morning":"images/hotel-morning.webp",
        "hotel dusk":"images/hotel.webp", "hotel night":"images/hotel-night.webp",
        "w4 work hotel":"images/week4/hotel-work-laptop-v2.webp",
        "w4 home old":"images/cast/apartment-empty.webp",
        "ch3 old night":"images/chapter3/old-rental-night-v1.webp",
        "ch3 rental":"images/chapter3/ch3-rental-day-v2.webp",
        "w4 home new":"images/chapter3/ch3-rental-day-v2.webp",
        "ch3 home evening":"images/chapter3/ch3-rental-evening-v2.webp",
        "ch3 home night":"images/chapter3/ch3-rental-night-v2.webp",
        "housing studio home":"images/housing/studio-v2.webp",
        "housing studio night":"images/housing/studio-night-v2.webp",
        "housing quiet home":"images/chapter3/ch3-rental-day-v2.webp",
        "housing quiet night":"images/chapter3/ch3-rental-night-v2.webp",
        "housing central home":"images/housing/central-bedroom-v1.webp",
        "housing central night":"images/housing/central-bedroom-evening-v2.webp",
        "housing modern home":"images/housing/modern-evening-v2.webp",
        "housing modern night":"images/housing/modern-evening-v2.webp",
    }.items():
        renpy.image("bg "+key,DynamicDisplayable(functools.partial(home_keepsake_plate,path=path)))
    renpy.image("bg w4 work detail",DynamicDisplayable(home_keepsake_work_detail))

label home_keepsakes_unpack:
    if "asya_tin" in home_keepsake_owned() and "asya_tin" not in home_keepsakes_unpacked:
        "Олег высыпает медиаторы из бокового кармана чехла в синюю коробочку. Пуговицы оставляет там же. Закрывает крышку и ставит коробочку у окна."
        $ home_keepsakes_unpacked.append("asya_tin")
    if "marta_card" in home_keepsake_owned() and "marta_card" not in home_keepsakes_unpacked:
        "Карточка двора немного согнулась в кармане. Олег расправляет её и прислоняет к стеклу у окна."
        $ home_keepsakes_unpacked.append("marta_card")
    if "varya_zine" in home_keepsake_owned() and "varya_zine" not in home_keepsakes_unpacked:
        "Варин зин Олег достаёт из рюкзака и ставит у окна обложкой к комнате. Кот теперь смотрит на него, пока он ищет зарядку."
        $ home_keepsakes_unpacked.append("varya_zine")
    return
