# Presentation preferences persist independently of the story save.
default persistent.story_text_size = 27

init python:
    def story_text_size(base=27):
        selected = getattr(persistent, "story_text_size", 27)
        selected = selected if selected in (24, 27, 30, 33) else 27
        return int(round(base * selected / 27.0))

    def diary_readable_entries():
        technical = ("Быстрый старт:", "Быстрый вход в главу", "Готовая предыстория к главе")
        entries = []
        for entry in diary_entries:
            if entry.startswith("Готовая предыстория к главе"):
                # Translate the stored snapshot, not the current relationship:
                # later play must not rewrite an old diary memory.
                draft = dict(relations={}, home="")
                words = dict(friend="дружим", interest="есть взаимный интерес", kiss="уже целовались", night="были поцелуй и общая ночь", space="решили не торопиться с прикосновениями")
                for person, name in late_history_names.items():
                    for state, phrase in words.items():
                        if name + ": " + phrase + "." in entry:
                            draft["relations"][person] = state
                    if name + ": осталась обида" in entry:
                        draft["relations"][person] = "hurt"
                for home, caption in late_history_homes(7):
                    if caption + "." in entry:
                        draft["home"] = home
                entries.extend(diary_history_opening(7, draft))
            elif not entry.startswith(technical):
                entries.append(entry)
        return entries

    def diary_history_opening(chapter, draft):
        homes = {"hotel":"Пока остаюсь в гостинице.", "studio":"Снял студию. Пытаюсь устроиться на этих метрах.",
            "month":"Живу в старом фонде. По договорённости хозяин иногда приезжает.",
            "whole":"Снял квартиру целиком. Можно наконец раскладывать свои вещи.",
            "central":"Снял квартиру с отдельной спальней. Теперь надо привыкнуть к её ступеням.",
            "modern":"Переехал в новый дом. С гулом ещё придётся разобраться."}
        entries = [homes.get(draft.get("home"), "Начинается новая неделя в Петербурге.")]
        names = {"nika":"Никой", "lera":"Лерой", "asya":"Асей", "marta":"Мартой"}
        for person, state in draft.get("relations", {}).items():
            if person not in names:
                continue
            if state == "night":
                entries.append("С " + names[person] + " уже оставались вместе на ночь.")
            elif state == "kiss":
                entries.append("Мы с " + names[person] + " целовались.")
            elif state == "hurt":
                entries.append(late_history_names[person] + " на меня обижена.")
            elif state == "friend":
                entries.append("С " + names[person] + " дружим.")
            elif state == "interest":
                entries.append("Мне нравится видеться с " + names[person] + ".")
            elif state == "space":
                entries.append("С " + names[person] + " решили не торопиться.")
        return entries
