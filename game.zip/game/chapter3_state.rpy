# Confirmed appointments, promises and time are independent saved story state.
default chapter3_previous = {}
default chapter3_plans = {}
default chapter3_tasks = {}
default chapter3_housing = "search"
default chapter3_candidate = "new"
default chapter3_day = 0
default chapter3_clock = 650
default chapter3_area = "vaska"
default chapter3_current = ""
default chapter3_results = {}
default chapter3_notes = []
default chapter3_bag = False
default chapter3_late_reply = ""
default chapter3_voice_wrong = False
default chapter3_solo = ""
default chapter3_selections = []
default chapter3_eta = 0

init python:
    chapter3_names = {"nika": "Ника", "asya": "Ася", "lera": "Лера", "varya": "Варя", "keys": "Квартира"}
    chapter3_kinds = {"album": "Пластинки", "jam": "Поиграть вместе", "coffee": "Кофе", "shop": "Музыкальный магазин", "photos": "Выставка фотографий", "market": "Барахолка", "lunch": "Обед", "print": "Забрать тираж", "walk": "Искать дворы", "keys": "Ключи", "view": "Просмотр"}
    chapter3_statuses = {"idea": "обсуждаем", "confirmed": "договорились", "done": "состоялось", "canceled": "отменено", "deferred": "перенесено", "busy": "занята", "missed": "сорвалось"}

    def chapter3_setup_entry(profile):
        global ending_id, chapter2_origin, chapter2_route, chapter2_housing
        global chapter2_initiative, chapter2_followup, chapter2_varya_reply, diary_entries, chapter2_early_evening
        chapter2_early_evening = {}
        samples = {
            "nika": ("connection", "nika", "refuse", "invite", "record", "read"),
            "asya": ("friendship", "asya", "conditions", "honest", "plan", "read"),
            "lera": ("delay", "lera", "temporary", "invite", "plan", "walk"),
            "quiet": ("delay", "rest", "refuse", "", "nika", "read"),
            "rush": ("connection", "nika", "conditions", "invite", "plan", "read"),
            "friends": ("friendship", "nika", "refuse", "guitar", "record", "walk"),
        }
        ending_id, chapter2_route, chapter2_housing, chapter2_initiative, chapter2_followup, chapter2_varya_reply = samples[profile]
        chapter2_origin = ending_id
        diary_entries = ["Быстрый старт: выбран итог второй главы. Обычные сохранения можно продолжить отдельно."]

    def chapter3_reset():
        global home_keepsakes, home_keepsakes_unpacked, home_keepsakes_version
        home_keepsakes, home_keepsakes_unpacked, home_keepsakes_version = {}, [], 1
        chapter34_phone_reset(3)
        global chapter3_marta_checked, chapter3_marta_can_visit, chapter3_evening_checked_days
        global chapter3_previous, chapter3_plans, chapter3_tasks, chapter3_housing, chapter3_candidate
        global chapter3_day, chapter3_clock, chapter3_area, chapter3_current, chapter3_results
        global chapter3_evening_completed, chapter3_evening_dialogues, chapter3_evening_choices
        global chapter3_departures
        global chapter3_notes, chapter3_bag, chapter3_late_reply, chapter3_voice_wrong, chapter3_solo
        global chapter3_selections, phone_reply_log, diary_entries, chapter3_buldak_stage, chapter3_friends_reported, chapter3_friend_history, chapter3_result_chat, chapter3_buldak_chat
        chapter3_previous = {"origin": chapter2_origin, "route": chapter2_route, "housing": chapter2_housing,
                             "initiative": chapter2_initiative, "followup": chapter2_followup, "varya": chapter2_varya_reply,
                             "early_evening": dict(chapter2_early_evening)}
        chapter3_plans = {}
        chapter3_marta_checked = chapter3_marta_can_visit = False
        chapter3_evening_checked_days = []
        chapter4_reset(clear_plans=True)
        chapter3_tasks = {"guitar": "pending" if chapter2_route == "nika" and (chapter2_followup == "record" or chapter2_initiative == "guitar") else "none",
                          "pdf": "pending" if chapter2_varya_reply == "read" else "none", "place": "none"}
        if chapter2_early_evening.get("person") == "nika":
            if chapter2_early_evening.get("initiative") == "guitar":
                chapter3_tasks["guitar"] = "pending"
            elif chapter2_early_evening.get("initiative") == "invite":
                chapter3_plan("nika", 0, None, "album", "idea")
        elif chapter2_early_evening.get("person") == "asya":
            chapter3_plan("asya", 0, None, "photos", "idea")
        # A fixed coffee time is the only already-confirmed clock time in chapter2.
        if chapter2_route == "rest" and chapter2_followup == "nika" and chapter2_origin == "connection":
            chapter3_plan("nika", 0, 840, "coffee")
        elif (chapter2_route == "nika" and (chapter2_initiative == "invite" or chapter2_followup == "plan")) or (chapter2_route == "rest" and chapter2_followup == "nika" and chapter2_origin == "friendship"):
            kind = "album" if chapter2_initiative == "invite" or chapter2_followup == "plan" else "jam"
            if chapter2_route == "rest":
                kind = "shop"
            chapter3_plan("nika", 0, None, kind, "idea")
        if chapter2_route == "asya" or (chapter2_route == "rest" and chapter2_followup == "asya"):
            chapter3_plan("asya", 0, None, "photos", "idea")
        if chapter2_route == "lera" or (chapter2_route == "rest" and chapter2_followup == "lera"):
            chapter3_plan("lera", 1, None, "lunch", "idea")
        if chapter2_varya_reply == "walk":
            chapter3_plan("varya", 0, None, "walk", "idea")
        housing_reset()
        chapter3_housing = "search"
        chapter3_candidate = "new"
        chapter3_day, chapter3_clock, chapter3_area = 0, 650, "vaska"
        chapter3_current = chapter3_late_reply = chapter3_solo = ""
        chapter3_results, chapter3_notes, chapter3_selections = {}, [], []
        chapter3_departures = {}
        chapter3_evening_completed, chapter3_evening_dialogues, chapter3_evening_choices = [], {}, {}
        chapter3_bag = chapter3_voice_wrong = False
        chapter3_buldak_stage, chapter3_friends_reported, chapter3_friend_history = 0, [], []
        chapter3_result_chat, chapter3_buldak_chat = "ch3_date_result", "ch3_buldak"
        phone_reply_log = {k: v for k, v in phone_reply_log.items() if not k[0].startswith("ch3_")}
        diary_entries = [entry for entry in diary_entries if not entry.startswith("Глава 3:")]
        reset_oleg_mood(chapter=3)

    def chapter3_plan(person, day, minute, kind, status="confirmed"):
        chapter3_plans[person] = {"day": day, "time": minute, "kind": kind, "status": status}

    def chapter3_plan_text(person):
        plan = chapter3_plans[person]
        day = ["Сб", "Вс", "След. неделя"][min(plan["day"], 2)]
        clock = chapter3_time(plan["time"]) if plan["time"] is not None else "время открыто"
        return "{} · {} · {} · {}".format(day, clock, chapter3_kinds[plan["kind"]], chapter3_statuses[plan["status"]])

    def chapter3_time(minute):
        return "{:02d}:{:02d}".format(minute // 60, minute % 60)

    def chapter3_nika_available():
        return chapter3_previous["origin"] != "delay" and not chapter3_nika_broke_gallery_plan()

    def chapter3_nika_broke_gallery_plan():
        return (chapter3_previous.get("origin") == "connection"
            and chapter3_previous.get("route") in ("asya", "lera")
            and chapter3_previous.get("early_evening", {}).get("person") != "nika")

    def chapter3_nika_planning_chat():
        if not chapter3_nika_available():
            return "ch3_nika_busy" if chapter3_nika_broke_gallery_plan() else "ch3_nika_unavailable"
        return "ch3_nika_coffee" if chapter3_plans.get("nika", {}).get("kind") == "coffee" else "ch3_nika_music"

    def chapter3_keys_tomorrow():
        plan = chapter3_plans.get("keys", {})
        return chapter3_day == 0 and plan.get("day") == 1 and plan.get("status") == "confirmed"

    def chapter3_chat_fresh(chat):
        global phone_reply_log
        phone_reply_log = {k: v for k, v in phone_reply_log.items() if k[0] != chat}

    def chapter3_area_for(person):
        kind = chapter3_plans[person]["kind"]
        if person == "nika" and kind == "jam":
            return "ligovsky"
        if person == "asya" and kind == "market":
            return "vaska"
        return "sadovaya" if person == "lera" else "vaska"

    def chapter3_travel(area):
        if area == chapter3_area:
            return 15
        return {frozenset(("vaska", "ligovsky")): 38, frozenset(("vaska", "market")): 45,
                frozenset(("vaska", "sadovaya")): 30, frozenset(("ligovsky", "market")): 50,
                frozenset(("ligovsky", "sadovaya")): 20, frozenset(("market", "sadovaya")): 45}[frozenset((chapter3_area, area))]

    def chapter3_pending(day=None):
        day = chapter3_day if day is None else day
        return sorted([person for person, plan in chapter3_plans.items() if plan["day"] == day and plan["status"] == "confirmed"],
                      key=lambda person: chapter3_plans[person]["time"])

    def chapter3_schedule_conflicts():
        notes = []
        for day in (0, 1):
            tasks = chapter3_pending(day)
            for first, second in zip(tasks, tasks[1:]):
                p, q = chapter3_plans[first], chapter3_plans[second]
                duration = {"varya": 100, "keys": 30, "nika": 90, "asya": 120, "lera": 100}[first]
                travel = 15 if chapter3_area_for(first) == chapter3_area_for(second) else 40
                if p["time"] + duration + travel > q["time"]:
                    notes.append((first, second))
        return notes

    def chapter3_schedule_notes():
        return ["{} → {}: мало времени на дорогу.".format(chapter3_names[first], chapter3_names[second]) for first, second in chapter3_schedule_conflicts()]

    def chapter3_stamp(location):
        global place_name, save_name
        place_name = "{} · {} {}".format(location, ["суббота", "воскресенье"][chapter3_day], chapter3_time(chapter3_clock))
        save_name = "Глава 3 · " + place_name

    def chapter3_done(person, result, minutes):
        global chapter3_clock
        chapter3_plans[person]["status"] = "done"
        chapter3_results[person] = result
        chapter3_clock += minutes
        chapter3_notes.append(chapter3_names[person] + ": " + result)

    def chapter3_defer(person):
        plan = chapter3_plans[person]
        if person == "keys" and chapter3_day == 0:
            chapter3_plan(person, 1, 720, plan["kind"])
        else:
            chapter3_plan(person, 2, None, plan["kind"], "deferred")

    def chapter3_live_summary():
        person = chapter3_shared_person()
        if not person:
            return "За ключами договорился съездить. Хочется уже вещи разложить." if chapter3_plans.get("keys",{}).get("status")=="confirmed" else "Пока ни с кем не договорился. Хочу просто погулять, а там посмотрим."
        plan = chapter3_plans[person]
        words = {
            "album":"С Никой договорились пластинку послушать. Хочу спокойно досидеть до конца стороны.",
            "jam":"С Никой поиграем вместе. Интересно, что получится вне моей комнаты.",
            "coffee":"С Никой на кофе договорились. Рад, что увидимся.",
            "shop":"С Никой зайдём в музыкальный. Хочу с ней гитары попробовать.",
            "photos":"С Асей пойду фотографии смотреть. Любопытно, что ей там нравится.",
            "market":"С Асей на барахолку собираюсь. Хочу побродить и что-нибудь повыбирать.",
            "lunch":"С Лерой договорились поесть. Хочу уже нормально поговорить, когда музыка не орёт.",
            "print":"Варе помогу с тиражом. Хочу посмотреть, как её зин выглядит на бумаге.",
            "walk":"С Варей пойдём дворы искать. Хочу увидеть, как она их выбирает для съёмки.",
        }
        text = words[plan["kind"]]
        if chapter3_plans.get("keys",{}).get("status")=="confirmed": text += " Ещё за ключами съезжу."
        return text

    def chapter3_shared_person():
        people = [p for p in ("nika","asya","lera","varya") if chapter3_plans.get(p,{}).get("status")=="confirmed"]
        route = chapter3_previous.get("route")
        return route if route in people else next(iter(people),None)
