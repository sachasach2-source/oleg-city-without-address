label week6_thursday:
    $ week6_stage = "thursday"
    $ week6_stamp("Дома · обед", 750, 4)
    scene bg w6 thai shirt with fade
    $ set_soundscape("ch3_room")
    if week6_sea.get("feeling") == "wear":
        "Перед работой Олег складывает рубашку и убирает её к остальным вещам."
    "Рубашка лежит сверху. Олег отодвигает её, чтобы достать тёплые носки. На улице вчерашний снег уже превратился в серую кашу."
    if week6_pending_marta():
        call week6_chat("marta", "answer_thursday", [], [
            ("yes", "Я обещал до четверга ответить. Хочу в субботу с тобой встретиться. В два? Не с карточками — просто с тобой.", [("Марта", "Хочу. В два могу. Я тогда рабочее на утро оставлю.")]),
            ("no", "Обещал сегодня ответить: я пока не готов договариваться на субботу. Не держи её под меня.", [("Марта", "Жаль. Я уже думала, куда пойдём."), ("Марта", "Хорошо. Тогда у меня свои планы.")])])
        $ week6_event("marta_answer_sent", _return, "marta")
        if _return == "yes":
            $ week6_relations["marta"]["facts"]["chapter6_saturday"] = "14:00"
    call week6_thursday_home
    if week6_rita.get("active") and week6_rita.get("next_check") == "thursday":
        call week6_rita_thursday
    if week6_varya.get("role") in ("play", "audience"):
        call week6_invite_concert_guest
    if not week6_exhibition.get("visited"):
        $ week6_stamp("После работы", max(week6_clock, 1075))
        scene bg w6 snow courtyard night with dissolve
        "Олег снова видит светлое море в витрине бывшего магазина. На двери часы: до восьми. Сегодня ещё можно успеть."
        $ week6_exhibition_options = [("Зайду один. Хочу посмотреть, что там.", "alone")]
        if week6_known("asya") and not week6_issues("asya"):
            $ week6_exhibition_options.append(("Позову Асю. Может, успеет после работы.", "asya"))
        $ week6_exhibition_options.append(("Сегодня домой. Не хочу ещё куда-то идти.", "skip"))
        call screen chapter3_intentions("Море в бывшем продуктовом", week6_exhibition_options)
        if _return == "asya":
            call week6_chat("asya", "exhibition", [], [
                ("invite", "Тут в бывшем продуктовом море показывают. До восьми. Хочешь со мной посмотреть? В половине седьмого у входа.", [("Ася", "Хочу. Я в шесть заканчиваю, успею. Пришли точку.")]),
                ("alone", "Увидел смешную выставку по дороге. Сегодня один зайду, потом расскажу.", [("Ася", "Давай. Я ещё полчаса на работе буду.")])])
            if _return == "invite":
                $ week6_exhibition["with_asya"] = True
                $ week6_event("exhibition_agreed", "Четверг, 18:30", "asya")
            call week6_ulya_exhibition
        elif _return == "alone":
            call week6_ulya_exhibition
        else:
            $ week6_exhibition["skipped"] = True
            "Он покупает хлеб в соседней двери и идёт к дому. Море остаётся светиться в витрине."
    if week6_has_contact("ulya"):
        $ week6_stamp("Дома", 1275)
        scene expression home_keepsake_background(week6_home_path(True)) with dissolve
        call week6_chat("ulya", "after_exhibition", [("Уля", "Я нашла звук, который вырезала. Там в конце сосед сверху табурет двигает. Поэтому в выставочную версию не вошло.")], [
            ("send", "Не вырезай окончательно. У меня сейчас за стеной похожее море. Только без воды.", [("Уля", "Ахах. Домашняя версия."), ("Уля", "Опять после закрытия засиделась. Пойду проектор выключать, а то сама тут усну.")]),
            ("ask", "А ты ещё показывать это где-нибудь будешь? Я бы ещё зашёл.", [("Уля", "До воскресенья здесь. Потом пока не знаю."), ("Уля", "Если что-то придумаю, напишу.")])])
        $ week6_event("first_message", _return, "ulya")
    call housing_story_evening
    jump week6_friday_concert

label week6_thursday_home:
    if week6_home.get("kind") != "hotel":
        "Олег расстилает у двери газету и ставит на неё мокрые ботинки. В углу ещё стоит пакет с проводами; до него руки пока не дошли."
        $ week6_event("winter_home")
        if not week6_pending_keys():
            call housing_story_incident
        return
    if week6_home.get("keys_due") not in (None, "", "done"):
        "В переписке уже согласована передача ключей. Олег перечитывает время и не открывает новые объявления."
        $ week6_event("existing_keys_kept", week6_home["keys_due"])
        return
    call week6_chat("agent", "modern_offer", [("Агент", "Добрый день. В новом доме объект освободился. Тепло, нормальный рабочий стол, без лестниц внутри. Сегодня в половине второго могу показать.")], [
        ("visit", "В половине второго могу. Пришлите адрес. У меня потом работа, до двух хочу закончить.", [("Агент", "Да, уложимся. Адрес отправляю.")]),
        ("skip", "Сегодня не пойду. Пока хочу спокойно посмотреть документы и то, что уже присылали.", [("Агент", "Понял. Если решите, напишите, уточню актуальность.")])])
    if _return == "skip":
        $ week6_housing["decision"] = "not_viewed"
        return
    call housing_choose_companion(6)
    $ week6_stamp("Квартира в новом доме", 810)
    scene bg w6 housing approach with fade
    $ set_soundscape("courtyard")
    call housing_companion_arrival
    scene bg w6 housing entry with fade
    $ set_soundscape("ch3_room")
    "В лифте сухо и тепло. Олег расстёгивает куртку ещё до того, как агент находит нужную дверь."
    "За окном кирпичный корпус. Стол действительно нормальный: ноутбук и локти помещаются одновременно."
    "Олег снимает куртку и оставляет её у входа. Агент ждёт, пока он оглядится."
    scene bg w6 housing modern with dissolve
    agent "Восемьдесят шесть, плюс счётчики. Залог за месяц. Здесь всё очень продумано."
    menu:
        "Открою окно. Хочу понять, что за звук снаружи.":
            scene bg w6 housing window with dissolve
            "В комнату входит ровный низкий гул. На здании напротив крутятся вентиляторы."
            o "Это постоянно?"
            agent "Звуки города. Не тишина дачного посёлка, конечно."
            o "А ночью?"
            agent "Ночью город тоже живёт."
            $ week6_housing["checked"] = "noise"
        "Проверю, как работает умный дом.":
            scene bg w6 housing controls with dissolve
            "Олег меняет температуру на панели. На телефоне агента почти сразу появляется уведомление."
            o "Это хозяину тоже приходит?"
            agent "Чувствуется участие. Вы не один на один с квартирой."
            o "Я бы как раз хотел один на один."
            $ week6_housing["checked"] = "account"
    scene bg w6 housing modern with dissolve
    "Олег закрывает окно и просит уточнить два вопроса: ночной режим вентиляции и чей аккаунт останется в панели. Агент звонит собственнику."
    "Ответ приходит без рекламных формулировок: оборудование работает круглосуточно; управление можно полностью передать новому жильцу при выдаче ключей. Олег ещё раз приоткрывает окно и закрывает."
    call housing_companion_opinion("modern")
    menu:
        "С закрытым окном мне нормально. Готов снять на этих условиях.":
            o "Аккаунт передаём при мне, это вписываем. Гул я услышал. Договор пришлите сегодня, до подписи прочитаю."
            agent "Конечно. В субботу в одиннадцать можем ключи передать."
            $ week6_housing.update(candidate="modern", decision="documents", keys="saturday11")
            $ week6_home.update(candidate="modern", keys_due="chapter6_saturday11")
            "Олег получает файл договора. Ключи пока остаются у агента; сначала нужно дочитать условия и согласовать оплату."
        "Не готов. Хочу сначала ещё раз послушать с улицы и подумать.":
            o "Я сегодня не подпишу. Документы пришлите, но пока без брони."
            agent "Понял. Актуальность тогда надо будет проверить."
            $ week6_housing.update(candidate="modern", decision="thinking")
        "Не моё. Откажусь, пока опять не начал себя уговаривать.":
            o "Нет. Я всё-таки хочу, чтобы можно было спокойно открыть окно. Спасибо за показ."
            agent "Здесь вентиляция хорошая, вы быстро перестанете об этом думать."
            o "Я уже решил."
            $ week6_housing.update(candidate="modern", decision="declined")
    $ week6_event("apartment_viewed", week6_housing["decision"])
    $ week6_stamp("После просмотра", 835)
    scene bg w6 snow courtyard with dissolve
    $ set_soundscape("courtyard")
    "На улице Олег застёгивает куртку. До двух ещё есть время взять обед и вернуться к ноутбуку."
    scene bg w6 housing approach with dissolve
    call housing_companion_goodbye
    return

label week6_rita_thursday:
    $ week6_stamp("Перерыв после работы", 1040)
    scene bg w6 thai shirt with dissolve
    $ week6_puzzle = week6_rita.setdefault("puzzle", {})
    if week6_puzzle.get("status") != "candidate_ready":
        call week6_chat("rita_group", "missing_calendar", [], [("check", "Я вернулся. Проверяю то, чего нам не хватало: три часа всем нужны? Кто во сколько уходит и когда можно попасть в студию?", [("Ира", "Мне с трёх до шести в воскресенье. Потом за ребёнком."), ("Денис", "До шести свободен. Потом к маме."), ("Агент", "Я к полудню с дачи вернусь."), ("Рита", "У меня до двух примерка. Студия свободна с трёх до шести, и три часа хочется целиком.")])])
        $ week6_puzzle.setdefault("asked", [])
        python:
            for answer in ("hours", "travel", "place"):
                if answer not in week6_puzzle["asked"]:
                    week6_puzzle["asked"].append(answer)
            week6_puzzle.update(status="candidate_ready", proposal="sunday_early")
    call week6_chat("rita_group", "budget", [("Рита", "Узнала. Готовая студия — десять тысяч, уборка входит. Зайти разложить вещи можно без четверти три. Уходим в шесть."), ("Рита", "За восемь есть пустой зал. Но всё расставить самим, убрать тоже, до шести. Это минимум полчаса в конце."), ("Ира", "Я могу две тысячи."), ("Лёша", "Я тоже две."), ("Денис", "У меня полторы свободных, больше не сейчас."), ("Агент", "Две тысячи с меня."), ("Рита", "Я две с половиной могу.")], [("read", "То есть в готовой три часа целиком, в пустой полчаса съедает уборка. И десять тысяч у нас в сумме есть.", [("Рита", "Да. Только давайте уже каждый за себя подтвердит, не просто поставит сердечко.")])])
    $ week6_budget_done = False
    while not week6_budget_done:
        call screen chapter3_intentions("Как предложить?", [("Готовая студия. Каждый вносит столько, сколько сам назвал.", "ready"), ("Возьмём готовую, скинемся поровну по две тысячи.", "equal"), ("Возьмём пустой зал. Уберём в конце побыстрее.", "bare"), ("Я дальше не организую. Передам Рите то, что выяснили.", "leave")])
        $ week6_budget_choice = _return
        $ week6_puzzle.setdefault("budget_attempts", []).append(week6_budget_choice)
        if week6_budget_choice == "equal":
            call week6_chat("rita_group", "equal_budget", [("Денис", "Я полторы могу. Я выше написал."), ("Ира", "Да, было. Давайте не переспрашивать по кругу.")], [("fix", "Точно. Я не так разделил. Сейчас другое предложу.", [("Рита", "Давай.")])])
        elif week6_budget_choice == "bare":
            call week6_chat("rita_group", "bare_room", [("Ира", "Я до шести могу быть здесь, но хочу три часа, а не два с половиной."), ("Лёша", "Я быстро убираю, но полчаса всё равно не ноль.")], [("fix", "Да, это время уже занято уборкой. Значит, этот вариант нам не подходит.", [("Рита", "Угу. Готовая ещё свободна.")])])
        elif week6_budget_choice == "leave":
            call week6_chat("rita_group", "handoff", [], [("leave", "Я на сегодня заканчиваю. Цены и ваши суммы остаются в чате, время тоже. Рита, дальше сама?", [("Рита", "Да. Спасибо, я дальше соберу.")])])
            $ week6_rita["active"] = False
            $ week6_puzzle["resolution"] = "handed_over"
            $ week6_budget_done = True
        else:
            call week6_chat("rita_group", "confirm_money", [], [("offer", "Готовая на воскресенье с трёх до шести. Ира, Лёша и агент — по две, Денис — полторы, Рита — две с половиной. Сходится в десять. Каждый подтверждает свою сумму, Рита бронирует.", [("Ира", "Подтверждаю две."), ("Лёша", "Две, да."), ("Денис", "Полторы подтверждаю."), ("Агент", "Две. Лично приеду."), ("Рита", "Мои две с половиной, всё. Бронирую."), ("Рита", "Готово. Воскресенье, 15–18. Я в 14:45 буду на месте.")])])
            $ week6_puzzle.update(stage=2, status="booked", resolution="ready_room", confirmed=["rita", "ira", "lesha", "denis", "agent"])
            $ week6_budget_done = True
    $ week6_event("moderation_budget", week6_puzzle["resolution"], "rita")
    "Олег убирает телефон и разминает затёкшую шею. Пора собираться, а он ещё даже не поел."
    return

label week6_invite_concert_guest:
    $ week6_concert.setdefault("guest", "")
    $ week6_guest_options = [("Хочу прийти один. Варю поддержать, людей послушать.", "alone")]
    python:
        for person, name in [("nika", "Нику"), ("lera", "Леру"), ("asya", "Асю"), ("marta", "Марту")]:
            if week6_known(person):
                week6_guest_options.append(("Позову " + name + " на Варин номер.", person))
    call screen chapter3_intentions("Кого хочется позвать?", week6_guest_options)
    if _return == "alone":
        return
    $ week6_guest = _return
    if week6_careful(week6_guest):
        call week6_chat(week6_guest, "concert_not_now", [], [("ask", "В пятницу Варя поёт на маленьком акустическом вечере. Хотел тебя позвать послушать.", [(week4_names[week6_guest], "Спасибо, но в эту пятницу не хочу. Я пока не готова встречаться как будто всё уже нормально.")])])
        $ week6_event("concert_guest_declined", person=week6_guest)
        return
    $ week6_onstage = "Я с ней играю, часть вечера буду на сцене. " if week6_varya.get("role") == "play" else "Я приду слушать. "
    $ week6_after_offer = "Потом хочу с тобой пройтись вдвоём." if not week6_friend(week6_guest) else "Потом можем вместе до метро дойти."
    call week6_chat(week6_guest, "concert_invite", [], [
        ("walk", "В пятницу Варя поёт на небольшом вечере. В семь у входа, её номер в половине восьмого. " + week6_onstage + week6_after_offer, [(week4_names[week6_guest], {"nika":"Пойду. И потом пройдёмся. Только я слушать, не за пульт.", "lera":"Да! Хочу. Потом ещё расскажу тебе про свой сет, там смешное было.", "asya":"Давай. В семь буду. И после хочу пройтись, я всю неделю в помещении.", "marta":"Хочу. Тогда в семь у входа. После номера вместе уйдём?"}[week6_guest])]),
        ("show", "В пятницу Варя поёт на небольшом вечере. В семь у входа, её номер в половине восьмого. " + week6_onstage + "Я потом домой, но послушать вместе хочу.", [(week4_names[week6_guest], "Давай. Тогда только на концерт, в семь буду.")])])
    $ week6_concert.update(guest=week6_guest, walk_promised=_return == "walk")
    $ week6_event("concert_guest_agreed", _return, week6_guest)
    if week6_guest == "marta" and week6_concert.get("walk_promised"):
        call week6_chat("marta", "concert_walk_answer", [], [("yes", "Да, после номера уйдём вместе. Хочу с тобой пройтись.", [("Марта", "Хорошо. Тогда до пятницы.")])])
    call week6_chat("varya", "guest_permission", [], [("tell", "Со мной будет [week4_names[week6_guest]]. Ещё один человек послушать, можно?", [("Варя", "Да! Там свободный вход. Я тогда вам напишу, куда куртки девать.")])])
    return

label week6_friday_concert:
    $ week6_stage = "concert"
    $ week6_stamp("Пятница после работы", 1120, 5)
    if week6_varya.get("role") not in ("play", "audience"):
        scene bg w6 snow courtyard night with fade
        $ set_soundscape("ch3_outside")
        "Олег выходит за едой. Под подошвой хрустит ледяная корка; снег со вчерашнего дня так и не лёг ровным слоем."
        $ week6_stamp("Дома · после концерта", 1260)
        if week6_known("varya"):
            call week6_chat("varya", "after_absence", [("Варя", "Я спела. Пока не спрашивай как, у меня руки трясутся."), ("Варя", "Вообще хочу ещё.")], [("ask", "Поздравляю! Отдышись, потом расскажешь. Записал кто-нибудь?", [("Варя", "Папа снимал. Половину с пальцем, но звук есть. Потом скину.")])])
            $ week6_event("concert_heard_after", person="varya")
        jump week6_friday_end
    scene bg w6 venue empty with fade
    $ set_soundscape("ch3_evening")
    $ week6_stamp("Музыкальная площадка", 1140)
    "На двери маленькая афиша. За ней — узкий гардероб и зал с невысокой сценой. Олег вытирает ботинки о коврик, снимает куртку."
    $ week6_concert["attended"] = True
    if week6_concert.get("guest"):
        "[week4_names[week6_concert['guest']]] приходит почти следом. Они здороваются и оставляют вещи рядом."
        if week6_varya.get("role") == "play":
            o "Я сначала к Варе, звук проверить. Встретимся после номера?"
            "Она кивает и идёт выбирать место в зале."
    scene bg w6 venue varya with dissolve
    v "Папа пришёл. Я его ещё не видела, но он уже написал, что хорошо слышно. Я ещё даже не пела."
    o "Значит, микрофон работает."
    v "Я его позвала. В личку. Он написал, что постарается."
    o "На твой номер?"
    v "Угу. Он же не слышал, как я пою. Думаю, ему понравится. Он такое слушает."
    "Она показывает Олегу переписку, потом снова глядит на дверь. Под приглашением только «постараюсь»; новых сообщений нет."
    $ week6_varya["crush_invited"] = True
    $ week6_varya["crush_expectation"] = "impress_him"
    $ week6_event("crush_invitation_known", "Варя сама позвала; ответ — постараюсь", "varya")
    menu:
        "Займу её конкретным делом.":
            o "Давай воду возьмём. Ты куда её поставишь, чтобы со сцены не слезать?"
            v "Точно. Я вообще не взяла. Сейчас."
            $ week6_concert["before"] = "water"
        "Спрошу, хочет ли она поговорить про него.":
            o "Ты его сейчас ждёшь?"
            v "Да. Я ему ещё вход сфоткала, тут со двора не сразу понятно. Может, он уже идёт."
            o "Понял."
            $ week6_concert["before"] = "asked"
        "Дам ей минуту. Сам проверю, куда идти.":
            o "Я тут рядом. Если что, позови."
            "Варя кивает и убирает телефон в карман. Через минуту достаёт снова."
            $ week6_concert["before"] = "space"
    $ week6_stamp("Сцена", 1170)
    call week6_concert_number
    $ week6_concert["performed"] = True
    $ week6_event("performed", week6_varya["role"], "varya")
    $ week6_stamp("После номера", 1190)
    scene bg w6 venue varya with dissolve
    $ set_soundscape("ch3_evening")
    v "Я на второй строчке вообще перестала дышать. Потом как-то вспомнила."
    "Она крутит крышку бутылки, проливает немного воды на пальцы."
    if week6_concert.get("guest"):
        if week6_entry.get("varya", {}).get("help") == "together" and week6_entry.get("person") == week6_concert["guest"]:
            v "И [week4_names[week6_concert['guest']]] спасибо, что пришла. Я ей ещё за ту поездку нормально не сказала. Сейчас сама скажу."
        else:
            if connection_get("asya_varya", week6_relations).get("scene_done") and week6_concert["guest"] == "asya":
                v "Ася тоже пришла? Пойдём к ней, я ей запись потом скину."
            elif connection_get("marta_varya", week6_relations).get("scene_done") and week6_concert["guest"] == "marta":
                v "Марта тоже здесь? Пойдём к ней. Я ей ещё до концерта написать хотела."
            else:
                v "Пойдём к твоей знакомой? Я ещё толком не поздоровалась."
    if week6_concert.get("guest") == "asya":
        call week6_concert_asya_varya
    call week6_varya_after_concert
    "Варя уходит к отцу посмотреть запись. До Олега доносится: «Пап, это палец. Тут тоже палец». Потом они оба смеются."
    $ week6_concert["varya_with_father"] = True
    if week6_varya.get("crush_response") == "explain":
        "Олег машет ей перед уходом. Варя коротко кивает и снова поворачивается к экрану отцовского телефона."
    call week6_zhenya_meeting
    jump week6_friday_end

label week6_friday_end:
    $ week6_stage = "friday_finished"
    $ week6_stamp("Поздний вечер", 1330, 5)
    scene expression home_keepsake_background(week6_home_path(True)) with fade
    $ set_soundscape("ch3_room")
    if week6_has_contact("zhenya"):
        "Уже дома Олег ещё раз открывает новый контакт. «Женя, шарф». Пока оставляет так."
    elif week6_has_contact("ulya"):
        "В новых сообщениях Ули больше ничего нет. Олег вспоминает волну, которая уходит поперёк, и улыбается."
    else:
        "Олег вытаскивает монету из кармана и кладёт на стол. На улице снова идёт снег."
    jump week6_weekend_plan

# The outcome stays separate from Varya's enjoyment of her own performance.
label week6_varya_after_concert:
    v "Он так и не пришёл."
    "Варя открывает переписку. Набирает «Ты где?», смотрит на эти два слова и стирает."
    v "Может, он думал, что позже. Я афишу скинула, там весь вечер написан. Хотя про полвосьмого я тоже написала."
    "В зале начинают следующий номер. Варя убавляет яркость экрана."
    v "Я думала, он меня хоть тут увидит. А то я при нём всё время какую-то херню несу."
    $ week6_varya["crush_attended"] = False
    $ week6_varya["crush_expectation"] = "still_hoping"
    $ week6_event("crush_missed_concert", "Приглашён Варей; на её номер не пришёл", "varya")
    menu:
        "Не стану лезть. Лучше вернусь к её выступлению.":
            o "Ты в конце сама улыбаться начала. На записи, наверное, будет видно."
            v "Я там в текст попала. Наконец-то."
            "Она на секунду улыбается, но телефон не убирает."
            v "Запись ему всё равно скину. Вдруг посмотрит."
            $ week6_varya["crush_response"] = "ignore"
            $ week6_concert["after_varya"] = "music"
        "Поддержу её. Она ждала его, и это обидно.":
            o "Жаль, что он не пришёл. Ты его ждала."
            v "Я даже эту песню поэтому взяла. Ну, не только поэтому. Мне она тоже нравится."
            o "Мне очень понравилось, как ты спела. Я рад, что услышал."
            "Варя закручивает бутылку. На этот раз мимо резьбы, со второй попытки попадает."
            v "Спасибо. Я ему запись отправлю. Только сначала посмотрю, что папа наснимал."
            $ week6_varya["crush_response"] = "support"
            $ week6_concert["after_varya"] = "her"
        "Скажу прямо: по-моему, пора перестать его добиваться.":
            o "Варь, ты его позвала, написала время. Он не пришёл и даже не предупредил. Я бы больше его никуда не звал."
            v "Он не обещал. «Постараюсь» — это не обещал."
            o "Да. Но ты ждёшь, а он даже ничего не предлагает. Мне кажется, ты ему не так интересна, как он тебе."
            if any(e.get("event") == "fed_illusion" for e in week6_relations.get("varya", {}).get("events", [])):
                v "Ты же сам говорил, что он просто стесняется."
                o "Говорил. Зря я за него придумал. Я его не знаю. Но вижу, что он делает."
                $ week6_varya["earlier_illusion_acknowledged"] = True
            v "Ты его вообще не знаешь. Может, у него что-то случилось."
            o "Может. Но я бы перестал за ним бегать."
            "Она убирает телефон в карман и вытирает мокрые пальцы о джинсы."
            v "Я сегодня первый раз спела перед людьми. Можно хотя бы сегодня без этого?"
            o "Хорошо. Не буду продолжать."
            $ week6_varya["crush_response"] = "explain"
            $ week6_varya["crush_conversation"] = "guarded"
            $ week6_concert["after_varya"] = "crush"
    $ week6_event("crush_concert_response", week6_varya["crush_response"], "varya")
    return
