# Saved with this playthrough, never read from the persistent high-score table.
init -11 python:
    vignette_scene_effects = {
        "photo": ("office_spread", "reshoot", "varya_camera"),
        "riff": ("duet_take", "bass_guide", "unrecorded_jam"),
        "studio": ("measured_plan", "reworked_plan", "no_plan"),
        "hum": ("clean_channel", "bypassed_return", "lera_mix"),
        "laundry": ("aired", "turn_inside", "ordinary_drying"),
        "box": ("dry_parcel", "damp_corner", "ordinary_delivery"),
        "shadow": ("wave_loop", "missed_take", "empty_wave"),
        "balloons": ("quiet_after", "water_break", "offscreen_after"),
    }

    def vignette_scene_effect(state):
        result = state.get("result")
        if result not in ("smooth", "funny", "skipped"):
            return ""
        if state.get("context") in ("solo_recording", "solo_practice"):
            return {"smooth":"solo_ready", "funny":"solo_practice", "skipped":"solo_skipped"}[result]
        return vignette_scene_effects[state["kind"]][("smooth", "funny", "skipped").index(result)]

    def vignette_effect(kind):
        # Old saves without this scene retain their original continuation.
        return vignette_history.get(kind, {}).get("scene_effect", "")

    def vignette_photo_print(shot):
        w, h = int(410 / shot["zoom"]), int(286 / shot["zoom"])
        x = max(0, min(960 - w, int(shot["x"] - w / 2)))
        y = max(0, min(560 - h, int(shot["y"] - h / 2)))
        plate = Fixed(Transform(vignette_art("courtyard-board"), xysize=(960, 560)),
            Text("ОФИС", xpos=696, ypos=99, size=25, color="#4b534b"), xysize=(960, 560))
        return Transform(plate, crop=(x, y, w, h), xysize=(350, 245))

screen vignette_photo_proof():
    zorder -1
    add Solid("#14252b")
    frame:
        xalign .5 ypos 130 padding (22, 22) background Solid("#efe3cb")
        vbox:
            spacing 12
            text "ТРИ КАДРА" size 18 color "#4f5146" kerning 2
            hbox:
                spacing 22
                for i, shot in enumerate(vignette_history["photo"].get("shots", [])):
                    vbox:
                        spacing 7
                        add vignette_photo_print(shot)
                        text ("%02d" % (i + 1)) size 16 color "#65604f"

screen vignette_studio_proof():
    zorder -1
    add Solid("#14252b")
    frame:
        xalign .5 ypos 100 xysize (500, 555) padding (24, 24) background Solid("#efe3cb")
        text "ПРИМЕРКА НА БУМАГЕ" size 19 color "#5a503e" kerning 1
        for item, (cx, cy) in enumerate(vignette_history["studio"]["layout"]):
            $ title, w, h, colour, art = vignette_furniture[item]
            fixed:
                xpos (cx * 108) ypos (45 + cy * 108) xysize (w * 108, h * 108)
                add vignette_prop("furniture-" + art, w * 108 - 8, h * 108 - 8) xalign .5 yalign .5

label vignette_laundry_care:
    if week5_laundry.get("where") == "lera" and week5_laundry.get("drying_care") == "turn_requested":
        "В перерыве Олег вспоминает футболку, которую оставили вдвое. Лера просила напомнить после утра, не с будильником."
        call week5_chat("lera", "drying_turn", [], [("remind", "Напоминаю про футболку на левом краю. Сгиб перевернуть, как вчера говорили.", [("Лера", "Да, сейчас. Полотенца уже сняли, расправлю целиком."), ("Лера", "Вечером сгиб потрогай, прежде чем в пакет убирать.")])])
        $ week5_laundry["drying_care"] = "turned"
    return
