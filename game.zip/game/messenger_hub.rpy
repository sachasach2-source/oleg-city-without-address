# Reversible presentation experiment. Story callers keep their original returns.
default persistent.messenger_experiment = True
default messenger_deliveries = {}
default messenger_views = {}

init 90 python:
    import os as messenger_os
    def messenger_enabled():
        return bool(getattr(persistent, "messenger_experiment", True))

    def messenger_initial_view(token, inbox_mode, instant):
        if not messenger_enabled() or inbox_mode or instant:
            return "thread"
        return messenger_views.get(token, {}).get("view", "list")

    def messenger_caption(caption):
        return "Агент" if caption == "Просмотр квартиры" else caption

    def messenger_chapter(token=None):
        if isinstance(token, str):
            if token in messenger_pending:
                return messenger_pending[token]["chapter"]
            for prefix, number in (("w7_",7),("w6_",6),("w5_",5),("w4_",4),("ch4_",3),("ch3_",3),("ch2_",2)):
                if token.startswith(prefix):
                    return number
        names = {"Свои вещи":2, "Не сохнет":4, "Я тебя зову":5, "До тебя доехать":6, "Кем нарядиться":7}
        if city_chapter in names:
            return names[city_chapter]
        return 3 if any(word in city_chapter for word in ("Нормально посид", "Тёплые выходные", "тёплые выходные")) else 1

    def messenger_known_contacts(chapter=None):
        chapter = messenger_chapter() if chapter is None else chapter
        result = ["Мои шлюхи", "Саша", "Саня", "Агент"]
        if chapter >= 4:
            relations = {4:week4_relations, 5:week5_relations, 6:week6_relations, 7:week7_relations}[min(chapter,7)]
            for person, relation in relations.items():
                if relation.get("known") and (person not in ("zhenya", "ulya") or relation.get("facts",{}).get("contact")):
                    result.append(week4_names.get(person,person))
            if week4_rita_contact:
                result.append("Рита")
        elif chapter == 3:
            if chapter3_previous.get("origin", chapter2_origin) in ("connection", "friendship"):
                result.append("Ника")
            if chapter3_previous:
                result += ["Ася", "Лера"]
            if chapter3_previous.get("varya") or "varya" in chapter3_plans:
                result.append("Варя")
            if chapter4_marta_contact:
                result.append("Марта")
        elif chapter == 2:
            if chapter2_origin in ("connection", "friendship"):
                result.append("Ника")
            if chapter2_varya:
                result.append("Варя")
        elif invitation in ("yes", "slow"):
            result.append("Ника")
        return list(dict.fromkeys(result))

    def messenger_threads():
        # Full per-message records are authoritative, not the short chapter tails.
        chapter = messenger_chapter()
        result = week7_saved_threads(chapter)
        # Replies to an older optional conversation arrive after intervening
        # threads. Preserve their insertion order instead of grouping its
        # whole suffix back at the original morning's position.
        affected = {item["caption"] for item in messenger_pending.values() if item["chapter"] <= chapter}
        for caption in affected:
            result[messenger_caption(caption)] = [(sender, message, stamp)
                for (token, position), (sender, message, stamp) in phone_message_times.items()
                if phone_thread_contacts.get(token) == caption and messenger_chapter(token) <= chapter]
        return result

    def messenger_contacts(current="", chapter=None, threads=None):
        threads = messenger_threads() if threads is None else threads
        contacts = ([messenger_caption(current)] if current else []) + list(threads) + messenger_known_contacts(chapter)
        return list(dict.fromkeys(contacts))

    def messenger_note_delivery(token, caption, messages, seen=False):
        if not messenger_enabled():
            messenger_mark_seen(caption)
            return
        incoming = [(sender, text) for sender,text in messages if sender != "Олег"]
        old = messenger_deliveries.get(token, {})
        if incoming and incoming != old.get("incoming"):
            messenger_deliveries[token] = dict(caption=messenger_caption(caption), incoming=incoming,
                unread=not seen, preview=phone_message_label(incoming[-1][1]))

    def messenger_mark_seen(caption):
        for delivery in messenger_deliveries.values():
            if delivery["caption"] == messenger_caption(caption):
                delivery["unread"] = False

    def messenger_unread(caption):
        return any(item["unread"] and item["caption"] == messenger_caption(caption) for item in messenger_deliveries.values()) or any(not item.get("seen") for item in messenger_week7_pending(caption))

    def messenger_switch(view, caption=None):
        screen = renpy.get_screen("phone_thread")
        if screen:
            screen.scope["messenger_view"] = view
            screen.scope["messenger_archive_contact"] = caption
            messenger_views[screen.scope["thread_token"]] = dict(view=view, contact=caption)
            renpy.retain_after_load()
            soundscape_reading(view != "closed")
            if view in ("thread", "archive"):
                messenger_mark_seen(caption or screen.scope["caption"])
            renpy.restart_interaction()

    def messenger_history_more(caption):
        screen = renpy.get_screen("messenger_browser") or renpy.get_screen("phone_thread")
        if screen:
            limits = screen.scope["messenger_history_limits"]
            limits[caption] = limits.get(caption, 40) + 40
            viewport = renpy.get_widget(screen.screen_name[0], "messenger_history_messages")
            if viewport is not None:
                viewport.yadjustment.change(0)
            renpy.restart_interaction()

    def messenger_browser_pick(caption=None):
        screen = renpy.get_screen("messenger_browser")
        if screen:
            screen.scope["contact"] = caption
            if caption:
                messenger_mark_seen(caption)
            renpy.restart_interaction()

    def messenger_finish_view(caption, view):
        soundscape_reading(False)
        if not messenger_enabled() or view == "thread":
            messenger_mark_seen(caption)

    def messenger_close_story(pending, decisions):
        if pending:
            messenger_switch("closed")
        else:
            return decisions

    def messenger_notify(caption, messages):
        # A receipt from an already chosen action does not need a modal screen.
        # Its actual transcript is committed by the caller before notifying.
        renpy.show_screen("messenger_received_notice", caption=caption, messages=messages)

    def messenger_open_notice(caption):
        renpy.hide_screen("messenger_received_notice")
        messenger_mark_seen(caption)
        if messenger_pending_for(caption):
            messenger_open_session(messenger_caption(caption))
        else:
            renpy.show_screen("messenger_browser", initial_contact=messenger_caption(caption))

    # Existing QA profiles keep the prior presentation; the experiment has its
    # own UI and compatibility checks, explicitly enabling it in private saves.
    if messenger_os.environ.get("OLEG_QA_REPORT_DIR"):
        persistent.messenger_experiment = False

screen messenger_contacts(current="", story=False, pending=False, decisions=None, chapter=None, session=False):
    $ threads = messenger_threads()
    $ contacts = messenger_contacts(current, chapter, threads)
    add Solid("#071019a8")
    add PhoneShell() xpos 1050 ypos 26
    fixed:
        xpos 1050 ypos 26 xsize 500 ysize 844
        text "Сообщения" xpos 29 ypos 65 size 30 color "#e4e8e7"
        textbutton "×":
            id "messenger_close"
            xpos 428 ypos 57 padding (8,4) text_size 28
            action (Return("__close__") if session else Function(messenger_close_story, pending, decisions) if story else Hide("messenger_browser"))
        text "Чаты" xpos 30 ypos 115 size 16 color "#8fa6b3"
        viewport:
            xpos 25 ypos 155 xsize 452 ysize 620
            mousewheel True draggable True scrollbars "vertical"
            vscrollbar_xsize 12 side_spacing 10 vscrollbar_unscrollable "hide"
            vbox:
                spacing 10 xsize 420
                for person in contacts:
                    $ rows = threads.get(person, [])
                    $ active = story and person == messenger_caption(current)
                    button:
                        id ("messenger_contact_" + person)
                        xsize 420 padding (14,12)
                        background PhoneRound("#193344" if active else "#11232d", 12)
                        action (Return(person) if session else Function(messenger_switch, "thread", person) if active else Function(messenger_open_session, person) if messenger_pending_for(person) else Function(messenger_switch, "archive", person) if story else Function(messenger_browser_pick, person))
                        hbox:
                            spacing 12
                            use phone_avatar(person, 38)
                            vbox:
                                spacing 5 xsize 335
                                text (person + (" · новое" if messenger_unread(person) else "")) size 22 color ("#f0d3a1" if active or messenger_unread(person) else "#e4e8e7")
                                text messenger_contact_preview(person, rows, active, pending) size 15 color "#9eb2bf" xmaximum 330
                                if active and rows:
                                    textbutton "Вся переписка":
                                        id "messenger_current_history"
                                        padding (0,3) background None hover_background None text_size 15 text_color "#91b8d5"
                                        action Function(messenger_switch, "archive", person)
                                elif session and rows and (messenger_pending_for(person) or messenger_week7_pending(person)):
                                    textbutton "Вся переписка":
                                        id ("messenger_session_history_" + person)
                                        padding (0,3) background None hover_background None text_size 15 text_color "#91b8d5"
                                        action Return(("history", person))

screen messenger_history(caption, back, page=40):
    default message_scroll = ui.adjustment()
    $ records = messenger_threads().get(caption, [])
    $ start = max(0, len(records) - page)
    add PhoneShell() xpos 1050 ypos 26
    fixed:
        xpos 1050 ypos 26 xsize 500 ysize 844
        textbutton "←":
            id "messenger_history_back"
            action back xpos 18 ypos 60 padding (6,4) text_size 26
        text caption xpos 72 ypos 65 size 27 color "#e4e8e7" xmaximum 390
        viewport:
            id "messenger_history_messages"
            xpos 25 ypos 135 xsize 452 ysize 615
            mousewheel True draggable True scrollbars "vertical"
            yadjustment message_scroll yinitial 1.0
            vscrollbar_xsize 12 side_spacing 10 vscrollbar_unscrollable "hide"
            vbox:
                spacing 7 xsize 414
                if start:
                    textbutton "Ранние сообщения ↑":
                        id "messenger_earlier"
                        action Function(messenger_history_more, caption)
                        text_size 17
                for index, (sender, message, stamp) in enumerate(records[start:]):
                    use phone_message(sender, message, stamp, "archive_" + str(start+index), animate=False, can_react=False)
                if not records:
                    text "В этой переписке пока нет сообщений." size 20 color "#9eb2bf" xmaximum 400
        textbutton "К чатам →":
            action back xpos 25 ypos 755 xsize 450 text_size 20 text_xalign 0.5

screen messenger_browser(initial_contact=None):
    modal True
    zorder 150
    default contact = initial_contact
    default messenger_history_limits = {}
    on "show" action Function(soundscape_reading, True)
    on "hide" action Function(soundscape_reading, False)
    if contact is None:
        use messenger_contacts
    else:
        add Solid("#071019a8")
        use messenger_history(contact, Function(messenger_browser_pick), messenger_history_limits.get(contact, 40))
    key "game_menu" action (Function(messenger_browser_pick) if contact else Hide("messenger_browser"))

screen messenger_received_notice(caption, messages):
    zorder 95
    # Notifications never intercept a choice or a phone already in use.
    if not ui_in_menu() and not any(renpy.get_screen(name) for name in ui_focus_screens + ("menu", "week7_phone_inbox", "messenger_browser", "choice")):
        button:
            id "messenger_received_notice"
            xpos 550 ypos 160 xsize 425 padding (20,16)
            background context_panel("panel")
            action Function(messenger_open_notice, caption)
            vbox:
                spacing 7
                text ("Сообщения · " + messenger_caption(caption)) size 20 color "#e4c698"
                $ incoming = [text for sender,text in messages if sender != "Олег"]
                if incoming:
                    text phone_past_excerpt(incoming[-1]) size 18 color "#c4d2dc" xmaximum 380
    timer 4.0 action Hide("messenger_received_notice")

screen messenger_notification(caption, messages):
    $ incoming = [text for sender,text in messages if sender != "Олег"]
    button:
        id "messenger_notification"
        xpos 550 ypos 160 xsize 425 padding (20,16)
        background context_panel("panel")
        action Function(messenger_switch, "thread", caption)
        vbox:
            spacing 7
            text ("Сообщение · " + messenger_caption(caption)) size 20 color "#e4c698"
            if incoming:
                text phone_past_excerpt(incoming[-1]) size 18 color "#c4d2dc" xmaximum 380
