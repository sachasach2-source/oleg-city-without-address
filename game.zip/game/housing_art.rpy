# Clean dialogue plates and object inserts. Original sprites retain proportions.
image bg housing studio establishing = Transform("images/housing/studio-v2.webp", xysize=(1600, 900))
image bg housing quiet establishing = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))
image bg housing central establishing = Transform("images/housing/central-evening-v2.webp", xysize=(1600, 900))
image bg housing modern establishing = Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900))
image bg housing studio = Transform("images/housing/studio-v2.webp", xysize=(1600, 900))
image bg housing studio home = Transform("images/housing/studio-v2.webp", xysize=(1600, 900))
image bg housing studio night = Transform("images/housing/studio-night-v2.webp", xysize=(1600, 900))
image bg housing studio bed = Transform(Transform("images/housing/studio-bed-v2.webp", xysize=(1600, 900)), crop=(220, 210, 1120, 630), xysize=(1600, 900))
image bg housing shared washer = Transform("images/housing/shared-washer-v1.webp", xysize=(1600, 900))
image bg housing modern controls = Transform(Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900)), crop=(650, 60, 900, 506), xysize=(1600, 900))
image bg housing studio desk = Transform(Transform("images/housing/studio-v2.webp", xysize=(1600, 900)), crop=(430, 120, 1120, 630), xysize=(1600, 900))
image bg housing quiet = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))
image bg housing quiet home = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))
image bg housing quiet night = Transform("images/chapter3/ch3-rental-night-v2.webp", xysize=(1600, 900))
image bg housing central = Transform("images/housing/central-evening-v2.webp", xysize=(1600, 900))
image bg housing central kitchen = Transform("images/housing/central-kitchen-evening-v2.webp", xysize=(1600, 900))
image bg housing central loft = Transform(Transform("images/housing/central-kitchen-evening-v2.webp", xysize=(1600, 900)), crop=(530, 0, 1067, 600), xysize=(1600, 900))
image bg housing central bedroom = Transform("images/housing/central-bedroom-evening-v2.webp", xysize=(1600, 900))
image bg housing modern = Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900))
image bg housing modern window = Transform(Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900)), crop=(460, 0, 1067, 600), xysize=(1600, 900))

init -6 python:
    for key, path, tone in [
        ("housing studio", "images/housing/studio-v2.webp", "warmday"),
        ("housing quiet", "images/chapter3/ch3-rental-day-v2.webp", "warmday"),
        ("housing central", "images/housing/central-evening-v2.webp", "warmday"),
        ("housing central kitchen", "images/housing/central-kitchen-evening-v2.webp", "warmday"),
        ("housing central bedroom", "images/housing/central-bedroom-evening-v2.webp", "warmday"),
        ("housing modern", "images/housing/modern-evening-v2.webp", "evening"),
    ]:
        cast_stages[key] = (path, [("oleg", "indoor", 400, 55, 920), ("agent", "", 1250, 55, 840)], None, tone)

# Accepted housing is a home, not a viewing with the agent still on screen.
image bg housing central home = Transform("images/housing/central-bedroom-v1.webp", xysize=(1600, 900))
image bg housing central night = Transform("images/housing/central-bedroom-evening-v2.webp", xysize=(1600, 900))
image bg housing modern home = Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900))
image bg housing modern night = Transform("images/housing/modern-evening-v2.webp", xysize=(1600, 900))
