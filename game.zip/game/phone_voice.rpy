# Listening/viewing are saved separately from receiving a message.
default phone_media_viewed = {}
default phone_voice_ranges = {}
default phone_voice_transcripts = {}
default phone_voice_active = ""
default phone_voice_position = 0.0
default phone_voice_previous = None

init -1 python:
    renpy.music.register_channel("phone_voice", mixer="voice", loop=False)

    def phone_media_open(media_id):
        phone_media_viewed[media_id] = True

    def phone_voice_stop():
        global phone_voice_active, phone_voice_previous
        renpy.music.stop(channel="phone_voice")
        renpy.music.set_pause(False, channel="phone_voice")
        soundscape_levels(delay=.15)
        phone_voice_active, phone_voice_previous = "", None

    def phone_voice_play(media_id, position=None):
        global phone_voice_active, phone_voice_position, phone_voice_previous
        if phone_voice_active == media_id and position is None and renpy.music.get_playing(channel="phone_voice"):
            paused = not renpy.music.get_pause(channel="phone_voice")
            renpy.music.set_pause(paused, channel="phone_voice")
            if paused:
                soundscape_levels(delay=.15)
            else:
                renpy.music.set_volume(soundscapes[audio_scene][3] * .18, delay=.15, channel="music")
            return
        pos = phone_voice_position if phone_voice_active == media_id and position is None else (position or 0.)
        phone_voice_stop()
        phone_voice_active, phone_voice_position, phone_voice_previous = media_id, pos, None
        renpy.music.play("<from %.3f>%s" % (pos, phone_media[media_id]["path"]), channel="phone_voice", loop=False)
        renpy.music.set_volume(soundscapes[audio_scene][3] * .18, delay=.15, channel="music")

    def phone_voice_add_range(media_id, start, end):
        if end <= start:
            return
        ranges = list(phone_voice_ranges.get(media_id, [])) + [(start, end)]
        merged = []
        for left, right in sorted(ranges):
            if merged and left <= merged[-1][1] + .12:
                merged[-1] = (merged[-1][0], max(right, merged[-1][1]))
            else:
                merged.append((left, right))
        phone_voice_ranges[media_id] = merged

    def phone_voice_tick(media_id):
        global phone_voice_position, phone_voice_previous
        if phone_voice_active != media_id:
            return
        pos = renpy.music.get_pos(channel="phone_voice")
        if pos is not None:
            if phone_voice_previous is not None and 0 <= pos - phone_voice_previous < .8:
                phone_voice_add_range(media_id, phone_voice_previous, pos)
            phone_voice_position, phone_voice_previous = pos, pos
        elif not renpy.music.get_playing(channel="phone_voice"):
            phone_voice_stop()
        renpy.restart_interaction()

    def phone_voice_knows(media_id):
        if phone_voice_transcripts.get(media_id):
            return True
        left, right = phone_media[media_id]["meaning_range"]
        return sum(max(0., min(b, right) - max(a, left)) for a, b in phone_voice_ranges.get(media_id, [])) >= (right - left) * .85

    def phone_voice_caption(media_id):
        phone_voice_transcripts[media_id] = True

    config.after_load_callbacks.append(phone_voice_stop)

screen phone_voice_viewer(media_id):
    modal True
    zorder 500
    $ media = phone_media[media_id]
    $ current = min(media["duration"], phone_voice_position) if phone_voice_active == media_id else 0.
    on "show" action Function(phone_voice_stop)
    on "hide" action Function(phone_voice_stop)
    key "game_menu" action [Function(phone_voice_stop), Hide("phone_voice_viewer")]
    key "K_ESCAPE" action [Function(phone_voice_stop), Hide("phone_voice_viewer")]
    timer .15 repeat True action Function(phone_voice_tick, media_id)
    add Solid("#060d14f5")
    frame:
        xalign .5 yalign .5 xsize 1120 padding (45, 35) background phone_round("#213544", 20)
        vbox:
            spacing 22
            text media["title"] size 30
            text ("%02d:%02d / %02d:%02d" % (int(current)//60, int(current)%60, int(media["duration"])//60, int(media["duration"])%60)) size 25
            bar value StaticValue(current, media["duration"]) xsize 1000 thumb None
            hbox:
                spacing 20
                textbutton ("Пауза" if phone_voice_active == media_id and renpy.music.get_playing(channel="phone_voice") and not renpy.music.get_pause(channel="phone_voice") else "Слушать"):
                    id "voice_play"
                    action Function(phone_voice_play, media_id)
                textbutton "Сначала":
                    id "voice_replay"
                    action Function(phone_voice_play, media_id, 0.)
                textbutton "−3 сек" action Function(phone_voice_play, media_id, max(0., current-3.))
                textbutton "+3 сек" action Function(phone_voice_play, media_id, min(media["duration"]-.2, current+3.))
            textbutton "Показать расшифровку":
                id "voice_transcript"
                action Function(phone_voice_caption, media_id)
            if phone_voice_transcripts.get(media_id):
                text media["transcript"] size 24 line_spacing 5
            textbutton "Закрыть ×":
                id "voice_close"
                action [Function(phone_voice_stop), Hide("phone_voice_viewer")]


screen week7_attachment_archive():
    modal True
    zorder 450
    add Solid("#060d14f5")
    key "game_menu" action Hide("week7_attachment_archive")
    key "K_ESCAPE" action Hide("week7_attachment_archive")
    frame:
        xalign .5 yalign .5 xsize 1160 padding (35,25) background phone_round("#213544",18)
        vbox:
            spacing 16
            text "Фото и голосовые из этой переписки" size 30
            viewport:
                xsize 1090 ysize 555 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 10
                    for item in week7_attachments:
                        $ media=phone_media[item["token"]]
                        $ day=("Пн","Вт","Ср","Чт","Пт","Сб","Вс")[item["day"]]
                        $ label=day+" · "+chapter3_time(item["time"])+" · "+item["sender"]+" · "+("Голосовое" if media.get("kind")=="voice" else "Фото")+" · "+media["caption"]
                        textbutton label:
                            id ("archive_"+item["token"].split(":")[1])
                            text_size 23 xsize 1030 padding (12,10)
                            if media.get("kind")=="voice":
                                action Show("phone_voice_viewer",media_id=item["token"])
                            else:
                                action [Function(phone_media_open,item["token"]),Show("phone_photo_viewer",media_id=item["token"])]
            textbutton "Закрыть ×":
                id "archive_close"
                action Hide("week7_attachment_archive")
