# Small lived details; new facts are saved only when their scene was played.
image bg ch3 asya gift = Transform("images/chapter3/asya-tin-gift-v3.webp", xysize=(1600, 900))

init python:
    def chapter3_bedtime_memories():
        memories = []
        if chapter4_marta_seen:
            if chapter4_game_moment == "wrong_courtyard":
                memories.append("Марта закрывает лицо ладонями, когда проход снова закрывается. «Теперь я тут живу». Олег улыбается в темноте: надо же было заблудиться на одном столе.")
            elif chapter4_game_moment == "fountain":
                memories.append("Марта ведёт пальцем по его маршруту и обводит сквозной двор. «Этот проход оставлю». Зелёная фишка стоит у фонтана.")
            elif chapter4_game_moment == "blocked_route":
                memories.append("Карандаш поперёк прохода. «А тут хоть лавка есть?» Марта взяла карандаш, будто и правда собиралась дорисовать ему скамейку на ночь.")
            else:
                memories.append("У Марты на скетчбуке было пятно. Он сначала принял его за часть рисунка. Карточку из книжного Олег положил к телефону, чтобы утром не забыть в кармане.")
        people = sorted((p for p in ("nika", "asya", "lera", "varya") if chapter3_plans.get(p, {}).get("status") == "done"), key=lambda p: chapter3_plans[p]["day"], reverse=True)
        for person in people:
            reaction = chapter3_departures.get(person, {}).get("reaction")
            if reaction in ("hurt", "disappointed"):
                nika = "Ника погасила карту раньше, чем выбрала место. Он уже почти написал ей «хорошего вечера». Хорошо, что не отправил." if chapter3_departures[person].get("choice") == "later" else "У метро Ника достала наушники раньше, чем они попрощались. Он это видел. Сейчас всё равно хочется задержать тот момент."
                asya = "«Ты мне не мешаешь. Я с тобой сюда пришла». Он так и остался у гардероба. Теперь перед сном почему-то вспоминается эта фраза." if chapter3_departures[person].get("choice") == "entrance" else "Ася поправляет сумку и уходит по другой стороне двора. «Мне тоже». Кажется, в тот момент он мог хотя бы не торопиться с благодарностью за прогулку."
                memories.append({"nika":nika,
                    "asya":asya,
                    "lera":"Лера всё никак не застегнёт сумку. Олег переворачивается на другой бок. В голове это прощание почему-то дольше самой дороги домой.",
                    "varya":"Варя держит ремень двумя руками. «Я же тоже тебя сегодня ждала». Завтра написать ей не про тираж. Хотя сначала она ещё может не захотеть отвечать."}[person])
            elif person == "nika":
                if chapter3_tasks.get("nika_evening") is not None:
                    memories.append("Ника не сразу засмеялась над его речью про картошку. Сначала отпила чай, потом вспомнила. Олегу хочется ещё раз её так рассмешить.")
                elif chapter3_previous.get("origin") == "friendship":
                    memories.append("Ника сочиняла сообщение басисту и отбрасывала варианты прямо на ходу. Интересно, в итоге отправила самый простой или опять переписала.")
                else:
                    memories.append("Ника смотрела на его футболку, пока он объяснял про пять одинаковых. Олег вспоминает её лицо и улыбается в темноте.")
            elif person == "asya":
                if chapter3_tasks.get("asya_tea_topic") == "grandmother":
                    memories.append("У автобуса к Асиной бабушке два последних рейса. Ася серьёзно показывала оба в разных приложениях. Олег вспоминает её лицо и тихо смеётся.")
                elif chapter3_tasks.get("asya_tea"):
                    memories.append("Ася всё-таки дождалась, пока он закончит про паркомат. Потом переспросила про номер зоны. Без этой спешки ему было легче с ней говорить.")
                elif chapter3_tasks.get("asya_gift"):
                    memories.append("В синей коробочке что-то стукнуло. Пуговицы он так и не выложил. Утром надо проверить, не мешают ли закрывать крышку.")
                elif chapter3_tasks.get("asya_outing") == "photos":
                    memories.append("На фотографии между домами осталось совсем немного неба. Олег вспоминает, как отходил к другой стене, чтобы посмотреть на снимок издалека.")
                else:
                    memories.append("Асин керамический кот смотрел на него с полки. Олег пытается вспомнить, какой именно ценник его так оскорбил, и сбивается.")
            elif person == "lera":
                if chapter3_tasks.get("lera_private_topic") == "swim":
                    memories.append("Лера на секунду поверила в телефон в пакете. «Не бери в пакет». Её локоть ещё помнит его рука.")
                elif chapter3_tasks.get("lera_private_topic") == "music":
                    memories.append("Лера придержала его перед переходом: там ещё не закончился припев. Название он не запомнил. Надо попросить прислать.")
                else:
                    memories.append("Лера ещё не успела поздороваться: «Да, всё дома». Он действительно посмотрел ей на руки — не несёт ли опять провода. Смешно, что она сразу заметила.")
            elif chapter3_tasks.get("varya_drawing") or (chapter3_tasks.get("varya_pages") and chapter3_departures.get("varya", {}).get("choice") != "twenty"):
                memories.append("У нарисованного Олегом кота Варя насчитала семь ног. Надо было согласиться. Теперь доказать, что это усы, уже невозможно.")
            elif chapter3_tasks.get("varya_pages"):
                if chapter3_tasks.get("varya_editor") == "ask":
                    memories.append("Варя собиралась отправить маме ответ редактору. «Без восьми восклицательных знаков». Интересно, сколько в итоге оставила.")
                else:
                    memories.append("Кот с Вариной обложки смотрел прямо на него. На другом рисунке уже уходил по своим делам. Олег вспоминает, как она перелистывала между ними.")
            elif chapter3_plans[person].get("kind") == "print":
                memories.append("От тиража пахло тёплой бумагой. Варя проверяла одного и того же кота в разных экземплярах; он сначала даже не понял, что не так с чёрным.")
            else:
                memories.append("Варя приседала у стены ради кадра. Он бы прошёл мимо этой стены ещё сто раз. Интересно будет посмотреть, что получилось.")
            if len(memories) >= 3:
                break
        if not memories:
            if chapter3_solo == "купил собственную лампу":
                memories.append("Лампу он проверил ещё в магазине, но перед сном всё равно щёлкнул выключателем два раза. Работает. На абажуре маленькая царапина, которую днём не заметил.")
            elif chapter3_solo == "поиграл на гитаре для себя":
                memories.append("Вместо мыслей в голове крутится недоигранный куплет. Завтра, если вспомнит, попробует с другого аккорда. Гитара сейчас слишком далеко, чтобы вставать.")
            else:
                memories.append("За день успело нагреть шею. Подушка с этой стороны кажется холоднее. Олег переворачивает её обратно и ещё немного лежит с открытыми глазами.")
        return memories[:3]

label ch3_asya_gift:
    "Ася возвращается от соседнего прилавка с маленькой синей коробочкой."
    a "А это тебе."
    scene bg ch3 asya gift with dissolve
    "На крышке потёртый трамвай. Внутри две разные пуговицы."
    o "Они тоже мне?"
    a "Я внутри не посмотрела."
    o "То есть в обмене я уже веду три — один."
    a "Нет, их можно обратно высыпать."
    o "Не, пусть будут."
    scene bg ch3 market with dissolve
    "Олег закрывает коробочку. С первого раза крышка встаёт криво; Ася уже тянется поправить, но он справляется сам."
    o "Спасибо. Я туда медиаторы сложу."
    "Ася улыбается и протягивает ему маленький пакет. Свою покупку заворачивает отдельно."
    $ chapter3_tasks["asya_gift"] = "tram_tin"
    $ home_keepsake_receive("asya_tin")
    $ chapter3_asya_result += "; Ася подарила коробочку с трамваем"
    return

label ch3_bedtime:
    call home_keepsakes_unpack
    if chapter3_clock < 1350:
        "Он ещё успевает поесть, принять душ и повозиться с гитарой. Когда откладывает её, за окном уже темно. До будильника осталось меньше, чем хотелось."
    $ chapter3_clock = max(chapter3_clock, 1350)
    $ chapter3_stamp("Перед сном")
    if chapter3_housing == "new" and housing_home == "studio":
        "Перед сном Олег проверяет замок и убирает ноутбук со стола. Осталось разложить диван. Пельмени он уже достал."
    elif chapter3_housing == "new":
        "Перед сном Олег ещё раз проверяет замок. Свет из прихожей остаётся под дверью незнакомой комнаты. Чемодан пока не разобран; чистую футболку он вытащил сверху."
    elif chapter3_housing in ("whole", "month"):
        "Олег оставляет кружку на кухне и идёт ложиться. Из окна тянет; он прикрывает створку, запоминая, куда повернуть тугую ручку."
    else:
        "В номере Олег ставит телефон на зарядку и ложится. В коридоре кто-то не сразу попадает карточкой в замок. Потом тихо — попал."
    scene black with Dissolve(.8)
    hide screen scene_marker
    $ chapter3_sleep_memories = chapter3_bedtime_memories()
    $ chapter3_memory_index = 0
    while chapter3_memory_index < len(chapter3_sleep_memories):
        $ chapter3_memory = chapter3_sleep_memories[chapter3_memory_index]
        "[chapter3_memory]"
        $ chapter3_memory_index += 1
    if chapter4_marta_contact and chapter4_marta_relation == "interest":
        if chapter4_marta_plan == "coffee":
            mind "Завтра ещё кофе с Мартой. Только сначала работа. Будильник-то поставил?"
        elif chapter4_marta_plan == "walk":
            mind "До следующей субботы почти неделя. Посмотрим, куда на этот раз попадём."
    elif chapter3_housing not in ("new", "whole", "month"):
        mind "Номер с утра опять будет тот же. Ладно. Будильник на девять."
    else:
        mind "Будильник на девять. Окно утром надо будет открыть."
    "Олег убирает руку с телефона. Экран гаснет."
    return
