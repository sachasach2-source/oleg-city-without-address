# A viewing stays Oleg's decision. Companions never occupy a dating slot.
default housing_companion = ""
default housing_companion_chapter = 0

init python:
    def housing_companion_options(chapter):
        relations = week6_relations if chapter == 6 else week4_relations
        options = [("Съезжу один. Хочу спокойно сам посмотреть.", "")]
        for person, name in (("nika", "Нику"), ("lera", "Леру"), ("asya", "Асю")):
            relation = relations.get(person, {})
            if relation.get("known") and not any(i.get("status") != "resolved" for i in relation.get("issues", [])):
                options.append(("Спрошу " + name + ", не съездит ли со мной.", person))
        return options

    def housing_companion_stage(stage):
        if not housing_companion or cast_background_key() not in (
                "housing studio", "housing central", "housing central kitchen",
                "housing central bedroom", "housing modern", "housing quiet", "w6 housing modern",
                "housing approach", "w6 housing approach"):
            return stage
        if cast_background_key() in ("housing approach", "w6 housing approach"):
            wardrobe = ("winter" if housing_companion_chapter == 6 and housing_companion != "lera"
                else "coat" if housing_companion == "asya" else "outdoor")
            return (stage[0], [("oleg", "outdoor", 400, 55, 920),
                (housing_companion, wardrobe, 1220, 45, 1060 if wardrobe == "winter" else 920)], None, stage[3])
        wardrobe = {"nika":"standing", "lera":"indoor", "asya":""}[housing_companion]
        actors = [("oleg", "indoor", 285, 65, 900),
            (housing_companion, wardrobe, 790, 65, 900), ("agent", "", 1320, 65, 830)]
        return (stage[0], actors, stage[2], stage[3])

label housing_choose_companion(chapter=4):
    $ housing_companion = ""
    $ housing_companion_chapter = chapter
    $ housing_company_options = housing_companion_options(chapter)
    if len(housing_company_options) < 2:
        return
    "Олег открывает присланную точку. Можно попросить кого-нибудь съездить вместе."
    call screen chapter3_intentions("С кем съездить?", housing_company_options)
    $ housing_companion = _return
    if not housing_companion:
        return
    $ housing_company_time = "в половине второго, минут на двадцать" if chapter == 6 else "в половине седьмого, до восьми"
    $ housing_company_message = "Сегодня квартиру смотрю, " + housing_company_time + ". Не хочешь со мной? Мне бы ещё с кем-нибудь потом её обсудить."
    $ housing_company_answer = {"nika":"Могу. Давай вместе. Только я за тебя выбирать не умею.", "lera":"Поеду. Мне бы самой на что-нибудь без соседки посмотреть. Адрес кидай.", "asya":"Да, я свободна. Пришли точку, встретимся у подъезда."}[housing_companion]
    if chapter == 6:
        call week6_chat(housing_companion, "viewing_together", [], [("invite", housing_company_message, [(week4_names[housing_companion], housing_company_answer)])])
        $ week6_housing["companion"] = housing_companion
        $ week6_event("viewing_invitation", housing_companion, housing_companion)
    else:
        call week4_chat(housing_companion, "viewing_together", [], [("invite", housing_company_message, [(week4_names[housing_companion], housing_company_answer)])])
        $ week4_home["viewing_companion"] = housing_companion
        $ week4_event(housing_companion, "viewing_invitation")
    return

label housing_companion_arrival:
    if not housing_companion:
        return
    if housing_companion == "nika":
        "Ника ждёт у подъезда, убрав телефон в карман. Увидев Олега, придерживает тяжёлую дверь."
        n "Пошли. Ты объявление сохранил? Хочу потом с настоящей квартирой сравнить."
    elif housing_companion == "lera":
        "Лера подходит со стороны остановки и сразу заглядывает на номер над дверью."
        l "Сюда? Хорошо. Я в соседний двор сначала зашла. Там тоже сдаётся, но на двери написано, что гараж."
    else:
        "Ася стоит под козырьком. Олег сворачивает карту; она первой берётся за ручку двери."
        if housing_companion_chapter == 6:
            a "Я по дороге булку взяла. Ты на обед вышел?"
            o "Да. До двух обратно надо."
        else:
            a "Я по дороге булку взяла. Потом поделим. Ты после работы сразу?"
            o "Да. Спасибо."
    return

label housing_companion_opinion(candidate):
    if not housing_companion:
        return
    if housing_companion == "nika":
        n "Можно минуту просто послушать?"
        agent "Здесь очень спокойные соседи, всё интеллигентные люди."
        n "Я про сейчас."
        "Агент замолкает. За стеной коротко двигают стул, потом слышно только холодильник. Ника смотрит на Олега, не вынося вердикта."
        n "Ты ведь здесь и работать будешь. Я бы ещё вечером так постояла."
    elif housing_companion == "lera":
        if candidate == "central":
            l "Мне спальня нравится. Я бы из-за неё эти ступени простила."
            o "А я себя ночью уже на них представил."
            l "Ну да. Тебе ходить. Я сейчас чужую квартиру легко выбираю."
        else:
            "Лера отодвигает стул и просит Олега сесть как за работой. Сама проходит у него за спиной, не касаясь спинки."
            l "Вот так нормально. Я у себя каждый раз жду, пока соседка чай пронесёт."
        "Она возвращает стул на место и забирает свой шарф."
    else:
        a "Мне здесь свет нравится. Ты чего такой?"
        menu:
            "Мне важнее, чтобы ничего каждый день не приходилось обходить.":
                o "Я всё на проходы смотрю. Свет хороший, но ходить здесь каждый день."
                "Ася смотрит туда, откуда они пришли. Потом сама проходит обратно к двери, уже не оглядывая окна."
                a "Поняла. Я пока только глазами тут пожила."
            "Мне тоже нравится. Пытаюсь понять, не уговариваю ли себя.":
                o "Мне тоже нравится. Боюсь только опять быстро согласиться."
                a "Тогда не отвечай сейчас. Давай выйдем, булку съедим."
    if housing_companion_chapter == 6:
        $ week6_housing["discussed_with"] = housing_companion
    else:
        $ housing_records.setdefault(candidate, {})["companion"] = housing_companion
    return

label housing_companion_goodbye:
    if housing_companion:
        if housing_companion == "nika":
            n "Напиши, что решишь. Я бы и ключи с тобой забрала, если совпадём по времени."
        elif housing_companion == "lera":
            l "Ну всё, у меня дальше дела. Потом скажешь, какую всё-таки взял."
        else:
            "У выхода Ася разворачивает бумажный пакет. Половина булки ещё тёплая. Они едят, пока Олег убирает документы в рюкзак."
            a "Потом расскажешь? Я теперь тоже хочу знать, чем кончится."
        o "Расскажу. Спасибо, что поехала."
    $ housing_companion = ""
    return

image bg housing approach = Transform("images/week4/courtyard-rain-v1.webp", xysize=(1600, 900))
image bg w6 housing approach = Transform("images/week6/snow-courtyard-v2.webp", xysize=(1600, 900))

init -6 python:
    cast_stages["housing approach"] = ("images/week4/courtyard-rain-v1.webp", [], None, "dusk")
    cast_stages["w6 housing approach"] = ("images/week6/snow-courtyard-v2.webp", [], None, "day")
