init -10 python:
    import pygame_sdl2 as vignette_pygame

    class VignetteTrace(renpy.Displayable):
        def __init__(self, **kwargs):
            super(VignetteTrace, self).__init__(**kwargs)
            self.points = []
            self.active = False
            self.round = -1

        def reset(self):
            self.points, self.active, self.round = [], False, -1
            renpy.redraw(self, 0)

        def render(self, width, height, st, at):
            rv = renpy.Render(960, 530)
            s = vignette_state
            if not s or s["kind"] != "shadow" or s["rounds"] >= 3:
                return rv
            if self.round != s["rounds"]:
                self.points, self.active, self.round = [], False, s["rounds"]
            guide = vignette_shadow_paths[s["rounds"]][1]
            canvas = rv.canvas()
            for p, q in zip(guide, guide[1:]):
                canvas.line((27, 66, 77, 150), p, q, 16)
            for p in guide:
                canvas.circle((27, 66, 77, 150), p, 8)
            for p, q in zip(guide, guide[1:]):
                canvas.line((235, 233, 200, 210), p, q, 5)
            for p in guide:
                canvas.circle((235, 233, 200, 210), p, 3)
            canvas.circle((247, 203, 119, 255), guide[0], 13)
            canvas.circle((255, 247, 217, 255), guide[-1], 14, 3)
            for p, q in zip(self.points, self.points[1:]):
                canvas.line((19, 49, 59, 255), p, q, 12)
                canvas.line((115, 225, 215, 255), p, q, 6)
            if self.points:
                canvas.circle((244, 231, 180, 255), self.points[-1], 7)
            return rv

        def event(self, ev, x, y, st):
            if not vignette_state or vignette_state["kind"] != "shadow" or vignette_state["result"]:
                return
            if ev.type == vignette_pygame.MOUSEBUTTONDOWN and ev.button == 1 and 60 <= x <= 900 and 70 <= y <= 500:
                self.points, self.active = [(int(x), int(y))], True
                renpy.redraw(self, 0)
                raise renpy.IgnoreEvent()
            if self.active and ev.type == vignette_pygame.MOUSEMOTION:
                if not (0 <= x <= 960 and 0 <= y <= 530):
                    self.points, self.active = [], False
                elif vignette_math.hypot(x - self.points[-1][0], y - self.points[-1][1]) >= 5 and len(self.points) < 1000:
                    self.points.append((int(x), int(y)))
                renpy.redraw(self, 0)
                raise renpy.IgnoreEvent()
            if self.active and ev.type == vignette_pygame.MOUSEBUTTONUP and ev.button == 1:
                self.points.append((int(x), int(y)))
                stroke = list(self.points)
                self.points, self.active = [], False
                renpy.end_interaction(("trace", stroke))
                raise renpy.IgnoreEvent()

    def vignette_clear_trace():
        if vignette_state and vignette_state["kind"] == "shadow":
            vignette_trace_layer.reset()

default vignette_trace_layer = VignetteTrace()
