# Actual chapter four. chapter4_* remains the legacy chapter-three Marta episode.
default week4_started = False
default week4_entry = {}
default week4_relations = {}
default week4_history = {}
default week4_events = []
default week4_day = 0
default week4_clock = 492
default week4_work = {}
default week4_home = {}
default week4_plan = ""
default week4_plan_status = ""
default week4_plan_short = False
default week4_package = "none"
default week4_package_window = ""
default week4_delivery = ""
default week4_rita_contact = False
default week4_rita_interest = False
default week4_contacted = []
default week4_evening = ""
default week4_evening_result = ""
default week4_chat_index = 0
default week4_good_moment = ""
default week4_finished = False
default week4_laundry = {}
default week4_current = ""
default week4_result = ""
default week4_retry = False

init python:
    import copy
    week4_names = {"nika":"Ника", "asya":"Ася", "lera":"Лера", "varya":"Варя", "marta":"Марта", "rita":"Рита", "friends":"Мои шлюхи", "sasha":"Саша", "work":"Работа", "owner":"Хозяин", "agent":"Агент", "rita_group":"Четверг точно"}

    def week4_import_relations(previous, plans, tasks, results, departures, marta):
        """One explicit legacy boundary; never infer another person's private thoughts."""
        result = {}
        for person in ("nika", "asya", "lera", "varya", "marta"):
            plan = plans.get(person, {})
            departure = departures.get(person, {})
            known = person in plans or previous.get("route") == person or (person in ("asya", "lera") and bool(previous))
            if person == "nika":
                known = known or previous.get("origin") in ("connection", "friendship")
            if person == "varya":
                known = known or bool(previous.get("varya"))
            if person == "marta":
                known = marta.get("contact", False)
            touch = tasks.get("touch_" + person, "")
            mode = "uncertain"
            if person == "varya" or (person == "nika" and previous.get("origin") == "friendship"):
                mode = "friendship"
            elif person == "marta":
                mode = marta.get("relation") or "uncertain"
            elif touch in ("hand", "hug", "shoulder", "space") or previous.get("route") == person or (person == "nika" and previous.get("origin") == "connection"):
                mode = "interest"
            elif person == "asya" and "свиданием" in results.get(person, ""):
                mode = "interest"
            issues = []
            if plan.get("status") == "missed":
                issues.append({"cause":"missed_meeting", "status":"open"})
            if departure.get("reaction") in ("hurt", "disappointed"):
                issues.append({"cause":"early_departure", "detail":departure.get("choice", ""), "status":"open"})
            if person == "nika" and tasks.get("guitar") in ("pending", "deferred"):
                issues.append({"cause":"unsent_riff", "status":"open"})
            if person == "varya" and tasks.get("pdf") in ("pending", "deferred"):
                issues.append({"cause":"unread_zine", "status":"open"})
            result[person] = {"known":bool(known), "mode":mode,
                "last_meeting":results.get(person, ""), "last_status":plan.get("status", ""),
                "last_departure":copy.deepcopy(departure), "previous_touch":touch,
                "issues":issues, "events":[], "promises":(["Прогулка в следующую субботу"] if person == "marta" and marta.get("plan") == "walk" and known else []), "new_touch":"",
                "facts":{key:copy.deepcopy(value) for key,value in tasks.items() if person in key},
                "outcome":"", "invited":False}
        return result

    def week4_reset():
        chapter34_phone_reset(4)
        global week4_package_window
        week4_package_window = ""
        global phone_reply_log, phone_message_times, week4_laundry
        global week4_started, week4_entry, week4_relations, week4_history, week4_events
        global week4_day, week4_clock, week4_work, week4_home, week4_plan, week4_plan_status, week4_plan_short
        global week4_package, week4_delivery, week4_rita_contact, week4_rita_interest
        global week4_contacted, week4_evening, week4_evening_result, week4_chat_index, week4_good_moment, week4_finished
        week4_entry = copy.deepcopy({"previous":chapter3_previous, "plans":chapter3_plans,
            "tasks":chapter3_tasks, "results":chapter3_results, "departures":chapter3_departures,
            "housing":chapter3_housing, "marta":{"contact":chapter4_marta_contact,
            "relation":chapter4_marta_relation, "plan":chapter4_marta_plan}})
        week4_relations = week4_import_relations(week4_entry["previous"], week4_entry["plans"],
            week4_entry["tasks"], week4_entry["results"], week4_entry["departures"], week4_entry["marta"])
        week4_history = {"friends":copy.deepcopy(chapter3_friend_history)}
        for person in ("nika", "asya", "lera", "varya"):
            week4_history[person] = copy.deepcopy(phone_contact_history("w4_entry", week4_names[person])) if week4_relations[person]["known"] else []
        phone_reply_log = {k:v for k,v in phone_reply_log.items() if not k[0].startswith("w4_")}
        phone_message_times = {k:v for k,v in phone_message_times.items() if not k[0].startswith("w4_")}
        week4_laundry = {"method":"", "status":"dirty", "where":"home", "return":"", "washer":False}
        week4_events, week4_contacted = [], []
        week4_day, week4_clock, week4_chat_index = 0, 492, 0
        week4_work = {"stance":"", "deadline":"", "report":"open", "check":"", "apology":False, "evening":False}
        week4_home = {"kind":chapter3_housing if chapter3_housing in ("new", "whole", "month") else "hotel",
            "visit":"", "repaired":False, "boxes_gone":False, "search":False, "hotel":"same"}
        week4_plan = week4_plan_status = week4_evening = week4_evening_result = week4_delivery = week4_good_moment = ""
        week4_plan_short = week4_rita_contact = week4_rita_interest = week4_finished = False
        week4_package = "none"
        rita_moderation_reset()
        week4_started = True

    def week4_stamp(location, minute=None, day=None):
        global week4_clock, week4_day, place_name, save_name
        if minute is not None:
            week4_clock = minute
        if day is not None:
            week4_day = day
        place_name = "{} · {}, {}".format(location, ("понедельник", "вторник", "среда", "четверг")[week4_day], chapter3_time(week4_clock))
        save_name = "Глава 4 · " + place_name

    def week4_home_bg():
        if week4_home["kind"] == "new" and housing_home:
            return housing_home_background(week4_clock >= 1140)
        if week4_home["kind"] == "new":
            return "bg ch3 home night" if week4_clock >= 1140 else "bg w4 home new"
        if week4_home["kind"] in ("whole", "month"):
            return "bg ch3 old night" if week4_clock >= 1140 else "bg w4 home old"
        return "bg hotel night" if week4_clock >= 1140 else "bg hotel dusk" if week4_clock >= 1080 else "bg hotel morning"

    def week4_work_bg(detail=False):
        if week4_home["kind"] == "hotel":
            return "bg w4 work detail" if detail else "bg w4 work hotel"
        return week4_home_bg()

    def week4_event(person, event, detail=""):
        item = {"day":week4_day, "time":week4_clock, "event":event, "detail":detail}
        week4_events.append(dict(item, person=person))
        bonus_gallery_event(person, event, 4)
        if person in week4_relations:
            week4_relations[person]["events"].append(item)

    def week4_has(person, event):
        if person in week4_relations:
            return any(item["event"] == event for item in week4_relations[person]["events"])
        return any(item["person"] == person and item["event"] == event for item in week4_events)

    def week4_unresolved(person, serious_only=False):
        causes = ("early_departure", "missed_meeting", "dismissed", "broken_plan")
        return [item for item in week4_relations[person]["issues"]
                if item["status"] != "resolved" and (not serious_only or item["cause"] in causes)]

    def week4_acknowledge(person):
        for item in week4_unresolved(person, True):
            item["status"] = "acknowledged"
        week4_event(person, "acknowledged_hurt")

    def week4_open_issue(person, cause, detail=""):
        week4_relations[person]["issues"].append({"cause":cause, "detail":detail, "status":"open"})
        week4_event(person, cause, detail)

    def week4_can_touch(person):
        relation = week4_relations[person]
        # An apology cannot unlock contact. A newly reciprocal good scene must follow it.
        return relation["mode"] == "interest" and relation["previous_touch"] != "space" and relation["invited"] and week4_has(person, "mutual_time") and not any(
            issue["status"] == "open" for issue in week4_unresolved(person, True))

    def week4_complete_evening(person, outcome, touch="", moment=""):
        # Callers supply only a moment that was actually played.
        global week4_evening, week4_evening_result, week4_plan_status, week4_good_moment
        week4_evening, week4_evening_result = person, outcome
        relation = week4_relations[person]
        relation["outcome"] = outcome
        if outcome == "warm":
            # Repair needs both acknowledgment and a completed new interaction.
            for issue in relation["issues"]:
                if issue["status"] == "acknowledged":
                    issue["status"] = "resolved"
            week4_good_moment = moment or "побыли вместе"
        if touch and week4_can_touch(person):
            relation["new_touch"] = touch
        week4_event(person, "evening_" + outcome)
        if week4_plan == person:
            week4_plan_status = "done"

    def week4_thursday_free():
        return not (week4_plan_status == "confirmed" or week4_home.get("visit") == "thursday" or week4_home.get("viewing") or week4_work.get("evening"))

    def week4_book(person, short=False):
        global week4_plan, week4_plan_status, week4_plan_short
        if not week4_thursday_free() or not week4_relations[person]["known"]:
            return False
        week4_plan, week4_plan_status, week4_plan_short = person, "confirmed", short
        week4_relations[person]["invited"] = True
        week4_event(person, "confirmed_thursday", "short" if short else "evening")
        return True

    def week4_phone_dialogue(incoming, options):
        return {"start":{"messages":incoming, "options":[{"id":key,"text":text,"messages":replies,"next":None} for key,text,replies in options]}}

label week4_chat(person, key, incoming, options):
    $ week4_chat_token = "w4_{}_{}_{}".format(person, key, week4_chat_index)
    $ week4_chat_index += 1
    $ week4_chat_dialogue = week4_phone_dialogue(incoming, options)
    $ week4_chat_past = week4_history.get(person, [])[-2:]
    call screen phone_thread([], caption=week4_names[person], conversation=week4_chat_token, past=week4_chat_past, dialogue=week4_chat_dialogue)
    $ week4_chat_transcript, week4_chat_decisions, week4_chat_pending = phone_conversation_state(week4_chat_token, [], week4_chat_dialogue)
    $ week4_history[person] = (week4_history.get(person, []) + week4_chat_transcript)[-20:]
    return week4_chat_decisions[-1][1]
