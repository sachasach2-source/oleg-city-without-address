# Chapter seven continues the played sixth chapter; fixtures live in QA only.
default week7_started = False
default week7_finished = False
default week7_entry = {}
default week7_relations = {}
default week7_home = {}
default week7_history = {}
default week7_events = []
default week7_day = 0
default week7_clock = 1080
default week7_stage = ""
default week7_party = {}
default week7_rita = {}
default week7_friends = {}
default week7_costume = "horns"
default week7_guest = ""
default week7_chat_index = 0
default week7_attachments = []
default week7_outfits = {}

init python:
    week7_costumes = [("Вампир: рубашка и жилет.", "vampire"), ("Безумный учёный в халате.", "scientist"), ("Пугало: нашивки, солома и шляпа.", "scarecrow"), ("Маленькие рожки. Остальное — как обычно.", "horns")]
    week7_costume_names = dict(vampire="вампир", scientist="безумный учёный", scarecrow="пугало", horns="рожки")

    def week7_reset():
        global week7_started, week7_finished, week7_entry, week7_relations, week7_home
        global week7_history, week7_events, week7_day, week7_clock, week7_stage
        global week7_party, week7_rita, week7_friends, week7_costume, week7_guest, week7_chat_index, week7_attachments, week7_outfits
        global week7_public, week7_venue
        week7_entry = copy.deepcopy(dict(relations=week6_relations, home=week6_home,
            housing=week6_housing, events=week6_events, history=week6_history,
            rita=week6_rita, sea=week6_sea, dates=week6_dates, varya=week6_varya,
            previous=week6_entry, home_day=week6_home_path(), home_night=week6_home_path(True)))
        week7_relations = copy.deepcopy(week6_relations)
        week7_home = copy.deepcopy(week6_home)
        week7_history = copy.deepcopy(week6_history)
        week7_events, week7_party, week7_rita, week7_friends = [], {}, {}, {}
        week7_attachments = []
        week7_outfits = {}
        week7_public, week7_venue = {}, {}
        week7_day, week7_clock, week7_stage = 0, 1080, "monday"
        week7_costume, week7_guest, week7_chat_index = "horns", "", 0
        week7_started, week7_finished = True, False
        for mapping in (phone_reply_log, phone_message_times):
            for key in list(mapping):
                if str(key[0]).startswith("w7_"):
                    del mapping[key]
        for mapping in (phone_media_viewed, phone_voice_ranges, phone_voice_transcripts):
            for key in list(mapping):
                if str(key).startswith(("photo:w7_", "voice:w7_")):
                    del mapping[key]

    def week7_stamp(location, minute, day=None):
        global week7_day, week7_clock, place_name, save_name
        if day is not None:
            week7_day = day
        week7_clock = minute
        place_name = "{} · {}, {}".format(location, ("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")[week7_day], chapter3_time(minute))
        save_name = "Глава 7 · " + place_name

    def week7_event(event, detail="", person=""):
        item = dict(event=event, detail=detail, person=person, day=week7_day, time=week7_clock)
        week7_events.append(item)
        if person in week7_relations:
            relation = week7_relations[person]
            relation.setdefault("events", []).append(copy.deepcopy(item))
            relation.setdefault("facts", {}).setdefault("chapter7", []).append(copy.deepcopy(item))

    def week7_known(person):
        r = week7_relations.get(person, {})
        return bool(r.get("known") and (person in ("nika", "lera", "asya", "marta", "varya") or r.get("facts", {}).get("contact")))

    def week7_friend(person):
        return person == "varya" or week7_relations.get(person, {}).get("mode") == "friendship" or (person == "marta" and week7_entry.get("previous", {}).get("marta", {}).get("next") in ("friendship", "friendship_requested"))

    def week7_careful(person):
        r = week7_relations.get(person, {})
        past = week7_entry.get("previous", {})
        return bool(any(x.get("status") != "resolved" for x in r.get("issues", [])) or (past.get("person") == person and past.get("result") in ("awkward_goodbye", "interrupted_separate")) or (person=="marta" and past.get("marta",{}).get("plan")=="cancelled"))

    def week7_touch_allowed(person):
        r = week7_relations.get(person, {})
        return not week7_friend(person) and not week7_careful(person) and r.get("new_touch") != "space" and not (r.get("previous_touch") == "space" and not r.get("new_touch")) and bool(week7_entry.get("dates", {}).get(person, {}).get("kiss") or r.get("facts", {}).get("kissed_chapter5"))

    def week7_home_path(night=True):
        return week7_entry.get("home_night" if night else "home_day", "images/hotel-night.webp" if night else "images/hotel-morning.webp")

    def week7_dinner():
        dinner = week7_home.get("story", {}).get("dinner", {})
        if not dinner:
            for r in week7_relations.values():
                candidate = r.get("facts", {}).get("housing_dinner", {})
                if candidate.get("agreed") and not candidate.get("played"):
                    dinner = candidate
                    break
        return dinner if dinner.get("agreed") and not dinner.get("played") else {}

    def week7_actor(person):
        return dict(nika=n, lera=l, asya=a, marta=m, varya=v, zhenya=zh, ulya=uly, rita=wr)[person]

    def week7_say(person, text):
        week7_actor(person)(text)

    def week7_party_scene(person=""):
        if person==week7_guest and week7_party.get("guest_departed"):
            person=""
        return "bg w7 party " + week7_costume + (" " + person if person else "")

    def week7_home_scene(person="", costume=False):
        # Staging data are derived from saved state, never written into init dictionaries.
        return "bg w7 home " + (week7_costume if costume else "plain") + (" " + person if person else "")

    week7_girl_costumes = dict(nika="вампирша из старого кино", lera="Дороти", asya="Медуза Горгона", marta="ночной мотылёк", zhenya="пиратский капитан", ulya="цифровое привидение")
    week7_pair_costumes = dict(nika="vampire", lera="scarecrow", ulya="scientist")

    def week7_paired(person):
        outfit = week7_outfits.get(person, {})
        return bool(outfit.get("pair") and outfit.get("pair_costume") == week7_costume)

label week7_chat(person, key, incoming, options):
    $ week7_token = "w7_{}_{}_{}".format(person, key, week7_chat_index)
    $ week7_chat_index += 1
    python:
        for sender, message in incoming:
            if phone_media_item(message) and message not in [x["token"] for x in week7_attachments]:
                week7_attachments.append(dict(token=message,sender=sender,day=week7_day,time=week7_fixed_times.get(message,week7_clock)))
    $ week7_dialogue = week4_phone_dialogue(incoming, options)
    if len(options) == 1:
        $ phone_record_reply(week7_token, "start", options[0][0], [], week7_dialogue)
    call screen phone_thread([], caption=week4_names[person], conversation=week7_token, past=week7_history.get(person, [])[-4:], dialogue=week7_dialogue)
    $ week7_transcript, week7_decisions, week7_pending = phone_conversation_state(week7_token, [], week7_dialogue)
    $ week7_history[person] = week7_history.get(person, []) + week7_transcript
    return week7_decisions[-1][1] if week7_decisions else ""

init 60 python:
    _week7_original_stamp = phone_stamp_messages
    _week7_original_status = phone_status_time
    def phone_stamp_messages(token, messages, caption=None):
        if not str(token).startswith("w7_"):
            return _week7_original_stamp(token, messages, caption)
        if caption is not None:
            phone_thread_contacts[token] = caption
        for index, (sender, message) in enumerate(messages):
            if (token, index) not in phone_message_times:
                sent = week7_fixed_times.get(message, week7_clock)
                phone_message_times[(token, index)] = (sender, message, chapter3_time(sent))

    def phone_status_time(index, token):
        if str(token).startswith("w7_"):
            return chapter3_time(week7_clock)
        return _week7_original_status(index, token)
