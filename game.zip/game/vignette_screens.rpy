style vignette_button is button:
    background Frame("images/gimmicks/vignettes/button.svg", 12, 12)
    hover_background Frame("images/gimmicks/vignettes/button-hover.svg", 12, 12)
    selected_background Solid("#52606a")
    insensitive_background Solid("#23363e")
    padding (18, 12)
style vignette_button_text is button_text:
    size 23
    color "#f3e9d9"
    hover_color "#ffffff"
    selected_color "#ffffff"
    insensitive_color "#657c80"
style vignette_small is vignette_button
style vignette_small_text is vignette_button_text:
    size 19

screen vignette_system():
    use minigame_system(vignette_state["kind"],stop_vignette=True)
    key "game_menu" action [Function(vignette_pump, False), Function(vignette_clear_trace), ShowMenu()]
    key "rollback" action Rollback()

screen vignette_board():
    modal True
    zorder 80
    $ s = vignette_state
    $ kind = s["kind"]
    $ solo_riff = s.get("context") in ("solo_recording", "solo_practice")
    $ skin = mini_skins[kind]
    $ accent = skin["accent"]
    add mini_surface(kind,"backdrop") xysize (1600,900)
    add mini_surface(kind,"score") xpos 1090 ypos 25 xysize (455,105)
    text ("Олег · гитара для себя" if s.get("context") == "solo_practice" else "Олег · запись для Ники" if solo_riff else vignette_titles[kind][1]) xpos 60 ypos 42 size 19 color skin["title"] kerning 2
    text vignette_titles[kind][0] xpos 58 ypos 78 size 43 bold True color skin["title"]
    if kind in ("balloons", "shadow"):
        text ("ДВА ШАРА РЯДОМ" if kind == "balloons" else "ТРИ ЖЕСТА ДЛЯ РОЛИКА") xpos 1110 ypos 72 size 23 color skin["ink"]
    else:
        text skin["label"] xpos 1110 ypos 38 size 15 color skin["muted"] kerning 2
        text ("%05d" % s["score"]) xpos 1106 ypos 69 size 54 color skin["ink"]
        text ("РЕКОРД  %d" % vignette_best(kind)) xpos 1370 ypos 94 size 16 color skin["muted"]
        if s["last_gain"] > 0:
            text ("+%d" % s["last_gain"]) xpos 1370 ypos 57 size 25 color accent at vignette_score_pop(s["feedback_id"])
    add Solid(accent) xpos 55 ypos 145 xysize (1490, 2)
    frame:
        xpos 55 ypos 168 xysize (1020, 650) padding (25, 20) background mini_surface(kind,"stage")
        viewport:
            xysize (960, 610)
            mousewheel False draggable False
            fixed:
                xysize (960, 610)
                if kind == "photo":
                    use vignette_photo(s)
                elif kind == "riff":
                    use vignette_riff(s)
                elif kind == "studio":
                    use vignette_studio(s)
                elif kind == "hum":
                    use vignette_hum_panel(s)
                elif kind == "laundry":
                    use vignette_laundry(s)
                elif kind == "box":
                    use vignette_box(s)
                elif kind == "shadow":
                    use vignette_shadow(s)
                else:
                    use vignette_balloons(s)
                if kind in ("photo", "shadow", "studio", "hum", "laundry", "riff"):
                    add vignette_motion_layer
    frame:
        xpos 1110 ypos 168 xysize (435, 650) padding (28, 25) background mini_surface(kind)
        vbox:
            spacing (10 if kind == "laundry" else 18)
            text vignette_next_action(s) size 16 color skin["ink"] kerning .5
            bar value StaticValue(vignette_progress(s), 1.0) xysize (375, 5) left_bar Solid(accent) right_bar Solid(skin["edge"]) thumb None
            text ("ДУБЛЬ %d / 3" % (s["rounds"] + 1) if kind in ("photo", "shadow") else "ПРОБА %d / 3" % (s["attempts"] + 1) if kind == "hum" else {"riff": "ДВЕ ФРАЗЫ · НА СЛУХ", "studio": "7 ПРЕДМЕТОВ · ПОЛЕ 4×4", "laundry": "МЕСТО · ВОЗДУХ · РАВНОВЕСИЕ", "box": "180 МЕТРОВ ДО ТЕАТРА", "balloons": "ДВА ШАРА · 16 СЕКУНД"}[kind]) size 18 color accent kerning 2
            if kind == "photo":
                text vignette_photo_targets[s["rounds"]][3] size 24 color skin["ink"] line_spacing 3
            elif kind == "shadow":
                text ("Нарисуй %s одним движением." % ("волну", "рыбу", "ладонь")[s["rounds"]]) size 24 color skin["ink"]
            else:
                text vignette_brief_instructions(kind) size 21 color skin["ink"] line_spacing 3
            textbutton "Как играть · подробнее":
                id "vignette_help_button"
                action ShowMenu("vignette_help")
                properties mini_button(kind,small=True)
            $ placement_problem = vignette_laundry_problem(s, s["selected"], *divmod(s["cursor"], vignette_laundry_columns)) if kind == "laundry" else ""
            text (placement_problem or s["note"]) size 20 color accent line_spacing 3
            if kind == "laundry":
                $ moment = vignette_laundry_balance(s)
                text ("РАВНОВЕСИЕ · " + ("ровно" if abs(moment) <= 3 else "допустимо" if abs(moment) <= 10 else "перевес справа" if moment > 0 else "перевес слева")) size 17 color accent
                fixed:
                    xysize (365, 28)
                    add Solid("#354b52") ypos 8 xysize (365, 12)
                    add Solid("#93b491") xpos 137 ypos 8 xysize (91, 12)
                    add Solid("#f2ce88") xpos int(178 + max(-1, min(1, moment / 40.0)) * 175) xysize (8, 28)
                text ("Сложено %d · На сушилке %d / %d" % (sum(s["folded"]), len(s["places"]), vignette_laundry_count)) size 18 color accent
                text ("✓ Можно проверить сушилку" if len(s["places"]) == vignette_laundry_count and abs(moment) <= 10 else "Тяжёлые вещи сдвигай к лёгкому краю." if abs(moment) > 10 else "Осталось разместить вещи из корзины.") size 18 color accent
            if s["combo"] >= 2 and kind not in ("balloons", "shadow"):
                text ("СЕРИЯ %d  ·  ×%g" % (s["combo"], 1 + min(4, s["combo"] - 1) * .25)) size 22 color accent
        vbox:
            ypos 500 spacing 12 xfill True
            if kind == "photo":
                textbutton vignette_titles[kind][2] properties mini_button(kind) action Return(("capture", None)) xfill True
            elif kind in ("riff", "box", "balloons") and not s["running"]:
                textbutton ("Послушать запись" if solo_riff else vignette_titles[kind][2]) properties mini_button(kind) action Return(("start", None)) xfill True
            elif kind == "laundry":
                textbutton "Проверить сушилку" properties mini_button(kind) sensitive len(s["places"]) == vignette_laundry_count action Return(("laundry_finish", None)) xfill True
            elif kind == "hum":
                textbutton "Послушать" properties mini_button(kind) action Return(("listen", None)) xfill True
            textbutton ("Отложить гитару" if s.get("context") == "solo_practice" else "Перейти к записи" if solo_riff else vignette_titles[kind][3]) properties mini_button(kind,small=True) action Return(("skip", None)) xfill True
    if s["running"] and kind in ("riff", "box", "balloons"):
        # A restored game may need its images again. Loading overlays must
        # suspend this clock just like the separate save/help menu context.
        timer .05 repeat True modal True action Function(vignette_tick)
    if getattr(store, "_qa_gimmick_auto", False):
        timer .01 action Return(("skip", None))
    use vignette_system

screen vignette_photo(s):
    $ kind = "photo"
    add city_background(vignette_art("courtyard-board"), (960, 560))
    text "ОФИС" xpos 696 ypos 99 size 25 color "#4b534b"
    text "ДВОР · ПЕРВАЯ ЛИНИЯ" xpos 40 ypos 506 size 19 color "#fff0d4" outlines [(2, "#393529", 0, 0)]
    $ w, h = int(410 / s["zoom"]), int(286 / s["zoom"])
    draggroup:
        drag:
            drag_name "camera"
            xpos int(s["x"] - w / 2) ypos int(s["y"] - h / 2)
            draggable True droppable False drag_offscreen True
            dragged vignette_drag_position
            fixed:
                xysize (w, h)
                add Transform("images/gimmicks/vignettes/viewfinder.svg", xysize=(w, h), rotate=s["angle"], rotate_pad=False) xalign .5 yalign .5
    hbox:
        xpos 8 ypos 562 spacing 12
        for caption, act in [("−", ("zoom", -.1)), ("+", ("zoom", .1)), ("Q · наклон", ("angle", -2)), ("E · наклон", ("angle", 2))]:
            textbutton caption properties mini_button(kind,small=True) action Return(act)
        text ("  %d снимка" % s["rounds"]) yalign .5 size 22 color mini_skins[kind]["title"]
    key "K_LEFT" action Return(("move", (-30, 0)))
    key "K_RIGHT" action Return(("move", (30, 0)))
    key "K_UP" action Return(("move", (0, -25)))
    key "K_DOWN" action Return(("move", (0, 25)))
    key "+" action Return(("zoom", .1))
    key "=" action Return(("zoom", .1))
    key "-" action Return(("zoom", -.1))
    key "q" action Return(("angle", -2))
    key "e" action Return(("angle", 2))
    key "K_SPACE" action Return(("capture", None))

screen vignette_riff(s):
    $ kind = "riff"
    add vignette_art("riff-board") xysize (960, 560)
    add Solid("#11222b99") xysize (960, 130)
    $ phase = s["riff_phase"]
    $ phrase = vignette_riff_phrases[s["rounds"]]
    $ current = min(len(phrase) - 1, s["play_ticks"] // 12)
    text (("СТАРАЯ ЗАПИСЬ" if s.get("context") in ("solo_recording", "solo_practice") else "НИКА ИГРАЕТ") if phase == "listen" else "ТВОЯ ОЧЕРЕДЬ" if phase == "repeat" else "ПОСЛУШАЙ ФРАЗУ %d / 2" % (s["rounds"] + 1)) xpos 55 ypos 40 size 28 color "#eedec3"
    text "Запомни порядок нот. Повторять можно в любом темпе." xpos 55 ypos 92 size 23 color "#b9c9cc"
    for lane, caption in enumerate(("МИ", "ЛЯ")):
        $ lit = phase == "listen" and phrase[current] == lane and s["play_ticks"] % 12 < 8
        frame:
            xpos 55 ypos (180 + lane * 130) xysize (285, 100) padding (24, 20)
            background mini_surface("riff",active=lit)
            hbox:
                spacing 30
                add ("images/gimmicks/vignettes/note-%d.svg" % lane) xysize (56, 56)
                text caption size 40 color "#fff0d7" yalign .5
                text ("●" if lit else "") size 40 color "#ffdf99" yalign .5
    hbox:
        xpos 55 ypos 462 spacing 16
        for i in range(len(phrase)):
            frame:
                xysize (62, 56) padding (0, 0)
                background mini_surface("riff","button" if i < len(s["phrase_input"]) else "panel")
                text (("МИ" if s["phrase_input"][i] == 0 else "ЛЯ") if i < len(s["phrase_input"]) else "·") xalign .5 yalign .5 size 22 color ("#251d20" if i < len(s["phrase_input"]) else "#b2acb7")
    hbox:
        xpos 80 ypos 550 spacing 30
        textbutton "A / ← · ми" properties mini_button(kind) xsize 375 sensitive phase == "repeat" action Function(vignette_live_action, "pluck", 0)
        textbutton "D / → · ля" properties mini_button(kind) xsize 375 sensitive phase == "repeat" action Function(vignette_live_action, "pluck", 1)
    if phase == "repeat":
        key "a" action Function(vignette_live_action, "pluck", 0)
        key "K_LEFT" action Function(vignette_live_action, "pluck", 0)
        key "d" action Function(vignette_live_action, "pluck", 1)
        key "K_RIGHT" action Function(vignette_live_action, "pluck", 1)

screen vignette_studio(s):
    $ kind = "studio"
    add vignette_art("plan-board") xysize (960, 560)
    for row in range(4):
        for col in range(4):
            add Solid("#f5e8ce33" if (row + col) % 2 else "#172c3922") xpos (58 + col * 116) ypos (58 + row * 116) xysize (114, 114)
    text "ОКНО / РАБОЧЕЕ МЕСТО" xpos 145 ypos 16 size 18 color "#374743" kerning 1
    draggroup:
        for item, (cx, cy) in enumerate(s["layout"]):
            $ title, w, h, colour, art = vignette_furniture[item]
            $ prior = s["layouts"][-1][item] if s["layouts"] else (cx, cy)
            drag:
                drag_name str(item)
                xpos (58 + cx * 116) ypos (58 + cy * 116)
                draggable True droppable False dragged vignette_furniture_dragged
                clicked Return(("furniture", item))
                fixed:
                    at vignette_piece_settle((prior[0] - cx) * 116, (prior[1] - cy) * 116)
                    xysize (w * 116 - 6, h * 116 - 6)
                    if s["selected"] == item:
                        add Solid("#f9df98") xysize (w * 116 - 6, 4)
                        add Solid("#f9df98") ypos (h * 116 - 10) xysize (w * 116 - 6, 4)
                        add Solid("#f9df98") xysize (4, h * 116 - 6)
                        add Solid("#f9df98") xpos (w * 116 - 10) xysize (4, h * 116 - 6)
                    add vignette_prop("furniture-" + art, w * 116 - 12, h * 116 - 12) xalign .5 yalign .5
                    text str(item + 1) xpos 12 ypos 9 size 20 color "#fff2dc" outlines [(2, "#26393c", 0, 0)]
                    text title xalign .5 yalign .88 size (16 if w == 1 else 19) color "#fff2dc" outlines [(2, "#26393c", 0, 0)]
    text "ХОЧУ, ЧТОБЫ БЫЛО ТАК" xpos 600 ypos 64 size 18 color "#534431"
    # Match the plan's cell boundaries to the playable floor, including blanks.
    for row in range(4):
        for col in range(4):
            fixed:
                xpos (608 + col * 72) ypos (108 + row * 72) xysize (72, 72)
                add Solid("#695c4430") xysize (72, 1)
                add Solid("#695c4430") xysize (1, 72)
                add Solid("#695c4430") ypos 71 xysize (72, 1)
                add Solid("#695c4430") xpos 71 xysize (1, 72)
    for item, (gx, gy) in enumerate(vignette_studio_goal):
        $ title, w, h, colour, art = vignette_furniture[item]
        fixed:
            xpos (608 + gx * 72) ypos (108 + gy * 72) xysize (w * 72 - 4, h * 72 - 4)
            add vignette_prop("furniture-" + art, w * 72 - 8, h * 72 - 8) xalign .5 yalign .5
            text str(item + 1) xpos 4 ypos 4 size 20 color "#fff2dc" outlines [(2, "#26393c", 0, 0)]
    text ("%d / 7 на месте" % vignette_studio_matches(s)) xpos 600 ypos 418 size 26 color "#46513e"
    text ("Ходов: %d · за точный план +700\nМеньше ходов — больше бонус" % s["moves"]) xpos 600 ypos 463 size 18 color "#625745" line_spacing 6
    hbox:
        xpos 58 ypos 548 spacing 12
        for caption, delta in [("←", (-1, 0)), ("↑", (0, -1)), ("↓", (0, 1)), ("→", (1, 0))]:
            textbutton caption properties mini_button(kind) sensitive vignette_studio_can(s["layout"], s["selected"], delta) action Return(("slide", (s["selected"], delta)))
        textbutton "Отменить ход" properties mini_button(kind,small=True) sensitive bool(s["layouts"]) action Return(("undo", None))
        textbutton "Сначала" properties mini_button(kind,small=True) action Return(("reset", None))
    for sym, delta in [("K_LEFT", (-1, 0)), ("K_RIGHT", (1, 0)), ("K_UP", (0, -1)), ("K_DOWN", (0, 1))]:
        key sym action Return(("slide", (s["selected"], delta)))
    for item in range(7):
        key str(item + 1) action Return(("furniture", item))

screen vignette_hum_panel(s):
    $ kind = "hum"
    add vignette_art("mixer-board") xysize (960, 560)
    for i, caption in enumerate(("МИКРОФОН", "ЛИНЕЙНЫЙ", "ВЫХОД")):
        button:
            xpos (158 + i * 244) ypos 76 xysize (175, 116)
            background Solid("#00000000") hover_background Solid("#f9d39322") padding (0, 0)
            action Return(("source", i))
            text caption size 18 xalign .5 yalign 1.0 color ("#ffdc98" if s["source"] == i else "#ced5cf") outlines [(2, "#13232b", 0, 0)]
            if s["source"] == i:
                text "●" xpos 135 ypos 10 size 22 color "#cce5a3"
    text "МУЗЫКА" xpos 85 ypos 214 size 20 color "#efc99c"
    bar value DictValue(s, "level", 100) xpos 268 ypos 214 xysize (556, 24) left_bar Solid("#dfa36e77") right_bar Solid("#00000000") thumb MiniFader() thumb_offset 8
    text "ВОЗВРАТ" xpos 85 ypos 287 size 20 color "#efc99c"
    bar value DictValue(s, "feedback", 100) xpos 268 ypos 287 xysize (556, 24) left_bar Solid("#a9bdd177") right_bar Solid("#00000000") thumb MiniFader() thumb_offset 8
    $ noise, music = vignette_hum(s)
    for i in range(50):
        $ height = int(8 + noise * (25 + (i * 37 % 70)))
        add Solid("#dc986e") xpos (100 + i * 15) ypos (425 - height // 2) xysize (6, height)
    text ("Кабель: " + ("микрофонный вход" if s["source"] == 0 else "линейный вход" if s["source"] == 1 else "выход — сигнал возвращается в себя")) xpos 80 ypos 568 size 20 color mini_skins[kind]["title"]
    text "ЦЕЛЬ: МУЗЫКА СЛЫШНА, ГУЛ НА МИНИМУМЕ" xpos 80 ypos 24 size 18 color "#cfdbbf"
    text ("Гул  %d%%" % round(noise * 100)) xpos 100 ypos 474 size 20 color ("#cbd9a7" if noise < .15 else "#e7a27b")
    text ("Музыка  %d%%" % round(music * 100)) xpos 620 ypos 474 size 20 color "#ddcba2"
    key "1" action Return(("source", 0))
    key "2" action Return(("source", 1))
    key "3" action Return(("source", 2))
    key "K_SPACE" action Return(("listen", None))

screen vignette_laundry(s):
    $ kind = "laundry"
    add vignette_art("laundry-board") xysize (960, 560)
    $ cell_w = vignette_laundry_cell_size
    $ row, col = divmod(s["cursor"], vignette_laundry_columns)
    $ selected = s["selected"]
    $ sw = vignette_laundry_width(s, selected)
    $ valid = vignette_laundry_can(s, selected, row, col)
    for r in range(2):
        for c in range(vignette_laundry_limits[r]):
            $ cell = vignette_laundry_cell(s, r, c)
            $ start_ok = vignette_laundry_can(s, selected, r, c)
            fixed:
                xpos (35 + c * cell_w) ypos (15 + r * 180) xysize (cell_w - 2, 164)
                add Solid("#5babc15c" if cell == "air" else "#17293266" if cell == "shirt" else "#84c18a38" if start_ok else "#132b3440")
                add Solid("#e7e3ceaa") xysize (cell_w - 2, 2)
                add Solid("#e7e3ceaa") ypos 162 xysize (cell_w - 2, 2)
                add Solid("#e7e3ceaa") xysize (2, 164)
                add Solid("#e7e3ceaa") xpos (cell_w - 4) xysize (2, 164)
                if c == col and r == row:
                    text str(c + 1) xpos 6 ypos 4 size 16 color "#fff2d4" outlines [(2, "#152730", 0, 0)]
                if cell == "air":
                    text "ВОЗ-\nДУХ" xalign .5 ypos 66 size 11 text_align .5 color "#d1f0f5" outlines [(2, "#244650", 0, 0)]
                elif cell == "free" and start_ok:
                    text "●" xalign .5 ypos 136 size 18 color "#a1e2ab" outlines [(2, "#15392c", 0, 0)]
                elif cell == "free":
                    text "·" xalign .5 ypos 74 size 18 color "#f0e2c4" outlines [(2, "#35444b", 0, 0)]
    $ footprint = max(1, min(sw, vignette_laundry_limits[row] - col)) * cell_w - 2
    $ mark = "#a4efac" if valid else "#ef9c84"
    add Solid("#bad6a92c" if valid else "#d6877333") xpos (35 + col * cell_w) ypos (15 + row * 180) xysize (footprint, 164)
    add Solid(mark) xpos (35 + col * cell_w) ypos (15 + row * 180) xysize (footprint, 4)
    add Solid(mark) xpos (35 + col * cell_w) ypos (175 + row * 180) xysize (footprint, 4)
    add Solid(mark) xpos (35 + col * cell_w) ypos (15 + row * 180) xysize (4, 164)
    add Solid(mark) xpos (31 + col * cell_w + footprint) ypos (15 + row * 180) xysize (4, 164)
    text "ПОЛОТЕНЦА\nНЕ ТРОГАЕМ" xpos 710 ypos 60 size 19 color "#fff0d4" outlines [(2, "#544737", 0, 0)]
    text "ПОЛОТЕНЦА" xpos 645 ypos 250 size 19 color "#fff0d4" outlines [(2, "#544737", 0, 0)]
    draggroup:
        drag:
            drag_name "basket"
            xpos 10 ypos 425 xysize (940, 115) draggable False droppable True
            add Solid("#00000000")
        for r in range(2):
            for c in range(vignette_laundry_limits[r]):
                drag:
                    drag_name ("%d:%d" % (r, c))
                    xpos (35 + c * cell_w) ypos (15 + r * 180) xysize (cell_w - 1, 164)
                    draggable False droppable True
                    clicked Return(("hang", (selected, r, c)))
                    hovered SetDict(s, "cursor", r * vignette_laundry_columns + c)
                    add Solid("#ffffff00")
        for item in range(vignette_laundry_count):
            $ place = s["places"].get(item)
            $ width = vignette_laundry_width(s, item) * cell_w - 6 if place else 82
            $ sx, sy = vignette_laundry_position(s, item)
            drag:
                drag_name str(item)
                xpos sx ypos sy
                draggable True droppable False dragged vignette_drop_laundry
                clicked Return(("laundry_select", item))
                fixed:
                    xysize (width, 148 if place else 110)
                    if place:
                        add Solid("#213b4b88")
                        add Solid("#c8d5dbaa") xysize (width, 3)
                        add Solid("#c8d5dbaa") ypos 145 xysize (width, 3)
                        add Solid("#c8d5dbaa") xysize (3, 148)
                        add Solid("#c8d5dbaa") xpos (width - 3) xysize (3, 148)
                    if item == selected:
                        add Solid("#f6d48744")
                    add vignette_prop(vignette_laundry_asset(s, item), width, 110 if place else 88) xalign .5 ypos (12 if place and vignette_laundry_types[item] == "sock" else 0)
                    if place:
                        for pin_x in ((.5,) if vignette_laundry_types[item] == "sock" else (.3, .7)):
                            $ pin_w, pin_h = (8, 20) if vignette_laundry_types[item] == "sock" else (14, 34)
                            add vignette_prop("clothespin", pin_w, pin_h) xpos int(width * pin_x - pin_w / 2) ypos 0
                        text ("№%d" % (item + 1) if vignette_laundry_width(s, item) == 1 else "№%d · %d кл." % (item + 1, vignette_laundry_width(s, item))) xalign .5 ypos 110 size 12 color "#fff0d4" outlines [(2, "#162a33", 0, 0)]
                    text ("●" * vignette_laundry_weights[item] if place else "%d · %s" % (item + 1, "●" * vignette_laundry_weights[item])) xalign .5 ypos (129 if place else 86) size (14 if place else 11) color "#fff0d4" outlines [(2, "#302d26", 0, 0)]
    text "ЗЕЛЁНАЯ ТОЧКА — МОЖНО ПОВЕСИТЬ С ЭТОЙ КЛЕТКИ" xpos 35 ypos 366 size 18 color "#e4f4d7" outlines [(2, "#24332b", 0, 0)]
    hbox:
        xpos 30 ypos 552 spacing 14
        text ("№%d · %d кл." % (selected + 1, sw)) yalign .5 size 21 color mini_skins[kind]["ink"]
        textbutton (("R · расправить" if s["folded"][selected] else "R · сложить вдвое") if vignette_laundry_types[selected] == "shirt" else "Носок" if vignette_laundry_types[selected] == "sock" else "Трусы") properties mini_button(kind,small=True) sensitive vignette_laundry_types[selected] == "shirt" action Return(("fold", None))
        textbutton "В корзину" properties mini_button(kind,small=True) action Return(("unhang", None))
        text ("%d / %d на сушилке" % (len(s["places"]), vignette_laundry_count)) yalign .5 size 21 color mini_skins[kind]["ink"]
    for item in range(vignette_laundry_count):
        key str((item + 1) % 10) action Return(("laundry_select", item))
    for sym, delta in [("K_LEFT", (-1, 0)), ("K_RIGHT", (1, 0)), ("K_UP", (0, -1)), ("K_DOWN", (0, 1))]:
        key sym action Return(("laundry_cursor", delta))
    key "r" action Return(("fold", None))
    key "K_SPACE" action Return(("hang", (selected, row, col)))

screen vignette_box(s):
    $ kind = "box"
    add city_background("images/week4/courtyard-rain-v1.webp", (960, 560))
    add Solid("#415b58") xpos 150 ypos 455 xysize (660, 18)
    add Solid("#8daa83") xpos 330 ypos 455 xysize (300, 18)
    add vignette_motion_layer
    add mini_surface("box","stage") ypos 505 xysize (960,105)
    hbox:
        xpos 180 ypos 515 spacing 30
        textbutton "← · перехватить слева" properties mini_button(kind) action Function(vignette_live_action, "steady", -1) sensitive s["running"]
        textbutton "Перехватить справа · →" properties mini_button(kind) action Function(vignette_live_action, "steady", 1) sensitive s["running"]
    text ("До театра: %d м" % max(0, int(180 - s["ticks"] * .5))) xpos 350 ypos 584 size 21 color mini_skins[kind]["ink"]
    key "K_LEFT" action Function(vignette_live_action, "steady", -1)
    key "K_RIGHT" action Function(vignette_live_action, "steady", 1)

screen vignette_shadow(s):
    $ kind = "shadow"
    add city_background(vignette_art("sea-board"), (960, 560))
    text vignette_shadow_paths[s["rounds"]][0] xpos 40 ypos 28 size 28 color "#f0e3c1" kerning 2
    add vignette_trace_layer
    text "Зажми мышь у золотой точки → обведи → отпусти у кольца" xpos 40 ypos 568 size 21 color mini_skins[kind]["ink"]

screen vignette_balloons(s):
    $ kind = "balloons"
    add city_background(vignette_art("night-board"), (960, 560))
    add vignette_motion_layer
    text ("Ветер стихает" if s["ticks"] > 270 else "Не обязательно одинаково. Можно рядом.") xpos 110 ypos 28 size 24 color "#e9c9d2"
    if s["running"]:
        button:
            xpos 250 ypos 535 xysize (460, 65) properties mini_button(kind)
            action NullAction()
            text ("Отпусти · дай остыть" if s["pump"] else "Держи пробел или мышь") xalign .5 yalign .5 size 24 color mini_skins[kind]["button_ink"]
        key "K_SPACE" action Function(vignette_pump, True)
        key "keyup_K_SPACE" action Function(vignette_pump, False)
        key "mousedown_1" action Function(vignette_pump, True)
        key "mouseup_1" action Function(vignette_pump, False)

screen vignette_done():
    modal True
    zorder 90
    $ kind = vignette_state["kind"]
    $ skin = mini_skins[kind]
    add mini_surface(kind,"backdrop") xysize (1600,900)
    frame:
        xalign .5 yalign .5 xsize 1100 padding (50,45) background mini_surface(kind,"result")
        vbox:
            spacing 22 xfill True
            text ("ТРИ ЖЕСТА" if kind == "shadow" else "ВДВОЁМ" if kind == "balloons" else skin["label"]) xalign .5 size 17 kerning 3 color skin["muted"]
            text vignette_summary(vignette_state) xalign .5 text_align .5 size 39 color skin["ink"]
            if vignette_state["result"] != "skipped" and kind not in ("balloons", "shadow"):
                text ("%d очков" % vignette_state["score"]) xalign .5 size (30 if kind == "balloons" else 54) bold True color skin["accent"]
                if vignette_state.get("new_record") and kind != "balloons":
                    text "НОВЫЙ РЕКОРД" xalign .5 size 20 color skin["accent"] kerning 3
                if kind != "balloons":
                    text ("Лучшая серия: %d" % vignette_state["best_combo"] if vignette_state["best_combo"] > 1 else "Рекорд сохранён для следующей попытки") xalign .5 size 21 color skin["muted"]
    timer (0.01 if getattr(store, "_qa_gimmick_auto", False) else .9 if vignette_state["kind"] == "balloons" else 2.0) action Return()

# A menu context suspends the timed board while the player reads.
screen vignette_help():
    tag menu
    $ kind = vignette_state["kind"]
    use menu_shell("Как играть"):
        vbox:
            xpos 100 ypos 180 xsize 1280 spacing 30
            text vignette_titles[kind][0] size 30 color "#e4c698"
            text vignette_instructions[kind] size story_text_size() xmaximum 1200 line_spacing 8
            if kind == "laundry":
                text "Выбери вещь в корзине, затем зелёную точку на сушилке. Точки уже учитывают размер вещи и промежутки. Кружки под вещью показывают её вес. Если сушилка наклоняется, перенеси тяжёлую вещь к лёгкому краю." size story_text_size(24) xmaximum 1200 line_spacing 6
            text "Можно вернуться к сцене без высокого результата. Отношения не зависят от рекорда." size 23 color "#b5c0c5" xmaximum 1200
            textbutton "Вернуться к игре →" id "vignette_help_close" action Return()
