label week4_laundry_monday:
    "Чистых чёрных футболок осталось две. Олег пересчитывает: в стопке грязного «Берсерка» уже численное преимущество."
    if week4_home["kind"] == "new" and housing_home == "studio":
        "Машинка в общей прихожей свободна после шести. Олег сверяется с расписанием и записывает себя на вечер. Сушилка хранится за его диваном."
        menu:
            "Займу вечер. Сам развешу, пока дома.":
                $ week4_laundry.update(method="shared", status="dirty", where="home", washer=True)
            "В этот раз сдам в отель. Не хочу подстраивать день.":
                $ week4_laundry.update(method="hotel", status="washing", where="hotel", **{"return":"tuesday"})
                "Олег уточняет у знакомого администратора приём вещей, относит пакет и забирает квитанцию. В квартире оставляет две чистые футболки."
    elif week4_home["kind"] != "hotel":
        "В ванной есть машинка. Он проверяет карманы, выворачивает футболки принтом внутрь и ищет короткий режим."
        $ week4_laundry.update(method="own", status="drying", where="home", washer=True)
        "Машинка начинает крутить футболки. Олег ставит таймер на обед: тогда и развесит."
    else:
        reception "Пакет сдайте до десяти, завтра вечером вернём. Список и цену я вам распечатала."
        menu:
            "Оплачу. Сейчас это дешевле, чем ещё одно дело в голове.":
                $ week4_laundry.update(method="hotel", status="washing", where="hotel", **{"return":"tuesday"})
                "Он относит пакет и забирает квитанцию. Одну чистую футболку оставляет на завтра."
            "Пока заберу список. Может, у знакомых попрошу машинку.":
                $ week4_laundry["method"] = "pending"
                "Пакет остаётся у шкафа. В гости с ним Олег пока ни к кому не договаривался."
    return

label week4_laundry_midweek:
    if week4_laundry["method"] == "hotel":
        "Чистое бельё он забрал ещё во вторник. В пакете футболки сложены так ровно, что первую даже жалко доставать."
        $ week4_laundry.update(status="clean", where="home")
    elif week4_laundry["method"] == "shared":
        "В понедельник после работы Олег успел занять машинку. Теперь снимает с сушилки сухие футболки и складывает её, освобождая проход."
        $ week4_laundry.update(status="clean", where="home")
    elif week4_laundry["method"] == "own":
        if week4_laundry["status"] == "dirty":
            "После работы он наконец запускает машинку. На завтра остаётся последняя чистая футболка."
            $ week4_laundry["status"] = "drying"
        else:
            "На сушилке всё высохло, кроме толстого ворота одной футболки. Олег перевешивает её. Остальные убирает в шкаф; на стуле впервые за неделю можно сесть."
            $ week4_laundry["status"] = "clean"
    elif week4_plan == "lera" and week4_plan_status == "confirmed" and not week4_unresolved("lera", True):
        call week4_chat("lera", "washer", [], [("ask", "У меня бытовой вопрос. В отеле стирка как маленький ужин. Можно в четверг у тебя одну машинку запустить? Сам всё сделаю.", [("Лера", "Можно. Соседка до семи закончит. Только у нас не сушильная, мокрое придётся оставить."), ("Лера", "Заберёшь в пятницу после работы. Напиши перед выходом.")]), ("hotel", "Я сейчас сдавал футболки в стирку и вспомнил, что мы поесть собирались. В семь на месте.", [("Лера", "Давай. Мне как раз оплатили остаток. Будет ужин без злобы.")])])
        if _return == "ask":
            $ week4_laundry.update(method="lera", where="home", **{"return":"friday"})
            $ week4_relations["lera"]["promises"].append("Забрать сухие вещи в пятницу после работы, предварительно написать")
        else:
            $ week4_laundry.update(method="hotel", status="washing", where="hotel", **{"return":"thursday"})
    elif week4_laundry["method"] == "pending":
        "Просить машинку в первом же сообщении никому не хочется. Олег сдаёт вещи в отеле; обещают вернуть завтра после шести."
        $ week4_laundry.update(method="hotel", status="washing", where="hotel", **{"return":"thursday"})
    return
