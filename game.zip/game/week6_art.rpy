image bg w6 snow courtyard = Transform("images/week6/snow-courtyard-v2.webp", xysize=(1600, 900))
image bg w6 thai shirt = Transform("images/week6/thai-shirt-v1.webp", xysize=(1600, 900))
image bg w6 snow courtyard night = Transform("images/week6/snow-courtyard-night-v1.webp", xysize=(1600, 900))
image bg w6 courtyard asya = Transform("images/week6/snow-courtyard-night-v1.webp", xysize=(1600, 900))
image bg w6 exhibition asya = Transform("images/week6/exhibition-hammock-v3.webp", xysize=(1600, 900))
image bg w6 housing entry = Transform("images/week6/modern-day-v1.webp", xysize=(1600, 900))
image bg w6 housing modern = Transform("images/week6/modern-day-v1.webp", xysize=(1600, 900))
image bg w6 housing controls = Transform(Transform("images/week6/modern-day-v1.webp", xysize=(1600, 900)), crop=(650, 60, 900, 506), xysize=(1600, 900))
image bg w6 housing window = Transform(Transform("images/week6/modern-day-open-v1.webp", xysize=(1600, 900)), crop=(460, 0, 1067, 600), xysize=(1600, 900))

image bg w6 exhibition empty = Transform("images/week6/exhibition-hammock-v3.webp", xysize=(1600, 900))
image bg w6 exhibition ulya = Transform("images/week6/exhibition-hammock-v3.webp", xysize=(1600, 900))
image bg w6 exhibition group = Transform("images/week6/exhibition-hammock-v3.webp", xysize=(1600, 900))
image bg w6 venue empty = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue varya = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue varya asya = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue zhenya = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue zhenya nika = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue zhenya lera = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue zhenya asya = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 venue zhenya marta = Transform("images/week6/venue-night-v1.webp", xysize=(1600, 900))
image bg w6 rehearsal = Transform("images/week6/rehearsal-pair-v1.webp", xysize=(1600, 900))
image bg w6 concert pair = Transform("images/week6/concert-pair-v1.webp", xysize=(1600, 900))
image bg w6 concert solo = Transform("images/week6/concert-solo-v1.webp", xysize=(1600, 900))
image bg w6 sea detail = Transform(Transform("images/week6/exhibition-hammock-v3.webp", xysize=(1600, 900)), crop=(529, 117, 650, 366), xysize=(1600, 900))

init -9 python:
    cast_assets[("zhenya", "indoor")] = {"neutral":"images/week6/zhenya-neutral-v1.webp", "amused":"images/week6/zhenya-laugh-v1.webp"}
    cast_assets[("ulya", "indoor")] = {"neutral":"images/week6/ulya-neutral-left-v2.webp", "amused":"images/week6/ulya-laugh-left-v2.webp"}
    cast_stages["w6 exhibition ulya"] = ("images/week6/exhibition-hammock-v3.webp", [("oleg", "indoor", 360, 40, 950), ("ulya", "indoor", 1250, 40, 1050)], None, "windowday")
    cast_stages["w6 exhibition group"] = ("images/week6/exhibition-hammock-v3.webp", [("oleg", "indoor", 280, 40, 950), ("ulya", "indoor", 780, 40, 1050), ("asya", "", 1300, 40, 950)], None, "windowday")
    cast_stages["w6 venue varya"] = ("images/week6/venue-night-v1.webp", [("oleg", "indoor", 360, 50, 950), ("varya", "weekend", 1240, 50, 950)], None, "evening")
    cast_stages["w6 venue varya asya"] = ("images/week6/venue-night-v1.webp", [("oleg", "indoor", 270, 50, 950), ("varya", "weekend", 780, 50, 950), ("asya", "", 1300, 50, 950)], None, "evening")
    cast_stages["w6 venue zhenya"] = ("images/week6/venue-night-v1.webp", [("oleg", "indoor", 360, 50, 950), ("zhenya", "indoor", 1230, 20, 1200)], None, "evening")
    for person, wardrobe, height in [("nika", "standing", 950), ("lera", "indoor", 950), ("asya", "", 950), ("marta", "bookshop", 1280)]:
        cast_stages["w6 venue zhenya " + person] = ("images/week6/venue-night-v1.webp", [("oleg", "indoor", 270, 50, 950), (person, wardrobe, 780 if person == "marta" else 1300, 50, height), ("zhenya", "indoor", 1280 if person == "marta" else 780, 20, 1200)], None, "evening")
    cast_cues.update({("ulya", "Оно на удалёнке."):"amused", ("ulya", "Ванна. Хорошее море стоит денег."):"amused", ("zhenya", "Мы три репетиции спорили, как называться. Мне кажется, нет."):"amused", ("zhenya", "Нет. Мы бы и на них поссорились."):"amused"})

image bg w6 port empty = Transform("images/week6/port-winter-v1.webp", xysize=(1600, 900))
image bg w6 port nika = Transform("images/week6/port-winter-v1.webp", xysize=(1600, 900))
image bg w6 shore empty = Transform("images/week6/shore-winter-v1.webp", xysize=(1600, 900))
image bg w6 shore asya = Transform("images/week6/shore-winter-v1.webp", xysize=(1600, 900))
image bg w6 garden empty = Transform("images/week6/garden-winter-v1.webp", xysize=(1600, 900))
image bg w6 garden asya = Transform("images/week6/garden-winter-v1.webp", xysize=(1600, 900))
image bg w6 garden marta = Transform("images/week6/garden-winter-v1.webp", xysize=(1600, 900))
image bg w6 garden evening = Transform("images/week6/garden-dusk-v1.webp", xysize=(1600, 900))
image bg w6 garden marta dusk = Transform("images/week6/garden-dusk-v1.webp", xysize=(1600, 900))
image bg w6 tram pair = Transform("images/week6/tram-pair-v1.webp", xysize=(1600, 900))
image bg w6 train asya = Transform("images/week6/train-asya-v2.webp", xysize=(1600, 900))
image bg w6 cafe marta = Transform("images/week6/cafe-marta-v1.webp", xysize=(1600, 900))
image bg w6 kiss nika = Transform("images/week6/nika-port-kiss-v1.webp", xysize=(1600, 900))
image bg w6 kiss lera = Transform("images/week6/lera-tram-kiss-v1.webp", xysize=(1600, 900))
image bg w6 kiss asya = Transform("images/week6/asya-shore-boots-v1.webp", xysize=(1600, 900))
image bg w6 lera set = Transform("images/week6/lera-set-v1.webp", xysize=(1600, 900))
image bg w6 keys detail = Transform("images/week6/keys-detail-v2.webp", xysize=(1600, 900))
image bg w6 sea plans = Transform("images/week6/sea-plans-v3.webp", xysize=(1600, 900))
image bg w6 port detail = Transform(Transform("images/week6/port-winter-v1.webp", xysize=(1600, 900)), crop=(700, 290, 820, 461), xysize=(1600, 900))
image bg w6 shore detail = Transform(Transform("images/week6/shore-winter-v1.webp", xysize=(1600, 900)), crop=(480, 350, 820, 461), xysize=(1600, 900))

init -9 python:
    for person in ("nika", "asya", "marta"):
        cast_assets[(person, "winter")] = {"neutral":"images/week6/" + person + "-winter-v1.webp", "amused":"images/week6/" + person + "-winter-smile-v1.webp", "warm":"images/week6/" + person + "-winter-smile-v1.webp"}
    for scene_key, file, person in [("w6 port nika", "port-winter-v1", "nika"), ("w6 shore asya", "shore-winter-v1", "asya"), ("w6 garden asya", "garden-winter-v1", "asya"), ("w6 garden marta", "garden-winter-v1", "marta")]:
        cast_stages[scene_key] = ("images/week6/" + file + ".webp", [("oleg", "outdoor", 380, 50, 950), (person, "winter", 1230, 25, 1280 if person == "marta" else 1090)], None, "shade")
    cast_stages["w6 garden marta dusk"] = ("images/week6/garden-dusk-v1.webp", cast_stages["w6 garden marta"][1], None, "night")
    cast_stages["w6 courtyard asya"] = ("images/week6/snow-courtyard-night-v1.webp", cast_stages["w6 shore asya"][1], None, "night")
    cast_stages["w6 exhibition asya"] = ("images/week6/exhibition-hammock-v3.webp", [("oleg", "indoor", 360, 40, 950), ("asya", "", 1250, 40, 950)], None, "windowday")
    cast_stages["w6 housing modern"] = ("images/week6/modern-day-v1.webp", [("oleg", "indoor", 400, 55, 920), ("agent", "", 1250, 55, 840)], None, "workday")
    cast_cues.update({("nika", "Тогда пусть ещё раз. Я первый не записала."):"amused", ("nika", "Вот это мне нравится. Ничего для нас не украсили. Работают."):"amused", ("asya", "Это пока ты так решил."):"amused", ("asya", "Вот перчатки важнее. Там от ветра не спрячешься."):"amused", ("marta", "У неё теперь места больше. Может, булку положим."):"amused"})

init 35 python:
    phone_media["photo:w6_pool"] = {"path":"images/week6/friends-pool-v2.webp", "title":"Аквапарк · выходной", "caption":"За стеклом снег, здесь тепло"}
image bg w6 kiss marta = Transform("images/week6/marta-garden-boots-dusk-v1.webp", xysize=(1600, 900))

init python:
    soundscapes["w6_water"] = ("neva", .48, "returning", .16)
    soundscapes["w6_transit"] = ("hotel-room", .24, None, 0)

# A single floor plan: exterior entrance left of front glazing; reverse view inside.
image bg w6 food exterior = Transform("images/week6/food-exterior-v1.webp", xysize=(1600, 900))
image bg w6 food empty = Transform("images/week6/food-interior-v2.webp", xysize=(1600, 900))
image bg w6 food standing = Transform("images/week6/food-interior-v2.webp", xysize=(1600, 900))
image bg w6 food standing nika = Transform("images/week6/food-interior-v2.webp", xysize=(1600, 900))
image bg w6 food standing lera = Transform("images/week6/food-interior-v2.webp", xysize=(1600, 900))
init -10 python:
    def week6_food_arm_patch(source):
        # Only the repaired arm is used; faces and the rest stay in the original PNG.
        patch = Composite((370, 300),
            (0, 0), Crop((530, 405, 370, 300), source),
            # The folded paper edge covers remnants of the old grip.
            (0, 0), "images/gimmicks/shawarma/paper-edge-cleanup-v1.svg")
        patch = AlphaMask(AlphaMask(patch, "images/gimmicks/shawarma/arm-fade-x-v1.svg"), "images/gimmicks/shawarma/arm-fade-y-v1.svg")
        return Transform(patch, xysize=(354, 287))

image bg w6 food seated = Composite((1600, 900), (0, 0), Transform("images/week6/food-pair-v2.webp", xysize=(1600, 900)), (507, 387), week6_food_arm_patch("images/week6/food-pair-arm-v1.webp"))
image bg w6 food seated nika = Transform("images/week6/food-nika-v2.webp", xysize=(1600, 900))
image bg w6 food seated lera = Transform("images/week6/food-lera-v2.webp", xysize=(1600, 900))
image bg w6 food joy = Composite((1600, 900), (0, 0), Transform("images/week6/food-joy-v2.webp", xysize=(1600, 900)), (507, 387), week6_food_arm_patch("images/week6/food-joy-arm-v1.webp"))
image bg w6 food messy = Composite((1600, 900), (0, 0), "bg w6 food seated", (0, 0), "images/gimmicks/shawarma/sauce-pair-v1.svg")
image bg w6 food messy nika = Composite((1600, 900), (0, 0), "bg w6 food seated nika", (0, 0), "images/gimmicks/shawarma/sauce-nika-v1.svg")
image bg w6 food messy lera = Composite((1600, 900), (0, 0), "bg w6 food seated lera", (0, 0), "images/gimmicks/shawarma/sauce-lera-v1.svg")
image bg w6 food messy joy = Composite((1600, 900), (0, 0), "bg w6 food joy", (0, 0), "images/gimmicks/shawarma/sauce-joy-v1.svg")

init -9 python:
    cast_stages["w6 food standing"] = ("images/week6/food-interior-v2.webp", [("oleg", "indoor", 360, 50, 950), ("zhenya", "indoor", 1230, 20, 1200)], None, "warmday")
    for person, wardrobe in [("nika", "standing"), ("lera", "indoor")]:
        cast_stages["w6 food standing " + person] = ("images/week6/food-interior-v2.webp", [("oleg", "indoor", 300, 50, 950), ("zhenya", "indoor", 780, 20, 1200), (person, wardrobe, 1300, 50, 950)], None, "warmday")
    cast_cues.update({("zhenya", "Не знаю. Меня пока без машины пускали."):"amused", ("zhenya", "Не надо. У меня там уже партнёр есть."):"amused"})

image bg w6 ulya play = Transform("images/week6/ulya-closing-play-v1.webp", xysize=(1600, 900))
image bg w6 ulya quiet = Transform("images/week6/ulya-closing-quiet-v1.webp", xysize=(1600, 900))
image bg w6 exhibition off = Transform("images/week6/exhibition-off-v1.webp", xysize=(1600, 900))
image bg w6 exhibition off ulya = Transform("images/week6/exhibition-off-v1.webp", xysize=(1600, 900))
init -9 python:
    cast_stages["w6 exhibition off ulya"] = ("images/week6/exhibition-off-v1.webp", [("oleg", "indoor", 360, 40, 950), ("ulya", "indoor", 1250, 40, 1050)], None, "windowday")
    cast_cues.update({("ulya", "Нет. Надёжная."):"amused", ("ulya", "Вот и мне сейчас нравится."):"amused", ("ulya", "Сначала как реквизит. Сейчас как человека тоже."):"amused"})

image bg w6 closing empty = Transform("images/week6/exhibition-closing-on-v1.webp", xysize=(1600, 900))
image bg w6 closing ulya = Transform("images/week6/exhibition-closing-on-v1.webp", xysize=(1600, 900))
init -9 python:
    cast_stages["w6 closing ulya"] = ("images/week6/exhibition-closing-on-v1.webp", [("oleg", "indoor", 360, 40, 950), ("ulya", "indoor", 1250, 40, 1050)], None, "windowday")
