# Arcade presentation is separate from the persistent bite/relationship state.
init python:
    shawarma_tiers = {"perfect": ("ИДЕАЛЬНО!", "#a4ffcb"), "great": ("СОЧНО!", "#ffe49c"),
        "good": ("НЕПЛОХО!", "#c9d9ff"), "spill": ("ПОМИДОР СБЕЖАЛ!", "#ffad9d")}

    class ShawarmaPoints(renpy.Displayable):
        def __init__(self, value, previous=None, **kwargs):
            super(ShawarmaPoints, self).__init__(**kwargs)
            self.value, self.previous = value, value if previous is None else previous

        def render(self, width, height, st, at):
            progress = min(1.0, st / .55)
            shown = int(round(self.previous + (self.value - self.previous) * (1 - (1 - progress) ** 3)))
            child = Text(format(shown, ",").replace(",", " "), size=56, bold=True, color="#fff0bb", outlines=[(2,"#361c29",0,0)])
            if progress < 1.0:
                renpy.redraw(self, .016)
            return renpy.render(child, width, height, st, at)

    class ShawarmaTimingBar(renpy.Displayable):
        def __init__(self, timing, **kwargs):
            super(ShawarmaTimingBar, self).__init__(**kwargs)
            self.timing = timing

        def render(self, width, height, st, at):
            result = renpy.Render(270, 45)
            canvas = result.canvas()
            canvas.rect("#b85d66", (0, 12, 270, 20))
            canvas.rect("#e8b95d", (65, 12, 140, 20))
            green = self.timing["green"]
            canvas.rect("#56b985", (int((.5-green)*270), 12, int(green*540), 20))
            perfect = self.timing["perfect"]
            canvas.rect("#b1ffd0", (int((.5-perfect)*270), 12, int(perfect*540), 20))
            x = int(self.timing["position"] * 264 + 3)
            canvas.polygon("#ffffff", [(x-7, 0), (x+7, 0), (x, 10)])
            canvas.rect("#ffffff", (x-2, 9, 4, 27))
            return result

transform shawarma_glow_pulse:
    alpha .60 zoom .97
    ease 1.3 alpha .9 zoom 1.03
    ease 1.3 alpha .60 zoom .97
    repeat

transform shawarma_grade_pop:
    alpha 0 zoom .35 rotate -12 yoffset 20
    easeout .10 alpha 1 zoom 1.18 rotate 3 yoffset 0
    easein .10 zoom 1.0 rotate -2
    pause .25
    easeout .30 alpha 0 yoffset -60 zoom 1.07

transform shawarma_points_fly:
    alpha 0 zoom .7
    easeout .10 alpha 1 zoom 1.2
    ease .16 zoom 1.0
    pause .12
    easeout .36 xoffset 450 yoffset -270 zoom .45 alpha 0

transform shawarma_particle(dx, dy, spin, wait):
    alpha 0 zoom .1 rotate 0
    pause wait
    easeout .07 alpha 1 zoom 1
    parallel:
        easeout .55 xoffset dx
    parallel:
        easeout .22 yoffset dy
        easein .33 yoffset (dy + 95)
    parallel:
        linear .55 rotate spin
    parallel:
        pause .30
        linear .25 alpha 0 zoom .4

transform shawarma_ring_burst:
    alpha .8 zoom .25 rotate -20
    easeout .60 zoom 1.5 alpha 0 rotate 15

transform shawarma_flash:
    alpha .15
    linear .16 alpha 0

screen shawarma_impact(state):
    $ grade = state.get("last_grade") or dict(tier="good", points=0, quality=0, combo=0)
    $ title, accent = shawarma_tiers[grade["tier"]]
    add Solid("#fff1bd") at shawarma_flash
    add "images/gimmicks/shawarma/burst-v2.svg" xcenter 800 ycenter 410 at shawarma_ring_burst
    $ amount = 34 if grade["tier"] == "perfect" else 24 if grade["tier"] == "great" else 14
    for i in range(amount):
        $ angle = (i * 2.399963 + state["bites"]) % (2 * math.pi)
        $ distance = 130 + (i * 47 % 180)
        $ dx, dy = int(math.cos(angle) * distance * 1.6), int(math.sin(angle) * distance * .75 - 40)
        $ particle = "images/gimmicks/shawarma/star-v2.svg" if i % 4 == 0 else "images/gimmicks/shawarma/confetti-v2.svg"
        add Transform(particle, matrixcolor=TintMatrix(("#ffd47a", "#ff7fa4", "#97ffc5", "#c9b3ff")[i % 4])) xcenter 800 ycenter 425 at shawarma_particle(dx, dy, i * 91 - 340, (i % 4) * .015)
    if grade["tier"] == "spill":
        add "images/gimmicks/shawarma/tomato.svg" xcenter 800 ycenter 450 at shawarma_particle(245, 100, 320, 0)
    text title xcenter 800 ycenter 265 size (67 if grade["tier"] != "spill" else 48) bold True color accent outlines [(5,"#351b35",0,0),(2,"#ffffff",0,0)] at shawarma_grade_pop
    text ("+%d" % grade["points"]) xcenter 850 ycenter 360 size 62 bold True color "#fff5c4" outlines [(4,"#4c2734",0,0)] at shawarma_points_fly
    text ("ТОЧНОСТЬ %d%%" % grade["quality"]) xcenter 800 ycenter 330 size 24 bold True color "#ffffff" outlines [(2,"#351b35",0,0)] at shawarma_grade_pop

screen shawarma_game(state, finished=False, feedback=False):
    $ aim_ticks = state.get("aim_ticks", 0)
    $ aiming = state.get("phase") == "aim" and not feedback and not finished
    $ timing = shawarma_timing(state, aim_ticks)
    modal True
    zorder 80
    add Solid("#1b1023dc")
    add "images/gimmicks/shawarma/stage-v2.svg"
    add "images/gimmicks/shawarma/glow-v2.svg" xcenter 800 ycenter 440 at shawarma_glow_pulse
    text "ОПЕРАЦИЯ «ШАВЕРМА»" xpos 60 ypos 43 size 19 color "#ffb7a8" kerning 4
    text "СОЧНЫЙ УКУС" xpos 57 ypos 73 size 47 bold True color "#fff2dc"
    text "Три укуса. Держи начинку — собирай очки." xpos 60 ypos 136 size 21 color "#cbb8c8"
    add "images/gimmicks/shawarma/coin-v2.svg" xpos 1224 ypos 55
    text "ОЧКИ" xpos 1300 ypos 42 size 17 color "#e5bf99" kerning 3
    $ grade = state.get("last_grade")
    $ total = state.get("score", 0)
    add ShawarmaPoints(total, total - grade["points"] if feedback and grade else total) xpos 1295 ypos 64
    for i in range(3):
        $ past = state.get("grades", [])
        $ color = shawarma_tiers[past[i]["tier"]][1] if i < len(past) else "#675067"
        text "●" xpos (1231 + i * 45) ypos 133 size 32 color color
    text ("%d / 3" % state["bites"]) xpos 1390 ypos 143 size 18 color "#d4becd"
    add ShawarmaGrip(state, interactive=not finished and not feedback and not aiming, impact=feedback) xpos 425 ypos 140
    if not finished:
        frame:
            xpos 60 ypos 244 xysize (300, 470) padding (24, 24) background Transform("images/gimmicks/shawarma/panel-v2.svg", xysize=(300, 470))
            vbox:
                spacing 17
                text "ЛОВИ ИДЕАЛЬНЫЙ" size 18 bold True color "#ffd5a3" kerning 1
                text "Сам выбери, сколько\nснять бумаги.\nНажми «Откусить»." size 23 line_spacing 9 color "#fff1e2"
                text "Потом лови бегунок в зелёной зоне. На каждый укус — несколько секунд." size 20 line_spacing 4 color "#cdb7c8"
                text "↑ ↓ — бумага\n← → — наклон\nПробел — укус" size 18 color "#9c8baf" line_spacing 4
        $ precision, balance = shawarma_precision(state)
        frame:
            xpos 1220 ypos 238 xysize (320, 410) padding (24, 25) background Transform("images/gimmicks/shawarma/panel-v2.svg", xysize=(320, 410))
            vbox:
                spacing 12
                if aiming:
                    text "ПОЙМАЙ МОМЕНТ" size 17 color "#d8b7d0" kerning 1
                    text ("%.1f с" % timing["remaining"]).replace(".", ",") size 43 bold True color ("#ffad9d" if timing["remaining"] < 1 else "#ffe4a1")
                    add ShawarmaTimingBar(timing)
                    text "Жми в зелёном! Промах или ожидание — соус мимо рта." size 21 color "#f4e5e2"
                elif feedback:
                    text "ТОЧНОСТЬ УКУСА" size 17 color "#d8b7d0" kerning 1
                    text ("%d%%" % grade["quality"]) size 43 bold True color shawarma_tiers[grade["tier"]][1]
                    text state["note"] size 21 line_spacing 4 color "#f4e5e2"
                else:
                    text "ПОДГОТОВЬ УКУС" size 17 color "#d8b7d0" kerning 1
                    text "Сколько открыть?" size 23 bold True color "#ffd59d"
                    text ("Начинка по центру" if abs(balance) <= .3 else "Начинка у края") size 22 color ("#a4ffcb" if abs(balance) <= .3 else "#ffd59d")
                    text state["note"] size 21 line_spacing 4 color "#f4e5e2"
                if state.get("combo", 0):
                    null height 4
                    text ("СЕРИЯ %d  ·  ×%g" % (state["combo"], 1 + .5 * max(0, state["combo"] - 1))) size 22 bold True color "#ffdc93"
        if not feedback:
            textbutton ("Кусай!" if aiming else "Откусить"):
                xpos 1220 ypos 656 xysize (320, 78) padding (0, 0)
                background "images/gimmicks/shawarma/button-v2.svg"
                hover_background Transform("images/gimmicks/shawarma/button-v2.svg", matrixcolor=BrightnessMatrix(.12))
                text_size 27 text_bold True text_color "#381a31" text_hover_color "#381a31" text_xalign .5 text_yalign .5
                action Return(shawarma_timing_action(state, aim_ticks) if aiming else ("arm", None))
            textbutton "Доесть спокойно →" xpos 1220 ypos 753 xsize 320 properties mini_button("shawarma",small=True,secondary=True) action Return(("skip", None))
            if aiming:
                timer .025 repeat True action If(timing["expired"], Return(shawarma_timing_action(state, aim_ticks)), Function(shawarma_tick, state))
                key "K_SPACE" action Return(shawarma_timing_action(state, aim_ticks))
                key "K_RETURN" action Return(shawarma_timing_action(state, aim_ticks))
            else:
                key "K_LEFT" action Return(("tilt", state["tilt"] - 7))
                key "K_RIGHT" action Return(("tilt", state["tilt"] + 7))
                key "K_DOWN" action Return(("peel", state["peel"] + 35))
                key "K_UP" action Return(("peel", state["peel"] - 35))
                key "K_SPACE" action Return(("arm", None))
        else:
            use shawarma_impact(state)
            timer .78 action Return(("fx_done", None))
    else:
        frame:
            xpos 1160 ypos 235 xysize (380, 370) padding (26, 25) background Transform("images/gimmicks/shawarma/panel-v2.svg", xysize=(380, 370))
            vbox:
                spacing 17
                text ("БЕЗУПРЕЧНЫЙ УЖИН" if state.get("perfects", 0) == 3 else "УЖИН ЗАСЧИТАН") size 22 bold True color "#ffe4a1"
                text ("Идеальных: %d / 3" % state.get("perfects", 0)) size 24 color "#fff3dc"
                text ("Лучшая серия: %d" % state.get("best_combo", 0)) size 21 color "#cdb7c8"
                for i, item in enumerate(state.get("grades", [])):
                    text ("%d.  %d%%       +%d" % (i + 1, item["quality"], item["points"])) size 22 color shawarma_tiers[item["tier"]][1]
                text "Возвращаемся к ужину…" size 18 color "#a995ae"
        timer 2.3 action Return(("done", None))
        key "K_SPACE" action Return(("done", None))
        key "K_RETURN" action Return(("done", None))
    if not feedback and not finished:
        text ("ПРОБЕЛ ИЛИ «КУСАЙ!» — ОСТАНОВИТЬ БЕГУНОК" if aiming else "ПОТЯНИ БУМАГУ ВНИЗ  ·  ПОВЕРНИ ЗА ВЕРХУШКУ") xcenter 800 ypos 777 size 17 color "#d7bbd0" kerning 1
    use minigame_system("shawarma")
    key "game_menu" action ShowMenu()
    key "rollback" action Rollback()
