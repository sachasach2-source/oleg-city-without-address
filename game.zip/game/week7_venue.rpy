label week7_party_explore:
    $ week7_venue_prepare()
    $ week7_stamp("Фойе",((week7_clock+4)//5)*5)
    "У гардероба висит план. Из прихожей дверь ведёт в большой зал со сценой и буфетом. Из зала четыре двери ведут в красную гостиную, игровую, тихую комнату и оранжерею. Гардероб и санузел — у входа."
    "Катя объявляет: «Квиз до половины девятого, дальше сами садитесь и врите друг другу. Музыканты до четверти десятого играют, потом танцы. Площадку до половины одиннадцатого сняли»."
    while not week7_venue.get("ending"):
        if week7_party_guest()=="lera" and (week7_clock>=1245 or not any(week7_venue_available(k) for k in week7_venue_places if k!="leave")):
            if not week7_public.get("lera",{}).get("discussed"):
                call week7_relationship_talk(True)
            $ week7_stamp("Гардероб",min(1260,week7_clock+5))
            call week7_lera_departure
            if week7_venue.get("ending"):
                return
        if week7_clock>=1350:
            "Музыка стихает. У сцены сматывают первый кабель, в гардеробе уже собралась очередь."
            $ week7_party["exit_reason"]="closing"
            $ week7_venue["ending"]=True
            return
        $ week7_available_places=[k for k in week7_venue_places if week7_venue_available(k)]
        if len(week7_available_places)==1:
            $ week7_destination=week7_available_places[0]
        else:
            call screen week7_party_map
            $ week7_destination=_return
        if week7_destination=="phone":
            call week7_phone
        elif week7_destination=="leave":
            $ week7_party["exit_reason"]="own"
            $ week7_party["early"]=True
            $ week7_venue["ending"]=True
        else:
            $ week7_visit=week7_venue.get("visits",{}).get(week7_destination,0)
            $ week7_venue["room"]=week7_destination
            $ week7_stamp(week7_venue_location(week7_destination),week7_clock)
            $ week7_venue["route"].append(dict(room=week7_destination,time=week7_clock,guest=week7_party_guest()))
            if week7_destination=="music":
                if not week7_visit:
                    call week7_party_music
                else:
                    call week7_party_listen
            elif week7_destination=="dance":
                if not week7_visit:
                    call week7_party_dance
                else:
                    call week7_party_second_dance
            elif week7_destination=="table":
                if not week7_visit:
                    call week7_party_table
                    call week7_party_colleagues
                else:
                    call week7_party_tea
            elif week7_destination=="games":
                call week7_party_games
            elif week7_destination=="bluff":
                call week7_party_bluff
            elif week7_destination=="garden":
                call week7_party_garden
            elif week7_destination=="oracle":
                call week7_party_oracle
            elif week7_destination=="quiet":
                if week7_party_guest() and not week7_public.get(week7_party_guest(),{}).get("discussed"):
                    call week7_relationship_talk
                else:
                    call week7_party_breather
            call week7_threads_room(week7_destination)
            $ week7_venue["visits"][week7_destination]=week7_visit+1
            $ week7_party["activities"].append(week7_destination)
            $ week7_event("party_room",week7_destination,week7_party_guest())
            $ week7_stamp("Большой зал",week7_clock+week7_venue_places[week7_destination]["duration"])
            call week7_marta_costume_changed
            call week7_threads_hall
            if len(week7_venue["route"])==1 and week7_party_guest():
                $ week7_say(week7_party_guest(),{"nika":"Я ещё музыкантов хочу послушать. Не обязательно с гитарой, можно просто рядом постоять.","lera":"Я бы ещё потанцевала. Только потом не дай мне до утра здесь остаться, у меня сет.","asya":"Я в игровую ещё хочу. Катя сказала, там после квиза можно свои истории рассказывать.","marta":"Я бы в тихую комнату заглянула. Здесь столько всего сразу, я половину твоих слов не слышу.","zhenya":"Я ещё у сцены постою. В вашем барабанщике что-то подозрительно знакомое — так же на переходах спешит.","ulya":"Хочу на эту игру с враньём. Только историю надо придумать так, чтобы мне никто не поверил."}[week7_party_guest()])
    return

label week7_party_colleagues:
    call week7_colleagues_buffet
    return

label week7_party_games:
    $ week7_person=week7_party_guest()
    scene expression week7_venue_scene("games",week7_person,True) with dissolve
    if week7_clock<1230:
        $ week7_venue.setdefault("played_games",[]).append("quiz")
        "Катя собирает последние карточки. Олег сдвигает две пустые коробки, чтобы освободить край стола. Участники стоят рядом, сверяют ответы и спорят через соседей."
        w7k "Следующий вопрос. Фильм узнаём по плохому пересказу: человек приехал на работу, коллектив оказался чужим, из-за этого всё сгорело."
        menu:
            "«Нечто». Очень плохое трудоустройство.":
                w7k "Да. Я убрала слово «Антарктида», а то вы слишком быстро отгадывали."
                $ week7_venue["quiz_answer"]="thing"
            "Это у нас про прошлый релиз документалку сняли?":
                w7k "Если в документалке был огнемёт, я что-то пропустила. Название всё-таки надо."
                o "Тогда «Нечто»."
                $ week7_venue["quiz_answer"]="joke_then_thing"
            "Я не понял. Подскажи, это вообще хоррор?":
                w7k "Да. Полярная станция."
                o "А. «Нечто». Без станции я у себя на работе застрял."
                $ week7_venue["quiz_answer"]="hint"
        if week7_person:
            $ week7_say(week7_person,{"nika":"Мне первый ваш спор больше понравился, там никто даже название фильма не спросил.","lera":"Нормально. Мне нравятся вопросы, где можно сначала что-нибудь уверенно ляпнуть.","asya":"Но коллектив там не весь чужой. В этом же и весь ужас.","marta":"Я бы за слово «чужой» вообще другой фильм написала.","zhenya":"«Нечто» давно не смотрела. Надо пересмотреть.","ulya":"Я «Чужого» подумала. Всё время их путаю."}[week7_person])
        w7k "Карточки сдавайте. Победителям — право первыми выбрать оставшуюся пиццу. Я полкоробки спрятала."
        "Илья за дверью требует пересчёта, потому что пиццу он и заказывал. Катя поднимает пустую карточку: «Тогда сначала ответ допиши»."
        $ week7_event("party_quiz",week7_venue["quiz_answer"],week7_person)
    else:
        $ week7_venue.setdefault("played_games",[]).append("stories")
        call week7_colleagues_stories
        if week7_person:
            $ week7_say(week7_person,{"nika":"Я теперь тоже хочу. Только вы потом не требуйте доказательства.","lera":"Мой выход. У меня как раз три поездки есть, одну сейчас выдумаю.","asya":"Мне нужно минуту выбрать. Я уже сама в своих версиях запуталась.","marta":"А если я сама считаю, что правда, но никто не верит? Ладно, другое возьму.","zhenya":"Я хочу послушать ещё круг. Потом расскажу.","ulya":"Я сейчас такую правду расскажу, что вы за враньё всё засчитаете."}[week7_person])
        "Спор продолжается уже без Катиных карточек. Кто-то смеётся раньше конца истории, и приходится начинать заново."
        $ week7_event("party_stories",week7_venue["story"],week7_person)
    return

label week7_party_listen:
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    "Второй сет начинается тише. Олег остаётся перед сценой, не просится к инструментам. Ударник наконец перестаёт поправлять стойку."
    if week7_party_guest():
        $ week7_say(week7_party_guest(),{"nika":"Вот сейчас они друг друга услышали. Не хочу разговаривать, давай дослушаем.","lera":"Этот трек я в дорогу люблю. У них медленнее, но нормально.","asya":"Сейчас мне больше нравится. Можно хотя бы голос разобрать.","marta":"Я слов половину не знаю, а мелодию уже напеваю.","zhenya":"Педаль ему подстроили. Теперь бочка не пропадает. Я бы тоже к ним села как-нибудь.","ulya":"Хорошо, что ты сейчас просто слушаешь. Я тоже не хочу ни снимать, ни что-то делать."}[week7_party_guest()])
    "Олег ставит стакан на подоконник, чтобы хлопать обеими руками. После последнего аккорда забирает его обратно."
    return

label week7_party_second_dance:
    call week7_dice_requested_track
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    "В зале уже свободнее: часть людей ушла в игровую. Олег слышит знакомое начало и сам делает шаг с края танцпола."
    if week7_party_guest():
        $ week7_say(week7_party_guest(),{"nika":"На эту я пойду. Подожди, воду поставлю.","lera":"Ещё одну. И потом я уже на часы смотрю.","asya":"Давай. Уже не так неловко, как в первый раз.","marta":"Подожди, крылья поправлю. Всё, теперь пойдём.","zhenya":"Эту я знаю. Всё, я тоже.","ulya":"Вот под эту мне нравится."}[week7_party_guest()])
    scene expression "bg w7 dance "+week7_costume with dissolve
    if week7_party_guest()=="lera":
        "Лера оставляет корзинку за колонкой, где её не заденут ногами, и возвращается к Олегу."
    "К концу трека вокруг уже поют громче записи. Олег слова путает, но перестаёт из-за этого замолкать."
    if week7_party_guest()=="lera":
        "Лера забирает корзинку. Красная лента зацепилась за ручку — приходится распутать, прежде чем идти дальше."
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    return

label week7_party_tea:
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    "На краю буфета появились чайник и бумажные стаканы. Горячее уже разобрали, зато кто-то разрезал пирог ровными узкими кусками."
    if week7_party_guest():
        $ week7_say(week7_party_guest(),{"nika":"Мне кусочек. Большой не хочу. Хотя вот этот край можно.","lera":"О, чай. Я ещё кружку успею, потом поеду.","asya":"У них даже лимон остался. Сейчас я себе сделаю.","marta":"Мне маленький пока. Потом ещё возьму, если захочу.","zhenya":"Я за чаем шла. Теперь и пирог возьму.","ulya":"Мне два кусочка. Одного мало."}[week7_party_guest()])
    "Олег ждёт, пока освободится место у окна. На стекле отражаются бумажные звёзды и чужие шляпы."
    return

label week7_party_breather:
    scene expression week7_venue_scene("quiet",week7_party_guest()) with dissolve
    if week7_party_guest():
        $ week7_say(week7_party_guest(),{"nika":"Вот тут можно просто постоять. Я на минуту помолчу, ладно?","lera":"Я сейчас поняла, что полчаса ничего не говорила. Танцевала, а не организовывала. Хорошо.","asya":"Здесь я тебя хотя бы нормально слышу. У меня от музыки уже в ухе звенело.","marta":"Мне здесь лучше слышно. Там я уже только кивала.","zhenya":"Я давно на вечеринке часы не забывала проверить. Сейчас всё-таки проверю.","ulya":"Я рада, что выбралась. У меня дома ещё монтаж ждёт, но не прямо сейчас."}[week7_party_guest()])
        o "Давай немного здесь побудем."
    else:
        call week7_colleague_quiet
    "За дверью кто-то ищет свой шарф. Олег смотрит на пустой диван и отвечает, что здесь его нет."
    return

label week7_lera_departure:
    scene expression week7_party_scene("lera") with dissolve
    l "Мне выезжать пора. Я сейчас куртку возьму."
    menu:
        "Провожу к машине. Я тоже на сегодня закончил.":
            o "Пойдём. Телефон только со стола заберу."
            $ week7_party["ending"]="lera_to_work"
            $ week7_venue["ending"]=True
        "Провожу до машины, потом ещё немного побуду.":
            o "Хорошего сета. Я завтра спрошу, как прошло."
            l "Спасибо. Напиши после обеда, я раньше не оживу."
            $ week7_party["ending"]="stayed_after_lera"
    "Лера уезжает на свою площадку. Олег отходит от машины обратно под навес."
    $ week7_party["guest_departed"]=True
    $ week7_event("guest_departed","Лера уехала на сет; Олег не отменял её работу","lera")
    scene expression week7_party_scene() with dissolve
    return

label week7_guest_farewell:
    if week7_party.get("exit_reason")=="own":
        o "Я на сегодня закончил. Ты хочешь ещё остаться?"
        if week7_clock<1245 and week7_party_guest()=="lera":
            l "Я ещё потанцую. Мне же потом на площадку, не домой. В девять отсюда выеду."
            o "Хорошего сета. Завтра напишу, спрошу, как прошло."
            l "Давай после обеда. Раньше я точно спать буду."
            $ week7_party["ending"]="guest_stayed"
        elif week7_clock<1260 and week7_party_guest() in ("nika","ulya"):
            $ week7_say(week7_guest,"Я ещё немного побуду. С ребятами поговорю, потом сама поеду.")
            o "Хорошо. Напиши, когда доберёшься?"
            $ week7_say(week7_guest,"Напишу.")
            $ week7_party["ending"]="guest_stayed"
        else:
            $ week7_say(week7_guest,"Я тоже поеду. Давай до метро вместе.")
            o "Пойдём. Я только попрощаюсь."
            $ week7_party["ending"]="left_together"
    else:
        $ week7_say(week7_guest,"Уже музыку выключают. Я за курткой.")
        o "Я тоже. До метро вместе пойдём?"
        $ week7_say(week7_guest,"Да, пойдём.")
        $ week7_party["ending"]="left_together"
    if week7_party["ending"]=="left_together":
        $ week7_event("party_left_together","Дорога до метро; без обещания общей ночи",week7_guest)
    else:
        $ week7_event("party_guest_stayed","Олег уехал; она осталась по своему желанию",week7_guest)
    return
