# One tactile insert during the meal with Zhenya. No relationship score.
default shawarma_state = None

init python:
    import math
    shawarma_hero_assets = (
        "images/gimmicks/shawarma/hero-v2-0.webp",
        "images/gimmicks/shawarma/hero-v2-1.webp",
        "images/gimmicks/shawarma/hero-v2-2.webp",
        "images/gimmicks/shawarma/hero-v2-3.webp",
    )

    def shawarma_paper(peel, front=False):
        path = "images/gimmicks/shawarma/paper-front-v3.webp" if front else "images/gimmicks/shawarma/paper-v2.webp"
        return Transform(Crop((230, 45, 660, 1300), path), xysize=(270, 530 - int(85 + peel)))

    def shawarma_show_feedback(state):
        # This animation belongs to the bite, not to a separate rollback step.
        renpy.show_screen("shawarma_game", state, feedback=True, _transient=True)
        renpy.ui.interact(mouse="screen", type="screen")
        renpy.with_statement(None)

    def shawarma_start():
        return dict(bites=0, peel=0, tilt=0, filling=0.0, spills=0, result="",
            note="Сам прикину, сколько бумаги снять: верх открыть, низ удержать.", last="start",
            score=0, combo=0, best_combo=0, perfects=0, grades=[], last_grade=None,
            phase="prepare", aim=None, aim_ticks=0, timeouts=0)

    def shawarma_tick(state):
        if state.get("phase") == "aim" and not state.get("result"):
            state["aim_ticks"] = state.get("aim_ticks", 0) + 1
            # Keep in-progress UI time on load, as with the phone's live state.
            renpy.retain_after_load()

    def shawarma_timing(state, ticks):
        bite = min(state["bites"], 2)
        elapsed = ticks * .025
        period = (1.9, 1.6, 1.35)[bite]
        position = 1.0 - abs((elapsed / period) % 2.0 - 1.0)
        distance = abs(position - .5)
        perfect, green = ((.07, .14), (.055, .115), (.045, .09))[bite]
        quality = 100 if distance <= perfect else int(round(100 - 25 * (distance - perfect) / (green - perfect))) if distance <= green else int(round(75 * max(0.0, .32 - distance) / (.32 - green)))
        limit = (4.2, 3.6, 3.0)[bite]
        return dict(position=position, quality=quality, green=green, perfect=perfect,
            remaining=max(0.0, limit - elapsed), expired=elapsed >= limit)

    def shawarma_timing_action(state, ticks):
        timing = shawarma_timing(state, ticks)
        return ("bite", dict(aim=state.get("aim"), timing=0 if timing["expired"] else timing["quality"],
            timeout=timing["expired"], ticks=ticks))

    def shawarma_precision(state, aim=None):
        required = 70 + 70 * state["bites"]
        balance = state["filling"] + state["tilt"] / 12.0
        paper = max(0.0, abs(state["peel"] - required - 20) - 5) / 80.0
        targeting = max(0.0, min(1.0, float(aim)) - .15) / .85 if aim is not None else 0.0
        centered = max(0.0, abs(balance) - .08) / .77
        quality = int(round(100 * max(0.0, 1.0 - .55 * min(1.0, centered) - .30 * min(1.0, paper) - .15 * targeting)))
        return quality, balance

    def shawarma_grade(state, aim, spilled):
        hit = aim if isinstance(aim, dict) else dict(aim=aim, timing=0, timeout=False)
        quality, _ = shawarma_precision(state, hit.get("aim"))
        quality = int(round(quality * .45 + hit.get("timing", 0) * .55))
        if spilled:
            quality = min(quality, 35)
        combo = state.get("combo", 0) + 1 if quality >= 75 and not spilled else 0
        multiplier = 1.0 + .5 * max(0, combo - 1)
        tier = "perfect" if quality >= 90 else "great" if quality >= 75 else "good" if not spilled else "spill"
        points = max(10, int(round(quality * (2 if spilled else 10) * multiplier / 10.0)) * 10)
        return dict(quality=quality, points=points, combo=combo, multiplier=multiplier, tier=tier,
            timing=hit.get("timing", 0), timeout=hit.get("timeout", False))

    def shawarma_step(state, action):
        if state["result"]:
            return state
        kind, value = action
        new = dict(state)
        new["last"] = kind
        if kind == "skip":
            new.update(result="skipped", note="Ладно, обеими руками. Поем спокойно.")
        elif kind == "peel":
            if state.get("phase") == "aim":
                return state
            new["peel"] = max(0, min(270, int(value)))
            new["note"] = "Отогнул бумагу. Столько оставить?" if new["peel"] > state["peel"] else "Подтянул бумагу обратно. Так крепче держится."
        elif kind == "tilt":
            if state.get("phase") == "aim":
                return state
            new["tilt"] = max(-28, min(28, int(value)))
            new["note"] = "Начинку держу ровно." if abs(new["filling"] + new["tilt"] / 12.0) <= .85 else "Начинка съезжает к краю. Поверну обратно."
        elif kind in ("arm", "bite"):
            required = 70 + 70 * state["bites"]
            if state["peel"] < required:
                new["note"] = "Ещё немного бумаги вниз. Её есть не собираюсь."
                return new
            if kind == "arm" or state.get("phase", "prepare") != "aim":
                new.update(phase="aim", aim=value, aim_ticks=0, note="Лови зелёную зону. Теперь быстро!")
                return new
            hit = value if isinstance(value, dict) else dict(aim=value, timing=0, timeout=False)
            balance = state["filling"] + state["tilt"] / 12.0
            spilled = abs(balance) > .85 or state["peel"] - required > 85 or hit.get("timing", 0) < 40 or hit.get("timeout", False)
            grade = shawarma_grade(state, hit, spilled)
            new.update(score=state.get("score", 0) + grade["points"], combo=grade["combo"],
                best_combo=max(state.get("best_combo", 0), grade["combo"]),
                perfects=state.get("perfects", 0) + int(grade["tier"] == "perfect"),
                grades=list(state.get("grades", [])) + [grade], last_grade=grade)
            new["bites"] += 1
            new["phase"] = "prepare"
            new["timeouts"] = state.get("timeouts", 0) + int(hit.get("timeout", False))
            new["spills"] += int(spilled)
            new["filling"] = (1.15, -1.1, .25)[state["bites"]]
            new["note"] = "Передержал. Капнуло на стол, соус у губы." if hit.get("timeout") else "Мимо. На столе пара капель." if spilled else "Есть. А начинка уже на другом краю."
            if new["bites"] == 3:
                new["result"] = "clean" if not new["spills"] else "sauce" if new["spills"] < 3 else "escaped"
                new["note"] = {"clean":"Ну вот. Можно просто есть.", "sauce":"Салфетки были очень кстати.", "escaped":"Начинка отдельно, лаваш отдельно. Тоже ужин."}[new["result"]]
        return new

    class ShawarmaPicture(renpy.Displayable):
        def __init__(self, state, peel, tilt, **kwargs):
            super(ShawarmaPicture, self).__init__(**kwargs)
            self.state, self.peel, self.tilt = state, peel, tilt

        def render(self, width, height, st, at):
            result = renpy.Render(400, 560)
            stage = min(self.state["bites"], 3)
            asset = Crop((145, 95, 690, 1430), shawarma_hero_assets[stage])
            body = renpy.render(Transform(asset, zoom=250.0 / 690), 250, 519, st, at)
            sleeve_top = int(85 + self.peel)
            paper_height = 530 - sleeve_top
            # The food sits between the rear and front walls of the same sleeve.
            rear = renpy.render(shawarma_paper(self.peel), 270, paper_height, st, at)
            front = renpy.render(shawarma_paper(self.peel, front=True), 270, paper_height, st, at)
            result.blit(rear, (65, sleeve_top))
            # Everything below the front lip is inside the sleeve, including the base.
            visible_height = min(body.get_size()[1], sleeve_top + int(paper_height * .36))
            result.blit(body.subsurface((0, 0, body.get_size()[0], visible_height)), (75, 0))
            result.blit(front, (65, sleeve_top))
            return result

        def visit(self):
            return [renpy.displayable(shawarma_hero_assets[min(self.state["bites"], 3)]), renpy.displayable("images/gimmicks/shawarma/paper-v2.webp"), renpy.displayable("images/gimmicks/shawarma/paper-front-v3.webp")]

    class ShawarmaGrip(renpy.Displayable):
        def __init__(self, state, interactive=True, impact=False, **kwargs):
            super(ShawarmaGrip, self).__init__(**kwargs)
            self.state = state
            self.interactive = interactive
            self.impact = impact
            self.peel, self.tilt = state["peel"], state["tilt"]
            self.dragging = None
            self.origin = (0, 0)

        def render(self, width, height, st, at):
            picture = ShawarmaPicture(self.state, self.peel, self.tilt)
            punch = math.exp(-7 * st) * math.sin(23 * st) if self.impact else 0.0
            turned = renpy.render(Transform(picture, rotate=self.tilt + punch * 3,
                xzoom=1.0 + punch * .10, yzoom=1.0 - punch * .065), 750, 650, st, at)
            result = renpy.Render(750, 650)
            tw, th = turned.get_size()
            result.blit(turned, (375 - tw // 2, 325 - th // 2))
            if self.impact and st < .8:
                renpy.redraw(self, .016)
            if self.interactive:
                target_y = (130, 190, 250)[min(self.state["bites"], 2)]
                angle = math.radians(self.tilt)
                target_x = 375 - (target_y - 280) * math.sin(angle)
                target_y = 325 + (target_y - 280) * math.cos(angle)
                ring = renpy.render(Transform("images/gimmicks/shawarma/target-v2.svg", matrixcolor=TintMatrix("#ffdb81")), 72, 72, st, at)
                result.blit(ring, (int(target_x) - 36, int(target_y) - 36))
            return result

        def local_point(self, x, y):
            angle = math.radians(self.tilt)
            dx, dy = x - 375, y - 325
            return (200 + dx * math.cos(angle) + dy * math.sin(angle),
                    280 - dx * math.sin(angle) + dy * math.cos(angle))

        def event(self, ev, x, y, st):
            if not self.interactive:
                return
            pg = renpy.pygame
            if ev.type == pg.MOUSEBUTTONDOWN and ev.button == 1:
                px, py = self.local_point(x, y)
                if 65 <= px <= 335 and 45 <= py <= 510:
                    sleeve_top = int(85 + self.peel)
                    paper_hit = renpy.is_pixel_opaque(shawarma_paper(self.peel, front=True), 270, 530 - sleeve_top, st, st, int(px - 65), int(py - sleeve_top))
                    self.dragging = "peel" if paper_hit else "tilt"
                    self.origin = (x, y)
                    raise renpy.IgnoreEvent()
            if ev.type == pg.MOUSEMOTION and self.dragging:
                if self.dragging == "peel":
                    self.peel = max(0, min(270, self.state["peel"] + y - self.origin[1]))
                else:
                    self.tilt = max(-28, min(28, self.state["tilt"] + (x - self.origin[0]) * .20))
                renpy.redraw(self, 0)
                raise renpy.IgnoreEvent()
            if ev.type == pg.MOUSEBUTTONUP and ev.button == 1 and self.dragging:
                kind, self.dragging = self.dragging, None
                if kind == "tilt" and abs(x - self.origin[0]) + abs(y - self.origin[1]) < 8:
                    px, py = self.local_point(x, y)
                    target_y = (130, 190, 250)[min(self.state["bites"], 2)]
                    aim = min(1.0, math.hypot((px - 200) / 90.0, (py - target_y) / 85.0))
                    return ("arm", aim)
                return (kind, self.peel if kind == "peel" else self.tilt)

label shawarma_gameplay:
    $ shawarma_state = shawarma_start()
    window hide
    while not shawarma_state["result"]:
        call screen shawarma_game(shawarma_state)
        $ _shawarma_before_bites = shawarma_state["bites"]
        $ shawarma_state = shawarma_step(shawarma_state, _return)
        if shawarma_state["bites"] > _shawarma_before_bites:
            $ renpy.sound.play("audio/shawarma-" + shawarma_state["last_grade"]["tier"] + ".wav")
            $ shawarma_show_feedback(shawarma_state)
    if shawarma_state["result"] != "skipped":
        $ vignette_record_score("shawarma", shawarma_state["score"])
        call screen shawarma_game(shawarma_state, finished=True)
    return
