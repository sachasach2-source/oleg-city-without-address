# Local messenger UI. Reactions belong to the game's save, not an external chat.
default phone_reaction_votes = {}
default phone_reply_log = {}
default phone_message_times = {}
default phone_thread_contacts = {}
default phone_history_times = {}

init -1 python:
    import re
    import functools as phone_functools

    phone_profiles = {
        "Олег": ("#527db8", "guitar", "#91bdf0"),
        "Саня": ("#558575", "runner", "#8ecdb6"),
        "Саша": ("#8264a5", "astronaut", "#c5a4ec"),
        "Агент": ("#ac8152", "home", "#e7ba84"),
        "Ника": ("#715785", "guitar", "#d4b5ee"),
        "Лера": ("#b66b42", "fire", "#ffc6a0"),
        "Ася": ("#667a50", "heart", "#c7daa8"),
        "Марта": ("#80637d", "heart", "#d5b7d8"),
        "Варя": ("#657b39", "skull", "#c7e789"),
        "Рита": ("#a46170", "heart", "#edb0c0"),
        "Лёша": ("#677fa2", "guitar", "#b5c9ee"),
        "Ира": ("#648879", "runner", "#b0dac7"),
        "Денис": ("#88749d", "astronaut", "#d4bde8"),
        "Четверг точно": ("#9c694a", "fire", "#edbd98"),
        "Мои шлюхи": ("#615785", "boar", "#c5a4ec"),
    }
    phone_emoji_choices = ("laugh", "heart", "fire", "thumb", "skull")
    phone_reaction_labels = {"laugh": "Смех", "heart": "Сердце", "fire": "Огонь", "thumb": "Нравится", "skull": "Череп"}

    class PhoneRound(renpy.Displayable):
        def __init__(self, color, radius=14, **kwargs):
            super(PhoneRound, self).__init__(**kwargs)
            self.color = color
            self.radius = radius

        def render(self, width, height, st, at):
            w, h = max(1, int(width)), max(1, int(height))
            r = min(self.radius, w // 2, h // 2)
            canvas = UiSmoothCanvas(w, h)
            canvas.rect(self.color, (r, 0, w - r * 2, h))
            canvas.rect(self.color, (0, r, w, h - r * 2))
            for x in (r, w - r):
                for y in (r, h - r):
                    canvas.circle(self.color, (x, y), r)
            return canvas.finish()

    @phone_functools.lru_cache(maxsize=96)
    def phone_round_cached(color, radius=14):
        return PhoneRound(color, radius)

    def phone_round(color, radius=14):
        # Immutable background geometry can share render caches across bubbles.
        # Keep the existing native path; this targets the browser's memory peak.
        return phone_round_cached(color, radius) if renpy.emscripten else PhoneRound(color, radius)

    def phone_profile(sender):
        return phone_profiles.get(sender, phone_profiles["Агент"])

    def phone_contact_history(conversation, contact):
        # Read only messages the player actually exchanged with this contact.
        person = {"Ника": "nika", "Ася": "asya", "Лера": "lera", "Варя": "varya"}[contact]
        seen = set()
        for chat, node in reversed(list(phone_reply_log)):
            if chat == conversation or chat in seen:
                continue
            seen.add(chat)
            same_contact = chat.startswith(("ch2_" + person, "ch3_" + person)) or (person == "asya" and chat == "ch3_gallery_zine")
            if same_contact and chat in phone_dialogues:
                transcript, decisions, pending = phone_conversation_state(chat, [])
                if decisions:
                    return [(sender, msg) for sender, msg in transcript if sender in ("Олег", contact)][-2:]
        return []

    def phone_time(index, total, earlier=False):
        # The last current message matches the scene clock; earlier chat stays earlier.
        match = re.search(r"(\d{1,2}):(\d{2})", place_name)
        minutes = int(match[1]) * 60 + int(match[2]) if match else 19 * 60
        minutes -= (30 + (total - index - 1) * 4) if earlier else (total - index - 1) // 2
        minutes %= 24 * 60
        return "{:02d}:{:02d}".format(minutes // 60, minutes % 60)

    def phone_base_reactions(sender, msg):
        return {
            ("Олег", "Шумеры не пьют."): [("laugh", 2)],
            ("Саша", "Стена играет на басу? У меня так начиналась одна история."): [("laugh", 1)],
            ("Саня", "Ахах. Олег, я рад. Ещё увидитесь?"): [("heart", 1)],
        }.get((sender, msg), [])

    def phone_past_excerpt(msg):
        # Past chat is a glimpse, not a second conversation competing for attention.
        msg = phone_message_label(msg)
        return msg if len(msg) <= 70 else msg[:67].rsplit(" ", 1)[0] + "…"

    def phone_reactions(sender, msg):
        base = dict(phone_base_reactions(sender, msg))
        return [(emoji, base.get(emoji, 0) + int(bool(phone_reaction_votes.get((sender, msg, emoji)))))
                for emoji in phone_emoji_choices
                if emoji in base or phone_reaction_votes.get((sender, msg, emoji))]

    def phone_toggle_reaction(sender, msg, emoji):
        key = (sender, msg, emoji)
        if phone_reaction_votes.get(key):
            del phone_reaction_votes[key]
        else:
            phone_reaction_votes[key] = True
        renpy.retain_after_load()

    def phone_record_reply(conversation, node, reply, messages=None, dialogue=None):
        phone_reply_log[(conversation, node)] = reply
        if messages is not None:
            transcript, decisions, pending = phone_conversation_state(conversation, messages, dialogue)
            phone_stamp_messages(conversation, transcript)
        # A call-screen interaction otherwise reloads at its opening statement.
        renpy.retain_after_load()

    def phone_conversation_state(conversation, messages, dialogue_override=None):
        transcript, decisions, node = list(messages), [], "start"
        if not conversation:
            return transcript, decisions, None
        dialogue = phone_dialogues[conversation] if dialogue_override is None else dialogue_override
        while node is not None:
            turn = dialogue[node]
            transcript += turn["messages"]
            if not turn["options"]:
                node = None
                break
            chosen = phone_reply_log.get((conversation, node))
            reply = next((option for option in turn["options"] if option["id"] == chosen), None)
            if reply is None:
                break
            decisions.append((node, chosen))
            if reply.get("send", True):
                transcript.append(("Олег", reply["text"]))
            transcript += reply.get("messages", [])
            node = reply.get("next")
        return transcript, decisions, node

    def phone_at_bottom(adjustment):
        return adjustment.range - adjustment.value <= 24

    def phone_scroll_new_messages(adjustment):
        # Range changes also happen on reactions and photo/layout changes.
        # Only follow if the reader was already at the old bottom.
        previous = getattr(adjustment, "phone_previous_range", None)
        if previous != adjustment.range:
            if previous is None or previous - adjustment.value <= 24:
                adjustment.value = adjustment.range
            adjustment.phone_previous_range = adjustment.range

    def phone_scroll_to_latest():
        screen = renpy.get_screen("phone_thread")
        if screen:
            adjustment = screen.scope["chat_scroll"]
            adjustment.change(adjustment.range)
            renpy.restart_interaction()

    def phone_read_delay(messages, revealed):
        if not revealed:
            return 0.8
        message = messages[min(revealed, len(messages)) - 1][1]
        if phone_media_item(message):
            return 3.0
        # Give the preceding bubble time to be read, not just the next one typed.
        return min(5.0, max(1.5, 0.6 + len(phone_message_label(message)) / 35.0))

    def phone_reveal_next(expected):
        screen = renpy.get_screen("phone_thread")
        if not screen or renpy.get_screen("phone_photo_viewer") or renpy.get_screen("phone_voice_viewer") or renpy.get_screen("week7_attachment_archive"):
            return
        scope = screen.scope
        if scope["revealed_count"] != expected:
            return
        scope["revealed_count"] = min(expected + 1, len(scope["visible_messages"]))
        renpy.restart_interaction()

    def phone_stamp_messages(token, messages, caption=None):
        # Store once per actual transcript. Reactions and reopening don't retime it.
        if caption is not None:
            phone_thread_contacts[token] = caption
        saved_first = phone_message_times.get((token, 0))
        if token == "ch2_asya_after" and saved_first and saved_first[2] < "21:15":
            # Old saves could retain a QA/previous-run time from before their goodbye.
            for key in list(phone_message_times):
                if key[0] == token:
                    del phone_message_times[key]
        first = phone_time(0, 1)
        hour, minute = map(int, first.split(":"))
        # Anchor at the opening scene, then append forward. Recalculating the
        # start from transcript length made newly revealed replies predate Oleg.
        cursor = hour * 60 + minute
        for index, (sender, msg) in enumerate(messages):
            key = (token, index)
            saved = phone_message_times.get(key)
            if saved and saved[:2] == (sender, msg):
                stamp = saved[2]
                hour, minute = map(int, stamp.split(":"))
                saved_minute = hour * 60 + minute
                if index == 0:
                    cursor = saved_minute
                elif saved_minute < cursor % 1440:
                    # Repair legacy backwards times, but preserve midnight.
                    saved_minute += 1440 if cursor % 1440 > 1380 and saved_minute < 120 else 0
                    saved_minute = max(cursor, saved_minute)
                    stamp = "{:02d}:{:02d}".format((saved_minute // 60) % 24, saved_minute % 60)
                cursor = max(cursor, saved_minute)
            else:
                clock = cursor % (24 * 60)
                stamp = "{:02d}:{:02d}".format(clock // 60, clock % 60)
            phone_message_times[key] = (sender, msg, stamp)
            cursor += 1
        # A revised answer replaces the old suffix, including its timestamps.
        for key in list(phone_message_times):
            if key[0] == token and key[1] >= len(messages):
                del phone_message_times[key]

    def phone_finish_scene(token):
        # Explicitly called after early-chapter chats: the next conversation
        # starts after the last sent reply, including a midnight crossing.
        global place_name
        entries = [(key[1], saved[2]) for key, saved in phone_message_times.items() if key[0] == token]
        match = re.search(r"(\d{1,2}):(\d{2})", place_name)
        if not entries or not match:
            return
        stamp = max(entries)[1]
        hour, minute = map(int, stamp.split(":"))
        elapsed = (hour * 60 + minute - int(match[1]) * 60 - int(match[2])) % 1440
        if elapsed < 180:
            place_name = place_name[:match.start()] + stamp + place_name[match.end():]

    def phone_past_time(index, past, token, caption):
        sender, msg = past[index]
        # These contacts were exchanged at the catalogue table, before closing.
        # Authored times also replace the old fallback from legacy saves.
        if token == "ch2_asya_after" and tuple(past) == (("Олег", "Это Олег с выставки."), ("Ася", "Сохранила номер :)")):
            return ("19:38", "19:39")[index]
        if token == "ch2_lera_after" and tuple(past) == (("Лера", "Вход со двора, потом вниз по лестнице."), ("Олег", "Спасибо, нашёл.")):
            return ("22:57", "23:04")[index]
        for (source, position), saved in reversed(list(phone_message_times.items())):
            if source != token and phone_thread_contacts.get(source) == caption and saved[:2] == (sender, msg):
                return saved[2]
        # Authored history and legacy saves have no recorded timestamp yet.
        key = (caption, tuple(past), index)
        return phone_history_times.get(key, phone_time(index, len(past), earlier=True))

    def phone_stamp_history(caption, past, token):
        for index in range(len(past)):
            key = (caption, tuple(past), index)
            phone_history_times[key] = phone_past_time(index, past, token, caption)

    def phone_live_time(index, token=None):
        saved = phone_message_times.get((token, index))
        if saved:
            return saved[2]
        first = phone_time(0, 1)
        hour, minute = map(int, first.split(":"))
        minutes = (hour * 60 + minute + index) % (24 * 60)
        return "{:02d}:{:02d}".format(minutes // 60, minutes % 60)

    def phone_status_time(index, token):
        current = phone_time(0, 1)
        stamp = phone_live_time(index, token)
        hour, minute = map(int, current.split(":"))
        sent_hour, sent_minute = map(int, stamp.split(":"))
        elapsed = (sent_hour * 60 + sent_minute - hour * 60 - minute) % (24 * 60)
        # Queued older messages must not wind the device clock backwards.
        return stamp if elapsed < 180 else current

    def phone_reply_geometry(options):
        """Bound the composer so long choices never squeeze the conversation."""
        size = 18
        # Match the 404px column beside the scrollbar, minus button padding.
        # Keep integer pixels: Ren'Py treats float dimensions as proportions.
        heights = [int(renpy.render(Text(item["text"], size=size, line_spacing=2, xmaximum=380), 380, 2000, 0, 0).get_size()[1]) + 16 for item in options]
        content = sum(heights) + 8 * max(0, len(options) - 1)
        height = min(content, 220)
        return 790 - height - 48, height, content, size

transform phone_bubble_enter(outgoing=False):
    alpha 0.0
    xoffset (12 if outgoing else -8)
    yoffset 9
    easeout 0.18 alpha 1.0 xoffset 0 yoffset 0

transform phone_bubble_still:
    alpha 1.0

transform phone_typing_dot(delay=0.0):
    alpha 0.35
    pause delay
    block:
        ease 0.24 alpha 1.0 yoffset -3
        ease 0.24 alpha 0.35 yoffset 0
        pause 0.24
        repeat

screen phone_typing(sender):
    hbox:
        spacing 8
        use phone_avatar(sender, 22)
        frame:
            background phone_round("#213544", 12)
            padding (14, 10)
            hbox:
                spacing 5
                for dot in range(3):
                    add phone_round("#91aabd", 3) xysize (6, 6) at phone_typing_dot(dot * 0.12)

screen phone_avatar(sender, size=36):
    $ avatar_color, avatar_icon, name_color = phone_profile(sender)
    fixed:
        xsize size ysize size
        add phone_round(avatar_color, size // 2)
        add Transform("images/messenger/" + avatar_icon + ".webp", xysize=(int(size * 0.70), int(size * 0.70))) xalign 0.5 yalign 0.5

screen phone_message(sender, msg, timestamp, message_id, photo_height=190, animate=True, can_react=True):
    $ media = phone_media_item(msg)
    $ outgoing = sender == "Олег"
    $ name_color = phone_profile(sender)[2]
    frame:
        at (phone_bubble_enter(outgoing) if animate else phone_bubble_still)
        xsize (392 if outgoing else 414) padding (12, 8) xalign (1.0 if outgoing else 0.0)
        background phone_round("#294656" if outgoing else "#213544", 11)
        vbox:
            spacing 2
            hbox:
                xfill True spacing 6
                use phone_avatar(sender, 18)
                text sender size 13 color name_color yalign 0.5
                null width 1 xfill True
                text (timestamp + (" ✓✓" if outgoing else "")) size 11 color "#8da9ba" yalign 0.5
                if can_react:
                    textbutton "+":
                        id ("reaction_add_" + message_id)
                        alt ("Выбрать реакцию — " + sender + ": " + phone_message_label(msg))
                        action SetScreenVariable("reaction_target", (sender, msg))
                        background None hover_background phone_round("#4b7189", 8)
                        padding (5, 0) text_size 16 text_color "#91aabd"
            if media and media.get("kind") == "voice":
                textbutton ("▶ Голосовое · %d сек" % media["duration"]):
                    id ("voice_" + message_id)
                    action Show("phone_voice_viewer", media_id=msg)
                    text_size 22 padding (0, 8)
                text "Нажать, чтобы слушать" size 13 color "#91aabd"
            elif media:
                button:
                    id ("photo_" + message_id)
                    alt ("Открыть фото — " + media["caption"])
                    action [Function(phone_media_open, msg), Show("phone_photo_viewer", media_id=msg)]
                    background None hover_background phone_round("#36546a", 8)
                    padding (0, 4) xsize (368 if outgoing else 390)
                    vbox:
                        spacing 5
                        add Transform(media["path"], zoom=phone_photo_scale(media, (368 if outgoing else 390, photo_height))) xalign 0.5
                        text media["caption"] size 16 color "#aac5d8"
                        text "Нажать, чтобы рассмотреть ↗" size 13 color "#91aabd"
            else:
                text msg size 20 line_spacing 2 xmaximum (368 if outgoing else 390) color "#eef3f6"
            if phone_reactions(sender, msg):
                hbox:
                    spacing 5
                    for emoji, count in phone_reactions(sender, msg):
                        $ voted = bool(phone_reaction_votes.get((sender, msg, emoji)))
                        button:
                            id ("reaction_" + message_id + "_" + emoji)
                            alt (phone_reaction_labels[emoji] + " — " + sender)
                            action Function(phone_toggle_reaction, sender, msg, emoji)
                            background phone_round("#477b9c" if voted else "#304e63", 11)
                            hover_background phone_round("#4b7189", 11)
                            padding (6, 3)
                            hbox:
                                spacing 4
                                add Transform("images/messenger/" + emoji + ".webp", xysize=(17, 17))
                                text str(count) size 13 color "#e3f0f9" yalign 0.5
