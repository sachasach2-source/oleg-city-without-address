# Painted venue map. Room logic and saved visits remain in week7_party_state.
image w7 venue map = Transform("images/week7/venue-map-v21.webp", xysize=(1070,650), fit="contain")

init python:
    # Fresh architecture: central hall, four non-through side rooms, south foyer.
    # Source rectangles follow the 1586x992 illustration, fitted without stretching.
    def week7_map_area(rect,caption,width):
        scale=650.0/992.0
        inset=(1070-1586*scale)/2.0
        x,y,w,h=rect
        box=(int(round(x*scale+inset)),int(round(y*scale)),int(round(w*scale)),int(round(h*scale)))
        label=(int(round(caption[0]*scale+inset))-box[0],int(round(caption[1]*scale))-box[1],width,34)
        return box,label
    week7_map_hotspots = {
        "music":week7_map_area((900,30,265,215),(910,210),155),
        "dance":week7_map_area((610,245,345,355),(650,560),190),
        "table":week7_map_area((610,30,340,205),(665,175),155),
        "bluff":week7_map_area((60,55,340,300),(75,325),200),
        "garden":week7_map_area((1190,55,330,300),(1195,325),220),
        "games":week7_map_area((60,390,340,260),(75,610),180),
        "quiet":week7_map_area((1190,390,330,260),(1215,620),245),
        "leave":week7_map_area((435,650,575,160),(665,755),180),
        "oracle":week7_map_area((1200,440,145,175),(1200,555),95)
    }
    week7_map_previews = dict(
        music="images/week7/party-hall-v7.webp",dance="images/week7/party-hall-v7.webp",
        table="images/week7/party-hall-v7.webp",games="images/week7/games-room-v4.webp",
        quiet="images/week7/quiet-room-v5.webp",leave=Transform("images/week7/venue-map-v21.webp",crop=(405,630,790,265)),
        bluff="images/week7/devils-dice-table-v1.webp",garden="images/week7/pumpkin-garden-v3.webp",
        oracle="images/week7/oracle-table-v3.webp")

    class Week7MapPlate(renpy.Displayable):
        def __init__(self,w,h,active=False,available=True,**kwargs):
            super(Week7MapPlate,self).__init__(**kwargs)
            self.w,self.h,self.active,self.available=w,h,active,available
        def render(self,width,height,st,at):
            w,h=self.w,self.h
            r=renpy.Render(w,h);c=r.canvas()
            # Ink labels with clipped corners leave the miniature itself uncovered.
            shape=[(5,0),(w-5,0),(w,h//8),(w,h-5),(w-5,h),(5,h),(0,h-5),(0,5)]
            c.polygon("#15131bef" if self.active else "#10131ce8",shape)
            c.polygon("#e6bc7d" if self.active else "#80694c" if self.available else "#45444b",shape,1)
            c.line("#e8c68a" if self.active else "#a48c67",(10,1),(w-10,1),1)
            return r

    class Week7MapFocus(renpy.Displayable):
        def render(self,width,height,st,at):
            w,h=int(width),int(height)
            r=renpy.Render(w,h);c=r.canvas()
            # Fine corner marks, never a solid rectangle over the illustration.
            for x,y,sx,sy in ((3,3,1,1),(w-4,3,-1,1),(3,h-4,1,-1),(w-4,h-4,-1,-1)):
                c.line("#f1d2a2cc",(x,y),(x+sx*20,y),2)
                c.line("#f1d2a2cc",(x,y),(x,y+sy*15),2)
            return r

screen week7_party_map():
    modal True
    default selected = ""
    key "game_menu" action ShowMenu("save")
    add Solid("#080f18")
    text "ХЕЛЛОУИН  /  ПЕТЕРБУРГ" xpos 58 ypos 36 size 15 color "#c7a577" kerning 2
    text ("Куда пойдём?" if week7_party_guest() else "Куда пойти?"):
        xpos 56 ypos 66 size 37 color "#f1e4d2"
    text "НА ВЕЧЕРИНКЕ" xpos 1369 ypos 36 size 13 color "#a99379" kerning 1
    text chapter3_time(week7_clock) xpos 1370 ypos 61 size 36 color "#ebc797"
    add Solid("#72583d") xpos 58 ypos 124 xsize 1480 ysize 1
    add "w7 venue map" xpos 35 ypos 145
    for key,layout in week7_map_hotspots.items():
        $ bx,by,bw,bh=layout[0]
        $ lx,ly,lw,lh=layout[1]
        $ available=week7_venue_available(key)
        button:
            id "w7_room_"+key
            xpos bx+35 ypos by+145 xsize bw ysize bh padding (0,0)
            background None
            hover_background Week7MapFocus()
            action (Return(key) if available else SetScreenVariable("selected",key))
            hovered SetScreenVariable("selected",key)
            unhovered SetScreenVariable("selected","")
            fixed:
                xsize bw ysize bh
                add Week7MapPlate(lw,lh,selected==key,available) xpos lx ypos ly
                vbox:
                    xpos lx+13 ypos ly+7 xsize lw-26 spacing 2
                    text week7_venue_places[key]["title"] size 19 color ("#f5e3cb" if available or selected==key else "#a5a0a4")
    # Sanitary rooms are part of the physical venue, not another story activity.
    text "WC" xpos 773 ypos 632 size 18 color "#e9d5b6"
    frame:
        xpos 1140 ypos 150 xsize 410 ysize 650 padding (25,24)
        background Solid("#151a25")
        vbox:
            spacing 16
            text ("ВЫБРАННОЕ МЕСТО" if selected else "ОСМОТРЕТЬСЯ") size 12 color "#c4a373" kerning 2
            text (week7_venue_places[selected]["title"] if selected else "Вечер в октябре") size 28 color "#f1e1c7"
            add Transform(week7_map_previews.get(selected,"images/week7/party-hall-v7.webp"),xysize=(360,203),fit="contain")
            add Solid("#6c533e") xsize 360 ysize 1
            text week7_venue_description(selected) size 19 color "#c8c9ce" xmaximum 360
            if week7_party_guest():
                text (week4_names[week7_party_guest()]+" рядом.") size 18 color "#e0c29e"
            elif week7_party.get("guest_departed"):
                text "Спутница уже уехала. Олег остался с коллегами." size 18 color "#b7a68f"
            if week7_party_guest()=="lera":
                text "Лере выезжать в девять." size 18 color "#c6a383"
    text "Нажмите на место, куда хочется пойти." xpos 61 ypos 829 size 17 color "#a59b90"
    textbutton "Сохранить":
        xpos 1434 ypos 826 padding (0,0)
        background None hover_background None
        text_size 16 text_color "#a59b90" text_hover_color "#eac391"
        action ShowMenu("save")
