# Plans are remembered as people, promises and wishes; clock state stays in chapter3_state.
init python:
    def chapter3_planning_people(revise=False):
        people = ["nika", "asya", "lera", "varya"] + (["keys"] if chapter3_housing.startswith("pending_") else [])
        return [p for p in people if (chapter3_plans.get(p, {}).get("status", "idea") != "idea") == revise]

    def chapter3_write_intent(person):
        plan = chapter3_plans.get(person, {})
        if plan.get("status") == "confirmed":
            return {"nika": "С Никой уже договорились. Хочу изменить планы.",
                    "asya": "С Асей уже договорились. Надо поменять время.",
                    "lera": "Обед с Лерой назначен. Хочу пересогласовать встречу.",
                    "varya": "Варе уже ответил. Хочу поменять договорённость.",
                    "keys": "Передача ключей назначена. Нужно другое время."}[person]
        if plan.get("status") in ("canceled", "deferred", "busy"):
            if person == "nika" and plan.get("status") == "busy":
                return "Ника отказалась от встречи. Всё же спрошу про другой день."
            if person == "nika" and plan.get("status") == "deferred":
                return "С Никой отложили встречу. Попробую договориться заново."
            return {"nika": "Передумал насчёт Ники. Попробую договориться заново.",
                    "asya": "Всё-таки хочу увидеть Асю. Напишу ещё раз.",
                    "lera": "Хочу вернуться к разговору с Лерой.",
                    "varya": "Передумал. Напишу Варе про выходные ещё раз.",
                    "keys": "Хочу снова договориться о ключах."}[person]
        if person == "nika":
            if chapter3_tasks.get("guitar") == "pending":
                return "Написать Нике. Я ей ещё рифф обещал."
            if chapter3_previous.get("origin") == "friendship":
                return "Написать Нике. Хочется поиграть вместе."
            return "Написать Нике. Хочу снова её увидеть."
        if person == "asya":
            return "Хочу ещё поговорить с Асей. Напишу ей."
        if person == "lera":
            return "Узнать, выспалась ли Лера. И позвать поесть."
        if person == "varya":
            return "Написать Варе. Интересно, как там её зин."
        return "Спросить про ключи. Хочу уже зайти к себе."

    def chapter3_meeting_memory(person):
        plan = chapter3_plans[person]
        when = ("в субботу", "в воскресенье", "на следующей неделе")[min(plan["day"], 2)]
        if plan["time"] is not None:
            when += " в " + chapter3_time(plan["time"])
        what = {"jam":"поиграть с Никой", "album":"послушать пластинки с Никой", "shop":"зайти с Никой в музыкальный магазин", "coffee":"встретиться с Никой за кофе", "photos":"посмотреть фотографии с Асей", "market":"походить с Асей по барахолке", "lunch":"поесть с Лерой", "print":"помочь Варе с тиражом", "walk":"погулять с Варей по дворам", "keys":"забрать ключи"}[plan["kind"]]
        return when.capitalize() + " собираюсь " + what

    def chapter3_plan_thought():
        conflicts = chapter3_schedule_conflicts()
        if conflicts:
            first, second = conflicts[0]
            return chapter3_meeting_memory(first) + ". " + chapter3_meeting_memory(second) + ". А про дорогу я опять забыл. Лучше сейчас кому-нибудь написать."
        plan = chapter3_plans.get(chapter3_current, {})
        if plan.get("status") == "confirmed":
            agreed = sorted((p for p in chapter3_plans if chapter3_plans[p].get("status") == "confirmed"), key=lambda p: (chapter3_plans[p]["day"], chapter3_plans[p]["time"]))
            return "С этим договорились. " + ". ".join(chapter3_meeting_memory(p) for p in agreed[:2]) + "."
        if plan.get("status") in ("canceled", "deferred", "busy"):
            return "Пока так."
        if chapter3_tasks.get("guitar") == "pending":
            return "Нике я рифф обещал. А вообще хочется увидеться и поиграть, чтобы слышать друг друга без телефона."
        return "На выходных будет тепло. Хочется куда-нибудь выбраться. И с кем-нибудь, с кем не надо изображать идеальный вечер."

    def chapter3_go_intent(person):
        kind = chapter3_plans[person]["kind"]
        if person == "nika":
            return {"jam":"Хочу поиграть с Никой. Пойду на репетицию.", "album":"Пойти слушать пластинки с Никой.", "shop":"Зайти с Никой в музыкальный магазин.", "coffee":"Пойти за кофе с Никой. В этот раз доберусь."}[kind]
        if person == "asya":
            return "Хочу посмотреть фотографии с Асей." if kind == "photos" else "Пойти с Асей на барахолку. Интересно, что найдём."
        if person == "lera":
            return "Пойти к Лере. Хочется спокойно поесть вдвоём."
        if person == "varya":
            return "Заглянуть к Варе в типографию." if kind == "print" else "Пойти с Варей искать дворы."
        return "Забрать ключи. Очень хочется уже своего угла."

    def chapter3_day_conflict():
        pending = chapter3_pending()
        if not pending:
            return False
        first = pending[0]
        if chapter3_clock + chapter3_travel(chapter3_area_for(first)) > chapter3_plans[first]["time"] + 10:
            return True
        return any(a == first for a, b in chapter3_schedule_conflicts())

    def chapter3_day_options():
        pending = chapter3_pending()
        if pending:
            if not chapter3_day_conflict():
                return [(chapter3_go_intent(pending[0]), pending[0])]
            return ([(chapter3_go_intent(p), p) for p in pending]
                    + [("Надо предупредить и перенести встречу.", "reschedule")])
        options = []
        if chapter3_marta_evening_free():
            options.append(("Вечер освободился. Хочу ещё пройтись по Ваське.", "free_evening"))
        options.append((chapter3_finish_intent(), "finish"))
        return options

    def chapter3_on_the_way(person):
        kind = chapter3_plans[person]["kind"]
        return {"jam": "Пора к Нике. Пальцы уже соскучились по гитаре.",
                "album": "Пора в магазин пластинок. Интересно, что Ника выберет первой.",
                "shop": "Пойду к музыкальному. С Никой там и встретимся.",
                "coffee": "Пора выходить. Ника уже наверняка присматривает столик.",
                "photos": "Пойду в галерею. Хочется посмотреть фотографии с Асей.",
                "market": "Пора на барахолку. Ася обещала показать свои места.",
                "lunch": "Пора к Лере. Поесть вдвоём — хороший план.",
                "print": "Пора в типографию. Посмотрим, каким получился Варин кот на бумаге.",
                "walk": "Пойду к Варе. Сегодня дворы выбирает она.",
                "keys": "Пойду за ключами. Хорошо бы сегодня уже распаковаться."}[kind]

    def chapter3_day_thought():
        pending = chapter3_pending()
        if not pending:
            if chapter3_marta_evening_free():
                return "На сегодня договорённости закончились. И я ещё успеваю куда-нибудь зайти, а не только вернуться домой."
            return "Сегодня больше никого не ждёт мой подвиг с пересадками. Можно ещё походить для себя."
        person = pending[0]
        plan = chapter3_plans[person]
        if chapter3_clock + chapter3_travel(chapter3_area_for(person)) > plan["time"] + 10:
            return chapter3_meeting_memory(person) + ". Только я уже не успеваю к этому времени. Надо хотя бы честно предупредить."
        if chapter3_day_conflict():
            return "Встречи стоят слишком близко. Придётся поменять время или решить, к кому ехать сначала."
        reminder = chapter3_plans_reminder(person)
        return chapter3_on_the_way(person) + (" " + reminder if reminder else "")

    def chapter3_plans_reminder(current=""):
        # Confirmed people and keys only; no canceled plans, future days or ETA UI.
        plans = [p for p in chapter3_pending() if p != current]
        words = {"jam":"с Никой договорились поиграть", "album":"с Никой слушаем пластинки",
            "shop":"встречаемся с Никой у музыкального", "coffee":"встречаемся с Никой за кофе",
            "photos":"Ася ждёт у выставки", "market":"с Асей идём на барахолку",
            "lunch":"встречаемся с Лерой поесть", "print":"обещал помочь Варе с тиражом",
            "walk":"с Варей идём по дворам", "keys":"агент ждёт на передаче ключей"}
        return " ".join(("Ещё в " if i == 0 else "А в ") + chapter3_time(chapter3_plans[p]["time"]) + " " + words[chapter3_plans[p]["kind"]] + "." for i,p in enumerate(plans))

    def chapter3_finish_intent():
        if chapter3_pending():
            return "На сегодня хватит. Напишу, что уже не приеду."
        return "Сегодня уже никуда не тороплюсь." if chapter3_day == 0 else "Хватит бегать. Хочу остаток вечера для себя."

label ch3_remember_plans(person):
    $ chapter3_reminder = chapter3_plans_reminder(person)
    if chapter3_reminder:
        mind "[chapter3_reminder]"
    return
