# Saved blocking changes are tied to actions and particular lines, not sentiment.
default cast_direction_scene = ""
default cast_direction = "wide"

init -7 python:
    cast_direction_layouts = {
        "closer": {"oleg": (430, 32, 980, None), "nika": (1110, 32, 980, None), "varya": (1140, 32, 980, None)},
        "work": {"oleg": (350, 55, 920, None), "varya": (1240, 55, 920, None)},
        "appeal": {"oleg": (350, 55, 920, None), "varya": (1230, 30, 1120, "strap")},
        "leaving": {"oleg": (350, 30, 1120, "depart"), "varya": (1230, 30, 1120, "strap")},
        "defend": {"oleg": (340, 55, 920, None), "asya": (1240, 55, 920, None)},
        "listen": {"oleg": (430, 45, 950, None), "asya": (1130, 45, 950, None)},
        "near": {"oleg": (430, 45, 950, None), "nika": (1120, 45, 950, None), "lera": (1130, 45, 950, None)},
        "apart": {"oleg": (340, 55, 920, None), "lera": (1280, 55, 920, None)},
    }
    cast_direction_cues = {
        ("concert", "nika", "А где ты сейчас живёшь?"): "closer",
        ("varya reaction", "varya", "Серьёзно? Я эту страницу уже три раза собиралась выкинуть."): "closer",
        ("ch3 print", "varya", "Я попросила темнее чёрный. Теперь кот почти исчез."): "work",
        ("ch3 street varya", "varya", "Пойдём ещё пройдёмся? Я тут двор знаю. Минут двадцать. И я тебе кое-что рассказать хотела."): "appeal",
        ("ch3 street varya", "varya", "Ну хотя бы двадцать минут. Мы только нормально начали говорить."): "leaving",
        ("ch3 street varya", "varya", "А со мной ещё чуть-чуть нельзя? Я же не экскурсию предлагаю."): "leaving",
        ("ch3 street varya", "varya", "Да? Тогда туда. У меня ещё одна арка есть."): "wide",
        ("ch3 street varya", "varya", "Ладно. Только скажи в следующий раз раньше. Я уже всё придумала."): "wide",
        ("ch3 street nika", "nika", "Я вечером ещё свободна. Можно не разбегаться сразу."): "near",
        ("ch3 street asya", "asya", "Я же объясняю. Я не думаю, что ты обязан..."): "defend",
        ("ch3 cafe asya", "asya", "Я же объясняю. Я не думаю, что ты обязан..."): "defend",
        ("ch3 street asya", "asya", "А про паркомат... Ты потом разобрался или с тех пор туда не ездишь?"): "listen",
        ("ch3 street asya", "asya", "А ты вообще любишь водить? Или только доехать куда-нибудь?"): "listen",
        ("ch3 cafe asya", "asya", "А про паркомат... Ты потом разобрался или с тех пор туда не ездишь?"): "listen",
        ("ch3 cafe asya", "asya", "А ты вообще любишь водить? Или только доехать куда-нибудь?"): "listen",
        ("ch3 street lera", "lera", "Блин. А я только... Ладно."): "apart",
        ("ch3 street lera", "lera", "Вот этот."): "near",
    }

    def cast_direct(direction):
        global cast_direction_scene, cast_direction
        cast_direction_scene, cast_direction = cast_background_key(), direction

    def cast_direction_data():
        return cast_direction_layouts.get(cast_direction, {}) if cast_direction_scene == cast_background_key() else {}

    def cast_actor_pose(person):
        return cast_direction_data().get(person, (None, None, None, None))[3]

    def cast_choice_layout():
        key = cast_background_key()
        if key in ("w6 food seated", "w6 food seated nika", "w6 food seated lera", "w6 food joy", "w6 food messy", "w6 food messy nika", "w6 food messy lera", "w6 food messy joy"):
            return "grid"
        if key == "w5 personal lera":
            return "left"
        if key.startswith("w5 personal "):
            return "grid"
        if key == "w5 marta bakery":
            return "grid"
        if key.startswith("w5 affection "):
            return "grid"
        if key.startswith("w5 kiss "):
            return "grid"
        if key.startswith("housing "):
            return "grid"
        if key in ("ch3 print", "ch3 market"):
            return "grid"
        if key in ("ch3 varya cafe", "w4 nika farewell", "w4 nika steps apart", "w4 nika steps close", "w4 dinner", "w4 lera sofa", "w4 lera awkward", "w4 lera touch", "w4 lera kiss", "w4 asya kiss"):
            return "grid"
        if key == "ch3 street varya":
            return "gap"
        return None

    def cast_choice_prompt():
        if cast_background_key().startswith("w6 food "):
            return ""
        if cast_background_key() in ("w4 lera sofa", "w4 lera awkward"):
            return "Лера смотрит на него."
        say = renpy.get_screen("say")
        return say.scope.get("what", "") if say else ""

    for key, path, tone in [
        ("ch3 street varya", "images/chapter3/vaska-courtyard-shade-v1.webp", "shade"),
        ("ch3 street asya", "images/chapter3/vaska-courtyard-shade-v1.webp", "shade"),
        ("ch3 street nika", "images/chapter3/nika-record-lane-v1.webp", "warmday"),
        ("ch3 street lera", "images/chapter3/lera-bakery-sadovaya-v1.webp", "shade"),
        ("ch3 print", "images/chapter3/ch3-print-workday-v3.webp", "workday"),
    ]:
        old = cast_stages[key]
        cast_stages[key] = (path, old[1], old[2], tone)
    for key in ("ch3 market", "ch3 market solo", "ch3 photos"):
        old = cast_stages[key]
        cast_stages[key] = (old[0], old[1], old[2], "windowday")

screen cast_compact_choice(items, layout):
    frame:
        xpos (54 if layout in ("grid", "left") else 590) ypos 854 yanchor 1.0
        xsize (1492 if layout == "grid" else 570) padding (2, 2) background None
        frame:
            xfill True padding (16, 13) background context_panel("choice")
            vbox:
                spacing 10 xfill True
                if cast_choice_prompt():
                    text cast_choice_prompt() size story_text_size(22) color "#e9d4b0" xmaximum (1440 if layout == "grid" else 520)
                if layout == "grid":
                    $ choice_rows = (len(items) + 1) // 2
                    grid 2 choice_rows:
                        xfill True spacing 10
                        for item in items:
                            button:
                                action item.action xfill True padding (16, 10)
                                background context_panel("choice_button") hover_background context_panel("choice_button",True)
                                text item.caption size story_text_size(23) color "#162536" hover_color "#101c29" xmaximum 660
                        if len(items) % 2:
                            null
                else:
                    for item in items:
                        button:
                            action item.action xfill True padding (14, 10)
                            background context_panel("choice_button") hover_background context_panel("choice_button",True)
                            text item.caption size story_text_size(23) color "#162536" hover_color "#101c29" xmaximum 510
