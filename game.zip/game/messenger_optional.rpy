# Optional conversations are frozen at delivery. Opening an archive never
# creates an answer; the original story call continues without a decision.
default messenger_pending = {}

init 95 python:
    def messenger_enqueue(messages, caption, conversation=None, dialogue=None, past=None, completion=None):
        token = "optional_" + str(conversation or (caption, tuple(messages)))
        if token in messenger_pending:
            return token
        frozen = copy.deepcopy(dialogue if dialogue is not None else phone_dialogues.get(conversation, {}))
        if not frozen:
            frozen = {"start": dict(messages=[], options=[])}
        if conversation == "ch3_friends_morning":
            # Reading silently is the back button, not a message promising a
            # viewing that may already be over when this chat is opened.
            frozen["start"]["options"] = [o for o in frozen["start"]["options"] if o["id"] != "quiet"]
        transcript, decisions, node = phone_conversation_state(token if frozen else None, messages, frozen)
        messenger_pending[token] = dict(caption=caption, messages=list(messages), dialogue=frozen,
            past=list(past or []), chapter=messenger_chapter(), done=False, completion=copy.deepcopy(completion or {}))
        phone_stamp_history(caption, list(past or []), token)
        phone_stamp_messages(token, transcript, caption)
        messenger_note_delivery(token, caption, transcript)
        messenger_notify(caption, transcript)
        return token

    def messenger_pending_for(caption):
        return [token for token, item in messenger_pending.items() if not item["done"] and messenger_caption(item["caption"]) == messenger_caption(caption)]

    def messenger_reset_optional_history():
        # Explicit new chapter histories must not inherit drafts from another
        # history. Normal continuation and save loading never call this.
        messenger_pending.clear()
        messenger_deliveries.clear()
        messenger_views.clear()
        for records in (phone_reply_log, phone_message_times):
            for key in list(records):
                if str(key[0]).startswith("optional_"):
                    del records[key]
        for token in list(phone_thread_contacts):
            if str(token).startswith("optional_"):
                del phone_thread_contacts[token]

    def messenger_week7_pending(caption):
        if messenger_chapter() != 7:
            return []
        person = next((p for p, name in week4_names.items() if name == caption), caption)
        return week7_inbox_pending(person)

    def messenger_contact_preview(caption, rows, active=False, pending=False):
        if messenger_pending_for(caption):
            return "Можно ответить"
        waiting = messenger_week7_pending(caption)
        if waiting:
            return phone_message_label(waiting[-1]["messages"][-1][1]) if waiting[-1]["messages"] else "Можно написать"
        if active and pending:
            return "Ждёт ответа"
        return phone_message_label(rows[-1][1]) if rows else "Пока нет сообщений"

    def messenger_session_topics(caption):
        topics = []
        for token in reversed(messenger_pending_for(caption)):
            item = messenger_pending[token]
            incoming = item["messages"] + item["dialogue"].get("start", {}).get("messages", [])
            preview = next((phone_message_label(message) for sender, message in incoming if sender != "Олег"), "Можно написать")
            stamp = phone_message_times.get((token, 0), ("", "", ""))[2]
            earlier = item.get("stamp_positions", {}).get(0, messenger_clock_position()) // 1440 < messenger_clock_position() // 1440
            topics.append(dict(kind="optional", token=token, preview=preview, stamp=("Ранее · " if earlier else "") + stamp))
        for item in reversed(messenger_week7_pending(caption)):
            topics.insert(0, dict(kind="week7", token=item["key"], preview=item.get("preview") or "Новые сообщения", stamp=("Ранее · " if item["day"] < week7_day else "") + chapter3_time(item["time"])))
        return topics

    def messenger_open_session(caption=None):
        current = renpy.get_screen("phone_thread")
        if current:
            scope = current.scope
            if not scope["inbox_mode"] and not scope["instant"]:
                if caption is None or messenger_caption(caption) == messenger_caption(scope["caption"]):
                    messenger_switch("list" if caption is None else "thread", caption)
                    return
            elif scope["inbox_mode"]:
                # Already inside the session. Its back button returns to the list;
                # do not recursively create a second phone_thread screen.
                return
        if renpy.get_screen("messenger_session_list") or renpy.get_screen("messenger_topic_picker"):
            return
        renpy.hide_screen("messenger_browser")
        renpy.hide_screen("messenger_received_notice")
        renpy.call("messenger_session", caption, from_current=True)

    def messenger_complete_optional(token):
        item = messenger_pending[token]
        rows, decisions, node = phone_conversation_state(token if item["dialogue"] else None, item["messages"], item["dialogue"])
        if node is not None:
            return
        item["done"] = True
        meta = item["completion"]
        # A disclosure is learned only after the corresponding sent reply.
        if meta.get("fragment") and ("start", "date") in decisions:
            for relations in (week4_relations, week5_relations, week6_relations, week7_relations):
                relation = relations.get(meta["person"])
                if relation:
                    relation.setdefault("facts", {})["friends_fragment"] = meta["fragment"]
        messenger_mark_seen(item["caption"])

    def messenger_required_reason(token, caption):
        token = str(token)
        if caption in ("Агент", "Просмотр квартиры"):
            return "Нужно закончить разговор о квартире, прежде чем идти дальше."
        if any(word in token for word in ("plan", "invite", "confirm", "date", "offer")):
            return "Сначала договориться о встрече — от ответа зависят дальнейшие планы."
        if "rita" in token or caption == "Четверг точно":
            return "Нужно ответить на условия, прежде чем продолжать это дело."
        return "Олег открыл этот разговор, чтобы ответить. Остальные чаты можно посмотреть здесь же."

    def messenger_clock_position():
        chapter = messenger_chapter()
        day = {3:chapter3_day, 4:week4_day, 5:week5_day, 6:week6_day, 7:week7_day}.get(chapter, 0)
        if chapter == 3 and "пятниц" in place_name.lower():
            day = -1
        hour, minute = map(int, phone_time(0, 1).split(":"))
        return (chapter * 32 + day) * 1440 + hour * 60 + minute

    _messenger_optional_stamp = phone_stamp_messages
    def phone_stamp_messages(token, messages, caption=None):
        if token not in messenger_pending:
            return _messenger_optional_stamp(token, messages, caption)
        if caption is not None:
            phone_thread_contacts[token] = caption
        cursor = messenger_clock_position()
        positions = messenger_pending[token].setdefault("stamp_positions", {})
        for index, (sender, message) in enumerate(messages):
            key = (token, index)
            saved = phone_message_times.get(key)
            if not saved or saved[:2] != (sender, message):
                phone_message_times[key] = (sender, message, chapter3_time(cursor % 1440))
                positions[index] = cursor
            cursor = max(cursor, positions.get(index, cursor) + 1)
        for key in list(phone_message_times):
            if key[0] == token and key[1] >= len(messages):
                del phone_message_times[key]
                positions.pop(key[1], None)

label messenger_optional(messages, caption="Мои шлюхи", conversation=None, dialogue=None, past=None, completion=None):
    if messenger_enabled():
        $ messenger_enqueue(messages, caption, conversation, dialogue, past, completion)
        return []
    call screen phone_thread(messages, caption=caption, conversation=conversation, dialogue=dialogue, past=past)
    return _return

label week4_optional_chat(person, key, incoming, options, completion=None):
    if not messenger_enabled():
        call week4_chat(person, key, incoming, options)
        return _return
    $ messenger_optional_token = "w4_{}_{}_{}".format(person, key, week4_chat_index)
    $ week4_chat_index += 1
    $ messenger_optional_dialogue = week4_phone_dialogue(incoming, options)
    if key == "monday":
        $ next(o for o in messenger_optional_dialogue["start"]["options"] if o["id"] == "work")["messages"].append(("Олег", "Поем. Спасибо, мам."))
    call messenger_optional([], caption=week4_names[person], conversation=messenger_optional_token, dialogue=messenger_optional_dialogue, past=week4_history.get(person, [])[-2:], completion=completion)
    return None

label messenger_session(initial_contact=None):
    $ messenger_session_contact = initial_contact
label .contacts:
    while True:
        if messenger_session_contact is None:
            call screen messenger_session_list
            if _return == "__close__":
                return
            $ messenger_session_contact = _return
        $ messenger_session_archive = isinstance(messenger_session_contact, tuple)
        if messenger_session_archive:
            $ messenger_session_contact = messenger_session_contact[1]
        $ messenger_mark_seen(messenger_session_contact)
        $ messenger_session_topics_now = messenger_session_topics(messenger_session_contact)
        if len(messenger_session_topics_now) > 1:
            call screen messenger_topic_picker(messenger_session_contact, messenger_session_topics_now)
            if _return[0] == "close":
                return
            if _return[0] == "contacts":
                $ messenger_session_contact = None
                jump .contacts
            $ messenger_session_kind, messenger_session_token = _return
        elif messenger_session_topics_now:
            $ messenger_session_kind, messenger_session_token = messenger_session_topics_now[0]["kind"], messenger_session_topics_now[0]["token"]
        else:
            $ messenger_session_kind, messenger_session_token = "history", ""
        if messenger_session_kind == "optional":
            $ messenger_session_item = messenger_pending[messenger_session_token]
            $ messenger_mark_seen(messenger_session_contact)
            call screen phone_thread(messenger_session_item["messages"], caption=messenger_session_item["caption"], conversation=messenger_session_token, dialogue=messenger_session_item["dialogue"], past=messenger_session_item["past"], inbox_mode=True)
            $ messenger_complete_optional(messenger_session_token)
        elif messenger_session_kind == "week7":
            call week7_phone(("task", messenger_session_token), return_after_task=True)
        else:
            $ messenger_session_rows = messenger_threads().get(messenger_session_contact, [])
            call screen phone_thread([(sender, message) for sender, message, stamp in messenger_session_rows], caption=messenger_session_contact, past=[], instant=True, inbox_mode=True, archive_times=[stamp for sender, message, stamp in messenger_session_rows])
        $ messenger_session_contact = None

screen messenger_session_list():
    on "show" action Function(soundscape_reading, True)
    on "hide" action Function(soundscape_reading, False)
    modal True
    zorder 150
    use messenger_contacts(session=True)
    key "game_menu" action Return("__close__")

screen messenger_topic_picker(caption, topics):
    modal True
    zorder 150
    on "show" action Function(soundscape_reading, True)
    on "hide" action Function(soundscape_reading, False)
    add Solid("#071019a8")
    add phone_shell() xpos 1050 ypos 26
    fixed:
        xpos 1050 ypos 26 xsize 500 ysize 844
        textbutton "←" id "messenger_topics_back" action Return(("contacts", None)) xpos 18 ypos 57 padding (8,4) text_size 26
        text caption xpos 75 ypos 65 size 27 color "#e4e8e7" xmaximum 330
        textbutton "×" id "messenger_topics_close" action Return(("close", None)) xpos 428 ypos 57 padding (8,4) text_size 28
        text "На что ответить?" xpos 30 ypos 115 size 19 color "#8fa6b3"
        viewport:
            xpos 25 ypos 155 xsize 452 ysize 555
            mousewheel True draggable True scrollbars "vertical"
            vscrollbar_xsize 12 side_spacing 10 vscrollbar_unscrollable "hide"
            vbox:
                spacing 12 xsize 420
                for topic in topics:
                    button:
                        id ("messenger_topic_" + topic["kind"] + "_" + topic["token"])
                        action Return((topic["kind"], topic["token"]))
                        xsize 420 padding (16,14) background phone_round("#193344",12)
                        vbox:
                            spacing 9 xsize 385
                            text topic["stamp"] size 14 color "#9eb2bf"
                            text topic["preview"] size 20 color "#e4e8e7" xmaximum 385
                            text "Ответить →" size 17 color "#e4c698"
        textbutton "К чатам" id "messenger_topics_history" action Return(("contacts", None)) xpos 25 ypos 745 xsize 450 text_size 20 text_xalign .5
    key "game_menu" action Return(("contacts", None))
