# Chapter-four intimacy is an event in this playthrough, never a score reward.
init python:
    def week4_can_kiss(person):
        relation = week4_relations[person]
        return (person in ("nika", "lera", "asya")
                and not week4_plan_short
                and week4_can_touch(person)
                and relation["outcome"] == "warm"
                and not week4_unresolved(person, True))

    def week4_remember_kiss(person, moment):
        # Called only after the other person's affirmative response is played.
        global week4_good_moment
        week4_relations[person]["new_touch"] = "kiss"
        week4_relations[person]["facts"]["kissed_chapter4"] = True
        week4_event(person, "mutual_kiss", moment)
        week4_good_moment = moment

label week4_nika_kiss:
    scene bg w4 nika steps apart with dissolve
    "Ника уже повернулась к метро, но носком ботинка задевает его ботинок и остаётся."
    n "Я сейчас уйду."
    o "Вижу. Уже довольно давно."
    "Она смеётся, берёт его за край рукава и подтягивает к себе. Олег останавливается совсем близко."
    n "Вот так лучше."
    menu:
        "Поцеловать её.":
            "Он наклоняется. Ника сама подаётся навстречу."
            scene bg w4 nika steps close with dissolve
            "Её пятки отрываются от плитки. Олег придерживает Нику за талию; она целует его ещё раз, уже не торопясь к метро."
            $ week4_remember_kiss("nika", "целовались под козырьком у кафе")
            n "Так."
            o "Что?"
            n "Ничего. Я забыла, что хотела сказать."
            menu:
                "Остаться рядом ещё немного.":
                    "Олег не убирает руку. Они стоят, пока по козырьку стучит вода. Ника тихо смеётся ему в воротник."
                    n "Мне теперь в метро с таким лицом ехать."
                    o "Мне тоже."
                    $ week4_event("nika", "lingered_after_kiss")
                "Проводить её до входа в метро.":
                    n "Пойдём. Только я в другую сторону еду."
                    o "До турникетов дойду."
                    $ week4_event("nika", "walked_to_metro")
        "Прижать к себе. «Давай пока так».":
            scene bg w4 nika goodbye hug with dissolve
            n "Давай."
            "Ника обнимает его. Он чувствует тепло её щеки у воротника и запах мокрой кожанки."
            $ week4_relations["nika"]["new_touch"] = "hug"
            $ week4_event("nika", "chose_hug")
    scene bg w4 nika farewell with dissolve
    n "Напиши, как будешь дома."
    o "И ты."
    $ week4_relations["nika"]["home_due"] = True
    return

label week4_lera_kiss:
    "Лера гладит большим пальцем его ладонь. На секунду открывает рот — и только улыбается."
    menu:
        "Я хочу тебя поцеловать.":
            l "Угу."
            "Олег приближается, не отпуская её руки. Лера приподнимает лицо."
            scene bg w4 lera kiss with dissolve
            "Она целует его сначала осторожно, потом сама тянет ближе за футболку. Олег придерживает её за локоть."
            $ week4_remember_kiss("lera", "целовались на Лерином диване под тихую музыку")
            "Они отстраняются, чтобы перевести дух. Из кухни звякает ложка. Лера замирает, прислушиваясь."
            l "Я вообще-то трек тебе показывала."
            o "Я слушаю."
            l "Врёшь."
            menu:
                "Вру. Иди сюда.":
                    "Она сама возвращается к нему. Музыка заканчивается; никто не тянется включать следующую."
                    $ week4_event("lera", "returned_kiss")
                "Дослушаем следующий? Я сегодня всё-таки домой.":
                    l "Да. Я помню."
                    "Она остаётся рядом, плечом к его плечу. На этот раз паузу ничем не заполняет."
                    $ week4_event("lera", "kept_home_agreement")
            scene bg w4 lera touch with dissolve
        "Посидеть так. Не хочется торопиться.":
            o "Мне хорошо. Давай пока просто посидим."
            l "Можно."
            "Она удобнее устраивает их руки на диване и кивает на колонку."
            l "Вот теперь слушай. Тут дальше красиво."
            $ week4_event("lera", "chose_hand_only")
    return

label week4_asya_kiss:
    "Ася выключает свет над дальней стеной, но у выключателя не остаётся. Возвращается к столу, к нему."
    a "Ты сейчас на меня смотришь или на то, что за мной?"
    menu:
        "На тебя. Можно я тебя поцелую?":
            a "Да."
            "Она берёт его за руку и подходит вплотную."
            scene bg w4 asya kiss with dissolve
            "Очки задевают его щёку. Ася чуть поворачивает голову, и они целуются снова. У неё тёплые пальцы; она сжимает его руку, когда он уже собирается отстраниться."
            $ week4_remember_kiss("asya", "целовались с Асей в пустой галерее")
            a "Я сейчас вспомнила, что тут камера."
            o "Работает?"
            a "Нет. Но на секунду стало интересно."
            menu:
                "Поцеловать её ещё раз.":
                    "Ася сама тянется к нему. Ключи в её свободной руке тихо звенят о край стола."
                    $ week4_event("asya", "returned_kiss")
                "Сжать её ладонь. «Пойдём? А то останемся до утра».":
                    a "Пойдём. Мне ещё сигнализацию включать."
                    $ week4_event("asya", "left_together")
            scene bg w4 asya with dissolve
            "Они возвращаются за куртками. Ася два раза проверяет, взяла ли ключи, хотя всё ещё держит их в руке."
        "На тебя. Но мне сейчас нравится просто сидеть рядом.":
            a "Тогда я ещё на пять минут чайник включу. Не вставай."
            $ week4_event("asya", "chose_company")
    return
