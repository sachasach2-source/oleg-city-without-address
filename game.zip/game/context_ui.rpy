# Scene-aware decoration. Static edges leave the reading area and hit boxes intact.
init -10 python:
    import math as context_math

    context_palettes = {
        "autumn": dict(ink="#182523", edge="#8a7050", accent="#d3ac73", paper="#eee5d4", hover="#e3c597", ornament="#bf8c5052"),
        "rain": dict(ink="#14232d", edge="#627d88", accent="#acbfc6", paper="#e0e8e7", hover="#c4d6d9", ornament="#93b7c24c"),
        "snow": dict(ink="#182832", edge="#7899a8", accent="#c3dce7", paper="#e8eff0", hover="#c5dde6", ornament="#bbd8e660"),
        "halloween": dict(ink="#29202e", edge="#947984", accent="#deb38a", paper="#eae1e5", hover="#dfc3b2", ornament="#d8ac975a"),
    }

    def context_theme():
        # Started flags survive when replaying earlier chapters: never use them here.
        if main_menu:
            return "autumn"
        key = cast_background_key()
        chapter = {"Не сохнет":4,"Я тебя зову":5,"До тебя доехать":6,"Кем нарядиться":7}.get(city_chapter, 0)
        if key.startswith("w7 party") or key.startswith("w7 costume"):
            return "halloween"
        if chapter == 7 or key.startswith("w7 "):
            return "halloween" if week7_day == 4 and week7_clock >= 1050 else "rain"
        if chapter == 6 or key.startswith("w6 "):
            return "snow"
        if chapter in (4,5) or key.startswith(("w4 ","w5 ")):
            return "rain"
        return "autumn"

    def context_accent():
        return context_palettes[context_theme()]["accent"]

    def context_ink_mix(base, mark):
        # Canvas primitives replace pixels; preblend translucent ink to avoid holes.
        alpha = int(mark[7:9],16)/255.0 if len(mark)==9 else 1.0
        values = [round(int(base[i:i+2],16)*(1-alpha)+int(mark[i:i+2],16)*alpha) for i in (1,3,5)]
        return "#%02x%02x%02x"%tuple(values)

    class UiSmoothCanvas:
        """Draw small controls at 2x; keep their logical size and hit boxes."""
        def __init__(self, width, height):
            self.width, self.height = width, height
            self.render = renpy.Render(width * 2, height * 2)
            self.canvas = self.render.canvas()

        def point(self, value):
            return tuple(int(round(x * 2)) for x in value)

        def rect(self, color, rect, width=0):
            self.canvas.rect(color, self.point(rect), width * 2)

        def circle(self, color, center, radius, width=0):
            self.canvas.circle(color, self.point(center), int(round(radius * 2)), width * 2)

        def line(self, color, start, end, width=1):
            self.canvas.line(color, self.point(start), self.point(end), width * 2)

        def polygon(self, color, points, width=0):
            self.canvas.polygon(color, [self.point(p) for p in points], width * 2)

        def finish(self):
            result = renpy.Render(self.width, self.height)
            result.blit(self.render, (0, 0))
            result.zoom(.5, .5)
            return result

    def context_material(canvas,w,h,color,p,role,theme,active):
        # A fixed print pattern: no animated noise, random redraws or transparent holes.
        small = role in ("button","choice_button","quick")
        light = role == "choice_button"
        def ink(mark): return context_ink_mix(color,mark)
        def stroke(mark,a,b,width=1): canvas.line(ink(mark),a,b,width)
        if w<36 or h<24: return
        # Button captions need a quiet, solid surface. One-pixel fibres and
        # distressed edges become dirty speckles when the window is scaled.
        if small:
            if active:
                stroke(p["accent"]+"35",(12,3),(min(w-12,62),3))
            return
        # Broad, almost invisible ink density / coated-paper variation.
        bands = min(48,max(4,h//5))
        for band in range(bands):
            y0 = 9+(h-18)*band//bands
            y1 = 9+(h-18)*(band+1)//bands
            strength = int(3+3*(1+context_math.cos(band*context_math.pi/bands)))
            tint = ("#685339" if light else p["accent"])+"%02x"%strength
            canvas.rect(ink(tint),(3,y0,w-6,max(1,y1-y0)))
        seed = w*197+h*29+len(role)*71
        def rand(limit):
            nonlocal seed
            seed = (1664525*seed+1013904223)&0xffffffff
            return seed%max(1,limit)
        # Fine fibres and print pores, with only a few RGB levels of contrast.
        for i in range(min(600,w*h//950)):
            x,y = 11+rand(w-22),9+rand(h-18)
            tint = ("#4c4032" if light else "#e3d5bf")+("08" if i%3 else "04")
            canvas.line(ink(tint),(x,y),(x+rand(3),y),1)
        # Nicks follow the frame, rather than being speckles over the letters.
        for i in range(min(20,max(3,w//85))):
            x = 17+rand(w-34)
            y = (1 if i%2 else h-2)
            length = 2+rand(7 if small else 12)
            canvas.line(ink(p["edge"]+"30"),(x,y),(min(w-14,x+length),y),1)
            if not small and i%3==0:
                stroke(p["accent"]+"16",(x+1,y+(-2 if y>h//2 else 2)),(min(w-14,x+length+3),y+(-2 if y>h//2 else 2)))
        if theme == "autumn":
            for x,y in ((w-87,h-15),(w-19,18),(20,h-19)):
                stroke("#e5caa827",(x,y),(x+13,y-2))
                stroke("#080f1635",(x+3,y+2),(x+17,y))
            # A rubbed fold just inside the paper edge.
            stroke(p["edge"]+"25",(w-9,18),(w-10,min(h-18,92)))
        elif theme == "rain":
            for i in range(5):
                x,y = w-13-rand(39),15+rand(h-32)
                length = min(h-y-10,7+rand(25))
                stroke("#bfd8e21a",(x,y),(x-1,y+length))
                stroke("#020b1420",(x+1,y+2),(x,y+length))
            stroke("#c8e0e52a",(w-92,3),(w-22,3))
        elif theme == "snow":
            for i in range(11):
                x,y = w-14-rand(min(w-28,135)),3+rand(8)
                stroke("#e5f5ff35",(x,y),(x+2+rand(4),y))
            # Two faint icy glints live on the rim, away from the reading area.
            for x,y in ((w-23,8),(w-84,h-5)):
                stroke("#e5f5ff58",(x-3,y),(x+3,y))
                stroke("#e5f5ff38",(x,y-2),(x,y+2))
        else:
            # Worn violet ink with a trace of warm foil, not glitter behind text.
            for i in range(6):
                x,y = w-15-rand(min(w-30,90)),5+rand(7)
                stroke("#e9c28a30",(x,y),(x+1+rand(3),y))
            stroke("#d9a58838",(w-70,h-3),(w-28,h-3))
            stroke("#b192b31d",(w-67,h-5),(w-42,h-5))

    class ContextPanel(renpy.Displayable):
        def __init__(self, theme, role="panel", active=False, mood="calm", **kwargs):
            super(ContextPanel,self).__init__(**kwargs)
            self.theme, self.role, self.active, self.mood = theme,role,active,mood

        def render(self, width, height, st, at):
            w,h = max(1,int(width)),max(1,int(height))
            small = self.role in ("button","choice_button","quick")
            rv = renpy.Render(w,h)
            c = UiSmoothCanvas(w,h) if small else rv.canvas()
            p = context_palettes[self.theme]
            light = self.role == "choice_button"
            color = p["hover"] if light and self.active else p["paper"] if light else p["ink"]
            if self.role == "button" and self.active:
                color = {"autumn":"#3b453a","rain":"#304b59","snow":"#354f60","halloween":"#574052"}[self.theme]
            radius = min(13 if self.role not in ("button","choice_button","quick") else 7,w//2,h//2)
            def rounded(fill,x,y,bw,bh,r):
                c.rect(fill,(x+r,y,max(1,bw-2*r),bh))
                c.rect(fill,(x,y+r,bw,max(1,bh-2*r)))
                for px in (x+r,x+bw-r-1):
                    for py in (y+r,y+bh-r-1):
                        c.circle(fill,(px,py),r)
            rounded(p["edge"] if not self.active else p["accent"],0,0,w,h,radius)
            if w>4 and h>4: rounded(color,1,1,w-2,h-2,max(0,radius-1))
            context_material(c,w,h,color,p,self.role,self.theme,self.active)
            # Paper/ink texture is deterministic and quiet, never moving behind words.
            grain = context_ink_mix(color,"#4636240b" if light else "#eadbc70a")
            for i in range(0 if small else min(190,w*h//1700)):
                gx,gy = (i*137+19)%w,(i*71+13)%h
                if gx>w-65 or gy<8 or gy>h-8:
                    c.circle(grain,(gx,gy),1)
            accent = p["accent"]
            if self.mood == "tense" and not light: accent = p["edge"]
            if self.role in ("dialogue","panel","choice"):
                c.line(accent,(17,1),(min(w-18,112 if self.mood!="playful" else 155),1),2)
                c.line(p["edge"],(16,h-7),(min(w-16,75),h-7),1)
            ornament = context_ink_mix(color,"#544d4230" if light else p["ornament"])
            vein = context_ink_mix(color,"#71614a40" if light else p["edge"]+"90")
            def motif(x,y,s,angle=0):
                a=context_math.radians(angle)
                def pt(px,py):
                    return (int(x+s*(px*context_math.cos(a)-py*context_math.sin(a))),int(y+s*(px*context_math.sin(a)+py*context_math.cos(a))))
                def line(a,b,col=vein,width=1): c.line(col,pt(*a),pt(*b),width)
                if self.theme == "snow":
                    for n in range(6):
                        q=n*context_math.pi/3
                        dx,dy=context_math.cos(q),context_math.sin(q)
                        line((0,0),(dx*24,dy*24),ornament,2)
                        for length in (12,19):
                            for side in (-1,1):
                                line((dx*length,dy*length),(dx*(length-6)-dy*side*5,dy*(length-6)+dx*side*5),ornament)
                    c.circle(ornament,pt(0,0),max(1,int(s*2)))
                elif self.theme == "halloween":
                    c.circle(ornament,pt(0,-5),max(2,int(s*17)))
                    c.polygon(ornament,[pt(-12,3),pt(12,3),pt(9,19),pt(-9,19)])
                    for ex in (-7,7): c.circle(color,pt(ex,-4),max(1,int(s*4)))
                    c.polygon(color,[pt(0,2),pt(-3,8),pt(3,8)])
                    for ex in (-5,0,5): line((ex,12),(ex,18),color)
                    # Small bat, deliberately asymmetric like a printed marginal doodle.
                    c.polygon(ornament,[pt(-43,-24),pt(-29,-18),pt(-19,-23),pt(-24,-10),pt(-29,-13),pt(-33,-9),pt(-36,-15),pt(-42,-14)])
                elif self.theme == "rain":
                    for dx,dy,size in ((0,0,1),(-24,-10,.65),(17,-25,.45)):
                        points=[pt(dx,dy-18*size)]+[pt(dx+context_math.sin(t*context_math.pi/9)*7*size,dy+context_math.cos(t*context_math.pi/9)*8*size) for t in range(19)]
                        c.polygon(ornament,points)
                    for dx in (-32,-16,13): line((dx,-35),(dx-5,-25),ornament)
                else:
                    # A serrated maple leaf with its veins and curved stem.
                    outline=[(0,22),(-8,11),(-22,10),(-17,3),(-29,-5),(-17,-6),(-20,-20),(-8,-15),(0,-32),(8,-15),(20,-20),(17,-6),(29,-5),(17,3),(22,10),(8,11)]
                    c.polygon(ornament,[pt(*v) for v in outline])
                    line((0,28),(0,-25))
                    for end in ((-18,-13),(18,-13),(-19,1),(19,1)):
                        line((0,9),end)
            if self.role == "menu":
                motif(w-130,h-115,3.7,-22)
                motif(w-55,190,1.8,25)
                c.line(context_ink_mix(color,p["edge"]+"60"),(100,128),(w-100,128),1)
            elif self.role in ("button","choice_button","quick"):
                # Text buttons size themselves to the caption: do not stamp its end.
                if self.active and self.role != "quick" and w>40:
                    c.line(p["edge"],(8,h-4),(min(w-8,38),h-4),1)
            else:
                motif(w-28,h-27,.77,-28)
                if self.theme in ("autumn","snow"):
                    motif(w-58,h-13,.34,24)
                if h>180: motif(w-28,30,.48,20)
            return c.finish() if small else rv

    def context_panel(role="panel",active=False):
        return ContextPanel(context_theme(),role,active,getattr(store,"oleg_mood","calm"))

    def context_button_dynamic(st,at,active=False):
        return context_panel("button",active),None

init 5 python:
    style.button.background = DynamicDisplayable(context_button_dynamic)
    style.button.hover_background = DynamicDisplayable(context_button_dynamic,True)
    style.button.selected_background = DynamicDisplayable(context_button_dynamic,True)
