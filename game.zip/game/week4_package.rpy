init python:
    def week4_package_slot():
        return "tuesday_evening" if week4_day <= 1 else "wednesday_late" if week4_day == 2 else "thursday_late"

    def week4_package_slot_day(window=None):
        return {"tuesday_evening":1, "wednesday_late":2, "thursday_late":3}.get(window or week4_package_window)

    def week4_package_pickup_time():
        return {"tuesday_evening":1230, "wednesday_late":1300, "thursday_late":1310}.get(week4_package_window, 1040)

label week4_sasha_request:
    if week4_package != "none":
        return
    $ week4_package_offer = week4_package_slot()
    $ week4_package_when = "Завтра после восьми сможешь выбраться?" if week4_day == 0 else "Сегодня поздно вечером сможешь выбраться?"
    $ week4_package_hours = "Паша после восьми будет в мастерской. Рита до одиннадцати в театре, костюмы доделывает." if week4_package_offer == "tuesday_evening" else "Паша и Рита сегодня допоздна работают. После половины десятого можно, до полуночи оба на месте."
    $ week4_request_options = [("no", "Не возьмусь. У меня уже неделя через край.", [("Саша", "Ладно, понял. Найду курьера. Спасибо, что сразу сказал.")]), ("ask", "Сначала скажи, что и куда. А то ты как-то уже начинал с «маленькой просьбы».", [("Саша", "Закрытая коробка. От Паши на Садовой в театр, Рите. Пешком минут двадцать."), ("Саша", week4_package_hours), ("Саша", "Что внутри, сейчас не спрашивай, пожалуйста.")])]
    call week4_chat("sasha", "request", [("Саша", week4_package_when + " Есть маленькая просьба.")], week4_request_options)
    if _return == "no":
        $ week4_package = "declined"
        return
    $ week4_package_offer = week4_package_slot()
    $ week4_package_accept = "Да, во вторник вечером отвезу." if week4_package_offer == "tuesday_evening" else "Сегодня после своих дел отвезу."
    if week4_package_offer == "tuesday_evening":
        mind "К половине девятого доеду. Завтра не придётся уходить с работы раньше."
    else:
        mind "Сначала закончу то, о чём уже договорился. Паша с Ритой сегодня всё равно допоздна."
    menu:
        "[week4_package_accept]":
            $ week4_package = "accepted"
            $ week4_package_window = week4_package_offer
            call week4_chat("sasha", "terms", [("Саша", "Спасибо. И у неё про меня ничего не спрашивай.")], [("limit", "Ладно. Но я не буду врать, если она спросит.", [("Саша", "Не надо врать. Просто не начинай сам.")]), ("why", "Что у вас произошло? Мне надо знать, куда я иду.", [("Саша", "Тебе ничего не угрожает. Это мне неловко. Историю сейчас не хочу рассказывать."), ("Саша", "Если из-за этого не хочешь, я пойму.")])])
            if _return == "why":
                menu:
                    "Ладно. Коробку передам, в остальное не лезу.":
                        $ week4_event("sasha", "limited_help")
                    "Тогда всё-таки найди курьера. Не моё дело.":
                        $ week4_package = "declined"
                        o "Нет, Саш. В этот раз без меня."
        "Не хочу брать поручение, которое постепенно обрастает условиями.":
            $ week4_package = "declined"
            o "Саш, в этот раз без меня."
    if week4_package == "accepted":
        $ week4_package_time_text = "Во вторник в 20:30 буду у Паши." if week4_package_window == "tuesday_evening" else "Буду после своих дел. Напишу, когда выеду."
        $ week4_package_time_messages = [("Олег", week4_package_time_text), ("Саша", "Договорились. Предупредил обоих.")]
        $ phone_stamp_messages("w4_sasha_time_" + str(week4_chat_index), week4_package_time_messages, "Саша")
        $ week4_chat_index += 1
        $ week4_history["sasha"] = (week4_history.get("sasha", []) + week4_package_time_messages)[-20:]
        "Саша подтверждает время и присылает точный адрес мастерской."
        $ week4_event("sasha", "delivery_agreed", week4_package_window)
    return

# Keep the old label for saves stopped at the former lunch rescheduling call.
label week4_package_lunch_agreement:
    call week4_package_evening_agreement
    return

label week4_package_evening_agreement:
    $ week4_package_offer = week4_package_slot()
    $ week4_package_change = "Про коробку: днём у Риты не получается. Сегодня после своих дел сможешь? Они с Пашей до полуночи работают." if week4_package_window == "lunch" else "Про коробку: сегодня Паша и Рита допоздна на месте. Можешь после своих дел? До полуночи успеешь."
    if week4_package_window == "lunch" and week4_day == 2:
        $ week4_package_change = "Про завтрашнюю доставку: днём у Риты не получается. А сегодня после своих дел сможешь? Они с Пашей до полуночи работают."
    call week4_chat("sasha", "evening_change", [("Саша", week4_package_change)], [("yes", "Да. Сначала закончу свои дела, потом выеду. Предупреди их, что поздно.", [("Саша", "Уже. Не торопят, у них там работы полно.")]), ("no", "Вечером уже не хочу ехать. Давай в этот раз курьером.", [("Саша", "Ладно. Закажу, не переживай.")])])
    if _return == "yes":
        $ week4_package_window = week4_package_offer
        $ week4_event("sasha", "delivery_reagreed", week4_package_window)
    else:
        $ week4_package = "declined"
    return

label week4_package_extra_evening:
    if week4_package != "accepted":
        return
    if week4_package_slot_day() is None or week4_package_slot_day() < week4_day:
        call week4_package_evening_agreement
    if week4_package != "accepted" or week4_package_slot_day() != week4_day:
        return
    if week4_day == 1:
        $ week4_stamp("Вторник · к мастерской", max(1205, week4_clock))
        scene bg w4 rain with fade
        $ set_soundscape("courtyard")
        "Во дворе уже горят окна. Олег открывает Пашин адрес и сверяет номер дома. До половины девятого ещё есть время."
    else:
        "Олег открывает Сашину переписку. Паша подтвердил, что ещё работает и ждёт его с коробкой."
    call week4_package_pickup
    $ week4_stamp("Дома после поездки", week4_clock + 20)
    scene expression week4_home_bg() with fade
    $ set_soundscape("ch3_evening")
    "Дома он оставляет мокрую куртку у двери и идёт ставить чайник."
    return

label week4_package_pickup:
    $ week4_stamp("Двор на Садовой", max(week4_package_pickup_time(), week4_clock + 25) if week4_package_slot_day() is not None else 1040, week4_package_slot_day() if week4_package_slot_day() is not None else 3)
    scene bg w4 rain with fade
    $ set_soundscape("courtyard")
    if week4_package_slot_day() is not None:
        "В подвальном окне ещё горит свет. Олег находит дверь с нарисованным глазом и перечитывает Пашино сообщение."
    else:
        "Олег закончил работу пораньше, согласовав час с Максимом. Теперь ищет мастерскую: второй двор, подвальная дверь с нарисованным глазом."
    if week4_package_window == "before_nika" and week4_plan == "lera" and week4_laundry["method"] == "lera":
        $ week4_laundry["where"] = "with_oleg"
        "Пакет с футболками он тоже взял с собой: после театра с ним к Лере. Зонт пока удаётся сложить."
    "В сообщении от Паши: «ГОЛОВЫ НА ПОЛ НЕ СТАВИТЬ. Это не вам, извините. Вторая дверь»."
    call week4_chat("sasha", "door", [("Саша", "И лучше с ней особо не разговаривай.")], [("stop", "Саша, я взялся доставить коробку. Дальше сам решу, как разговаривать.", [("Саша", "Да. Извини. Я сейчас хуже делаю.")]), ("joke", "Мне уже начинать идти спиной?", [("Саша", "Не надо. Просто отдай. Всё.")])])
    menu:
        "Спуститься. Может, там обычная мастерская.":
            scene bg w4 workshop with dissolve
            "Первое, что Олег видит, — глаз во всю стену. Он моргает. Человек у стола поправляет проектор."
            wp "Не пугайтесь, это для спектакля. Коробка ваша вот."
            o "А ноги?"
            wp "Тоже для спектакля. Не везде в них удобно."
            "Паша переступает огромной птичьей лапой и отодвигает табурет. На верхней полке лежит несколько лиц."
            wp "Подержите дверь, пожалуйста. Я боком."
            $ week4_event("sasha", "saw_workshop")
        "Позвонить и попросить вынести к двери.":
            wp "Сейчас. Только ступеньку освободите."
            "Из двери сначала появляется картонная коробка, потом человек в серой футболке и огромных чёрных птичьих лапах."
            o "Помочь?"
            wp "Вы коробку заберите. Ногами сам справлюсь."
        "Передумал. Сначала позвоню Саше.":
            call week4_chat("sasha", "refuse_pickup", [], [("leave", "Я пока ничего не забрал. Не хочу дальше. Закажи доставку, Паше сейчас скажу.", [("Саша", "Блин. Ладно, закажу. Спасибо, что коробку у себя не оставил.")]), ("continue", "Меня эти новые инструкции напрягают. Дальше без них, договорились?", [("Саша", "Договорились.")])])
            if _return == "leave":
                $ week4_package = "declined_at_door"
                return
            "Паша выносит коробку во двор. Олег берёт её обеими руками."
    $ week4_package = "collected"
    "Скотч целый. Коробка не тяжёлая, но под мышкой нести неудобно. Олег убирает телефон в карман и идёт к театру."
    call vignette_box_scene
    $ week4_stamp("Служебный вход театра", week4_clock + 20 if week4_package_slot_day() is not None else max(1075, week4_clock) if week4_package_window == "before_nika" else 1085)
    scene bg w4 rain with dissolve
    $ set_soundscape("courtyard")
    call week4_chat("sasha", "throw", [("Саша", "Близко только не подходи."), ("Саша", "Можешь просто кинуть?")], [("what", "Кого, Саша?", [("Саша", "Коробку. Господи."), ("Саша", "Ладно. Отдай нормально. Я молчу.")]), ("no", "Нет. Отдам в руки и напишу, что дошло.", [("Саша", "Да. Хорошо. Спасибо.")])])
    call week4_rita
    return

label week4_rita:
    if week4_package_window == "before_nika":
        $ week4_stamp("Театральный буфет", max(1080, week4_clock))
        "До встречи он ещё успевает, переносить её не нужно."
    $ week4_stamp("Театральный буфет", week4_clock)
    scene bg w4 rita introduction with fade
    $ set_soundscape("ch2_gallery")
    "За служебным коридором — небольшой буфет. У окна ещё можно выпить чай, а дальний стол уже занят жилетом и катушками. Женщина в синем платье оборачивается к Олегу."
    "Из открытой двери справа считают вслух: «Пять, шесть, ещё раз». Она кивает на коробку."
    wr "Олег? Я Рита. Сашино сюда, на свободный край."
    $ postcard_meet("rita")
    menu:
        "Поставить коробку на стол.":
            $ week4_delivery = "table"
            scene bg w4 rita with dissolve
            o "Готово. Ничего не открывал."
            wr "А я и не спрашивала. Но теперь звучит интересно."
        "Передать в руки.":
            $ week4_delivery = "hands"
            wr "Давай, я поставлю."
            scene bg w4 rita with dissolve
            "Рита ставит коробку на свободный край стола, рядом с жилетом."
            o "Пожалуйста."
    call vignette_box_handover
    $ week4_package = "delivered"
    if week4_package_window == "before_nika":
        wr "Чаю?"
        o "Спасибо, сегодня не успею. В семь уже договорился встретиться."
        wr "Тогда беги. Саше скажи, что всё дошло."
        o "Скажу."
        $ week4_event("sasha", "early_delivery", "Передал без чая, сохранил встречу: " + week4_plan)
        $ week4_stamp("От театра к метро", max(1085, week4_clock + 5))
        return
    wr "Чаю хочешь? Я тут ещё минут двадцать буду шов переделывать."
    menu:
        "Хочу. У тебя тут очень спокойно после мастерской.":
            wr "Это ты на репетицию не попал. Проходи пока, я чай налью."
        "Спасибо, я поеду. Хотел только передать.":
            wr "Тогда спасибо, что довёз. Дверь на себя, она притворяется запертой."
            jump week4_package_report
    $ week4_event("rita", "tea_taken")
    if week4_package_slot_day() is not None:
        $ week4_clock += 20
    "Олег ставит зонт у батареи. Рита пока стоит у стола: проверяет, как сходятся края жилета."
    wr "У него попа хорошая, а жилет почему-то против. Второй раз перешиваю."
    o "У кого?"
    wr "У актёра. У жилета пока попы нет, но всё впереди."
    menu:
        "А ты давно здесь работаешь?":
            wr "Третий сезон. Сначала зашла помочь на один спектакль. Вот, всё помогаю."
            wr "До театра шесть лет рабочие куртки шила. Там сначала смотришь, что человек в ней делает: наклоняется, руки поднимает, инструмент в карман суёт."
            wr "Здесь эскиз принесут — красота. А актёр потом в этом на пол садится, обнимается, ещё его за рукав кто-нибудь тащит."
            wr "Вот и стою опять над швом. Хотя думала, в театре всё другое будет."
            o "Оплачивают хоть?"
            wr "Да. На одном энтузиазме попы не обшиваются."
            $ week4_event("rita", "work_talk")
        "Саша очень просил про него не спрашивать.":
            wr "Тогда и не спрашивай. У него спросишь, если захочет рассказать."
            o "Ладно."
            $ week4_event("rita", "asked_sasha")
        "Ты с таким интересом говоришь, что я начинаю жилету завидовать.":
            wr "Рано. Его сегодня два раза распарывали."
            o "Тогда пока останусь собой."
            $ week4_rita_interest = True
    "В коридоре зовут Риту. Она отвечает «пять минут» и возвращает ножницы в коробку."
    wr "Если захочешь как-нибудь на спектакль, могу афишу прислать. Только не сегодня: сегодня я вообще за кулисами живу."
    menu:
        "Давай контакт. Я бы пришёл.":
            $ week4_rita_contact = True
            wr "Записывай. И напиши, что это ты, а то у меня три Олега и один электрик без имени."
            if week4_rita_interest:
                wr "И чтобы без сюрпризов: у меня есть Лёша и Ира. Они друг о друге знают. Если это важно для твоего «пришёл»."
                menu:
                    "Понял. Пока хочу ещё с тобой поговорить.":
                        wr "Ну вот и поговорим. В день без этого жилета."
                    "Тогда я про спектакль. Без продолжения флирта.":
                        $ week4_rita_interest = False
                        wr "Хорошо. Афишу всё равно пришлю."
        "Пока без афиши. За чай спасибо.":
            wr "Пожалуйста. Я тогда работать."
    if week4_rita_contact:
        $ week4_event("rita", "theatre_contact")
        call rita_moderator_invitation
label week4_package_report:
    $ week4_stamp("У театра", week4_clock if week4_package_slot_day() is not None else 1120)
    scene bg w4 rain with dissolve
    if vignette_effect("box") == "damp_corner":
        $ week4_delivery_options = [("short", "Передал. По дороге намочил угол, Рите сказал. Скотч целый.", [("Саша", "Понял. Спасибо, что сказал ей сразу. И что довёз.")]), ("boundary", "Передал. Угол намочил, предупредил её. А новые условия давай в следующий раз до того, как я согласился.", [("Саша", "Да. Ладно. Я разнервничался и тебя задёргал. Спасибо.")])]
    else:
        $ week4_delivery_options = [("short", "Передал. Всё нормально.", [("Саша", "Спасибо. Я тебе должен.")]), ("boundary", "Передал. В следующий раз все условия до того, как я согласился, ладно?", [("Саша", "Ладно. Я что-то разнервничался. Спасибо.")])]
    $ week4_delivery_options += week4_rita_impression_options()
    call week4_chat("sasha", "delivered", [("Саша", "Ну что?")], week4_delivery_options)
    $ week4_event("sasha", "reported_delivery", _return)
    if week4_package_slot_day() is not None:
        $ week4_event("sasha", "evening_delivery", week4_package_window)
    else:
        $ week4_evening = "package"
        $ week4_evening_result = "delivered"
        $ week4_good_moment = "чай в театре" if week4_has("rita", "tea_taken") else "доставил Сашину коробку"
    return
