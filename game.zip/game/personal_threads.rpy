# Personal projects belong to this playthrough's chapter snapshots. Finishing
# something, telling a person, and that person hearing it are separate events.
init python:
    def personal_thread_event(events, person, event):
        return next((item.get("detail", "") for item in reversed(events)
            if item.get("person") == person and item.get("event") == event), "")

    def week5_own_music_kind():
        kind = personal_thread_event(week5_entry.get("events", []), "oleg", "own_music_started")
        return kind if kind in ("riff", "slow") else ""

    def week6_own_music_kind():
        kind = personal_thread_event(week6_entry.get("events", []), "oleg", "own_music_finished")
        return kind if kind in ("riff", "slow") else ""

    def week6_music_message_options():
        kind = week6_own_music_kind()
        if not kind:
            return []
        text = {"riff":"В пятницу свой рифф дописал. Там в конце пауза, я всё хотел её чем-нибудь забить. Оставил как есть. Хочу тебе показать.",
            "slow":"Записал свой медленный перебор. Без второго слоя, хотя собирался ещё кучу всего наложить. Хочу тебе показать, как получилось."}[kind]
        return [("own_music", text, [("Ника", "Давай запись. Только я вечером в наушниках послушаю, сейчас тут шумно."),
            ("Олег", "Отправил. Я пока сам с ней гуляю, слушаю, где тороплюсь."), ("Ника", "Вот так и пришли, не жди идеального дубля.")])]

    def week6_varya_project_news():
        # She did this herself. No incoming news is fabricated for a stranger,
        # and the specific feedback is remembered only after the sent reply.
        if not week6_known("varya"):
            return []
        feedback = week6_relations.get("varya", {}).get("facts", {}).get("zine_feedback")
        detail = {"window":"Разворот с бельём оставила. Ребята ещё про соседний двор спорили, а я думала, его вообще никто не заметит.",
            "cat":"Кот остался на обложке. Один парень спросил, кто автор. Я сказала, что кот, я только печатаю."}.get(feedback)
        news = [("Варя", "Я свой зин ребятам в универ отнесла. Попросили ещё несколько экземпляров. Теперь считаю, на сколько бумаги хватит.")]
        return news + ([("Варя", detail)] if detail else [])

label week4_own_music(kind):
    scene expression week4_home_bg() with dissolve
    $ set_soundscape("ch3_room")
    "Олег относит еду на стол и достаёт гитару. Включает диктофон и кладёт телефон экраном вниз рядом с хлебом."
    if kind == "riff":
        "В коротком риффе всё время просится ещё один удар. Олег играет его с ударом, потом без. Второй вариант хочется повторить."
        mind "Вот эту паузу оставлю. А конец завтра попробую."
    else:
        "На нижних струнах перебор гудит слишком густо. Олег сдвигает руку ближе к подставке и играет тише. В коридоре хлопает дверь; он начинает ещё раз."
        mind "Хочу, чтобы вот так почти шёпотом и осталось."
    "Он сохраняет полминуты. Переслушивает, уже отложив гитару, потом всё-таки берёт её обратно."
    $ week4_event("oleg", "own_music_started", kind)
    $ week4_good_moment = "нашёл паузу для своего риффа" if kind == "riff" else "играл тихий перебор дома"
    return

label week5_own_music_continue:
    $ personal_music_kind = week5_own_music_kind()
    if not personal_music_kind:
        return
    "Перед выходом Олег включает вчерашний черновик. На записи звякает посуда; он узнаёт место, где потянулся за хлебом, не переставая играть."
    menu:
        "Хочу закончить эту фразу. На один дубль время есть.":
            if personal_music_kind == "riff":
                "Он пробует закончить выше, морщится и возвращается к первой ноте. После неё оставляет тишину. Теперь наконец не хочется тут же начинать сначала."
            else:
                "Второй слой не подходит: всё становится слишком плотным. Олег выключает его, записывает один тихий проход и даёт последней струне затихнуть."
            "На этот раз он убирает гитару до переслушивания. В наушниках запись звучит непривычно близко. Ему нравится."
            $ week5_event("own_music_finished", personal_music_kind, "oleg")
        "Пока оставлю. Хочу нормально поесть и пройтись до своих дел.":
            "Олег дописывает к названию файла «конец» и закрывает диктофон. На улице выбирает дорогу через двор, где сегодня наконец убрали леса."
            $ week5_event("own_music_postponed", personal_music_kind, "oleg")
    return

label week5_short_date_goodbye:
    # The agreed hour stays the agreed hour. No extra time, touch, forgiveness,
    # or romantic status is awarded for keeping it.
    if week5_date.get("repair_only"):
        if week5_person == "nika":
            n "Я дальше одна поеду. На сегодня мне хватит."
            "Ника первой застёгивает куртку. Олег достаёт телефон, проверяет дорогу к своему метро и убирает его обратно."
        elif week5_person == "lera":
            l "Я сейчас домой. Не хочу ещё куда-то заходить."
            o "Хорошо. Я к своей остановке."
            "Лера кивает. Некоторое время они стоят рядом, прежде чем разойтись."
        else:
            a "Давай на сегодня всё. Я рада, что поговорили, но ещё перевариваю."
            o "Да. Я тоже."
            "Она убирает телефон в сумку и сама идёт к переходу. Олег ждёт свой зелёный на другой стороне улицы."
    elif week5_relations[week5_person].get("mode") == "friendship":
        if week5_person == "nika":
            n "Я поехала. Хорошо прогулялись."
            o "Ага. Я ещё за хлебом зайду."
        else:
            "У остановки они прощаются. Олег проходит дальше к магазину: хочется взять еды на утро."
    else:
        if week5_person == "nika":
            n "Я ещё десять минут кругами бы ходила. Но мы же оба ненадолго."
            o "Я тоже ещё хочу. Поэтому лучше потом нормально позову."
        elif week5_person == "lera":
            l "Ты вовремя сказал про час. Я бы сейчас уже придумывала, куда дальше."
            o "А я хочу ещё. Только в другой вечер, когда никуда не надо."
            l "Тогда зови."
        else:
            a "Мне понравилось, что ты специально позвал. Даже на час."
            o "Я хотел тебя увидеть. И сейчас рад, что вышел."
    $ week5_event("short_date_time_kept", "repair" if week5_date.get("repair_only") else "agreed", week5_person)
    return

label week6_nika_heard_own_music:
    $ personal_music_heard = week6_relations.get("nika", {}).get("facts", {}).get("oleg_music_shared", "")
    if personal_music_heard not in ("riff", "slow"):
        return
    "Пока телефон сохраняет запись, Ника отбивает пальцами по своему рукаву короткий рисунок. Олег поворачивается к ней."
    if personal_music_heard == "riff":
        n "Это твой. Пауза в конце. Я её сначала за обрыв записи приняла. Потом ещё раз включила."
        o "Я сам всё хотел её чем-нибудь забить. Теперь оставлю."
    else:
        n "Это я твой перебор пытаюсь вспомнить. Там одна нота всё время не туда, куда ждёшь."
        o "Да. Я ради неё остальные и убрал."
    n "У меня на базе бас остался. Я дома твой рисунок пальцами по столу гоняла. Хочу попробовать снизу подойти. Если получится — пришлю?"
    o "Пришли. Я свой пока так оставлю, но вместе тоже хочу попробовать."
    n "Ладно. Только я сначала дома сама посижу с ним."
    $ week6_event("own_music_heard", personal_music_heard, "nika")
    return
