default week4_entry_profile = "nika"
init python:
    def week4_sample(profile):
        """Explicit chapter-select histories; never applied to a continued save."""
        global chapter3_housing, chapter4_marta_contact, chapter4_marta_relation, chapter4_marta_plan
        base = profile if profile in ("nika", "asya", "lera", "friends") else "quiet"
        chapter3_setup_entry(base)
        chapter3_reset()
        chapter4_reset(clear_plans=True)
        chapter3_housing = "search"
        person = "nika" if profile == "friends" else profile
        if person in ("nika", "asya", "lera", "varya"):
            chapter3_plan(person, 1 if person == "lera" else 0, 900, {"nika":"coffee", "asya":"photos", "lera":"lunch", "varya":"print"}[person], "done")
            chapter3_results[person] = "провели вечер вместе" if person != "varya" else "забрали тираж"
            chapter3_tasks["touch_" + person] = {"nika":"hand", "asya":"hug", "lera":"shoulder", "varya":""}[person] if profile != "friends" else ""
        chapter3_tasks["guitar"] = "sent" if profile in ("nika", "friends") else "none"
        chapter3_tasks["pdf"] = "read"
        if profile == "marta":
            chapter4_marta_contact = True
            chapter4_marta_relation = "interest"
            chapter4_marta_plan = "coffee"
        if profile == "hurt":
            chapter3_previous["route"] = "nika"
            chapter3_previous["origin"] = "connection"
            chapter3_plan("nika", 0, 840, "jam", "done")
            chapter3_departures["nika"] = {"reaction":"hurt", "choice":"plans"}
            chapter3_results["nika"] = "поиграли; Олег ушёл раньше, чем Ника ожидала"
        diary_entries.append("Быстрый вход в главу 4: готовая предыстория, не личное прохождение.")

label week4_quick:
    $ week4_sample(week4_entry_profile)
    jump week4_start

screen week4_select():
    tag menu
    use menu_shell("Не сохнет · глава четвёртая"):
        vbox:
            xpos 100 ypos 150 xsize 1350 spacing 11
            text "Свою историю продолжай из сохранения в конце третьей главы.\nЗдесь — готовые предыстории для знакомства с новой главой." size 23 color "#bfc6c9"
            for profile, title in [("nika", "Ника · тёплые выходные"), ("friends", "Ника · дружба и музыка"), ("hurt", "Ника · обидный уход в выходные"), ("asya", "Ася · сближение в галерее"), ("lera", "Лера · взаимный интерес"), ("varya", "Варя · дружба и зин"), ("marta", "Марта · уже договорились о кофе в понедельник"), ("quiet", "Без договорённостей · свободный вечер")]:
                textbutton title action [SetVariable("week4_entry_profile", profile), Start("week4_quick")] xsize 1200 padding (20, 9)
