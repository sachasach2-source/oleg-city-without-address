# Three hands of social bluffing. Rolls happen only in script actions, never render.
init python:
    def week7_bluff():
        return week7_venue.get("bluff",{})

    def week7_bluff_claim(bid):
        count,face=bid
        numbers=("","одна","две","три","четыре","пять","шесть","семь","восемь","девять")
        nouns={1:("единица","единицы","единиц"),2:("двойка","двойки","двоек"),3:("тройка","тройки","троек"),4:("четвёрка","четвёрки","четвёрок"),5:("пятёрка","пятёрки","пятёрок"),6:("шестёрка","шестёрки","шестёрок")}
        return numbers[count]+" "+nouns[face][0 if count==1 else 1 if count<5 else 2]

    def week7_bluff_begin(person):
        week7_venue["bluff"]=dict(round=0,wins=0,history=[],phase="start",guest=person,
            names=["Олег","Катя",week4_names[person] if person else "Илья"],outcome="",turns=0,raised=False)
        week7_bluff_next()

    def week7_bluff_next():
        s=copy.deepcopy(week7_bluff())
        if s["round"]>=3:
            s.update(phase="finished",outcome="won" if s["wins"]>=2 else "lost")
        else:
            hands=[[renpy.random.randint(1,6) for _ in range(3)] for _ in range(3)]
            leader=1+s["round"]%2
            face=max(range(1,7),key=lambda f:(hands[leader].count(f),f))
            bid=(min(9,hands[leader].count(face)+renpy.random.randint(1,3)),face)
            s.update(round=s["round"]+1,hands=hands,bid=bid,bidder=leader,phase="bid",turns=0,
                log=s["names"][leader]+": «"+week7_bluff_claim(bid).capitalize()+"». Проверяем все девять костей.")
        week7_venue["bluff"]=s

    def week7_bluff_higher(bid,current):
        return 1<=bid[0]<=9 and 1<=bid[1]<=6 and tuple(bid)>tuple(current)

    def week7_bluff_npc_reply(hand,bid):
        # Only this opponent's own three dice and the public bid are visible to AI.
        known=hand.count(bid[1])
        return "doubt" if bid[0]>known+2 or bid==(9,6) else "raise"

    def week7_bluff_resolve(s,kind,actor):
        count,face=s["bid"]
        actual=sum(hand.count(face) for hand in s["hands"])
        won=(actual==count) if kind=="exact" else (actual<count if actor==0 else actual>=count)
        s.update(phase="reveal",actual=actual,won=won)
        s["wins"]+=int(won)
        s["log"]=("Ровно! " if kind=="exact" and won else "Ровно не получилось. " if kind=="exact" else "Вскрываем. ")+"Заявка: "+week7_bluff_claim(s["bid"])+". На столе: "+str(actual)+". "+("Это твой раунд." if won else "Этот раунд забирает стол.")
        s["history"].append(dict(round=s["round"],bid=s["bid"],hands=copy.deepcopy(s["hands"]),actual=actual,move=kind,challenger=actor,won=won))
        return s

    def week7_bluff_move(action):
        s=copy.deepcopy(week7_bluff())
        if s.get("phase")!="bid":return False
        kind=action[0]
        if kind=="watch":
            s.update(phase="finished",outcome="watched" if not s["history"] else "left")
        elif kind in ("doubt","exact"):
            s=week7_bluff_resolve(s,kind,0)
        elif kind=="raise":
            bid=(action[1],action[2])
            if not week7_bluff_higher(bid,s["bid"]):return False
            s.update(bid=bid,bidder=0,turns=s["turns"]+1)
            s["raised"]=True
            opponent=1+(s["turns"]-1)%2
            if week7_bluff_npc_reply(s["hands"][opponent],bid)=="doubt":
                s=week7_bluff_resolve(s,"doubt",opponent)
                s["log"]=s["names"][opponent]+": «Не верю. Открываем!» "+s["log"]
            else:
                s.update(bid=(bid[0]+1,bid[1]),bidder=opponent)
                s["log"]=s["names"][opponent]+": «Тогда "+week7_bluff_claim(s["bid"])+"». Твой ход."
        else:return False
        week7_venue["bluff"]=s
        return True

    class Week7Die(renpy.Displayable):
        def __init__(self,value,size=62,**kwargs):
            super(Week7Die,self).__init__(**kwargs)
            self.value,self.size=value,size
        def render(self,width,height,st,at):
            n=self.size;r=renpy.Render(n,n);c=r.canvas()
            c.rect("#371b1a99",(3,4,n-3,n-4))
            c.polygon("#dbc8a6",[(5,0),(n-5,0),(n,5),(n,n-5),(n-5,n),(5,n),(0,n-5),(0,5)])
            c.line("#fff2d6",(6,2),(n-6,2),2)
            patterns={1:[(1,1)],2:[(0,0),(2,2)],3:[(0,0),(1,1),(2,2)],4:[(0,0),(2,0),(0,2),(2,2)],5:[(0,0),(2,0),(1,1),(0,2),(2,2)],6:[(0,0),(2,0),(0,1),(2,1),(0,2),(2,2)]}
            for x,y in patterns[self.value]:c.circle("#402329",(int(n*(.25+x*.25)),int(n*(.25+y*.25))),max(3,n//12))
            return r

    class Week7DiceCup(renpy.Displayable):
        def render(self,width,height,st,at):
            r=renpy.Render(180,180);c=r.canvas()
            c.circle("#230c1699",(94,96),78)
            c.circle("#a46b43",(88,86),77)
            c.circle("#3d2222",(88,86),70)
            c.circle("#79472e",(88,86),64)
            c.circle("#c29864",(88,86),58,2)
            for x in (65,88,111):c.line("#895836",(x,44),(x,129),2)
            c.circle("#362022",(88,86),14)
            return r

screen week7_devils_dice():
    modal True
    $ s=week7_bluff()
    style_prefix "dice_game"
    default amount = min(9,s["bid"][0]+1)
    default face = s["bid"][1]
    key "game_menu" action ShowMenu("save")
    add Transform("images/week7/devils-dice-table-v1.webp",xysize=(1600,900),fit="cover")
    text "КОСТИ ДЬЯВОЛА" xpos 45 ypos 25 size 30 color "#f6d9ac" kerning 2
    text ("Раунд "+str(s["round"])+" из 3  ·  Твои победы: "+str(s["wins"])) xpos 48 ypos 70 size 20 color "#e0c79e"
    for seat,cx,cy in ((1,290,265),(2,805,265),(0,550,640)):
        text s["names"][seat] xcenter cx ypos cy-105 size 23 color "#f5e0bd" outlines [(2,"#21131b",0,0)]
        if seat==0 or s["phase"]=="reveal":
            hbox:
                xcenter cx ycenter cy spacing 12
                for value in s["hands"][seat]:
                    add Week7Die(value)
        else:
            add Week7DiceCup() xcenter cx ycenter cy
    frame:
        xpos 1135 ypos 35 xsize 425 ysize 790 padding (25,22) background mini_surface("dice")
        vbox:
            spacing 10
            text (s["names"][s["bidder"]]+" заявляет") size 18 color "#bda27d"
            text week7_bluff_claim(s["bid"]).capitalize() size 31 color "#f1dab3"
            text s["log"] size 18 color "#d5cbd0" xmaximum 375
            if s["phase"]=="bid":
                text "На столе 9 костей. Заявка — «не меньше». Единицы обычные." size 17 color "#a9a1a8"
                text "Сколько и каких назовёшь ты?" size 19 color "#e4c293"
                hbox:
                    spacing 12
                    textbutton "−" action SetScreenVariable("amount",max(1,amount-1)) xsize 62 padding (8,4)
                    text str(amount) yalign .5 size 30 color "#f3d6a9" xsize 36 text_align .5
                    textbutton "+" action SetScreenVariable("amount",min(9,amount+1)) xsize 62 padding (8,4)
                hbox:
                    spacing 5
                    for f in range(1,7):
                        button:
                            id "w7_die_face_"+str(f)
                            padding (4,4) background mini_surface("dice","button" if face==f else "secondary") hover_background mini_surface("dice","button",True)
                            action SetScreenVariable("face",f)
                            add Week7Die(f,43)
                textbutton "Повышаю: "+week7_bluff_claim((amount,face)):
                    id "w7_dice_raise"
                    text_size 18 xsize 375 padding (12,12)
                    sensitive week7_bluff_higher((amount,face),s["bid"])
                    action Return(("raise",amount,face))
                text "Больше костей — или столько же с большим числом." size 15 color "#a9a1a8"
                textbutton "Блеф! Открываем.":
                    id "w7_dice_doubt" text_size 20 xsize 375 padding (12,12)
                    action Return(("doubt",))
                textbutton "Их ровно столько.":
                    id "w7_dice_exact" text_size 20 xsize 375 padding (12,12)
                    action Return(("exact",))
                textbutton "Дальше посмотрю со стороны":
                    id "w7_dice_watch" text_size 17 xsize 375 padding (12,10)
                    action Return(("watch",))
            else:
                text ("Нужных костей на столе: "+str(s["actual"])+".") size 20 color "#e6c698"
                textbutton ("Следующий раунд" if s["round"]<3 else "Закончить партию"):
                    id "w7_dice_next" xsize 375 text_size 20
                    action Return(("next",))
    use minigame_system("dice")

label week7_party_bluff:
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    "Из боковой гостиной слышен стук стаканчиков. На косяке приклеены красные рожки; под ними Катя держит дверь локтем."
    w7k "К нам? По три кости, видишь только свои. Говоришь, например: «Здесь не меньше четырёх двоек». Следующий либо повышает, либо говорит, что ты врёшь."
    o "И на что играете?"
    w7k "На право потом всем рассказывать, как ловко ты врал. Деньги убери, если достал."
    "За стол садятся втроём. Стаканчик тёплый от чужих ладоней; Олег заглядывает под свой и ставит его обратно."
    $ week7_bluff_begin(week7_party_guest())
    while week7_bluff()["phase"]!="finished":
        call screen week7_devils_dice
        if _return[0]=="next":
            $ week7_bluff_next()
        else:
            $ week7_bluff_move(_return)
    $ week7_dice_result=week7_bluff()["outcome"]
    "Олег отодвигает стул. В фойе музыка сразу слышна громче, чем за дверью гостиной."
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    if week7_dice_result=="won":
        w7k "Два раунда твои. Ладно, выбирай, что потом включим на танцы. Я как раз к ноутбуку иду."
        menu:
            "Что-нибудь с тяжёлым гитарным риффом.":
                $ week7_venue["dice_request"]="heavy"
            "Хочу танцевать. Давай что-нибудь быстрое.":
                $ week7_venue["dice_request"]="fast"
            "Я сегодня уже наигрался. Выбирай сама.":
                $ week7_venue["dice_request"]="katya"
        if week7_clock < 1230:
            w7k "Ответ принят. Поставлю. Только за ноутбук с этими стаканами не садитесь."
        else:
            w7k "Хорошо, поставлю. Только за ноутбук с этими стаканами не садитесь."
    elif week7_dice_result=="lost":
        "Катя уже зовёт следующих игроков. Олег помогает собрать кости: одна укатилась под стул, приходится отодвинуть его и поискать."
        o "Вот она. По крайней мере, эта шестёрка точно существует."
        w7k "Давай сюда, пока не потеряли."
    else:
        "Олег смотрит последний круг стоя. Катя доходит до семи четвёрок, её вскрывают — всего три. Она смеётся и передаёт стаканчики следующим."
    if week7_party_guest():
        $ week7_say(week7_party_guest(),({"nika":"Я тебе почти поверила. Ты когда врёшь, как будто переход в песне считаешь." if week7_bluff()["raised"] else "Я ещё воды возьму. После этой партии пить захотелось.","lera":"Я бы ещё поиграла. Нет, всё, а то я реально никуда не уеду.","asya":"Мне понравилось. Во второй раз уже не будешь одной только уверенности верить.","marta":"У чертей тоже кости под стул закатываются. Хорошая комната.","zhenya":"Я так после работы за столом давно не сидела. И даже без ноутбука.","ulya":"Я сейчас чужую уверенность за информацию принимала. Надо ещё попробовать."}[week7_party_guest()]))
        $ week7_relations[week7_party_guest()].setdefault("facts",{})["chapter7_dice"]=dict(outcome=week7_dice_result,wins=week7_bluff()["wins"],rounds=len(week7_bluff()["history"]))
    $ week7_event("devils_dice",week7_dice_result,week7_party_guest())
    return
