# Chapter selection only. Loading and normal chapter transitions bypass this file.
default chapter_history_draft = {}
default chapter_history_target = 2
default chapter_history_building = False
default history_entry_chapter = 0

init python:
    history_origins = [("connection", "С Никой — свидание"), ("friendship", "С Никой — дружба"), ("delay", "Отложил ответ Нике")]
    history_routes = [("nika", "Ника"), ("asya", "Ася"), ("lera", "Лера"), ("rest", "Вечер для себя")]

    def chapter_history_people(chapter):
        return ("nika", "lera", "asya", "marta") if chapter >= 4 else ()

    def chapter_history_allowed(chapter, person):
        if person == "marta":
            return ("none", "friend", "interest")
        return (("none", "friend") if person == "nika" else ("known",)) + ("interest", "space", "hurt")

    def chapter_history_homes(chapter):
        if chapter <= 3:
            return [("hotel", "Пока в гостинице")]
        return late_history_homes(6)[:4] + ([("central_pending", "В пятницу заберу ключи · квартира со ступенями")] if chapter == 5 else [])

    def chapter_history_default(chapter, focus="nika"):
        relations = dict(nika="none", lera="known", asya="known", marta="none")
        if focus in relations:
            relations[focus] = "interest"
        elif focus == "friends":
            relations["nika"] = "friend"
        return dict(focus=focus, origin="connection" if focus == "nika" else "friendship" if focus == "friends" else "delay",
            route="nika" if focus in ("nika", "friends") else focus if focus in ("asya", "lera") else "rest",
            relations=relations, home="hotel", house_offer="refuse", followup="plan", varya="read",
            guitar="none", date4=focus if chapter == 5 and focus in ("nika", "lera", "asya") else "",
            kiss4=False, rita="none", laundry="clean")

    def chapter_history_pick(draft, field, value, person=None):
        d = copy.deepcopy(draft)
        if person:
            d["relations"][person] = value
        else:
            d[field] = value
        if field == "origin" and value == "delay" and d.get("route") == "nika":
            d["route"] = "rest"
        if d.get("route") != "nika":
            d["followup"] = "plan"
        if d["relations"].get("nika") == "none":
            d["guitar"] = "none"
        if field == "date4" and value and d["relations"][value] in ("none", "known"):
            d["relations"][value] = "interest"
        if d.get("date4") not in ("nika", "lera", "asya") or d["relations"].get(d.get("date4")) not in ("interest",):
            d["kiss4"] = False
        return d

    def chapter_history_focus(chapter, draft, focus):
        d = copy.deepcopy(draft)
        base = chapter_history_default(chapter, focus)
        for field in ("focus", "origin", "route", "relations", "date4", "kiss4"):
            d[field] = base[field]
        return chapter_history_pick(d, "focus", focus)

    def chapter_history_problem(chapter, d):
        if chapter not in (2, 3, 4, 5):
            return "Выбери главу со второй по пятую."
        if d.get("origin") not in dict(history_origins) or d.get("route") not in dict(history_routes):
            return "Выбери итог знакомства и прошедший вечер."
        if chapter == 3 and d["origin"] == "delay" and d["route"] == "nika":
            return "После отложенного ответа Ника провела этот вечер с подругой."
        if d.get("home") not in dict(chapter_history_homes(chapter)):
            return "Это жильё пока недоступно."
        for person in chapter_history_people(chapter):
            if d.get("relations", {}).get(person) not in chapter_history_allowed(chapter, person):
                return "Такого события до этой главы ещё не было."
        if d.get("kiss4") and (chapter != 5 or not d.get("date4") or d["relations"].get(d["date4"]) != "interest"):
            return "Поцелуй возможен после тёплого романтического вечера четвёртой главы."
        if chapter < 5 and (d.get("date4") or d.get("rita") != "none"):
            return "Эти события ещё впереди."
        if d.get("house_offer") not in ("refuse", "conditions", "temporary") or d.get("followup") not in ("plan", "record") or d.get("varya") not in ("read", "walk", "later"):
            return "Проверь выбранные дела."
        if d.get("followup") == "record" and d.get("route") != "nika":
            return "Запись обещана после музыкального вечера с Никой."
        if d.get("date4") not in ("", "nika", "lera", "asya") or d.get("rita") not in ("none", "contact", "moderator") or d.get("laundry") not in ("clean", "lera") or d.get("guitar") not in ("none", "sent", "pending"):
            return "Выбери доступный исход дела."
        if d.get("guitar") == "pending" and d.get("relations", {}).get("nika") == "none":
            return "Для обещанной записи нужен контакт Ники."
        return ""

    def chapter_history_summary(chapter, d):
        if chapter <= 3:
            lines = [dict(history_origins)[d["origin"]] + ".", "Олег пока живёт в гостинице."]
            if chapter == 3:
                lines += ["Вечер второй главы: " + dict(history_routes)[d["route"]] + ".",
                    {"refuse":"Продолжает искать квартиру.", "conditions":"Попросил уточнить условия аренды.", "temporary":"Рассматривает аренду на месяц."}[d["house_offer"]],
                    {"read":"Пообещал прочитать зин Вари.", "walk":"Договорился обсудить прогулку с Варей.", "later":"Новых обещаний Варе не давал."}[d["varya"]]]
                if d["route"] == "nika" and d["followup"] == "record":
                    lines.append("Пообещал прислать Нике запись.")
            return lines
        lines = [dict(chapter_history_homes(chapter))[d["home"]] + "."]
        for person in chapter_history_people(chapter):
            lines.append(late_history_names[person] + ": " + {"none":"нет контакта", "known":"общаемся", "friend":"дружим", "interest":"есть интерес", "space":"решили не торопиться", "hurt":"осталась обида после раннего ухода"}[d["relations"][person]] + ".")
        if chapter == 5:
            lines.append("Четверг: " + ("встреча с " + late_history_names[d["date4"]] if d["date4"] else "вечер для себя") + ("; поцеловались." if d["kiss4"] else "; без поцелуя."))
            lines += [{"none":"С Ритой не обменивались контактами.", "contact":"Есть контакт Риты, без модерации.", "moderator":"Помогает Рите организовать встречу."}[d["rita"]],
                "Вещи сохнут у Леры; забрать в пятницу." if d["laundry"] == "lera" else "Стирка закончена."]
        return lines

    def chapter_history_apply(chapter, draft):
        global chapter_history_building, history_entry_chapter
        history_entry_chapter = chapter
        chapter_history_building = True
        try:
            chapter_history_apply_events(chapter, draft)
        finally:
            chapter_history_building = False

    def chapter_history_apply_events(chapter, draft):
        global ending_id, chapter2_origin, chapter2_route, chapter2_housing, chapter2_initiative, chapter2_followup, chapter2_varya_reply
        global chapter3_housing, housing_home, chapter4_marta_contact, chapter4_marta_relation, chapter4_marta_plan
        global week4_finished, week4_rita_contact, week4_package, week4_day, week4_clock
        d = copy.deepcopy(draft)
        problem = chapter_history_problem(chapter, d)
        if problem:
            raise ValueError(problem)
        messenger_reset_optional_history()
        ending_id = d["origin"]
        if chapter == 2:
            return
        chapter3_setup_entry("quiet")
        ending_id = chapter2_origin = d["origin"]
        chapter2_route, chapter2_housing = d["route"], d["house_offer"]
        chapter2_initiative = ("guitar" if d["followup"] == "record" else "invite") if chapter2_route == "nika" else "honest"
        chapter2_followup = d["followup"] if chapter2_route != "rest" else ""
        chapter2_varya_reply = d["varya"]
        if chapter == 3:
            diary_entries[:] = chapter_history_summary(chapter, d)
            return
        # A chronological witness using actual appointment slots: Saturday
        # print/rehearsal/photos, Sunday lunch and an optional bookshop evening.
        chapter2_origin = ending_id = "friendship" if d["relations"]["nika"] == "friend" else "connection" if d["relations"]["nika"] != "none" else "delay"
        chapter2_route = "rest"
        chapter2_housing = {"month":"temporary", "whole":"conditions"}.get(d["home"], "refuse")
        chapter2_initiative = chapter2_followup = ""
        chapter2_varya_reply = "later"
        chapter3_reset()
        for person, day, minute, kind in (("varya", 0, 660, "print"), ("nika", 0, 840, "jam"), ("asya", 0, 990, "photos"), ("lera", 1, 900, "lunch")):
            state = "friend" if person == "varya" else d["relations"][person]
            if state in ("none", "known"):
                continue
            chapter3_plan(person, day, minute, kind, "done")
            chapter3_results[person] = "встретились и поговорили"
            if state in ("interest", "space"):
                chapter3_tasks["touch_" + person] = "space" if state == "space" else {"nika":"hand", "asya":"hug", "lera":"shoulder"}[person]
            if state == "hurt":
                chapter3_departure(person, "hurt", "plans")
        chapter3_tasks["pdf"] = "none"
        chapter3_tasks["guitar"] = d["guitar"]
        chapter4_marta_contact = d["relations"]["marta"] != "none"
        chapter4_marta_relation = "friendship" if d["relations"]["marta"] == "friend" else "interest" if chapter4_marta_contact else ""
        chapter4_marta_plan = "coffee" if chapter4_marta_contact else ""
        previous_home = "hotel" if d["home"] == "central_pending" else d["home"]
        chapter3_housing = {"studio":"new", "hotel":"search"}.get(previous_home, previous_home)
        housing_home = "studio" if previous_home == "studio" else ""
        if chapter == 5:
            week4_reset()
            week4_day, week4_clock = 3, 1390
            week4_work["report"] = "done"
            week4_laundry.update(method="lera" if d["laundry"] == "lera" else "hotel" if previous_home == "hotel" else "home", status="drying" if d["laundry"] == "lera" else "clean", where="lera" if d["laundry"] == "lera" else "home", **{"return":"friday" if d["laundry"] == "lera" else ""})
            if d["home"] == "central_pending":
                week4_home.update(kind="hotel", candidate="central", keys_due="friday", paid_until="friday")
            if d["date4"]:
                person = d["date4"]
                relation = week4_relations[person]
                relation["invited"] = True
                if d["relations"][person] == "hurt":
                    week4_complete_evening(person, "unfinished")
                else:
                    week4_event(person, "mutual_time")
                    week4_complete_evening(person, "warm")
                    if d["kiss4"]:
                        assert week4_can_kiss(person)
                        week4_remember_kiss(person, "Взаимный поцелуй после встречи")
            week4_rita_contact = d["rita"] != "none"
            week4_package = "delivered" if week4_rita_contact else "none"
            rita_moderation.update(invited=week4_rita_contact, joined=d["rita"] == "moderator", active=d["rita"] == "moderator")
            week4_finished = True
        diary_entries[:] = chapter_history_summary(chapter, d)

label chapter_history_start:
    $ chapter_history_apply(chapter_history_target, chapter_history_draft)
    if chapter_history_target == 2:
        jump chapter2_start
    elif chapter_history_target == 3:
        jump chapter3_start
    elif chapter_history_target == 4:
        jump week4_start
    jump week5_start

screen chapter_history_options(draft, field, options, person=None):
    hbox:
        spacing 8
        for value, caption in options:
            textbutton caption:
                id ("early_" + (person or field) + "_" + value)
                selected (draft["relations"].get(person) if person else draft.get(field)) == value
                action SetScreenVariable("draft", chapter_history_pick(draft, field, value, person))
                text_size 20 padding (14, 9)

screen chapter_history_builder(chapter):
    tag menu
    default step = 0
    default details = False
    default draft = chapter_history_default(chapter)
    use menu_shell("Своя история · глава " + str(chapter)):
        vbox:
            xpos 100 ypos 145 xsize 1340 spacing 15
            text "Меняй только важное. Начать можно сразу — остальное уже настроено." size 23 color "#bfc6c9"
            hbox:
                spacing 14
                for index, caption in enumerate(("1 · Встречи", "2 · Быт и дела", "3 · Моя история")):
                    textbutton caption action SetScreenVariable("step", index) selected step == index text_size 22 padding (18, 9)
            viewport:
                xsize 1320 ysize 465 mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 14
                    if step == 0:
                        if chapter <= 3:
                            text "Чем закончился концерт и знакомство с Никой?" size 25
                            use chapter_history_options(draft, "origin", history_origins)
                            if chapter == 3:
                                text "С кем провёл вечер второй главы?" size 25
                                use chapter_history_options(draft, "route", [(value, caption) for value, caption in history_routes if value != "nika" or draft["origin"] != "delay"])
                                if draft["route"] == "nika":
                                    text "Что договорились сделать дальше?" size 25
                                    use chapter_history_options(draft, "followup", [("plan", "Спланировать встречу"), ("record", "Прислать запись")])
                        else:
                            text "Кому хочется уделить больше внимания?" size 25
                            hbox:
                                spacing 8
                                for profile, caption in [("nika", "Ника"), ("lera", "Лера"), ("asya", "Ася"), ("marta", "Марта"), ("friends", "Дружба с Никой"), ("quiet", "Без романтики")]:
                                    textbutton caption action SetScreenVariable("draft", chapter_history_focus(chapter, draft, profile)) selected draft["focus"] == profile text_size 20 padding (14, 9)
                            textbutton ("Скрыть другие знакомства ↑" if details else "Другие знакомства и настроение встреч…") action ToggleScreenVariable("details") text_size 21
                            if details:
                                for person in chapter_history_people(chapter):
                                    text late_history_names[person] size 22 color "#d5b384"
                                    use chapter_history_options(draft, "relations", [(state, late_history_caption(person, state)) for state in chapter_history_allowed(chapter, person)], person)
                            if chapter == 5:
                                text "С кем был вечер в четверг?" size 25
                                use chapter_history_options(draft, "date4", [("", "Для себя"), ("nika", "Ника"), ("lera", "Лера"), ("asya", "Ася")])
                                if draft["date4"] and draft["relations"][draft["date4"]] == "interest":
                                    textbutton ("Поцеловались: да" if draft["kiss4"] else "Поцеловались: нет") id "early_kiss" action SetScreenVariable("draft", chapter_history_pick(draft, "kiss4", not draft["kiss4"])) selected draft["kiss4"] text_size 23
                    elif step == 1:
                        if chapter == 2:
                            text "Первая глава ещё не давала ключей и обещаний. Всё остальное решишь по ходу игры." size 24 xmaximum 1200
                        elif chapter == 3:
                            text "Что решил по поводу квартиры?" size 25
                            use chapter_history_options(draft, "house_offer", [("refuse", "Искать дальше"), ("conditions", "Уточнить условия"), ("temporary", "Рассмотреть месяц")])
                            text "Что ответил Варе про зин?" size 25
                            use chapter_history_options(draft, "varya", [("read", "Прочитаю"), ("walk", "Давай погуляем"), ("later", "Пока без обещаний")])
                        else:
                            text "Где живёт Олег?" size 25
                            for value, caption in chapter_history_homes(chapter):
                                textbutton caption id ("early_home_" + value) action SetScreenVariable("draft", chapter_history_pick(draft, "home", value)) selected draft["home"] == value text_size 21 padding (12, 6)
                            if draft["relations"]["nika"] != "none":
                                text "Запись Нике" size 24
                                use chapter_history_options(draft, "guitar", [("none", "Не обещал"), ("sent", "Уже отправил"), ("pending", "Ещё должен прислать")])
                            if chapter == 5:
                                text "Рита и её чат" size 24
                                use chapter_history_options(draft, "rita", [("none", "Нет контакта"), ("contact", "Общаемся"), ("moderator", "Помогаю с чатом")])
                                text "Стирка" size 24
                                use chapter_history_options(draft, "laundry", [("clean", "Вещи уже чистые"), ("lera", "Сохнут у Леры")])
                    else:
                        for line in chapter_history_summary(chapter, draft):
                            text line size 23 xmaximum 1220
            text (chapter_history_problem(chapter, draft) or "Новый старт с выбранной историей. Своё прохождение можно продолжить из сохранения.") size 19 color "#bfc6c9"
        hbox:
            xpos 100 ypos 785 spacing 25
            if step:
                textbutton "← Назад" action SetScreenVariable("step", step - 1) text_size 23
            if step < 2:
                textbutton "Дальше →" id "history_next" action SetScreenVariable("step", step + 1) text_size 23
            textbutton "Начать главу":
                id "history_start"
                sensitive not chapter_history_problem(chapter, draft)
                action [SetVariable("chapter_history_target", chapter), SetVariable("chapter_history_draft", copy.deepcopy(draft)), Start("chapter_history_start")]
                text_size 25
