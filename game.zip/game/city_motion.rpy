# Ambient motion for approved story plates. Original image names and geometry
# remain unchanged, including old saves. No experimental artwork is required.
default persistent.city_motion = True

init -7 python:
    city_motion_assets = {
        "images/neva.webp": "city.neva",
        "images/neva-day.webp": "city.neva",
        "images/neva-night.webp": "city.neva",
        "images/week4/courtyard-rain-v1.webp": "city.puddles",
        "images/cast/concert-empty.webp": "city.stage_light",
        "images/concert-performance.webp": "city.stage_light",
        "images/cast/club-empty.webp": "city.wet_street",
        "images/chapter3/ch3-street-sunny-v2.webp": "city.autumn",
        "images/chapter2-lera-set.webp": "city.dj_light",
        "images/chapter2-lera-wave-axis-v2.webp": "city.dj_light",
        "images/chapter2-lera-wrap-axis-v2.webp": "city.dj_light",
    }
    city_motion_bindings = {
        "bg neva": "images/neva.webp",
        "bg neva dusk": "images/neva.webp",
        "bg neva day": "images/neva-day.webp",
        "bg neva night": "images/neva-night.webp",
        "bg w4 rain": "images/week4/courtyard-rain-v1.webp",
        "bg w4 lera yard": "images/week4/courtyard-rain-v1.webp",
        "bg concert performance": "images/concert-performance.webp",
        "bg lera set": "images/chapter2-lera-set.webp",
        "bg lera wave": "images/chapter2-lera-wave-axis-v2.webp",
        "bg lera wrap": "images/chapter2-lera-wrap-axis-v2.webp",
        "bg ch3 street": "images/chapter3/ch3-street-sunny-v2.webp",
        "bg ch3 alone": "images/chapter3/ch3-street-sunny-v2.webp",
    }

    def city_register_motion(name, body, functions=""):
        renpy.register_shader(name, variables="""
            uniform sampler2D tex0;
            varying vec2 v_tex_coord;
            uniform float u_city_time;
        """, fragment_functions=functions, fragment_300="""
            vec2 p = v_tex_coord;
            float t = u_city_time * 0.05235987756;
        """ + body)

    city_register_motion("city.neva", """
        // Water above the front railing. Stay clear of its granite caps,
        // pedestrians, both boats and the opposite embankment.
        float railing = 0.410 + p.x * 0.320;
        float water = smoothstep(0.225, 0.25, p.x)
            * smoothstep(0.487, 0.496, p.y)
            * (1.0 - smoothstep(railing - 0.012, railing - 0.004, p.y));
        float boat = smoothstep(0.760, 0.775, p.x)
            * (1.0 - smoothstep(0.960, 0.975, p.x))
            * (1.0 - smoothstep(0.522, 0.535, p.y));
        float distant_boat = smoothstep(0.462, 0.472, p.x)
            * (1.0 - smoothstep(0.560, 0.570, p.x))
            * (1.0 - smoothstep(0.500, 0.510, p.y));
        water *= (1.0 - boat) * (1.0 - distant_boat);
        float depth = max(p.y - 0.475, 0.014);
        float across = (p.x - 0.22) / depth;
        float phase = log(depth) * 32.0 - t * 43.0 + across * 0.55;
        vec2 offset = vec2((sin(phase) + 0.35 * sin(phase * 1.5 - t * 11.0)) * 0.0028,
            sin(log(depth) * 47.0 - t * 61.0 - across * 0.4) * 0.0008);
        vec4 river = texture2D(tex0, p + offset * water);
        float reflected_light = smoothstep(0.3, 0.7,
            dot(river.rgb, vec3(0.299, 0.587, 0.114)));
        river.rgb *= 1.0 + sin(phase) * (0.035 + reflected_light * 0.055) * water;
        gl_FragColor = mix(gl_FragColor, river, water);
    """)

    city_register_motion("city.puddles", """
        float ripple = city_puddle(p, vec2(0.325, 0.758), fract(u_city_time / 7.5))
            + city_puddle(p, vec2(0.665, 0.806), fract(u_city_time / 10.0 + 0.4))
            + city_puddle(p, vec2(0.845, 0.888), fract(u_city_time / 12.0 + 0.7));
        float light = smoothstep(0.18, 0.6, dot(gl_FragColor.rgb, vec3(0.299, 0.587, 0.114)));
        gl_FragColor.rgb += vec3(0.10, 0.09, 0.065) * ripple * (0.5 + light);
        // The scene describes rain. Fine occasional drops sit in the distant
        // courtyard only; the composited protagonists remain in front of them.
        float cycle = fract(u_city_time / 7.5);
        float fall = clamp((cycle - 0.72) / 0.24, 0.0, 1.0);
        vec2 d = abs(p - vec2(0.211, 0.55 + fall * fall * 0.12));
        float drop = (1.0 - smoothstep(0.0003, 0.0010, d.x))
            * (1.0 - smoothstep(0.002, 0.006, d.y))
            * smoothstep(0.72, 0.76, cycle) * (1.0 - smoothstep(0.92, 0.96, cycle));
        gl_FragColor.rgb += vec3(0.14, 0.15, 0.16) * drop;
    """, functions="""
        float city_puddle(vec2 p, vec2 center, float cycle) {
            float d = length((p - center) * vec2(1.0, 4.0));
            float radius = 0.004 + cycle * 0.055;
            return (1.0 - smoothstep(0.0005, 0.0022, abs(d - radius)))
                * (1.0 - smoothstep(0.42, 0.72, cycle)) * smoothstep(0.0, 0.08, cycle);
        }
    """)

    city_register_motion("city.stage_light", """
        // Slow illumination of the upper stage haze, with no movement or
        // flickering faces. No strobe and no global brightness pumping.
        float upper_stage = smoothstep(0.53, 0.67, p.x)
            * (1.0 - smoothstep(0.17, 0.21, p.y)) * smoothstep(0.025, 0.06, p.y);
        float singer = smoothstep(0.645, 0.66, p.x)
            * (1.0 - smoothstep(0.81, 0.825, p.x));
        upper_stage *= 1.0 - singer;
        float red = smoothstep(0.035, 0.18, gl_FragColor.r - gl_FragColor.g);
        float violet = smoothstep(0.02, 0.14, gl_FragColor.b - gl_FragColor.g);
        float shimmer = sin(t * 17.0) * 0.055 * red + sin(t * 13.0 + 1.2) * 0.045 * violet;
        gl_FragColor.rgb *= 1.0 + upper_stage * shimmer;
    """)

    city_register_motion("city.wet_street", """
        // Only the wet road below the diagonal kerb and the reflection in
        // front of the steps. Architecture, lamps and the steps stay fixed.
        float road = smoothstep(0.60 + p.x * 0.49, 0.62 + p.x * 0.49, p.y);
        float doorway = (1.0 - smoothstep(0.065, 0.095,
            length((p - vec2(0.65, 0.955)) * vec2(1.0, 0.62))))
            * smoothstep(0.90, 0.925, p.y);
        float ground = max(road, doorway);
        float warm = smoothstep(0.10, 0.32, gl_FragColor.r - gl_FragColor.b);
        float bright = smoothstep(0.25, 0.58, max(gl_FragColor.r, gl_FragColor.g));
        float drift = sin(p.y * 170.0 - t * 30.0 + sin(p.x * 60.0 + t * 7.0))
            * 0.075 + sin(p.y * 285.0 - t * 47.0) * 0.035;
        gl_FragColor.rgb *= 1.0 + ground * warm * bright * drift;
    """)

    city_register_motion("city.dj_light", """
        // The blue beam moves inside the empty haze above the audience.
        // Lera, the console, faces and raised hands are outside this mask.
        float haze = (1.0 - smoothstep(0.22, 0.29, p.x))
            * smoothstep(0.08, 0.11, p.y) * (1.0 - smoothstep(0.24, 0.265, p.y));
        float blue = smoothstep(0.03, 0.18, gl_FragColor.b - gl_FragColor.r);
        float sweep = sin(p.x * 19.0 - t * 18.0) * 0.09 + sin(t * 11.0) * 0.035;
        gl_FragColor.rgb *= 1.0 + haze * blue * sweep;
        // A small candle flame in the existing glass, not the entire table.
        float candle = 1.0 - smoothstep(0.007, 0.025,
            length((p - vec2(0.077, 0.92)) * vec2(1.0, 0.60)));
        gl_FragColor.rgb *= 1.0 + candle * (sin(t * 173.0) * 0.045 + sin(t * 229.0) * 0.025);
    """)

    city_register_motion("city.autumn", """
        // Two separate fallen leaves catch an occasional gust at ground
        // level. The image itself is never displaced; no breathing masonry.
        float cycle = fract(u_city_time / 20.0);
        float travel = clamp(cycle / 0.40, 0.0, 1.0);
        vec2 center = vec2(0.36 + travel * 0.43, 0.675 - sin(travel * 6.2831853) * 0.020);
        vec2 q = (p - center) * vec2(1600.0, 900.0);
        float angle = travel * 8.0;
        q = mat2(cos(angle), -sin(angle), sin(angle), cos(angle)) * q / 11.0;
        float fade = smoothstep(0.0, 0.015, cycle) * (1.0 - smoothstep(0.36, 0.40, cycle));
        float leaf = city_leaf(q) * fade;
        vec3 ochre = mix(vec3(0.47, 0.23, 0.055), vec3(0.77, 0.43, 0.10), clamp(q.y * 0.4 + 0.5, 0.0, 1.0));
        gl_FragColor.rgb = mix(gl_FragColor.rgb, ochre, leaf * 0.90);
        float other = fract(u_city_time / 30.0 + 0.72);
        float step = clamp(other / 0.24, 0.0, 1.0);
        vec2 q2 = (p - vec2(0.49 + step * 0.26, 0.735 + sin(step * 4.0) * 0.012)) * vec2(1600.0, 900.0);
        float turn = step * -6.0;
        q2 = mat2(cos(turn), -sin(turn), sin(turn), cos(turn)) * q2 / 7.5;
        float fade2 = smoothstep(0.0, 0.012, other) * (1.0 - smoothstep(0.21, 0.24, other));
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.55, 0.29, 0.07), city_leaf(q2) * fade2 * 0.85);
    """, functions="""
        float city_leaf(vec2 q) {
            float angle = atan(q.y, q.x);
            float radius = 0.66 + 0.20 * cos(angle * 5.0) + 0.06 * cos(angle * 10.0);
            float blade = 1.0 - smoothstep(radius - 0.09, radius, length(q));
            float stem = (1.0 - smoothstep(0.025, 0.065, abs(q.x)))
                * smoothstep(0.58, 0.64, q.y) * (1.0 - smoothstep(1.0, 1.10, q.y));
            return max(blade, stem);
        }
    """)

    def city_background(filename, size=(1600, 900)):
        base = Transform(filename, xysize=size)
        effect = city_motion_assets.get(filename)
        if effect is None:
            return base
        motion = city_cloud_loop(effect) if effect == "city.board_sky" else city_motion_loop(effect)
        return ConditionSwitch("persistent.city_motion", At(base, motion), "True", base)

    def city_cloud_clock(trans, st, at):
        # Elapsed scene time keeps advancing: clouds must not turn around or
        # jump back when the other ambient effects repeat their 120s cycle.
        trans.u_city_time = st
        return 1.0 / 30.0

transform city_cloud_loop(effect):
    mesh True
    shader effect
    function city_cloud_clock

transform city_motion_loop(effect):
    mesh True
    shader effect
    parallel:
        u_city_time 0.0
        linear 120.0 u_city_time 120.0
        repeat
    parallel:
        pause (1.0 / 30.0)
        repeat

init 510 python:
    # Ren'Py executes ordinary image declarations at priority 500.
    # Bind after them so the static declarations cannot overwrite the effect.
    for image_name, filename in city_motion_bindings.items():
        renpy.image(image_name, city_background(filename))
