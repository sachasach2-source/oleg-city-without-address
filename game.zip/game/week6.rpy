# Local chapter-six slice: actual entry history through Friday night.
label week6_start:
    if not week5_finished:
        "Для продолжения нужна история, с которой закончилась пятая глава."
        return
    if not week6_started:
        $ week6_reset()
    $ city_chapter = "До тебя доехать"
    $ quick_menu = False
    scene expression home_keepsake_background(week6_home_path()) with fade
    call screen chapter_card("До тебя доехать", "Глава шестая · октябрьский снег")
    $ quick_menu = True
    show screen scene_marker
    if week6_stage == "opening":
        call week6_laundry_handoff
        jump week6_sunday
    if week6_stage == "monday":
        jump week6_monday
    if week6_stage == "tuesday":
        jump week6_tuesday
    if week6_stage == "wednesday":
        jump week6_wednesday
    if week6_stage == "wednesday_evening":
        jump week6_wednesday_evening
    if week6_stage == "thursday":
        jump week6_thursday
    if week6_stage == "concert":
        jump week6_friday_concert
    if week6_stage in ("friday_finished", "weekend_plan"):
        jump week6_weekend_plan
    if week6_stage == "saturday":
        jump week6_saturday
    if week6_stage == "sunday":
        jump week6_sunday_weekend
    if week6_stage == "finished":
        call screen week6_ending
        if _return == "chapter7":
            jump week7_start
        return
    call screen week6_draft_end
    return

label week6_laundry_handoff:
    if week6_laundry.get("where") != "lera" or week6_laundry.get("return") != "saturday_after18":
        return
    $ week6_stamp("Дома · за пакетом", 1090, -1)
    # The handoff is still the preceding Saturday, not the next week's concert.
    $ place_name = "Дома · суббота, 18:10"
    scene expression home_keepsake_background(week6_home_path(True)) with fade
    "Напоминание про футболки закрывает половину экрана. Олег открывает Лерину переписку."
    call week6_chat("lera", "laundry", [], [
        ("collect", "Я за пакетом. Ты ещё дома? Минут через сорок могу быть.", [("Лера", "Да. Я до восьми дома, успеешь. Напиши снизу.")]),
        ("tomorrow", "Я сегодня уже не соберусь за вещами. Завтра около шести можно?", [("Лера", "Завтра с половины шестого до семи дома. В шесть нормально.")])])
    if _return == "collect":
        $ week6_stamp("У дома Леры", 1130, -1)
        $ place_name = "У дома Леры · суббота, 18:50"
        scene bg w4 lera yard with dissolve
        $ set_soundscape("courtyard")
        "В домофоне щёлкает. Лера выходит с пакетом и придерживает дверь плечом."
        l "Твои пять всадников. Высохли."
        o "Я их пересчитаю."
        l "А как ты поймёшь, если одного подменили?"
        "Олег заглядывает в пакет. Лера смеётся и прячет руки в рукава."
        o "Ладно, пока доверюсь. Спасибо."
        $ week6_laundry.update(where="home", status="clean", **{"return":"done"})
        $ week6_event("laundry_collected", person="lera")
    else:
        $ week6_laundry["return"] = "sunday18"
        $ week6_event("laundry_rescheduled", "Воскресенье 18:00; Лера дома 17:30–19:00", "lera")
    return

label week6_sunday:
    $ week6_stamp("Дома", 690, 0)
    scene expression home_keepsake_background(week6_home_path()) with fade
    $ set_soundscape("hotel_morning")
    if week6_entry.get("result") in ("shared_night", "sleep_together"):
        "Вторая чашка сохнет возле раковины. Олег берёт её, потом ставит обратно и достаёт свою."
    elif week6_entry.get("result") in ("paused_after_yes", "paused_at_home"):
        "Купленный к пятнице кофе ещё не открыт. Олег надрезает пакет ножницами, слишком низко, и пересыпает просыпавшееся со стола обратно."
    elif week6_entry.get("varya", {}).get("help") in ("solo", "together"):
        "В приложении такси ещё висит ночной маршрут. Олег закрывает его большим пальцем и ищет, сколько времени. Воскресенье уже почти наполовину."
    else:
        "За окном кто-то скребёт лопатой по асфальту. Снега ещё нет. Олег отдёргивает штору: дворник сгребает мокрые листья в один упрямый ком."
    if week6_home.get("kind") == "hotel":
        "Под дверью лежит карточка уборки. Олег переворачивает её стороной «не беспокоить» и зацепляет за ручку."
    else:
        "Из-под входной двери тянет мокрым подъездом. Олег ставит кроссовки на газету: коврик так и не купил."
    if week6_entry.get("marta", {}).get("scene_done"):
        "Олег убирает вчерашний чек из кармана. Переписка с Мартой всё ещё открыта там, где они попрощались."
    call screen chapter3_intentions("Кому хочется написать?", week6_options())
    $ week6_person = "" if _return == "alone" else _return
    if week6_person:
        call week6_sunday_message
    else:
        "В булочной перед ним берут семь одинаковых слоек. Олег смотрит на оставшуюся восьмую и тоже берёт. На улице ест её, придерживая пакет от ветра."
        $ week6_event("sunday_for_himself")
    if week6_laundry.get("return") == "sunday18":
        $ week6_stamp("Перед выходом", 1050)
        scene expression home_keepsake_background(week6_home_path()) with dissolve
        call week6_chat("lera", "laundry_sunday", [], [("onway", "Еду за пакетом, как договорились. К шести буду.", [("Лера", "Хорошо. Сейчас его у двери поставлю.")])])
        $ week6_stamp("У дома Леры", 1080)
        scene bg w4 lera yard with dissolve
        "Лера выносит пакет. Олег забирает его, благодарит. В этот раз напоминание можно удалить."
        $ week6_laundry.update(where="home", status="clean", **{"return":"done"})
        $ week6_event("laundry_collected", person="lera")
    $ week6_stage = "monday"
    jump week6_monday

label week6_sunday_message:
    if week6_careful(week6_person):
        "Олег набирает «Как выходной?». Стирает. Последние сообщения выше никуда не делись."
        if week6_past_date(week6_person) == "awkward_goodbye":
            "В пятницу она не захотела продолжать вечер, а он успел расстроиться и показать это. Вчера договорились пока спокойно переписываться."
        elif week6_past_date(week6_person) == "interrupted_separate" and not week6_issues(week6_person):
            "После ночной поездки они так и разъехались отдельно. Хочется снова позвать её, но не начинать с того места, где всё прервалось."
        call week6_chat(week6_person, "unfinished", [], [
            ("hello", "Привет. Не хочу пропадать после прошлого разговора. Как ты?", [(week4_names[week6_person], "Привет. Сегодня хочу спокойно побыть дома. Потом напишу.")]),
            ("space", "Привет. Сегодня не буду звать куда-то. Просто хотел пожелать хорошего воскресенья.", [(week4_names[week6_person], "Спасибо. Тебе тоже.")])])
        $ week6_event("careful_contact", _return, week6_person)
        "Он убирает телефон. Ответить ещё что-нибудь очень хочется, но нового вопроса у него нет."
        return
    if week6_past_date(week6_person) in ("paused_after_yes", "paused_at_home"):
        call week6_chat(week6_person, "after_pause", [], [
            ("see", "Привет. После пятницы немного неловко писать, но увидеть тебя я всё ещё хочу.", [(week4_names[week6_person], "Привет. Я тогда растерялась. Сейчас уже меньше. Только давай в следующий раз сначала просто погуляем.")]),
            ("slow", "Привет. Сегодня хочу спокойно побыть дома. Просто тебе написал, чтобы не исчезать после пятницы.", [(week4_names[week6_person], "Привет. Хорошо, что написал. Я тоже сегодня дома.")])])
        $ week6_event("pause_acknowledged", _return, week6_person)
        return
    if week6_friend(week6_person):
        call week6_chat(week6_person, "friend_sunday", [], [
            ("ask", "Привет. Чем занимаешься? Я выбираюсь за хлебом, пока не стемнело.", [(week4_names[week6_person], {"nika":"Привет. Струны меняю. Умудрилась потерять кусачки прямо сидя на полу.", "lera":"Я час назад проснулась. Завтрак будет торжественно в два.", "asya":"Разбираю фотографии. Половину сняла, пока пыталась убрать телефон в карман.", "marta":"Стираю. Сегодня без волшебства, просто на сорока градусах."}[week6_person])]),
            ("later", "Привет. Сегодня хочу поваляться. Просто машу тебе из-под одеяла.", [(week4_names[week6_person], "Привет. Лежи, воскресенье ещё не отменили.")])])
        $ week6_event("friend_sunday", _return, week6_person)
        return
    if week6_person == "nika":
        call week6_chat("nika", "sunday", [], [
            ("miss", "Привет. Хотел тебя сегодня увидеть. Ты как?", [("Ника", "Привет. Я уже на базе. Сегодня барабаны пишем, до вечера."), ("Ника", "Но я бы тебя увидела. Давай на неделе спишемся.")]),
            ("ordinary", "Я сейчас стоял у полки с чашками. Хотел купить две одинаковые, потом понял, что одну мне пока ставить некуда.", [("Ника", "Не бери мне чашку. У меня дома их девять."), ("Ника", "Если соберусь к тебе — могу свою принести.")])])
    elif week6_person == "lera":
        call week6_chat("lera", "sunday", [], [
            ("miss", "Привет. Проснулся и захотел тебе написать. Ты уже встала?", [("Лера", "Да! То есть встала и опять легла. Сегодня можно."), ("Лера", "Я вечером к подруге. А пока расскажи что-нибудь, я ещё минут десять никуда.")]),
            ("weekend", "Хочу на следующих выходных тебя забрать куда-нибудь. Прям на день.", [("Лера", "Подожди с целым днём, у меня сет в субботу."), ("Лера", "А после него — да. Если ты правда хочешь прийти.")])])
    elif week6_person == "asya":
        call week6_chat("asya", "sunday", [], [
            ("ordinary", "Привет. Я пытаюсь нормально позавтракать до обеда. У тебя получается?", [("Ася", "Я только поставила чайник. Сейчас попробуем обеими силами."), ("Ася", "Хорошо, что написал просто так.")]),
            ("walk", "Хочу тебя увидеть на неделе. Не после чего-нибудь, а специально.", [("Ася", "Специально мне нравится. Сегодня я дома за переводом, но на неделе давай."), ("Ася", "Только не в десять вечера, ладно?")])])
    else:
        $ week6_marta_hello = "Привет. Ты вчера нормально добралась?" if week6_entry.get("marta", {}).get("scene_done") else "Привет. Как воскресенье?"
        call week6_chat("marta", "sunday", [], [
            ("morning", week6_marta_hello, [("Марта", "Привет. За кормом сходила. Коту больше понравился пакет."), ("Марта", "Я тут уже смотрю, куда можно в субботу. У тебя она вообще свободна?")]),
            ("day", "Привет. Сегодня хочу побыть один, а тебе всё равно захотел написать.", [("Марта", "Привет. Я уже хотела спросить, не выйти ли за кофе."), ("Марта", "Тогда не выманиваю. Буду дома рисовать.")])])
    $ week6_event("sunday_contact", _return, week6_person)
    if week6_person == "marta" and _return == "morning":
        call week6_chat("marta", "saturday_question", [], [
            ("later", "Пока не знаю. Сначала разберусь с неделей, потом сам позову. Сейчас субботу не держи под меня.", [("Марта", "Ладно. А то я уже начала передвигать дела.")]),
            ("wish", "Хочу увидеться, но время пока не обещаю. Напишу до четверга, чтобы ты могла спланировать.", [("Марта", "Хорошо. До четверга тогда жду.")])])
        if _return == "wish":
            $ week6_event("marta_answer_due", "До четверга", "marta")
    return

label week6_monday:
    $ week6_stage = "monday"
    $ week6_stamp("Обеденный перерыв", 790, 1)
    scene expression home_keepsake_background(week6_home_path()) with fade
    $ set_soundscape("hotel_morning")
    "В понедельник Олег ставит обед рядом с ноутбуком и отодвигает ноутбук. Телефон тут же вибрирует."
    call week6_chat("friends", "palm", [("Саша", "Мы на море собрались."), ("Саня", "В Подмосковье."), ("Саша", "Зачем сразу уточнять."), ("Саня", "Потому что пальма пластиковая. И полотенце не входит.")], [
        ("ask", "Вы вдвоём в аквапарк едете?", [("Саша", "С ночёвкой. В субботу. Я хотел просто отоспаться, потом увидел горку."), ("Саня", "Я сначала поржал, потом сам номер нашёл. С бассейном до одиннадцати.")]),
        ("warm", "Я бы сейчас тоже в тёплую воду залез. Тут уже руки в карманах не отогреваются.", [("Саня", "Так и мы. Я в воскресенье вообще из дома не вышел, даже побегать."), ("Саша", "Я ещё взял номер с завтраком. Чтобы утром не надо было ничего решать.")]),
        ("towel", "Сань, ты уже цену полотенца обжаловал?", [("Саня", "Я позвонил. Оно НАПРОКАТ. Не навсегда."), ("Саша", "Он своё везёт. Теперь ищем, где дома его второе своё.")])])
    $ week6_event("friends_pool_plan", _return, "friends")
    "Еда успевает остыть по краям. Олег перемешивает её и всё-таки откладывает телефон."
    call housing_story_seed
    if week6_rita.get("joined") and week6_rita.get("active"):
        call week6_rita_monday
    $ week6_stage = "tuesday"
    jump week6_tuesday

label week6_rita_monday:
    $ week6_stamp("После работы", 1120)
    scene expression home_keepsake_background(week6_home_path(True)) with dissolve
    $ week6_puzzle = week6_rita.setdefault("puzzle", {})
    if week6_puzzle.get("status") == "candidate_ready":
        call week6_chat("rita_group", "calendar_kept", [("Рита", "Вернулась к твоему сообщению. Воскресенье, с трёх до шести. Студия пока свободна."), ("Рита", "Но уборка отдельно. И вопрос — кем.")], [
            ("details", "Время не двигаем. Пришли полную цену и что они называют уборкой. В четверг разберём, пока ничего не бронируй.", [("Рита", "Хорошо. Узнаю ещё про доступ до трёх, чтобы не полчаса коврики раскладывать.")]),
            ("leave", "Время мы нашли, дальше я всё-таки не возьму. У меня на этой неделе другие планы.", [("Рита", "Ладно. Дальше сама. Воскресенье не потеряем.")])])
    else:
        call week6_chat("rita_group", "calendar_unfinished", [("Рита", "Привет. Я про следующее воскресенье. Его ещё можно собрать или пока не трогать студию?")], [
            ("details", "Пока не бронируй. Я в четверг вернусь к расписанию и сначала дочитаю, что у нас уже выяснилось.", [("Рита", "Хорошо. До четверга тогда узнаю цену с уборкой. Оплачивать ничего не буду.")]),
            ("leave", "Я всё-таки выхожу из организации. Не хочу обещать тебе ещё один вечер и снова откладывать.", [("Рита", "Поняла. Спасибо, что сейчас сказал. Дальше сами.")])])
    if _return == "leave":
        $ week6_rita["active"] = False
        $ week6_event("moderation_left", person="rita")
    else:
        $ week6_rita["next_check"] = "thursday"
        $ week6_event("moderation_thursday", week6_puzzle.get("status", "collecting"), "rita")
    return

label week6_tuesday:
    $ week6_stage = "tuesday"
    $ week6_stamp("Дома · работа закончена", 1110, 2)
    scene expression home_keepsake_background(week6_home_path(True)) with fade
    $ set_soundscape("ch3_room")
    if not week6_known("varya"):
        "До следующего созвона никто не пишет. Олег играет кусок, который всё время откладывал, и наконец запоминает переход без паузы."
        $ week6_event("quiet_tuesday")
        $ week6_stage = "wednesday"
        jump week6_wednesday
    "В рабочем чате от Вари приходит ссылка на исправленную таблицу. Через минуту она пишет уже в личку."
    if any(i.get("cause") == "brushed_off_after_call" for i in week6_issues("varya")):
        call week6_chat("varya", "after_short_reply", [("Варя", "Рабочее отправила. Я ещё кое-что спросить хотела. Только не про ту ночь.")], [
            ("own", "Хорошо. Я тогда сухо ответил, это помню. Сейчас слушаю.", [("Варя", "Да. Мне неприятно было. Ладно, сейчас про другое.")]),
            ("listen", "Хорошо. Что хотела спросить?", [("Варя", "Про музыку. Только если не до этого, сразу скажи, я другого спрошу.")])])
        $ week6_event("varya_old_reply_remembered", _return, "varya")
    call week6_chat("varya", "concert", [("Варя", "Я в пятницу петь буду. Записалась на акустический вечер. Уже записалась, да."), ("Варя", "Минусовка у меня есть, но там в конце эти синтезаторы, будто титры у сериала про ментов. Ты можешь со мной сыграть?")], [
        ("play", "Могу. Давай завтра порепетируем, а в пятницу сыграю. Только сначала пришли, что за песня и в какой тональности поёшь.", [("Варя", "АА. Сейчас. Комнату у них на завтра можно забронировать, с семи до восьми. Берём?"), ("Олег", "Да, с семи до восьми. Гитару возьму."), ("Варя", "Забронировала. Сейчас пришлю адрес.")]),
        ("try", "Завтра с семи до восьми могу попробовать с тобой. А пятницу пока не обещаю: хочу сначала понять партию.", [("Варя", "Ладно. Я у площадки ещё музыканта спрошу, чтобы не в последний день."), ("Варя", "Комнату на завтра забронировала. Пришлю адрес.")]),
        ("audience", "Сыграть не возьмусь. Но в пятницу хочу прийти послушать. Во сколько твой номер?", [("Варя", "В половине восьмого. Начало в семь, там маленький зал."), ("Варя", "Жаль. Ладно, спрошу их гитариста. Приходи тогда просто так.")]),
        ("decline", "В эту пятницу не смогу. И с репетицией не хочу обещать. У них есть музыкант на площадке?", [("Варя", "Есть. Я просто с тобой хотела."), ("Варя", "Хорошо, напишу ему. Потом расскажу, как всё прошло.")])])
    $ week6_varya.update(role=_return, concert_day="friday", start=1140, number=1170, rehearsal=_return in ("play", "try"), rehearsal_time=1140, rehearsal_end=1200)
    $ week6_event("concert_answer", _return, "varya")
    if week6_entry.get("varya", {}).get("help") in ("solo", "together"):
        "Она начинает печатать ещё. Олег ждёт."
        call week6_chat("varya", "concert_after_help", [("Варя", "И я на этот раз в куртке буду. Ещё до твоего вопроса.")], [("good", "Хорошо. Музыканту мёрзнуть нельзя.", [("Варя", "ВОКАЛИСТКЕ. Уже началось.")])])
    if week6_varya.get("rehearsal"):
        "В календаре появляется комната на час. Олег достаёт из чехла гитару и проверяет, есть ли запасные струны."
    $ week6_stage = "wednesday"
    jump week6_wednesday

label week6_wednesday:
    $ week6_stage = "wednesday"
    $ week6_stamp("По дороге за кофе", 495, 3)
    scene bg w6 snow courtyard with fade
    $ set_soundscape("courtyard")
    "У арки Олег останавливается. Вчера здесь была чёрная лужа. Сегодня она всё ещё здесь, но у неё белые берега."
    "На лестнице человек чистит щёткой ботинок, стоя на другой ноге. Вид у него такой, будто снег выпал лично ему назло."
    mind "Надо было вчера перчатки купить."
    "Кофе обжигает пальцы через крышку. Олег перекладывает стакан в другую руку и возвращается домой."
    $ week6_stamp("Дома", 525)
    scene bg w6 thai shirt with dissolve
    "В поисках свитера он вытаскивает лёгкую рубашку. Из нагрудного кармана выпадает тайская монета."
    "Рубашка всё ещё чуть пахнет шкафом из той квартиры. Олег трёт пальцем край монеты: там он носил её с собой, когда шёл за водой."
    "Покупал холодную, но домой она доезжала уже тёплой. Зато можно было выйти на улицу вот так, в рубашке."
    menu:
        "Отправлю московским. У них там своё море намечается.":
            call week6_chat("friends", "thai_shirt", [("Олег", "Нашёл тайскую рубашку. Вышел бы в ней за кофе, но у нас снег.")], [("miss", "Хочу опять выйти на улицу и чтобы уже было тепло. Даже не купаться.", [("Саша", "Да я за этим аквапарк и забронировал. В воду ещё залезть надо собраться, а там просто ходишь без куртки."), ("Саня", "Я ради этого ещё на утро понедельника отгул взял. Не хочу из бассейна сразу на созвон.")])])
            $ week6_sea.update(shared="friends", feeling="warmth")
            $ week6_event("sea_shared", "Рубашка и тепло, не обещание поездки", "friends")
        "Примерю. Хоть дома похожу.":
            "В зеркале он поправляет воротник. Потом надевает поверх кардиган. Получается человек, который собирался на море и пошёл за квитанцией."
            $ week6_sea["feeling"] = "wear"
            $ week6_event("thai_shirt_worn")
        "Уберу рядом со свитером. Не надо опять на самое дно.":
            "Олег складывает её, оставляет сверху и берёт монету на стол. Нужный свитер всё это время лежал на спинке стула."
            $ week6_sea["feeling"] = "keep"
            $ week6_event("thai_shirt_kept")
    if week6_varya.get("rehearsal"):
        "На семь у него репетиция с Варей. Олег ставит чехол у двери, чтобы не вспомнить о нём уже в метро."
    else:
        "До работы ещё полчаса. Олег придвигает к себе кофе: пока не остыл."
    $ week6_stage = "wednesday_evening"
    jump week6_wednesday_evening

screen week6_draft_end():
    modal True
    add Solid("#09151bea")
    frame:
        xalign .5 yalign .5 xsize 1100 padding (50, 40) background Solid("#12232c")
        vbox:
            spacing 22
            text "ГЛАВА ШЕСТАЯ · ЛОКАЛЬНЫЙ ЧЕРНОВИК" size 18 color "#d5b384" kerning 2
            text "Первый снег" size 46
            text "Локальный вход сохранён. Можно продолжить свою историю дальше по шестой главе." size 25
            if week6_stage == "wednesday_evening":
                textbutton "Продолжить · репетиция и новые знакомства" action Jump("week6_wednesday_evening")
            if week6_stage == "friday_finished":
                textbutton "Продолжить · выходные" action Jump("week6_weekend_plan")
            textbutton "Сохранить здесь" action ShowMenu("save")
            textbutton "В главное меню" action Return()
