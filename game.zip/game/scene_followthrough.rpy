# Follow-ups use the frozen chapter-entry evidence, never persistent scores.
init python:
    def followthrough_riff_kind(entry=None):
        tasks = (week4_entry if entry is None else entry).get("tasks", {})
        take = tasks.get("nika_riff_take")
        game = tasks.get("nika_riff_game", {})
        expected = {"duet":"smooth", "guide":"funny", "live":"skipped"}
        if not isinstance(game, dict) or take not in expected:
            return ""
        if game.get("kind") != "riff" or game.get("context", "") != "" or game.get("result") != expected[take]:
            return ""
        return take

    def followthrough_photo_kind(entry=None):
        tasks = (week4_entry if entry is None else entry).get("tasks", {})
        frame = tasks.get("varya_zine_frame")
        game = tasks.get("varya_frame_game", {})
        expected = {"oleg_office":"smooth", "varya_reshoot":"funny", "varya_own":"skipped"}
        if not isinstance(game, dict) or frame not in expected:
            return ""
        if game.get("kind") != "photo" or game.get("result") != expected[frame]:
            return ""
        return frame

    def followthrough_photo_shots(entry=None):
        tasks = (week4_entry if entry is None else entry).get("tasks", {})
        if followthrough_photo_kind(entry) != "oleg_office":
            return ()
        shots = tasks.get("varya_frame_game", {}).get("shots", ())
        if len(shots) != 3:
            return ()
        for shot in shots:
            if not isinstance(shot, dict) or not all(isinstance(shot.get(key), (int, float)) for key in ("x", "y", "zoom")) or shot["zoom"] <= 0:
                return ()
        return shots

label week4_jam_followthrough:
    $ followthrough_take = followthrough_riff_kind()
    if not week4_relations.get("nika", {}).get("known") or not followthrough_take or week4_has("nika", "jam_recalled"):
        return
    if followthrough_take == "duet":
        n "Ты тот общий дубль не удалил? Я всё последнюю ноту вспоминаю."
        o "Нет. Мне там нравится, как мы уже закончили, а усилитель ещё думает."
        n "Вот этот хвост не обрезай, ладно?"
        o "Он там. Я сам его дослушиваю."
    elif followthrough_take == "guide":
        n "Ты ту мою запись сохранил? С четырьмя ударами в начале."
        o "Да. Я хочу сначала в этом темпе попасть, а не опять тебя догонять."
        n "Там можно вообще на двух нотах остаться. Если сам захочешь разогнаться, тогда."
        o "Вот так мне сейчас интереснее."
    else:
        n "Мы тот кусок так и не записали."
        o "А мне понравилось, что не стали. Я меньше на руки смотрел."
        n "Я тоже наконец перестала в телефон поглядывать."
    $ week4_event("nika", "jam_recalled", followthrough_take)
    return

label week4_photo_followthrough:
    $ followthrough_frame = followthrough_photo_kind()
    if not week4_relations.get("varya", {}).get("known") or not followthrough_frame or week4_has("varya", "office_frames_recalled"):
        return
    if followthrough_frame == "oleg_office":
        if followthrough_photo_shots():
            show screen vignette_photo_proof(shots=followthrough_photo_shots())
        v "А наши офисные кадры я так и оставила втроём. Арка, табличка, стул. Не стала ещё раз переснимать."
        o "Стул не выкинула?"
        v "Он там главный. Без него просто объявление о недвижимости."
        hide screen vignette_photo_proof
    elif followthrough_frame == "varya_reshoot":
        v "Помнишь, я у тебя камеру забрала? Из тех кадров в разворот пошли мои переснятые арка и табличка."
        o "Без стула?"
        v "Ему отдельное место ищу. Не втиснулся."
    else:
        v "Я ещё те свои снимки у офиса перебираю. Арку со стулом рядом поставила — смешнее, чем по одному."
        o "Табличка тоже там?"
        v "Да. Без неё никто не поймёт, что это действующий офис."
    $ week4_event("varya", "office_frames_recalled", followthrough_frame)
    return

label week4_asya_shared_look:
    a "Я сначала всё хотела убрать этот блик. Отойдёшь — нормально. Подойдёшь — опять мешает."
    a "Потом стала смотреть с ним. Получается, ты сам всё время меняешь картинку, пока ходишь."
    menu:
        "Мне нравится, что это надо самому найти.":
            o "Мне нравится, что это надо самому найти. С фотографии бы не понял."
            a "Я поэтому и прошу не стоять только напротив. Хотя сама потом застреваю в одном месте."
            $ week4_event("asya", "shared_look_preference", "light")
        "А я всё равно к стулу возвращаюсь. Мне он интереснее.":
            o "А я всё равно к стулу возвращаюсь. Мне он интереснее. Хочется понять, у кого он дома стоял."
            a "Ты уже почти с ним познакомился."
            "Она смотрит на стул вместе с ним, но через секунду снова поворачивается к стеклу."
            $ week4_event("asya", "shared_look_preference", "chair")
    return

label week4_lera_listen_together:
    l "Так. Теперь дослушаем, а то я тебе сейчас весь трек разговорами заменю."
    "Лера кладёт телефон экраном вниз. Несколько секунд она ещё качает ногой, потом устраивается удобнее. Олег перестаёт подбирать ответ."
    menu:
        "Оставь этот. Я пока просто послушаю.":
            o "Оставь этот. Я пока просто послушаю."
            l "Ладно. Я тоже попробую."
            "Она уже набирает воздух, чтобы что-то добавить, и вместо этого берёт чашку."
            $ week4_event("lera", "listening_preference", "stay")
        "Не совсем моё. Мне сейчас хочется чего-нибудь спокойнее.":
            o "Не совсем моё. Мне сейчас хочется чего-нибудь спокойнее."
            l "У меня есть. Только я за неё сейчас спорить не буду."
            o "Я бы сейчас вообще на одном переборе завис."
            l "Тогда вот этот попробуем."
            $ renpy.music.play("audio/lera-listening-slow.ogg", channel="music", loop=True, fadeout=.4, fadein=.6)
            "Она убирает телефон. Новый трек играет тихо; громкость Лера больше не трогает."
            $ week4_event("lera", "listening_preference", "quieter")
    return
