init -9 python:
    cast_assets[("katya","party")]={"neutral":"images/week7/katya-party-v1.webp"}
    for person in ("nika","lera","asya","marta","zhenya","ulya"):
        cast_assets[(person,"halloween")]["earnest"]="images/week7/"+person+"-costume-earnest-"+("v2" if person=="asya" else "v1")+".webp"
    for room,path in (("hall","images/week7/party-hall-v7.webp"),("quiet","images/week7/quiet-room-v5.webp"),("games","images/week7/games-room-v4.webp"),("garden","images/week7/pumpkin-garden-v3.webp")):
        for costume in ("vampire","scientist","scarecrow","horns"):
            for guest in ("","nika","lera","asya","marta","zhenya","ulya"):
                for social in (False,True):
                    key="w7 " + ("social " if social else "venue ")+room+" "+costume+(" "+guest if guest else "")
                    actors=[("oleg","w7_"+costume,290 if social and guest else 370,45,950 if social and guest else 1000)]
                    if social:
                        actors.append(("katya","party",790 if guest else 1230,75 if guest else 45,950 if guest else 1050))
                    if guest:
                        actors.append((guest,"halloween",1280 if social else 1230,65 if social else 45,970 if social else 1050))
                    cast_stages[key]=(path,actors,None,"evening")
                    renpy.image("bg "+key,Transform(path,xysize=(1600,900)))

init python:
    def week7_venue_scene(room,person=None,social=False):
        if person is None: person=week7_party_guest()
        return "bg w7 "+("social " if social else "venue ")+room+" "+week7_costume+(" "+person if person else "")
