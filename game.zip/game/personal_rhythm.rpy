default personal_rhythm_state = None
default personal_rhythm_history = {}

init python:
    import json as rhythm_json
    import uuid as rhythm_uuid
    rhythm_people = ("nika", "lera", "asya", "marta", "zhenya", "ulya")
    _rhythm_token = None

    def rhythm_result(person, payload):
        # No relationship, consent, money or unlock flags enter from JavaScript.
        payload = payload if isinstance(payload, dict) else {}
        score = payload.get("score", 0)
        score = max(0, min(1000, int(score))) if isinstance(score, (float, int)) and score == score and abs(score) < 1e9 else 0
        result = "skipped" if payload.get("skipped") else "smooth" if score >= 630 else "funny"
        return dict(kind="personal_rhythm", person=person, score=score, result=result,
            scene_effect=dict(smooth="quiet_after", funny="water_break", skipped="offscreen_after")[result])

    def rhythm_close():
        global _rhythm_token
        if renpy.emscripten:
            import emscripten
            emscripten.run_script("if(window.OlegRhythm) OlegRhythm.close();")
        _rhythm_token = None

    def rhythm_poll():
        global _rhythm_token
        if not renpy.emscripten or not personal_rhythm_state:
            renpy.end_interaction("fallback")
            return
        import emscripten
        if _rhythm_token is None:
            with renpy.file("rhythm_parent.js") as f:
                emscripten.run_script(f.read().decode("utf-8"))
            _rhythm_token = rhythm_uuid.uuid4().hex
            settings = dict(muted=_preferences.get_mute("music"), volume=_preferences.get_volume("music"))
            args = [personal_rhythm_state["person"], _rhythm_token, personal_rhythm_state.get("snapshot"), settings]
            if not emscripten.run_script_int("Number(OlegRhythm.open.apply(null," + rhythm_json.dumps(args) + "))"):
                rhythm_close()
                renpy.end_interaction("fallback")
                return
        packet = rhythm_json.loads(emscripten.run_script_string("OlegRhythm.poll()"))
        if packet.get("snapshot") is not None:
            personal_rhythm_state["snapshot"] = packet["snapshot"]
        if packet.get("command") in ("done", "save", "skip", "fallback"):
            renpy.end_interaction(packet["command"])

    config.after_load_callbacks.append(rhythm_close)

screen personal_rhythm_board():
    modal True
    on "hide" action Function(rhythm_close)
    add Solid("#15131d")
    text ("Общая волна · " + dict(nika="Ника", lera="Лера", asya="Ася", marta="Марта", zhenya="Женя", ulya="Уля").get((personal_rhythm_state or {}).get("person"), "Вдвоём")) xalign .5 yalign .4
    textbutton "Вернуться к шарам" xalign .5 yalign .6 action Return("fallback")
    timer .25 repeat True action Function(rhythm_poll, _update_screens=False)

screen personal_rhythm_save_card():
    add Solid("#15131d")
    vbox:
        xalign .5 yalign .5 spacing 22
        text "ОБЩАЯ ВОЛНА" size 28 color "#d5b384" xalign .5
        text dict(nika="Общий перебор · Ника", lera="На одной частоте · Лера", asya="Сила притяжения · Ася", marta="Живая лента · Марта", zhenya="Упругий ответ · Женя", ulya="Жидкий свет · Уля")[personal_rhythm_state["person"]] size 44 xalign .5
        text "Движение на паузе" size 26 xalign .5

label personal_rhythm_play(person, context=""):
    if person not in rhythm_people or not renpy.emscripten or getattr(store, "_qa_gimmick_auto", False):
        call vignette_play("balloons", context)
        return _return
    $ personal_rhythm_state = dict(person=person, context=context, snapshot=None)
    $ _rhythm_music_pause = renpy.music.get_pause(channel="music")
    $ _rhythm_ambience_pause = renpy.music.get_pause(channel="ambience")
    $ renpy.music.set_pause(True, channel="music")
    $ renpy.music.set_pause(True, channel="ambience")
    window hide
    $ _rhythm_command = None
    while _rhythm_command not in ("done", "skip", "fallback"):
        call screen personal_rhythm_board
        $ _rhythm_command = _return
        $ rhythm_close()
        if _rhythm_command == "save":
            show screen personal_rhythm_save_card
            $ renpy.pause(.02, hard=True)
            $ renpy.take_screenshot()
            call screen save
            hide screen personal_rhythm_save_card
    $ renpy.music.set_pause(_rhythm_music_pause, channel="music")
    $ renpy.music.set_pause(_rhythm_ambience_pause, channel="ambience")
    if _rhythm_command == "fallback":
        $ personal_rhythm_state = None
        call vignette_play("balloons", context)
        return _return
    $ _rhythm_payload = (personal_rhythm_state.get("snapshot") or {}).get("result") or {}
    if _rhythm_command == "skip":
        $ _rhythm_payload = dict(skipped=True)
    $ _rhythm_result = rhythm_result(person, _rhythm_payload)
    $ personal_rhythm_history[context or person] = vignette_copy.deepcopy(_rhythm_result)
    $ personal_rhythm_state = None
    return vignette_copy.deepcopy(_rhythm_result)
