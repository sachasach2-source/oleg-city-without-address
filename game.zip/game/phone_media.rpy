# Photo messages use stable IDs, so reactions and old saves keep ordinary text keys.
init -1 python:
    phone_media = {
        "photo:varya_zine": {
            "path": "images/messenger/varya-zine-spread-v2.webp",
            "title": "Варя · зин «Дворы»",
            "caption": "Разворот 12–13 и обложка",
        },
    }

    def phone_media_item(message):
        return phone_media.get(message)

    def phone_message_label(message):
        media = phone_media_item(message)
        return (("Голосовое · " if media.get("kind") == "voice" else "Фото · ") + media["caption"]) if media else message

    def phone_photo_scale(media, bounds=(1360, 680)):
        width, height = renpy.image_size(media["path"])
        return min(float(bounds[0]) / width, float(bounds[1]) / height)

screen phone_photo_viewer(media_id):
    modal True
    zorder 500
    default zoomed = False
    $ media = phone_media[media_id]
    $ fit_scale = phone_photo_scale(media)
    add Solid("#060d14f5")
    key "game_menu" action Hide("phone_photo_viewer")
    key "K_ESCAPE" action Hide("phone_photo_viewer")
    hbox:
        xpos 80 ypos 28 xsize 1440 spacing 22
        text media["title"] size 27 color "#e4e8e7" yalign 0.5
        null xfill True
        textbutton ("− Фото целиком" if zoomed else "+ Увеличить ×2"):
            id "photo_zoom"
            action ToggleScreenVariable("zoomed")
            background phone_round("#213544", 10) hover_background phone_round("#36546a", 10)
            text_size 22 padding (18, 10)
        textbutton "Закрыть ×":
            id "photo_close"
            action Hide("phone_photo_viewer")
            background phone_round("#213544", 10) hover_background phone_round("#36546a", 10)
            text_size 22 padding (18, 10)
    if zoomed:
        text "Перетаскивай фото, чтобы рассмотреть края" xalign .5 ypos 86 size 18 color "#a9bac6"
        $ image_w, image_h = renpy.image_size(media["path"])
        $ detail_size = (int(image_w * fit_scale * 2), int(image_h * fit_scale * 2))
        # Auto scrollbars wrap this in a Side and collapse the picture area.
        # Keep the bounded viewport itself; drag/wheel move the unchanged image.
        viewport:
            id "photo_detail"
            xpos 80 ypos 115 xsize 1440 ysize 695
            mousewheel True draggable True
            xinitial 0.5 yinitial 0.5
            child_size (max(1440, detail_size[0]), max(695, detail_size[1]))
            fixed:
                xysize (max(1440, detail_size[0]), max(695, detail_size[1]))
                add Transform(media["path"], xysize=detail_size) xalign 0.5 yalign 0.5
    else:
        add Transform(media["path"], zoom=fit_scale) xalign 0.5 yalign 0.52
    text media["caption"] xalign 0.5 ypos 846 size 20 color "#a9bac6"
