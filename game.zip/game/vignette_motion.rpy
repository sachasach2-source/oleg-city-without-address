# Rendering interpolates at the display refresh rate; saved mechanics keep their
# deterministic 50 ms clock. Menus pause that clock and do not award points.
init -10 python:
    class VignetteMotion(renpy.Displayable):
        def __init__(self, **kwargs):
            super(VignetteMotion, self).__init__(**kwargs)
            self.last_kind = None
            self.last_ticks = -1
            self.stamp = 0.0
            self.drawn_lean = 0.0
            self.drawn_height = .35
            self.previous_st = 0.0
            self.children_cache = {}
            self.last_feedback = -1
            self.feedback_stamp = 0.0

        def child(self, path, w, h, rotate=0):
            key = (path, w, h)
            if key not in self.children_cache:
                self.children_cache[key] = Transform(path, xysize=(w, h), fit="contain")
            child = self.children_cache[key]
            return Transform(child, rotate=rotate, rotate_pad=True) if rotate else child

        def render(self, width, height, st, at):
            rv = renpy.Render(960, 610)
            s = vignette_state
            if not s:
                return rv
            kind = s["kind"]
            dt = max(0, min(.05, st - self.previous_st))
            self.previous_st = st
            if self.last_kind != kind or s["ticks"] < self.last_ticks:
                self.drawn_lean, self.drawn_height = s["lean"], s["height"]
                self.last_kind = kind
            if self.last_feedback != s["feedback_id"]:
                self.last_feedback, self.feedback_stamp = s["feedback_id"], st
            if self.last_ticks != s["ticks"]:
                self.last_ticks, self.stamp = s["ticks"], st
            t = s["ticks"] * .05
            if s["running"]:
                t += max(0, min(.05, st - self.stamp))
            blend = min(1.0, dt * 25)
            self.drawn_lean += (s["lean"] - self.drawn_lean) * blend
            self.drawn_height += (s["height"] - self.drawn_height) * blend

            def paint(d, x, y):
                rr = renpy.render(d, 960, 610, st, at)
                rv.blit(rr, (int(x), int(y)))

            if kind == "box":
                parcel = self.child(vignette_art("parcel"), 360, 260, self.drawn_lean * 24)
                rr = renpy.render(parcel, 960, 610, st, at)
                rv.blit(rr, (int(480 - rr.width / 2), int(290 - rr.height / 2 + (vignette_math.sin(t * 7) * 3 if s["running"] else 0))))
                paint(Solid("#ffe0a1", xysize=(10, 34)), 475 + self.drawn_lean * 320, 447)
            elif kind == "balloons":
                target = .48 + .20 * vignette_math.sin(t * .7) + .06 * vignette_math.sin(t * 1.9)
                by = 410 - target * 330
                oy = 410 - self.drawn_height * 330
                paint(self.child(vignette_art("balloon-blue"), 160, 220), 570 + vignette_math.sin(t * .7) * 5, by)
                paint(self.child(vignette_art("balloon-coral"), 160, 220), 280 + vignette_math.sin(t) * 5, oy)
                paint(Text("ОЛЕГ", size=18, color="#fff0d7"), 325, oy + 192)
                paint(Text("ОНА", size=18, color="#d1eff5"), 620, by + 192)
                if s["squeaks"]:
                    paint(self.child(vignette_art("duck"), 95, 65), 780 - (t * 35) % 400, 80)
                if abs(s["height"] - target) < .15:
                    for i in range(5):
                        paint(Text("✦", size=17 + i % 2 * 5, color="#f5d6ac"), 465 + vignette_math.sin(t + i) * 28, 190 + i * 45 + vignette_math.sin(t * 2 + i) * 7)
            elapsed = st - self.feedback_stamp
            if s["last_gain"] > 0 and 0 <= elapsed < .65:
                cx, cy = {"riff": (150, 310), "box": (480, 290), "balloons": (480, 280), "laundry": (480, 285)}.get(kind, (480, 260))
                for i in range(9):
                    angle = i * 2.399 + s["feedback_id"]
                    distance = 20 + elapsed * (90 + (i % 3) * 28)
                    spark = Text("✦" if i % 3 == 0 else "·", size=max(6, int(24 * (1 - elapsed / .65))), color=vignette_colours[kind])
                    paint(spark, cx + vignette_math.cos(angle) * distance, cy + vignette_math.sin(angle) * distance + elapsed * elapsed * 95)
            renpy.redraw(self, 0)
            return rv

    def vignette_furniture_dragged(drags, drop):
        drag = drags[0]
        item = int(drag.drag_name)
        x, y = vignette_state["layout"][item]
        dx, dy = drag.x - (58 + x * 116), drag.y - (58 + y * 116)
        if max(abs(dx), abs(dy)) < 20:
            renpy.end_interaction(("furniture", item))
        else:
            delta = (1 if dx > 0 else -1, 0) if abs(dx) > abs(dy) else (0, 1 if dy > 0 else -1)
            renpy.end_interaction(("slide", (item, delta)))
        return True

    def vignette_progress(s):
        kind = s["kind"]
        if kind in ("photo", "shadow"):
            return s["rounds"] / 3.0
        if kind == "studio":
            return vignette_studio_matches(s) / 7.0
        if kind == "laundry":
            return len(s["places"]) / float(vignette_laundry_count)
        if kind == "riff":
            return s["rounds"] / 2.0
        if kind == "hum":
            return max(0, 1 - vignette_hum(s)[0])
        return min(1, s["ticks"] / (360.0 if kind == "box" else 320.0))

    def vignette_next_action(s):
        return {
            "photo": "ПЕРЕТАЩИ РАМКУ → СНИМИ",
            "riff": "ПОСЛУШАЙ → ПОВТОРИ ПОРЯДОК",
            "studio": "ВЫБЕРИ МЕБЕЛЬ → СДВИНЬ",
            "hum": "ВХОД → ПОЛЗУНКИ → ПРОСЛУШАТЬ",
            "laundry": "РАЗВЕСЬ → УРАВНОВЕСЬ",
            "box": "КЛОНИТСЯ ВПРАВО? ЖМИ ←",
            "shadow": "НАРИСУЙ ОДНИМ ДВИЖЕНИЕМ",
            "balloons": "ДЕРЖИ — ВВЕРХ · ОТПУСТИ — ВНИЗ",
        }[s["kind"]]

default vignette_motion_layer = VignetteMotion()

transform vignette_entrance:
    alpha 0.0 yoffset 12
    easeout .25 alpha 1.0 yoffset 0

transform vignette_score_pop(token):
    on show:
        alpha 1.0 yoffset 10
        easeout .25 yoffset 0
        pause .7
        linear .4 alpha .0
    on replace:
        alpha 1.0 yoffset 10
        easeout .25 yoffset 0
        pause .7
        linear .4 alpha .0

transform vignette_cloth_appear:
    alpha 0.0 yoffset -18 rotate -4
    easeout .25 alpha 1.0 yoffset 0 rotate 0

transform vignette_piece_settle(dx, dy):
    subpixel True
    xoffset dx yoffset dy
    easeout .16 xoffset 0 yoffset 0
