# One live conversation: own costume, optional duo, then how to prepare it.
# The classic presentation remains in week7_guest_costume for the toggle.
label week7_costume_planning_chat:
    $ week7_token = "w7_{}_costume_planning_{}".format(week7_person, week7_chat_index)
    $ week7_chat_index += 1
    python:
        week7_planning_incoming = [(week4_names[week7_person], week7_plan_text), ("Олег", week7_own_description)]
        week7_planning_materials = week4_phone_dialogue(
            [(week4_names[week7_person], "Я в семь пятнадцать зайду в магазин тканей недалеко от твоей работы. У меня до без четверти восемь есть время. Если хочешь, приходи.")],
            [("meet", "Хочу. Давай у магазина в семь пятнадцать. Потом мне домой собираться.", [(week4_names[week7_person], "Хорошо, адрес кинула. Я тоже потом доделывать поеду.")]),
             ("remote", "Сегодня останусь дома. Но могу сейчас помочь придумать, как доделать.", [(week4_names[week7_person], "Давай. Тут как раз есть над чем подумать.")])])["start"]
        if week7_pair_costumes.get(week7_person) == week7_costume:
            week7_pair_text = {
                "nika": "Мы можем вампирским дуэтом прийти. У тебя бордовая лента, у меня подкладка. Только без конкурса, где нас заставят сценку разыгрывать.",
                "lera": "Слушай, Дороти и Пугало! Давай вместе зайдём, как будто так и задумывали? Тотошку я не нашла. Считай, он дома остался.",
                "ulya": "Ты в халате, я сбежавшая цифровая нечисть. Можем сказать, что из одной лаборатории. Только я не буду весь вечер изображать, как ты меня ловишь."
            }[week7_person]
            week7_planning_dialogue = week4_phone_dialogue(week7_planning_incoming + [(week4_names[week7_person], week7_pair_text)], [
                ("pair", "Давай. Мне нравится общий образ. Встретимся у входа и зайдём вместе, без сценки.", [(week4_names[week7_person], "Вот так и договорились.")]),
                ("separate", "Мне нравится твой костюм. Но давай каждый в своём образе, без общей истории.", [(week4_names[week7_person], "Хорошо. Тогда просто встретимся у входа.")])])
            for option in week7_planning_dialogue["start"]["options"]:
                option["next"] = "materials"
            week7_planning_dialogue["materials"] = week7_planning_materials
        else:
            week7_planning_materials["messages"] = week7_planning_incoming + week7_planning_materials["messages"]
            week7_planning_dialogue = {"start": week7_planning_materials}
    call screen phone_thread([], caption=week4_names[week7_person], conversation=week7_token, past=week7_history.get(week7_person, [])[-4:], dialogue=week7_planning_dialogue)
    $ week7_planning_transcript, week7_planning_decisions, week7_planning_pending = phone_conversation_state(week7_token, [], week7_planning_dialogue)
    $ week7_history[week7_person] = week7_history.get(week7_person, []) + week7_planning_transcript
    $ week7_outfits[week7_person]["prep"] = week7_planning_decisions[-1][1]
    if week7_pair_costumes.get(week7_person) == week7_costume:
        $ week7_outfits[week7_person]["pair"] = week7_planning_decisions[0][1] == "pair"
        if week7_outfits[week7_person]["pair"]:
            $ week7_outfits[week7_person]["pair_costume"] = week7_costume
            $ week7_outfits[week7_person]["pair_context"] = "friends" if week7_friend(week7_person) else "shared_costume"
            $ week7_event("paired_costume_agreed", week7_costume, week7_person)
        else:
            $ week7_event("paired_costume_declined", "Каждый в своём образе; приглашение сохраняется", week7_person)
    return
