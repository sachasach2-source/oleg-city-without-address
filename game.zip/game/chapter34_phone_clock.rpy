# Chronology for chapters 3–4 only. Earlier chapters keep their original clock.
default chapter34_phone_days = {}
default chapter34_phone_tokens = {}

init 30 python:
    _chapter34_original_stamp = phone_stamp_messages
    _chapter34_original_status = phone_status_time

    def chapter34_phone_scope(token):
        if str(token).startswith("w4_"):
            return (4, week4_day)
        if str(token).startswith("ch3_"):
            return (3, -1 if "пятниц" in place_name.lower() else chapter3_day)
        return None

    def chapter34_phone_reset(chapter):
        global chapter34_phone_days, chapter34_phone_tokens
        chapter34_phone_days = {k:v for k,v in chapter34_phone_days.items() if k[0] != chapter}
        chapter34_phone_tokens = {k:v for k,v in chapter34_phone_tokens.items() if v["scope"][0] != chapter}

    def chapter34_scene_minute(scope):
        found = re.search(r"(\d{1,2}):(\d{2})", place_name)
        minute = int(found[1]) * 60 + int(found[2]) if found else (week4_clock if scope[0] == 4 else chapter3_clock)
        return max(minute, week4_clock if scope[0] == 4 else chapter3_clock if scope[1] >= 0 else minute)

    def chapter34_authored_minute(token, sender, message):
        # These updates arrived while Oleg was busy. Reading them late must not
        # turn a twenty-minute toilet emergency into a five-hour one.
        if str(token).startswith("ch3_buldak"):
            for part, minute in zip(chapter3_buldak_parts[:3], (650, 780, 798)):
                for index, item in enumerate(part):
                    if (sender, message) == tuple(item):
                        return minute + index
        return None

    def chapter34_sync_phone_clock(scope, minute):
        global place_name, chapter3_clock, week4_clock
        if scope[0] == 4:
            week4_clock = max(week4_clock, minute)
        elif scope[1] >= 0:
            chapter3_clock = max(chapter3_clock, minute)
        clock = "{:02d}:{:02d}".format(minute // 60, minute % 60)
        place_name = re.sub(r"\b\d{1,2}:\d{2}\b", clock, place_name)

    def phone_stamp_messages(token, messages, caption=None):
        scope = chapter34_phone_scope(token)
        if scope is None:
            return _chapter34_original_stamp(token, messages, caption)
        if caption is not None:
            phone_thread_contacts[token] = caption
        now = chapter34_scene_minute(scope)
        meta = chapter34_phone_tokens.get(token)
        fresh = not meta or meta["scope"] != scope
        if fresh:
            meta = {"scope":scope, "start":max(now, chapter34_phone_days.get(scope, now - 1) + 1)}
            chapter34_phone_tokens[token] = meta
        cursor = meta["start"]
        latest = max(now, chapter34_phone_days.get(scope, now))
        for index, (sender, message) in enumerate(messages):
            key = (token, index)
            saved = phone_message_times.get(key)
            authored = chapter34_authored_minute(token, sender, message)
            if authored is not None:
                minute = authored
            elif not fresh and saved and saved[:2] == (sender, message):
                hour, minute = map(int, saved[2].split(":"))
                minute += hour * 60
            else:
                minute = max(cursor, latest + 1) if sender == "Олег" else cursor
            stamp = "{:02d}:{:02d}".format((minute // 60) % 24, minute % 60)
            phone_message_times[key] = (sender, message, stamp)
            cursor = max(cursor, minute + 1)
            latest = max(latest, minute)
        for key in list(phone_message_times):
            if key[0] == token and key[1] >= len(messages):
                del phone_message_times[key]
        chapter34_phone_days[scope] = latest
        chapter34_sync_phone_clock(scope, latest)

    def phone_status_time(index, token):
        scope = chapter34_phone_scope(token)
        if scope is None:
            return _chapter34_original_status(index, token)
        minute = max(chapter34_scene_minute(scope), chapter34_phone_days.get(scope, 0))
        return "{:02d}:{:02d}".format((minute // 60) % 24, minute % 60)
