init -1 python:
    style.default.font = "DejaVuSans.ttf"
    style.default.size = 26
    style.default.color = "#eeeae1"
    style.default.language = "unicode"
    style.button.background = Solid("#14212be8")
    style.button.hover_background = Solid("#31444ceF")
    style.button.padding = (24, 16)
    style.button_text.color = "#ddd8cf"
    style.button_text.hover_color = "#f1c990"
    style.button_text.selected_color = "#f1c990"
    style.button_text.size = 25
    style.bar.left_bar = Solid("#c29f70")
    style.bar.right_bar = Solid("#37434a")
    style.bar.thumb = Solid("#eeeae1")
    style.bar.thumb_offset = 5
    style.bar.xsize = 540
    style.bar.ysize = 10
    style.slider = style.bar
    style.vscrollbar.base_bar = Solid("#27323b")
    style.vscrollbar.thumb = Solid("#9c8c75")
    style.vscrollbar.xsize = 8

screen say(who, what):
    if ui_dialogue_visible():
        if not main_menu and save_name and (recent_autosave_resume or save_name != recent_autosave_stage):
            timer .6 action Function(recent_stage_autosave, _update_screens=False)
        window:
            id "window"
            background context_panel("dialogue")
            xpos (1006 if cast_background_key() == "w5 kiss lera" else 54)
            xsize (540 if cast_background_key() == "w5 kiss lera" else 1492 if cast_background_key() in ("w4 lera sofa", "w4 lera touch", "w4 lera awkward", "w4 workshop", "w4 nika", "w4 rita introduction") else 1000)
            ypos 840 yanchor 1.0
            padding (26, 20)
            vbox:
                spacing 9
                if who:
                    text who id "who" size 23 color "#d5b384"
                text what id "what" size story_text_size() line_spacing 4 xmaximum (464 if cast_background_key() == "w5 kiss lera" else 1416 if cast_background_key() in ("w4 lera sofa", "w4 lera touch", "w4 lera awkward", "w4 workshop", "w4 nika", "w4 rita introduction") else 924)
        if not renpy.get_screen("choice"):
            text "▸" xpos (1518 if cast_background_key() in ("w5 kiss lera", "w4 lera sofa", "w4 lera touch", "w4 lera awkward", "w4 workshop", "w4 nika", "w4 rita introduction") else 1020) ypos 810 size 18 color "#b9a17e"

screen scene_marker():
    if not ui_in_menu() and not any(renpy.get_screen(name) for name in ui_focus_screens+("confirm",)):
        use ui_scene_marker

screen ui_scene_marker():
    frame:
        background context_panel("panel")
        padding (25, 15)
        xpos 42 ypos 32
        xmaximum 900
        vbox:
            spacing 4
            text city_chapter.upper() size 16 color "#d2b68e" kerning 3
            text place_name size 21 color "#e2e4e3" xmaximum 850

screen quick_menu():
    if ui_quick_visible():
        zorder 100
        frame:
            xalign 0.5 yalign .998 padding (13, 5) background context_panel("quick")
            hbox:
                spacing 17
                if messenger_enabled():
                    textbutton ("Телефон · новые" if any(item["unread"] for item in messenger_deliveries.values()) or messenger_chapter() == 7 and week7_inbox_unread() else "Телефон") action Function(messenger_open_session):
                        id "messenger_open"
                        background None hover_background None padding (3,2) text_size 19
                for label, act in [("Назад", Rollback()), ("История", ShowMenu("history")), ("Сохранить", ShowMenu("save")), ("Загрузить", ShowMenu("load")), ("Дневник", ShowMenu("diary")), ("Галерея", ShowMenu("bonus_gallery")), ("Настройки", ShowMenu("preferences")), ("Скрыть текст", HideInterface())]:
                    textbutton label action act:
                        background None hover_background None padding (3, 2)
                        text_size 17 text_color "#e4dfd4" text_hover_color "#ffdc9c"
                textbutton ("Звук выкл." if soundscape_muted() else "Звук вкл.") action Preference("all mute", "toggle"):
                    background None hover_background None padding (3, 2)
                    text_size 17 text_color "#e4dfd4" text_hover_color "#ffdc9c"

screen choice(items):
    modal True
    $ available = [item for item in items if item.action is not None and renpy.is_sensitive(item.action)]
    if len(available) == 1:
        timer .01 action available[0].action
    else:
        if cast_background_key() in ("ch4 table", "w4 rita introduction"):
            use chapter4_table_choice(items)
        elif cast_choice_layout():
            use cast_compact_choice(items, cast_choice_layout())
        else:
            use ui_story_options("НАСТРОЕНИЕ ОЛЕГА" if mood_menu else "ЧТО СКАЖЕТ ОЛЕГ?",[(i.caption,i.action) for i in items],ui_choice_prompt())

screen main_menu():
    tag menu
    on "show" action Function(set_soundscape, "title")
    add Transform("images/neva.webp", xysize=(1600, 900))
    add Solid("#08131a85")
    frame:
        background context_panel("panel")
        xpos 92 ypos 56 xsize 665 padding (48, 30)
        vbox:
            spacing 10
            text "ПЕТЕРБУРГСКАЯ НОВЕЛЛА" size 16 kerning 3 color "#d5b384"
            text "ОЛЕГ\nИ АЛЬТУШКИ" size 58 bold True line_spacing 2 outlines [(1,"#d5b38420",0,1)]
            text "Город без адреса" size 29 color "#d5b384"
            text "Вернуться в город проще,\nчем снова почувствовать себя дома." size 22 line_spacing 6 color "#bfc6c9"
            null height 4
            textbutton "Начать историю" action Start() xfill True padding (24, 11) style "ui_primary_button"
            hbox:
                spacing 12
                textbutton "Вторая глава" action ShowMenu("chapter_select") xsize 278 text_size 24 padding (16, 11)
                textbutton "Третья глава" action ShowMenu("chapter3_select") xsize 278 text_size 24 padding (16, 11)
            hbox:
                spacing 12
                textbutton "Четвёртая глава" action ShowMenu("week4_select") xsize 278 text_size 24 padding (16, 11)
                textbutton "Пятая глава" id "week5_start_button" action ShowMenu("week5_select") xsize 278 text_size 24 padding (16, 11)
            hbox:
                spacing 12
                textbutton "Шестая глава" id "week6_start_button" action ShowMenu("week6_select") xsize 278 text_size 24 padding (16, 11)
                textbutton "Седьмая глава" id "week7_start_button" action ShowMenu("week7_select") xsize 278 text_size 24 padding (16, 11)
            hbox:
                spacing 12
                textbutton "Продолжить" action ShowMenu("load") xsize 278 padding (16, 11)
                textbutton "Галерея" action ShowMenu("bonus_gallery") xsize 278 padding (16, 11)
            hbox:
                spacing 12
                textbutton "Настройки" action ShowMenu("preferences") text_size 21 padding (16, 10)
                textbutton "Выход" action Quit(confirm=True) text_size 21 padding (16, 10)
    text "7 ГЛАВ · ВЕРСИЯ [config.version]     /     РОМАНТИКА, МУЗЫКА И ПЕТЕРБУРГ" xpos 94 ypos 847 size 15 color "#c0c1bd" kerning 1
    text "Все свидания и героини вымышлены." xalign 0.96 ypos 847 size 14 color "#c0c1bd"

screen chapter_select():
    tag menu
    use menu_shell("Свои вещи · глава вторая"):
        vbox:
            xpos 100 ypos 180 xsize 1200 spacing 24
            text "Выбери, чем закончилась первая глава, или продолжи своё сохранение." size 25 color "#bfc6c9"
            textbutton "С Никой назначено свидание" action Start("chapter2_connection") xsize 900
            textbutton "С Никой договорились дружить" action Start("chapter2_friendship") xsize 900
            textbutton "Я отложил ответ, Ника идёт с подругой" action Start("chapter2_delay") xsize 900
            textbutton "Настроить свою историю…" id "history_customize" action ShowMenu("chapter_history_builder", 2) xsize 900

screen menu_shell(title):
    add context_panel("menu")
    text title xpos 100 ypos 65 xmaximum 1090 size 42 color "#e8dfd2" outlines [(1,context_palettes[context_theme()]["edge"]+"26",0,1)]
    textbutton "← Вернуться" action Return() xpos 1230 ypos 65 text_size 22
    transclude

screen save():
    tag menu
    use slots("Сохранить", True)

screen load():
    tag menu
    use slots("Загрузить", False)

screen slots(title, saving):
    use menu_shell(title):
        hbox:
            xpos 580 ypos 66 spacing 20
            textbutton "Сохранить" action ShowMenu("save") sensitive not saving text_size 22
            textbutton "Загрузить" action ShowMenu("load") sensitive saving text_size 22
        grid 3 2:
            xpos 100 ypos 180 spacing 24
            for i in range(1, 7):
                button:
                    xsize 450 ysize 240
                    action (FileSave(i) if saving else FileLoad(i))
                    sensitive not saving or FileCurrentPage() not in ("auto", "quick")
                    vbox:
                        spacing 12
                        hbox:
                            spacing 16
                            add FileScreenshot(i) xysize (176, 99) fit "contain"
                            vbox:
                                spacing 12 xsize 205
                                text "СЛОТ [i]" size 17 color "#d5b384" kerning 2
                                text FileTime(i, format="%d.%m.%Y\n%H:%M", empty="Пусто") size 20
                        text (FileSaveName(i) or ("Без названия" if FileLoadable(i) else "")) size 19 color "#b5c0c5" xmaximum 390
        hbox:
            xpos 100 ypos 725 spacing 12
            text "СТРАНИЦА" size 18 yalign 0.5 color "#b5c0c5"
            textbutton "Авто · последние этапы" id "autosave_page" action FilePage("auto")
            for page in range(1, 5):
                textbutton str(page) action FilePage(page)
        if FileCurrentPage() == "auto":
            text "Шесть последних автосохранений · самое новое в первом слоте" xpos 100 ypos 785 size 20 color "#b5c0c5"

screen history():
    tag menu
    use menu_shell("История разговора"):
        viewport:
            xpos 100 ypos 155 xsize 1370 ysize 650
            mousewheel True draggable True scrollbars "vertical"
            side_yfill True
            side_spacing 8
            vscrollbar_xsize 18
            vscrollbar_unscrollable "hide"
            yinitial 1.0
            vbox:
                spacing 26
                for h in _history_list:
                    vbox:
                        spacing 7
                        if h.who:
                            text h.who size 20 color "#d5b384"
                        text h.what size story_text_size(25) xmaximum 1270 substitute False
                if not _history_list:
                    text "Здесь появятся прочитанные реплики." color "#a9b5bc"

screen diary():
    tag menu
    use menu_shell("Город без адреса"):
        text "Четыре месяца в отелях. Один город, в котором хочется остаться." xpos 100 ypos 150 size 23 color "#d5b384"
        viewport:
            xpos 100 ypos 225 xsize 1300 ysize 535
            mousewheel True draggable True scrollbars "vertical"
            vbox:
                spacing 24
                for entry in diary_readable_entries():
                    text "— " + entry size story_text_size(26) xmaximum 1200 line_spacing 5
                if not diary_readable_entries():
                    text "Пока ничего не записал. Вернусь сюда после прогулки." size story_text_size(26) color "#b5c0c5"

screen preferences():
    tag menu
    use menu_shell("Настройки"):
        hbox:
            xpos 100 ypos 180 spacing 105
            vbox:
                xsize 595 spacing 18
                text "ОТОБРАЖЕНИЕ" size 18 kerning 2 color "#d5b384"
                hbox:
                    spacing 15
                    textbutton "Окно" action Preference("display", "window")
                    textbutton "Полный экран" action Preference("display", "fullscreen")
                textbutton ("Новый мессенджер: включён" if messenger_enabled() else "Новый мессенджер: выключен"):
                    id "messenger_experiment_toggle"
                    action ToggleField(persistent, "messenger_experiment")
                    text_size 19
                text "Скорость текста" size 23
                bar value Preference("text speed")
                text "Размер текста сцен и дневника" size 21
                hbox:
                    spacing 8
                    for value, caption in ((24,"Меньше"),(27,"Обычный"),(30,"Крупнее"),(33,"Большой")):
                        textbutton caption:
                            id ("story_font_" + str(value))
                            action SetField(persistent, "story_text_size", value)
                            selected persistent.story_text_size == value
                            text_size 18 padding (10,9)
                if renpy.emscripten:
                    textbutton ("Лёгкий режим: включён" if web_lite_enabled() else "Лёгкий режим: выключен"):
                        action ToggleField(persistent, "web_lite") text_size 22
                    if web_lite_enabled():
                        text "Статичные фоны и облегчённое оформление." size 18 color "#a9b5bc"
                textbutton ("Анимация фонов: включена" if persistent.city_motion and not web_lite_enabled() else "Анимация фонов: выключена"):
                    action Function(set_background_motion, not (persistent.city_motion and not web_lite_enabled())) text_size 22
                null height 25
                text "Пробел / Enter — дальше\nКолесо вверх — назад\nH — скрыть текст" size 20 line_spacing 12 color "#a9b5bc"
            vbox:
                xsize 595 spacing 23
                text "ЗВУК" size 18 kerning 2 color "#d5b384"
                text "Музыка" size 23
                bar value Preference("music volume")
                text "Город и фоновые звуки" size 23
                bar value Preference("mixer ambience volume")
                text "Уведомления" size 23
                bar value Preference("sound volume")
                text "Голосовые сообщения" size 23
                bar value Preference("voice volume")
                textbutton ("Включить звук" if soundscape_muted() else "Выключить весь звук") action Preference("all mute", "toggle") alt "Переключить весь звук"
                textbutton ("В фоне: включён" if _preferences.audio_when_unfocused else "В фоне: выключен") action [Preference("audio when unfocused", "toggle"), ToggleField(_preferences, "audio_when_minimized")]:
                    text_size 20
                text "В переписках музыка становится тише.\nУровни сохраняются между запусками." size 18 line_spacing 7 color "#a9b5bc"

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    add Solid("#070e16db")
    frame:
        xalign 0.5 yalign 0.5 xsize 900 padding (45, 40) background context_panel("panel")
        vbox:
            spacing 30
            text message size 28 xalign 0.5 text_align 0.5
            hbox:
                xalign 0.5 spacing 24
                textbutton "Да" action yes_action
                textbutton "Нет" action no_action

screen notify(message):
    zorder 150
    frame:
        xpos 1558 xanchor 1.0 ypos (196 if renpy.get_screen("bonus_gallery_unlocked") else 32) xmaximum 560 padding (22,16) background context_panel("panel")
        text message size 21 xmaximum 516
    timer 3.0 action Hide("notify")

screen chapter_card(title, subtitle):
    modal True
    add Solid("#0a141dcc")
    vbox:
        xalign 0.5 yalign 0.44 spacing 22
        text subtitle.upper() size 18 color "#d5b384" kerning 3 xalign 0.5
        text title size 54 xalign 0.5
    textbutton "Продолжить →" action Return() xalign 0.5 yalign 0.66 text_size 20

# Draw the device shell with native Ren'Py canvas primitives, so UI stays crisp.
init -1 python:
    class PhoneShell(renpy.Displayable):
        def render(self, width, height, st, at):
            rv = renpy.Render(500, 844)
            canvas = rv.canvas()
            for color, inset, radius in [("#05090c", 0, 38), ("#22313b", 3, 35), ("#0f1d26", 7, 31)]:
                w, h = 500 - inset * 2, 844 - inset * 2
                canvas.rect(color, (inset + radius, inset, w - radius * 2, h))
                canvas.rect(color, (inset, inset + radius, w, h - radius * 2))
                for cx in [inset + radius, 500 - inset - radius]:
                    for cy in [inset + radius, 844 - inset - radius]:
                        canvas.circle(color, (cx, cy), radius)
            return rv

    @phone_functools.lru_cache(maxsize=1)
    def phone_shell_cached():
        return PhoneShell()

    def phone_shell():
        return phone_shell_cached() if renpy.emscripten else PhoneShell()

screen phone_thread(messages, caption="Мои шлюхи", past=None, conversation=None, dialogue=None, instant=False, inbox_mode=False, archive_times=None):
    modal True
    default messenger_view = messenger_initial_view(conversation or (caption, tuple(messages)), inbox_mode, instant)
    default messenger_archive_contact = messenger_views.get(conversation or (caption, tuple(messages)), {}).get("contact")
    default messenger_notice_visible = True
    default messenger_history_limits = {}
    # Ren'Py can restore an existing screen scope from a pre-unified save,
    # bypassing default expressions. Normalize that scope as well as the model.
    if messenger_enabled() and messenger_view == "archive" and messenger_archive_contact and messenger_caption(messenger_archive_contact) == messenger_caption(caption):
        $ messenger_view = "thread"
    if inbox_mode:
        key "game_menu" action Return("__inbox__")
    on "show" action Function(soundscape_reading, True)
    on "hide" action Function(messenger_finish_view, caption, messenger_view)
    default reaction_target = None
    default chat_scroll = ui.adjustment(step=65, ranged=phone_scroll_new_messages)
    default reading_paused = False
    default reply_scroll = ui.adjustment()
    default archive_start = max(0, len(messages) - 40) if instant else 0
    default revealed_count = len(messages) if instant else 0
    $ active_dialogue = dialogue if dialogue is not None else phone_dialogues.get(conversation, {})
    $ transcript, reply_decisions, reply_node = phone_conversation_state(conversation, messages, active_dialogue)
    $ pending_reply = bool(conversation and reply_node is not None)
    $ reply_count = len(active_dialogue[reply_node]["options"]) if pending_reply else 0
    if messenger_enabled() and not inbox_mode and not instant and messenger_view != "closed":
        key "game_menu" action (Function(messenger_close_story, pending_reply, reply_decisions) if messenger_view == "list" else Function(messenger_switch, "list"))
    $ visible_messages = transcript if conversation else messages[archive_start:] if instant else messages
    $ thread_token = conversation or (caption, tuple(messages))
    $ arriving = revealed_count < len(visible_messages)
    $ next_sender = visible_messages[revealed_count][0] if arriving else None
    if arriving and not reading_paused and (messenger_view == "thread" or not messenger_enabled()):
        timer phone_read_delay(visible_messages, revealed_count) repeat True action Function(phone_reveal_next, revealed_count) id ("arrival", revealed_count)
    # Only recorded messages belong to this playthrough. Caller-provided tails
    # are legacy presentation hints, never evidence that a message was received.
    $ past = []
    if not instant:
        on "show" action [Function(phone_stamp_messages, thread_token, visible_messages, caption), Function(messenger_note_delivery, thread_token, caption, visible_messages, inbox_mode)]
    $ history_rows = messenger_chat_history(caption, thread_token) if not instant else []
    $ unified_rows = messenger_chat_rows(caption, thread_token, visible_messages, revealed_count) if not instant else []
    $ media_thread = any(phone_media_item(msg) for sender, msg in visible_messages)
    $ reply_y, reply_height, reply_content_height, reply_size = phone_reply_geometry(active_dialogue[reply_node]["options"]) if pending_reply else (535, 0, 0, 19)
    $ message_y = 158
    $ message_bottom = (reply_y-13 if pending_reply and not arriving else 750)
    if reaction_target is not None:
        $ message_bottom = min(message_bottom,reply_y-76 if pending_reply and not arriving else 667)
    $ messenger_display_view = messenger_view if messenger_enabled() else "thread"
    if messenger_display_view == "list":
        use messenger_contacts(caption, True, pending_reply, reply_decisions, messenger_chapter(conversation))
    elif messenger_display_view == "archive":
        add Solid("#071019a8")
        use messenger_history(messenger_archive_contact, Function(messenger_switch, "list"), messenger_history_limits.get(messenger_archive_contact, 40))
    elif messenger_display_view == "closed":
        # A synchronous story decision is still pending. Do not strand the
        # player on an apparently frozen scene after minimizing the phone.
        key "dismiss" action Function(messenger_switch, "thread", caption)
        frame:
            xpos 55 ypos 650 xsize 790 padding (24,18)
            background context_panel("panel")
            vbox:
                spacing 10
                text messenger_required_reason(conversation, caption) size 21 color "#e4e8e7"
                textbutton "Вернуться к сообщению →":
                    id "messenger_resume_reply"
                    action Function(messenger_switch, "thread", caption)
                    text_size 21
                textbutton "Посмотреть другие чаты":
                    id "messenger_reopen"
                    action Function(messenger_switch, "list")
                    text_size 18 text_color "#91b8d5"
    else:
        add phone_shell() xpos 1050 ypos 26
        fixed:
            xpos 1050 ypos 26 xsize 500 ysize 844
            add Solid("#030709") xpos 205 ypos 13 xsize 90 ysize 8
            text (chapter3_time(week7_clock) if instant else phone_status_time(max(0, revealed_count - 1), thread_token)) xpos 29 ypos 29 size 14 color "#b1bfc7"
            text "LTE  ▰" xpos 415 ypos 29 size 14 color "#b1bfc7"
            textbutton "←":
                id "phone_back"
                action (Function(messenger_switch, "list") if messenger_enabled() and not inbox_mode and not instant else Return("__inbox__" if inbox_mode else reply_decisions)) sensitive (inbox_mode or messenger_enabled() or (not pending_reply and not arriving)) xpos 17 ypos 58 background None hover_background None padding (8, 4)
                text_size 25 text_color "#91b8d5"
            fixed:
                xpos 62 ypos 61 xsize 48 ysize 48
                use phone_avatar(caption if caption in phone_profiles else "Агент", 48)
            text caption xpos 123 ypos 59 size 25 color "#e4e8e7" xmaximum 330
            text ((next_sender + " печатает…") if arriving and next_sender != "Олег" else "6 участников" if caption == "Четверг точно" else "Саня · Саша · Олег" if caption == "Мои шлюхи" else "была недавно" if caption in ("Ника", "Лера", "Ася", "Варя", "Марта") else "был недавно") xpos 124 ypos 94 size 13 color "#8fa6b3"
            if str(thread_token).startswith("w7_friends_") and week7_attachments:
                textbutton "Фото и звук":
                    id "week7_attachments"
                    xpos 326 ypos 89 padding (4,2) text_size 14 text_color "#aac5d8"
                    action Show("week7_attachment_archive")
            add Solid("#304552") xpos 22 ypos 124 xsize 456 ysize 1
            textbutton ("В конец ↓" if instant else "К новым ↓"):
                action Function(phone_scroll_to_latest)
                xpos 340 ypos 133
                padding (4, 2) text_size 13 text_color "#91b8d5" background None
            viewport:
                id "phone_messages"
                xpos 26 ypos message_y xsize 448 ysize max(40,message_bottom-message_y)
                mousewheel True draggable True scrollbars "vertical"
                side_yfill True
                side_spacing 8
                vscrollbar_xsize 18
                vscrollbar_unscrollable "hide"
                yinitial (1.0 if history_rows or instant or conversation and (conversation.startswith(("ch3_after_", "ch3_buldak", "ch3_evening_")) or conversation in ("ch3_friends_morning", "ch3_friends_plan", "ch3_friends_choices", "ch3_legal", "ch3_voice_friends", "ch3_date_result")) else 0.0) yadjustment chat_scroll
                vbox:
                    spacing 6 xsize 414
                    if instant and archive_start > 0:
                        textbutton "Ранние сообщения ↑":
                            id "phone_archive_earlier"
                            action [SetScreenVariable("archive_start", max(0, archive_start - 40)), Function(chat_scroll.change, 0)]
                            text_size 17 text_color "#91b8d5" padding (8,8)
                    if instant and not visible_messages:
                        text "В этой переписке пока нет сообщений." size 19 color "#9eb2bf" xmaximum 400
                    text ("ПЕРЕПИСКА" if instant or history_rows else "НОВЫЕ СООБЩЕНИЯ") size 11 color "#7897ab" kerning 1
                    null height 3
                    if not instant:
                        for sender, msg, stamp, source, position in unified_rows:
                            use phone_message(sender, msg, stamp, str(source) + "-" + str(position), photo_height=max(80, min(190, reply_y - message_y - 90)) if pending_reply and not arriving else 190, animate=source == thread_token, can_react=True) id (source, position)
                    else:
                        for index, (sender, msg) in enumerate(visible_messages[:revealed_count]):
                            use phone_message(sender, msg, archive_times[archive_start + index] if archive_times is not None else phone_live_time(index, thread_token), "live-" + str(index), animate=False) id (thread_token, index)
                    if arriving and next_sender != "Олег":
                        use phone_typing(next_sender)
            if pending_reply and not arriving:
                frame:
                    xpos 26 ypos reply_y xsize 448 ysize (reply_height + 48) padding (12, 12)
                    background phone_round("#132736", 14)
                    vbox:
                        spacing 8 xsize 424
                        text ("ОТВЕТИТЬ · прокрути варианты ↓" if reply_content_height > reply_height else "ОТВЕТИТЬ") size 13 color "#aac5d8" kerning 1
                        viewport:
                            id "phone_reply_choices"
                            xsize 424 ysize reply_height
                            mousewheel True draggable True scrollbars "vertical"
                            yadjustment reply_scroll
                            side_yfill True side_spacing 8
                            vscrollbar_xsize 12
                            vscrollbar_unscrollable "hide"
                            vbox:
                                spacing 8 xsize 404
                                for reply in active_dialogue[reply_node]["options"]:
                                    button:
                                        action [Function(reply_scroll.change, 0), Function(phone_record_reply, conversation, reply_node, reply["id"], messages, active_dialogue), SetScreenVariable("revealed_count", revealed_count + int(reply.get("send", True))), SetScreenVariable("reaction_target", None)]
                                        xfill True padding (12, 8)
                                        background phone_round("#eee8de", 9)
                                        hover_background phone_round("#e5bd87", 9)
                                        text reply["text"] size reply_size color "#162536" hover_color "#101c29" xmaximum 380 line_spacing 2
            if reaction_target is not None:
                frame:
                    xpos 26 ypos (reply_y-66 if pending_reply and not arriving else 677) xsize 448 padding (12, 10)
                    background phone_round("#36546a", 18)
                    hbox:
                        spacing 9
                        for emoji in phone_emoji_choices:
                            button:
                                id ("picker_" + emoji)
                                alt ("Добавить: " + phone_reaction_labels[emoji])
                                action [Function(phone_toggle_reaction, reaction_target[0], reaction_target[1], emoji), SetScreenVariable("reaction_target", None)]
                                background None hover_background phone_round("#56758b", 10)
                                padding (7, 5)
                                add Transform("images/messenger/" + emoji + ".webp", xysize=(30, 30))
                        textbutton "×":
                            action SetScreenVariable("reaction_target", None)
                            background None hover_background None padding (6, 4) text_size 25
            if arriving:
                textbutton ("Продолжить" if reading_paused else "Пауза"):
                    action ToggleScreenVariable("reading_paused")
                    xpos 25 ypos 755 xsize 150 text_size 18 text_xalign 0.5 text_color "#91b8d5"
                textbutton "Показать сразу ↓":
                    action SetScreenVariable("revealed_count", len(visible_messages))
                    xpos 177 ypos 755 xsize 297 text_size 18 text_xalign 0.5 text_color "#91b8d5"
            elif not pending_reply:
                textbutton ("Продолжить разговор →" if caption == "Переписка Вари" else "К чатам →" if inbox_mode or instant else "Убрать телефон →"):
                    id "phone_finish"
                    action Return(reply_decisions)
                    xpos 25 ypos 755 xsize 450 text_size 20 text_xalign 0.5
            add Solid("#7f939e") xpos 194 ypos 818 xsize 112 ysize 4
    if messenger_enabled() and not inbox_mode and not instant and messenger_notice_visible and messenger_unread(caption):
        use messenger_notification(caption, visible_messages)
        timer 4.0 action SetScreenVariable("messenger_notice_visible", False)

screen ending_card(title, body, chapter=1):
    modal True
    add Solid("#09151bd8")
    frame:
        xalign 0.5 yalign 0.46 xsize 1090 padding (50, 45) background Solid("#12232ce8")
        vbox:
            spacing 24
            text ("КОНЕЦ ПЕРВОГО ЭПИЗОДА" if chapter == 1 else "КОНЕЦ ВТОРОЙ ГЛАВЫ") size 16 kerning 3 color "#d5b384"
            text title size 43
            text body size 26 line_spacing 7 xmaximum 960
            if chapter == 1:
                text "Открыто финалов: [len(persistent.endings_seen)] / 3" size 18 color "#b0bec5"
                textbutton "Продолжить: глава 2" action Return("next") xfill True
            if chapter == 2:
                textbutton "Продолжить: глава 3" action Return("next") xfill True
            hbox:
                spacing 20
                textbutton "Пройти иначе" action Return("again")
                textbutton "В главное меню" action Return("menu")
