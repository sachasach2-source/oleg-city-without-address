# Chapter six is developed locally. No synthetic history on a continued save.
default week6_started = False
default week6_entry = {}
default week6_relations = {}
default week6_home = {}
default week6_laundry = {}
default week6_history = {}
default week6_rita = {}
default week6_events = []
default week6_day = 0
default week6_clock = 690
default week6_stage = ""
default week6_person = ""
default week6_chat_index = 0
default week6_varya = {}
default week6_sea = {}
default week6_concert = {}
default week6_exhibition = {}
default week6_housing = {}

init python:
    week6_days = ("воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")

    def week6_reset():
        global shawarma_state
        shawarma_state = None
        global week6_started, week6_entry, week6_relations, week6_home, week6_laundry
        global week6_history, week6_rita, week6_events, week6_day, week6_clock
        global week6_stage, week6_person, week6_chat_index, week6_varya, week6_sea
        global week6_concert, week6_exhibition, week6_housing, week6_weekend, week6_dates, week6_finished
        week6_entry = copy.deepcopy(dict(relations=week5_relations, home=week5_home,
            laundry=week5_laundry, events=week5_events, person=week5_person,
            date=week5_date, result=week5_result, plan=week5_plan, promise=week5_promise,
            varya=week5_varya, marta=week5_marta, rita=rita_moderation))
        week6_relations = copy.deepcopy(week5_relations)
        week6_home, week6_laundry = copy.deepcopy(week5_home), copy.deepcopy(week5_laundry)
        week6_history, week6_rita = copy.deepcopy(week5_history), copy.deepcopy(rita_moderation)
        week6_events, week6_varya, week6_sea = [], {}, {}
        week6_concert, week6_exhibition, week6_housing = {}, {}, {}
        week6_weekend, week6_dates, week6_finished = {}, {}, False
        week6_day, week6_clock, week6_chat_index = 0, 690, 0
        week6_stage, week6_person = "opening", ""
        # A replay from chapter five discards only chapter-six replies.
        for mapping in (phone_reply_log, phone_message_times):
            for key in list(mapping):
                if str(key[0]).startswith("w6_"):
                    del mapping[key]
        week6_started = True

    def week6_meet(person):
        # Meeting and permission to message are deliberately separate.
        postcard_meet(person)
        relation = week6_relations.setdefault(person, dict(known=False, mode="uncertain",
            issues=[], events=[], promises=[], new_touch="", facts={}, outcome="", invited=False))
        relation["known"] = True
        relation.setdefault("facts", {})["met_chapter6"] = True

    def week6_exchange(person, mode="uncertain"):
        week6_meet(person)
        week6_relations[person]["facts"]["contact"] = True
        week6_relations[person]["mode"] = mode
        week6_event("contact_exchanged", mode, person)

    def week6_has_contact(person):
        return bool(week6_relations.get(person, {}).get("facts", {}).get("contact"))

    def week6_pending_marta():
        return any(e["event"] == "marta_answer_due" for e in week6_events) and not any(e["event"] == "marta_answer_sent" for e in week6_events)

init 35 python:
    week4_names.update(zhenya="Женя", ulya="Уля")
    phone_profiles.update({"Женя": ("#805568", "guitar", "#d9adbf"), "Уля": ("#546e9d", "astronaut", "#aacbfa")})

    def week6_known(person):
        return bool(week6_relations.get(person, {}).get("known"))

    def week6_issues(person):
        return [x for x in week6_relations.get(person, {}).get("issues", []) if x.get("status") != "resolved"]

    def week6_friend(person):
        r = week6_relations.get(person, {})
        return person == "varya" or r.get("mode") == "friendship" or (
            person == "marta" and week6_entry.get("marta", {}).get("next") in ("friendship", "friendship_requested"))

    def week6_past_date(person):
        # Only this person's played Friday, never another heroine's ending.
        if week6_entry.get("person") == person:
            return week6_entry.get("result", "")
        return ""

    def week6_careful(person):
        # Awkwardness can survive without a formal grievance in issues.
        return bool(week6_issues(person) or week6_past_date(person) in (
            "awkward_goodbye", "interrupted_separate") or (
            person == "marta" and week6_entry.get("marta", {}).get("plan") == "cancelled"))

    def week6_touch_withdrawn(person):
        relation = week6_relations.get(person, {})
        return relation.get("new_touch") == "space" or (
            relation.get("previous_touch") == "space" and not relation.get("new_touch"))

    def week6_stamp(location, minute, day=None):
        global week6_clock, week6_day, place_name, save_name
        if day is not None:
            week6_day = day
        week6_clock = minute
        day_name = "суббота" if week6_day == -1 else week6_days[week6_day]
        place_name = "{} · {}, {}".format(location, day_name, chapter3_time(minute))
        save_name = "Глава 6 · " + place_name

    def week6_event(event, detail="", person=""):
        item = dict(event=event, detail=detail, person=person, day=week6_day, time=week6_clock)
        week6_events.append(item)
        if person in week6_relations:
            relation = week6_relations[person]
            relation.setdefault("events", []).append(copy.deepcopy(item))
            relation.setdefault("facts", {}).setdefault("chapter6", []).append(copy.deepcopy(item))

    def week6_options():
        names = dict(nika="Нике", lera="Лере", asya="Асе", marta="Марте")
        return [("Хочу написать " + names[p] + ".", p) for p in names if week6_known(p)] + [
            ("Сегодня хочу просто выйти за хлебом и никуда не спешить.", "alone")]

label week6_chat(person, key, incoming, options):
    $ week6_token = "w6_{}_{}_{}".format(person, key, week6_chat_index)
    $ week6_chat_index += 1
    $ week6_dialogue = week4_phone_dialogue(incoming, options)
    if len(options) == 1:
        $ phone_record_reply(week6_token, "start", options[0][0], [], week6_dialogue)
    call screen phone_thread([], caption=week4_names[person], conversation=week6_token, past=week6_history.get(person, [])[-2:], dialogue=week6_dialogue)
    $ week6_transcript, week6_decisions, week6_pending = phone_conversation_state(week6_token, [], week6_dialogue)
    $ week6_history[person] = (week6_history.get(person, []) + week6_transcript)[-30:]
    return week6_decisions[-1][1]

# This wrapper affects only chapter-six conversations; reopening never retimes them.
init 50 python:
    _week6_original_stamp = phone_stamp_messages
    _week6_original_status = phone_status_time

    def phone_stamp_messages(token, messages, caption=None):
        if not str(token).startswith("w6_"):
            return _week6_original_stamp(token, messages, caption)
        global week6_clock
        if caption is not None:
            phone_thread_contacts[token] = caption
        cursor = week6_clock
        for index, (sender, message) in enumerate(messages):
            saved = phone_message_times.get((token, index))
            if saved and saved[:2] == (sender, message):
                hh, mm = map(int, saved[2].split(":"))
                sent = hh * 60 + mm
            else:
                sent = cursor + 1
                phone_message_times[(token, index)] = (sender, message, chapter3_time(sent))
            cursor = max(cursor, sent)
        for key in list(phone_message_times):
            if key[0] == token and key[1] >= len(messages):
                del phone_message_times[key]
        week6_clock = cursor
        week6_stamp(place_name.split(" · ")[0], week6_clock)

    def phone_status_time(index, token):
        if str(token).startswith("w6_"):
            return chapter3_time(week6_clock)
        return _week6_original_status(index, token)
