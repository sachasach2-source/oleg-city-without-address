image bg w6 walk street = Transform("images/week6/walk-home-street-v1.webp", xysize=(1600, 900))
image bg w6 walk square = Transform("images/week6/garden-dusk-v1.webp", xysize=(1600, 900))
image bg w6 walk yard = Transform("images/week6/snow-courtyard-night-v1.webp", xysize=(1600, 900))

init -5 python:
    city_register_motion("city.street_snow", """
        float far = city_snow_layer(p, vec2(32.0, 18.0), vec2(0.12, 0.58), 0.024, u_city_time);
        float near = city_snow_layer(p + vec2(0.117, 0.071), vec2(20.0, 11.25), vec2(0.23, 0.88), 0.030, u_city_time);
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.88, 0.93, 1.0), far * 0.22 + near * 0.35);
    """, functions=city_gallery_snow_functions)
    for name, path in (("street", "walk-home-street-v1"), ("square", "garden-dusk-v1"), ("yard", "snow-courtyard-night-v1")):
        filename = "images/week6/" + path + ".webp"
        city_motion_assets[filename] = "city.street_snow"
        city_motion_bindings["bg w6 walk " + name] = filename

init python:
    soundscapes["w6_walk_street"] = ("club-street", .54, None, 0)
    soundscapes["w6_walk_yard"] = ("courtyard", .42, None, 0)

label week6_city_walk:
    $ week6_stamp("Воскресенье · по дороге домой", max(week6_clock, 1140), 7)
    scene bg w6 walk street with fade
    $ set_soundscape("w6_walk_street")
    if week6_exhibition.get("closing_done"):
        "За спиной щёлкает замок. Через витрину ещё видно, как Уля показывает монтажнику на потолок. Олег натягивает перчатки и идёт к остановке."
    else:
        "К вечеру Олег выходит за едой на понедельник. У магазина в соседнем квартале ещё горит свет. На ручке двери снаружи висит мокрая варежка."
    "Олег заходит в магазин, берёт хлеб и пачку творога."
    "У овощного ящика продавец стягивает перчатку зубами и пересчитывает мелочь. В глубине магазина переставляют пустые лотки."
    "Олег выходит с пакетом. Автобус у остановки включает поворотник; двое бегут к закрывающимся дверям. Водитель снова открывает."
    window hide
    pause 1.2
    window show
    "У светофора снег летит почти горизонтально. За углом сразу тише. Под подошвой хрустит тонкий лёд, а у края дороги всё ещё течёт вода."
    menu:
        "Пойду по улице. Тут ещё магазины светятся.":
            "В витрине отражается автобус. Он уходит вперёд, и в стекле остаётся Олег с пакетом."
            "У следующей двери курьер переставляет велосипед, чтобы пропустить женщину с коляской. Из открытого подъезда пахнет краской."
            $ week6_weekend["walk_home"] = "street"
        "Срежу через сквер и дворы.":
            scene bg w6 walk square with dissolve
            $ set_soundscape("w6_walk_yard")
            "В сквере дорожку протоптали по диагонали. Лавки белые, на одной остался круг от стакана. За оградой медленно ползут красные огни машин."
            "Кто-то зовёт собаку. Из темноты под кустами отвечают звоном ошейника. Олег придерживает калитку, пока они выходят."
            $ week6_weekend["walk_home"] = "yards"
    scene bg w6 walk yard with dissolve
    $ set_soundscape("w6_walk_yard")
    "В арке ветер подхватывает пакет за свободный край. Олег перехватывает ручки. Сверху гремит открывшееся окно."
    "Из тёмного двора выкатывается машина. Он отступает к стене; по мокрому асфальту медленно проходят две полосы света."
    window hide
    pause 1.4
    window show
    "Телефон коротко вибрирует в кармане. Олег достаёт его уже у двери."
    $ week6_stamp("После прогулки", week6_clock + 25)
    $ week6_event("city_walk_home", week6_weekend["walk_home"])
    return
