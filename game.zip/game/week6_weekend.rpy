# Weekend appointments are promises, not a menu to replay the whole cast.
default week6_weekend = {}
default week6_dates = {}
default week6_finished = False

init python:
    def week6_marta_saturday():
        return week6_known("marta") and week6_relations["marta"].get("facts", {}).get("chapter6_saturday") == "14:00"

    def week6_date_make(person, day, minute, limited=False):
        week6_dates[person] = dict(day=day, time=minute, confirmed=True, played=False,
            limited=limited, friendship=week6_friend(person), kiss=False, touch=False,
            night="", result="", boundary_renewed=False)
        week6_event("weekend_agreed", "{} {}".format(week6_days[day], chapter3_time(minute)), person)

    def week6_kiss_caption(person):
        return {"nika":"Скажу, чего хотел. И спрошу, можно ли её поцеловать.",
            "lera":"Скажу ей. Хочу её поцеловать.",
            "asya":"Нос красный. А поцеловать её всё равно хочу. Скажу.",
            "marta":"Спрошу, что будет, если я её сейчас поцелую."}[person]

    def week6_slow_caption(person):
        return {"nika":"Я за шарфом потянулся. Сегодня без поцелуя.",
            "lera":"Возьму её за руку. Сегодня мне достаточно этого.",
            "asya":"Поправлю капюшон и предложу идти греться.",
            "marta":"Отдам сумку. Хочу ещё пройти с ней до перекрёстка."}[person]

    def week6_can_touch(person):
        relation = week6_relations.get(person, {})
        date = week6_dates.get(person, {})
        withdrawn = week6_touch_withdrawn(person)
        return bool(date.get("confirmed") and not date.get("limited") and not week6_friend(person)
            and not week6_careful(person) and (not withdrawn or date.get("boundary_renewed")))

    def week6_home_path(night=False):
        kind = week6_home.get("kind", "hotel")
        if week6_housing.get("move_due") and not week6_housing.get("moved"):
            kind = week6_housing.get("previous_home", {}).get("kind", "hotel")
        candidate = week6_home.get("actual_home") or week6_home.get("candidate") or week6_entry.get("home", {}).get("actual_home") or week5_entry.get("housing_home")
        if kind == "new" and candidate:
            return {"modern":"images/week6/modern-night-v1.webp" if night else "images/week6/modern-day-v1.webp", "studio":"images/housing/studio-night-v2.webp" if night else "images/housing/studio-v2.webp", "central":"images/housing/central-bedroom-evening-v2.webp" if night else "images/housing/central-bedroom-v1.webp", "quiet":"images/chapter3/ch3-rental-night-v2.webp" if night else "images/chapter3/ch3-rental-day-v2.webp"}.get(candidate, "images/chapter3/ch3-rental-night-v2.webp")
        if kind in ("whole", "month"):
            return "images/chapter3/old-rental-night-v1.webp" if night else "images/cast/apartment-empty.webp"
        if kind == "new":
            return "images/chapter3/ch3-rental-night-v2.webp" if night else "images/chapter3/ch3-rental-day-v2.webp"
        return "images/hotel-night.webp" if night else "images/hotel-morning.webp"

    def week6_candidate_path():
        candidate = week6_home.get("candidate") or "central"
        return {"modern":"images/week6/modern-day-v1.webp", "central":"images/housing/central-bedroom-v1.webp", "studio":"images/housing/studio-v2.webp", "quiet":"images/chapter3/ch3-rental-day-v2.webp"}.get(candidate, "images/housing/central-bedroom-v1.webp")

    def week6_pending_keys():
        return week6_home.get("keys_due") not in (None, "", "done")

label week6_weekend_plan:
    $ week6_stage = "weekend_plan"
    $ quick_menu = True
    show screen scene_marker
    scene expression home_keepsake_background(week6_home_path(True)) with dissolve
    $ set_soundscape("ch3_room")
    "На субботу обещают мокрый снег. Олег смотрит на прогноз и на чехол гитары у двери. Чехол завтра можно оставить дома."
    if week6_marta_saturday():
        "В два он встречается с Мартой. Она уже перенесла работу на утро; это время занято."
        $ week6_date_make("marta", 6, 840, week6_careful("marta"))
    $ week6_weekend_options = [("Хочу выходной без новой договорённости. Выберусь сам.", "alone")]
    python:
        for person, caption in [("nika", "Позову Нику в воскресенье к порту. Там давно хотел пройтись."), ("lera", "Хочу в субботу послушать Лерин сет и уйти с ней."), ("asya", "Позову Асю в воскресенье к заливу. Поедем днём, пока светло."), ("marta", "Хочу увидеть Марту в субботу. Позову её сам.")]:
            if week6_known(person) and not (person == "marta" and (week6_marta_saturday() or any(e["event"] == "marta_answer_sent" and e["detail"] == "no" for e in week6_events))):
                week6_weekend_options.append((caption, person))
    call screen chapter3_intentions("Кого хочется увидеть?", week6_weekend_options)
    $ week6_weekend["main"] = _return
    if _return != "alone":
        $ week6_target = _return
        call week6_weekend_invite(week6_target)
    else:
        "Он убирает телефон. Оставить воскресенье пустым сейчас даже приятно."
    $ week6_stage = "saturday"
    jump week6_saturday

label week6_weekend_invite(person):
    if week6_careful(person):
        if any(i.get("cause") == "left_without_explanation" for i in week6_issues(person)):
            $ week6_reason = "После того, как ты тогда ушёл и отмахнулся, мне не хочется большого свидания."
        elif any(i.get("cause") == "missed_meeting" for i in week6_issues(person)):
            $ week6_reason = "Я пока помню, как освободила время, а встреча не состоялась."
        elif week6_past_date(person) == "awkward_goodbye":
            $ week6_reason = "После пятницы пока не хочу обещать ещё один длинный вечер. Ты тогда расстроился, когда я не захотела продолжать."
        elif week6_past_date(person) == "interrupted_separate" and not week6_issues(person):
            $ week6_reason = "После той поездки я так и не поняла, когда мы всё-таки вдвоём увидимся. Только давай сейчас ненадолго."
        else:
            $ week6_reason = "Я не хочу делать вид, что после прошлого раза у нас всё уже нормально."
        call week6_chat(person, "weekend_careful", [("Олег", "Хочу на выходных с тобой увидеться. Ты как?"), (week4_names[person], week6_reason)], [
            ("brief", "Помню. Не предлагаю забыть. Можем просто ненадолго увидеться, если ты хочешь. Без продолжения вечера.", [(week4_names[person], "Ненадолго могу. На сорок пять минут. Потом у меня свои дела.")]),
            ("space", "Понял. Тогда не буду сейчас звать. Если захочешь поговорить — напиши.", [(week4_names[person], "Хорошо. Спасибо, что услышал.")])])
        if _return == "space":
            $ week6_event("weekend_invite_declined", "Прежняя причина остаётся", person)
            return
        $ week6_date_make(person, 6 if person in ("lera", "marta") else 7, {"nika":720, "lera":1200, "asya":600, "marta":840}[person], True)
        call week6_chat(person, "brief_point", [], [("point", {"nika":"В воскресенье в двенадцать. На Канонерку возьмём машину от Балтийской, по берегу только короткий круг. В 12:45 поедем обратно.", "lera":"В субботу в восемь у выхода с твоего сета. В 20:45 разойдёмся, продолжение не предлагаю.", "asya":"В воскресенье в десять у Финляндского. Если хотим только сорок пять минут, давай кофе у вокзала; без поездки за город.", "marta":"В субботу в два у сада. До без четверти три, потом каждый по своим делам."}[person], [(week4_names[person], "Да. Так могу.")])])
        return
    if person == "nika":
        call week6_chat("nika", "port_invite", [], [("invite", "Хочу с тобой в воскресенье на Канонерку. В двенадцать у Балтийской, дальше возьмём машину. Посмотрим порт, потом погреемся. Пойдёшь?", [("Ника", "Пойду. Я там сто лет не была. Только недолго у воды, я не экспедиция."), ("Олег", "Да. Ветер надоест — уйдём. Я чай возьму."), ("Ника", "Ну всё, я тогда ничего не организую. До воскресенья.")])])
        $ week6_date_make(person, 7, 720)
    elif person == "lera":
        call week6_chat("lera", "set_invite", [], [("invite", "У тебя в субботу сет? Хочу послушать и потом с тобой уйти. Когда заканчиваешь?", [("Лера", "В восемь. Я всё равно потом не остаюсь. Приходи к половине восьмого, хвост послушаешь."), ("Олег", "Буду. После можем трамвай поймать и проехаться. Не на бегу до метро."), ("Лера", "Да! Я хочу потом есть. Вот это в план тоже внеси.")])])
        $ week6_date_make(person, 6, 1170)
    elif person == "asya":
        call week6_chat("asya", "gulf_invite", [], [("invite", "Хочу в воскресенье к заливу. В десять у Финляндского, электричкой до Курорта, к Сестрорецкому пляжу. Обратно засветло. Поедешь со мной?", [("Ася", "Поеду. Как раз хотела снег с песком поснимать. Я термос возьму."), ("Олег", "А я еду. И перчатки в этот раз."), ("Ася", "Вот перчатки важнее. Там от ветра не спрячешься.")])])
        $ week6_date_make(person, 7, 600)
    else:
        call week6_chat("marta", "garden_invite", [], [("invite", "Хочу в субботу с тобой встретиться. В два у сада, погуляем и в кафе?", [("Марта", "Хочу. В два буду. Папку постараюсь не брать."), ("Олег", "Можешь взять. Просто я к тебе иду, а не на сдачу макета."), ("Марта", "Всё, оставлю дома. Мне только это и надо было услышать.")])])
        $ week6_date_make(person, 6, 840)
    return

label week6_saturday:
    $ week6_stage = "saturday"
    $ week6_stamp("Дома · субботнее утро", 570, 6)
    scene expression home_keepsake_background(week6_home_path()) with fade
    $ set_soundscape("ch3_room")
    "Олег ищет вторую перчатку. Вчера обе лежали на тумбе. Сегодня одна уже успела уехать в рукав куртки."
    call week6_keys_and_home
    call housing_story_saturday
    if week6_dates.get("marta", {}).get("confirmed") and not week6_dates["marta"].get("played"):
        call week6_marta_garden
    $ week6_stamp("Пауза перед выходом", max(week6_clock, 1030), 6)
    scene expression home_keepsake_background(week6_home_path(True)) with dissolve
    call week6_friends_saturday
    call week6_varya_weekend
    if week6_dates.get("lera", {}).get("confirmed"):
        call week6_lera_tram
    elif not week6_dates.get("marta", {}).get("played"):
        $ week6_stamp("За хлебом", 1080, 6)
        scene bg w6 garden evening with fade
        $ set_soundscape("ch3_outside")
        "В маленьком саду у дома дорожку посыпали песком. Снег с неё исчез, и теперь дорожка выглядит как отдельный сезон."
        menu:
            "Обойду ещё квартал. Дома и так насиделся.":
                "В соседнем дворе горит окно ремонта обуви. Олег наконец вспоминает про оторванную петлю на ботинке и фотографирует часы работы."
                $ week6_event("own_walk", "Мастерская во дворе")
            "Возьму что-нибудь горячее и домой.":
                "Он несёт пакет с хачапури под курткой. Под аркой ветер пытается остудить его через Олега."
                $ week6_event("own_evening", "Еда и тепло")
    $ week6_stage = "sunday"
    jump week6_sunday_weekend

label week6_keys_and_home:
    if week6_pending_keys():
        $ week6_stamp("Документы перед ключами", 600, 6)
        if week6_home.get("keys_due") == "chapter6_saturday11":
            "В договоре те же восемьдесят шесть и залог за месяц. Пункт про передачу управления хозяин добавил. Олег дочитывает страницу с расторжением."
        else:
            "В переписке остаётся прежняя договорённость о ключах. Олег пишет агенту, когда может подъехать. Новый адрес ему не предлагают."
        call week6_chat("agent", "keys_time", [], [("confirm", "Я сегодня к одиннадцати могу за ключами. Договор дочитал. Проверяем доступы и акт, потом расчёт, как договорились?", [("Агент", "Да, собственник будет на месте. В одиннадцать ждём.")])])
        $ week6_stamp("Передача квартиры", 660, 6)
        scene expression Transform(week6_candidate_path(), xysize=(1600, 900)) with fade
        if week6_home.get("keys_due") == "chapter6_saturday11":
            scene bg w6 housing modern with dissolve
            "Хозяин выходит из приложения на своём телефоне. Олег входит на своём, меняет пароль и открывает окно. Уведомление теперь приходит ему."
        else:
            "Они сверяют показания счётчиков и то, что осталось в квартире. Олег пробует каждый ключ сам, пока собственник рядом."
        menu:
            "Подпишу и оплачу. Хочу уже здесь жить.":
                $ week6_housing["previous_home"] = copy.deepcopy(week6_home)
                $ week6_home.update(kind="new", actual_home=week6_home.get("candidate") or week6_entry.get("home", {}).get("actual_home") or week5_entry.get("housing_home") or "central", keys_due="done")
                $ week6_housing["keys_received"] = True
                $ week6_event("keys_received", week6_home["actual_home"])
                "На акте появляются подписи. После перевода собственник передаёт связку: два квартирных ключа и брелок от подъезда."
                scene bg w6 keys detail with dissolve
                "Олег пересчитывает ключи, убирает в отдельный карман. Пока там больше ничего нет."
                scene expression home_keepsake_background(week6_home_path()) with dissolve
                "Вещи остаются в гостинице. Он договаривается вывезти их завтра утром; сегодня не хочет ехать на встречу с сумками."
                $ week6_housing["move_due"] = "sunday_morning"
            "Я всё ещё не готов подписать. Скажу сейчас." if week6_home.get("keys_due") == "chapter6_saturday11":
                o "Извините, я всё-таки не подпишу. Оплаты и акта ещё нет. Не хочу въезжать, если уже сомневаюсь."
                agent "После согласования собственник приехал специально. Давайте хотя бы причину обозначим."
                o "Да. Я согласился слишком быстро. Это моя ошибка. Но квартиру я сейчас не возьму."
                $ week6_home["keys_due"] = ""
                $ week6_housing["decision"] = "declined_at_contract"
                $ week6_event("contract_declined", "Ключей и оплаты нет")
                "Он возвращает пробную связку. Гостиница остаётся гостиницей; второй просмотр на сегодня не появляется."
        $ week6_stamp("После передачи", 720)
        scene expression home_keepsake_background(week6_home_path()) with dissolve
        if week6_home.get("kind") == "hotel":
            "На стойке гостиницы Олег закрывает счёт и продлевает номер до следующего воскресенья. Администратор снова уточняет фамилию."
            $ week6_home["paid_until"] = "chapter7_sunday"
            $ week6_event("hotel_extended", "После отказа от договора")
    elif week6_home.get("kind") != "hotel":
        "Олег раскладывает газету у двери, потом всё-таки выходит за ковриком. В магазине выбирает тот, который помещается между дверью и стеной."
        menu:
            "Освобожу место для второй пары ботинок.":
                "Он убирает пустые пакеты с пола. Теперь можно войти вдвоём и не переступать через всё сразу."
                $ week6_weekend["home_change"] = "guest_space"
            "Сначала разберу собственный угол. Гостей потом.":
                "Под столом находятся два одинаковых кабеля. Олег соединяет каждый с зарядкой и выбрасывает тот, который месяц возил просто так."
                $ week6_weekend["home_change"] = "own_space"
        $ week6_event("home_settled", week6_weekend["home_change"])
    else:
        "На стойке он закрывает счёт за прошедшие дни и оплачивает продление номера до следующего воскресенья. Администратор снова уточняет фамилию, хотя уже знает её."
        $ week6_home["paid_until"] = "chapter7_sunday"
        $ week6_event("hotel_extended", "До следующего воскресенья")
    return
