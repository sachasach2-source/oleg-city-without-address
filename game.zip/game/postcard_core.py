"""Persistent postcard transactions. No Ren'Py state, clock, or save rollback dependencies."""
import copy
import random

def fresh():
    return dict(version=3,credits=0,earned=[],rewards={},met=[],opened={},favorites=[],viewed=[],pending=None,pending_person=None,batch=[],pity=0,serial=0,story_events=[])

def state(value):
    result=fresh()
    if isinstance(value,dict):
        result.update(copy.deepcopy(value))
        if value.get('version',1)<3:
            result['viewed']=[key for key in result['opened'] if key!=result['pending']]
    result['version']=3
    return result

def reward_amount(key):
    if key.startswith('milestone:'): return 10
    if key.startswith('game:'): return 5
    return 1

def rebalance(value):
    s=state(value)
    for key in s['earned']:
        previous=s['rewards'].get(key,1)  # Version 1 awarded one per achievement.
        amount=max(previous,reward_amount(key))
        s['credits']+=amount-previous
        s['rewards'][key]=amount
    s['version']=3
    return s

def grant(value,key,person=None,amount=1):
    s=state(value)
    if person and person not in s['met']: s['met'].append(person)
    if key in s['earned']: return s,False
    s['earned'].append(key)
    s['rewards'][key]=amount
    s['credits']+=amount
    return s,True

def participants(art):
    return tuple(art.get('people') or [art['person']])

def accessible(art,people):
    return bool(art and all(p in people for p in participants(art)))

def connection_events(histories,pairs):
    """A shared meeting must be recorded for BOTH participants in one history."""
    events=set()
    for relations in histories:
        for pair,people in pairs.items():
            records=[relations.get(p,{}).get('facts',{}).get('connections',{}).get(pair,{}) for p in people]
            if all(r.get('introduced') and r.get('scene_done') for r in records):
                events.add('connection:'+pair+':meeting')
    return sorted(events)

def unlock_story(value,catalog,event=None):
    """Remember played events even before their approved artwork is installed."""
    s=state(value)
    if event and event not in s['story_events']: s['story_events'].append(event)
    added=[]
    for art in catalog:
        token=art.get('unlock_event')
        if not token or not art.get('exclusive') or token not in s['story_events'] or art['id'] in s['opened']: continue
        for person in participants(art):
            if person not in s['met']: s['met'].append(person)
        s['serial']+=1
        s['opened'][art['id']]=dict(source='Общая встреча · '+art['name'],event=token,number=s['serial'])
        added.append(art['id'])
    return s,added

def candidates(value,catalog,people,person=None):
    s=state(value)
    return [a for a in catalog if accessible(a,people) and (not person or person in participants(a)) and not a['exclusive'] and not a.get('unlock_event') and a['id'] not in s['opened']]

def open_pack(value,catalog,people,person=None,target=None,rng=None):
    s=state(value)
    if s['batch']: return s,None
    if s['pending']:
        pending=next((a for a in catalog if a['id']==s['pending']),None)
        return s,s['pending'] if accessible(pending,people) and not pending.get('unlock_event') else None
    pool=candidates(s,catalog,people,person)
    cost=3 if target else 1
    if s['credits']<cost: return s,None
    if target:
        pool=[a for a in pool if a['id']==target]
    elif s['pity']>=4:
        rare=[a for a in pool if a['rarity'] in ('rare','collection')]
        if rare: pool=rare
    if not pool: return s,None
    rng=rng or random.SystemRandom()
    weights=[{'standard':4.0,'rare':2.0,'collection':1.0}.get(a['rarity'],1.0) for a in pool]
    draw=rng.random()*sum(weights)
    chosen=pool[-1]
    for a,w in zip(pool,weights):
        draw-=w
        if draw<0:
            chosen=a
            break
    s['credits']-=cost
    s['serial']+=1
    s['opened'][chosen['id']]=dict(source='Выбранная открытка' if target else 'Почтовый конверт',number=s['serial'])
    s['pending']=chosen['id']
    s['pending_person']=person
    s['pity']=0 if chosen['rarity'] in ('rare','collection') else s['pity']+1
    return s,chosen['id']

def complete(value):
    s=state(value)
    s['pending']=None
    return s

def open_batch(value,catalog,people,person=None,count=5,rng=None):
    """Reserve the entire result before showing it; reopening never redraws it."""
    s=state(value)
    if s['pending']: return s,[]
    if s['batch']:
        available={a['id'] for a in catalog if accessible(a,people) and not a.get('unlock_event')}
        return s,[key for key in s['batch'] if key in available]
    result=[]
    for _ in range(min(5,max(0,int(count)))):
        s,key=open_pack(s,catalog,people,person,rng=rng)
        if not key: break
        result.append(key)
        s=complete(s)
    s['batch']=result
    return s,result

def viewed(value,art_id):
    s=state(value)
    if art_id in s['opened'] and art_id not in s['viewed']:
        s['viewed'].append(art_id)
    return s

def complete_batch(value):
    s=state(value)
    s['batch']=[]
    return s

def favorite(value,art_id):
    s=state(value)
    if art_id not in s['opened']: return s
    if art_id in s['favorites']: s['favorites'].remove(art_id)
    else: s['favorites'].append(art_id)
    return s
