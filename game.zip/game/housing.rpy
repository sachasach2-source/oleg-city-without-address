# Four apartments; legacy housing values remain stable for old saves.
default housing_records = {}
default housing_pending = ""
default housing_home = ""
default housing_active = ""
default housing_second = ""
default housing_outcome = ""
default housing_next = ""

init python:
    housing_names = {"studio":"студия", "quiet":"квартира в тихом квартале", "central":"квартира со ступенями", "modern":"квартира в новом доме"}
    housing_rents = {"studio":62000, "quiet":68000, "central":78000, "modern":86000}

    def housing_reset():
        global housing_records, housing_pending, housing_home, housing_active, housing_second, housing_outcome, housing_next
        global housing_companion, housing_companion_chapter
        housing_companion, housing_companion_chapter = "", 0
        housing_records = {}
        housing_pending = housing_home = housing_active = housing_second = housing_outcome = ""
        housing_next = ""

    def housing_cancel_pending(reason="cancelled"):
        global housing_pending
        if housing_pending in housing_records:
            housing_records[housing_pending]["decision"] = reason
        housing_pending = ""

    def housing_note(candidate, fact):
        record = housing_records.setdefault(candidate, {"seen":False, "checks":[], "decision":"", "terms":False})
        if fact not in record["checks"]:
            record["checks"].append(fact)

    def housing_background(candidate, home=False):
        return "bg housing " + candidate + (" home" if home else "")

    def housing_home_background(night=False):
        return "bg housing " + housing_home + (" night" if night else " home")

    def housing_terms(candidate):
        rent = housing_rents[candidate]
        return "{} тысяч в месяц, залог столько же, комиссия {} тысяч один раз. Счётчики отдельно. Договор на год, досрочный выезд — с предупреждением за месяц.".format(rent // 1000, rent // 2000)

label housing_visit(candidate):
    $ housing_active = candidate
    $ housing_records.setdefault(candidate, {"seen":False, "checks":[], "decision":"", "terms":False})["seen"] = True
    $ set_soundscape("ch3_room")
    scene expression (housing_background(candidate) + " establishing") with fade
    if candidate == "studio":
        "Во дворе жилого дома агент открывает ещё одну дверь. За ней общая прихожая и три отдельных входа. Нужный — прямо."
        "В студии светло. Слева сложенный диван, справа кухня. Под единственным окном — стол."
        scene bg housing studio with dissolve
        call vignette_studio_scene
        if vignette_effect("studio") == "measured_plan":
            "Олег кладёт план у ноутбука. Стол и стул пока сходятся с замерами; диван он ещё не раскладывал."
        elif vignette_effect("studio") == "reworked_plan":
            "Листок с перечёркнутой стрелкой остаётся в руке. Ноутбук Олег пока не достаёт: сначала стоит понять, как здесь двигаться с открытым диваном."
        else:
            "Олег снимает рюкзак и достаёт ноутбук."
        agent "Всё своё. Кухня, санузел. Очень камерный вариант."
        menu:
            "Покажите, как диван раскладывается.":
                scene bg housing studio bed with dissolve
                "Агент выдвигает сиденье в середину комнаты. Между холодильником и краем спального места остаётся узкая щель."
                "Олег пробует открыть нижнюю дверцу. Она упирается в диван раньше, чем можно выдвинуть ящик морозилки. Верхнюю можно открыть свободно."
                $ housing_note(candidate, "bed")
                o "А морозилку с кроватью как открыть?"
                agent "Здесь разделены дневной и ночной сценарии."
                menu:
                    "Я ночью иногда пельмени варю.":
                        agent "Здесь режим быстро наладится."
                    "А если диван вдоль другой стены поставить?":
                        "Олег меряет проход шагами. У противоположной стены дверь санузла; перестановка перекроет её."
                        $ housing_note(candidate, "layout")
                        agent "Здесь дизайнер уже оптимальное решение нашёл."
            "Сначала проверю рабочее место.":
                scene bg housing studio desk with dissolve
                "Олег садится за стол, придвигает ноутбук. Мышь помещается справа. Если отъехать на стуле, до кухни всё ещё можно пройти."
                $ housing_note(candidate, "desk")
                o "А от плиты это никак не отделено? Мне здесь созвоны вести."
                agent "Открытая планировка. Вы всё время в пространстве."
                "Олег смотрит на плиту. Готовить на созвоне он и не собирался."
        scene bg housing studio with dissolve
        "В ванной есть душ и раковина. Машинки с фотографии объявления нет."
        menu:
            "А стирать где? На фото машинка была.":
                scene bg housing shared washer with dissolve
                "Агент возвращается в общую прихожую и открывает хозяйственный шкаф. Там одна машинка на три студии, рядом расписание."
                agent "У вас уже готовое соседское сообщество. Сейчас люди годами рядом живут и не знакомятся."
                o "А очередь на стирку тоже знакомится?"
                agent "Жильцы между собой прекрасно договариваются."
                $ housing_note(candidate, "washer")
                "Олег фотографирует расписание. Сушить вещи нужно у себя; отдельной сушильной машины нет."
            "Проверю розетки у стола.":
                scene bg housing studio desk with dissolve
                "Зарядка достаёт до розетки у стены. Олег включает лампу и ноутбук одновременно. Удлинитель здесь не понадобится."
                $ housing_note(candidate, "outlets")
                agent "Концентрация. Ничего не отвлекает."
        scene bg housing studio with dissolve
    elif candidate == "central":
        "Третий этаж, лифта нет. На площадке Олег убирает телефон: агент уже держит дверь."
        "Внутри широкие ступени ведут к трём креслам у окна. Слева зеркальный шкаф. Олег остаётся внизу, с курткой в руке."
        scene bg housing central with dissolve
        agent "Парадная входная группа."
        o "Кресла для тех, кто ждёт заселения?"
        agent "Для ваших гостей. Полноценная приёмная."
        menu:
            "Пройду, как будто уже здесь живу.":
                "Олег разувается, ставит ботинки у шкафа и поднимается. Чтобы пройти с пакетом, придётся обходить крайнее кресло."
                $ housing_note(candidate, "steps")
                o "А ступени зачем?"
                agent "Зонирование. Сразу чувствуете, что перешли в другую часть дома."
            "Кресла можно убрать? Мне ещё свой стол нужен.":
                $ housing_note(candidate, "furniture")
                agent "Здесь уже сложившийся интерьер. Вам даже придумывать ничего не надо."
                o "Мне работать надо. Хозяин разрешит?"
                agent "Я ему передам ваш запрос."
        scene bg housing central kitchen with dissolve
        "С площадки они проходят налево, в кухню. Над шкафами — деревянный настил с оградой. К нему приставлена лестница."
        o "А наверху встать можно?"
        agent "Там камерное пространство. Очень уютно."
        menu:
            "Поднимусь посмотрю.":
                scene bg housing central loft with dissolve
                "Со второй ступени видно: наверху коробки и корзина. Между настилом и потолком можно только сидеть. Олег держится за лестницу и дальше не лезет."
                $ housing_note(candidate, "loft")
                o "Это хранение?"
                agent "Вы сами выбираете сценарий использования."
            "А нормальная кровать где?":
                $ housing_note(candidate, "bedroom")
                agent "В спальне. Это дополнительный уровень."
        scene bg housing central bedroom with dissolve
        "Спальня за дверью напротив прихожей неожиданно просторная. Кровать стоит на полу. Справа свободная стена, у пола две розетки."
        "Олег прикладывает к стене сложенный зонт: стол здесь встанет без ежедневных перестановок. Из окна виден обычный двор."
        o "А здесь хорошо."
        agent "Я же говорю. Такие объекты долго не стоят."
        "Олег ещё раз смотрит в сторону прихожей. Кресла отсюда не видно. Ступени забыть труднее."
        $ housing_note(candidate, "desk")
        scene bg housing central with dissolve
    elif candidate == "modern":
        "От остановки Олег идёт вдоль длинного ограждения. Потом новый двор, чистый подъезд и лифт. В квартире тепло."
        "Рабочий стол нормальный: ноутбук, мышь и кружка помещаются одновременно. Олег проводит рукой по столешнице."
        scene bg housing modern with dissolve
        agent "Здесь всё для жизни. Свет, климат, шторы — с панели."
        menu:
            "Открою окно.":
                scene bg housing modern window with dissolve
                play ambience "audio/housing-fan.wav" loop volume .35 fadein .3
                "В комнату входит ровный гул. На кирпичном здании напротив крутятся вентиляторы."
                $ housing_note(candidate, "noise")
                o "Это что гудит?"
                agent "Звуки города. Вы же в Петербург приехали."
                menu:
                    "Это вентиляция здания напротив.":
                        agent "Ну вот. Город работает."
                    "Хочу послушать с закрытым окном.":
                        agent "Вы так весь городской контекст отсечёте."
                $ set_soundscape("ch3_room")
                "Олег закрывает створку. Гул становится заметно тише. Снова приоткрывает — возвращается."
                $ housing_note(candidate, "closed_window")
            "Покажите, как тут всё управляется.":
                scene bg housing modern controls with dissolve
                "Агент показывает управление климатом на панели. Олег убавляет температуру на градус. Цифра меняется."
                o "А без приложения можно?"
                agent "Умный дом, он под вас адаптируется."
                "Ниже есть обычный выключатель. Олег пробует его: свет гаснет и снова загорается."
                $ housing_note(candidate, "controls")
        if "noise" not in housing_records[candidate]["checks"]:
            scene bg housing modern window with dissolve
            play ambience "audio/housing-fan.wav" loop volume .35 fadein .3
            "Агент приоткрывает окно. С улицы тянет ровным гулом; Олег смотрит на вентиляторы напротив."
            $ housing_note(candidate, "heard_noise")
        else:
            scene bg housing modern with dissolve
        "Телефон агента коротко вибрирует. Он читает вслух: «Окно закрыли? Датчик сработал»."
        o "Хозяину приходит сообщение, когда я открываю окно?"
        agent "Чувствуется участие. Сейчас редко такой неравнодушный собственник."
        menu:
            "Мне нужен свой аккаунт. Без его уведомлений.":
                $ housing_note(candidate, "account")
                agent "Вы сначала поживите. Человек вам помогает."
                o "Уточните у него, пожалуйста. До договора."
                "Агент набирает сообщение. На этот раз не читает ответ, пока его нет."
            "Участие пока избыточное. А ночью там тоже гудит?":
                $ housing_note(candidate, "night_question")
                agent "Вечером город ещё красивее звучит."
                o "Это не ответ. Узнайте, пожалуйста, режим работы."
                "Агент обещает переслать вопрос собственнику. Ночной режим пока неизвестен."
        $ set_soundscape("ch3_room")
        scene bg housing modern with dissolve
    else:
        "Агент встречает Олега у остановки в жилом квартале на Ваське. Они проходят мимо продуктового и двора с деревьями."
        "В квартире отдельная кухня, ванная за соседней дверью. Агент показывает комнату и возвращается к окну кухни."
        scene bg housing quiet with dissolve
        agent "Полностью самостоятельный объект."
        menu:
            "Проверю воду, окно и место для ноутбука.":
                "Вода идёт. Окно закрывается. На столе хватает места, и дверца холодильника ни во что не упирается."
                $ housing_note(candidate, "basics")
                "Олег открывает шкаф под раковиной. Пусто и сухо. Пока всё подозрительно нормально."
            "Посмотрю, как отсюда добираться вечером.":
                "Олег открывает маршрут до знакомого бара на Лиговском. С пересадкой выходит около сорока минут; поздно проще на такси."
                $ housing_note(candidate, "travel")
                o "До бара мне отсюда ездить."
                agent "Зато у вас будет время побыть с собой. Сейчас это роскошь."
        landlord_phone "Выключатель над дверью не трогайте. Он ничего не включает. Я сама забыла, зачем его поставили."
        o "Хорошо. Буду уважать историю."
        "Хозяйка остаётся на громкой связи. Олег спрашивает про машинку: она своя, в ванной. Вещи из комнаты можно переставлять."
        $ housing_note(candidate, "own_washer")
    return

label housing_decide(candidate, chapter=4):
    $ housing_outcome = ""
    if not housing_records.get(candidate, {}).get("seen"):
        return
    agent "Ну что, оформляем?"
    menu:
        "Мне нравится. Хочу увидеть окончательные условия.":
            call housing_confirm(candidate, chapter)
        "Хочу сравнить. Пока ничего не обещаю.":
            $ housing_records[candidate]["decision"] = "considering"
            $ housing_outcome = "considering"
            agent "Тогда напишите, как решите. До пятницы, до шести, могу дождаться ответа."
        "Не моё. Эту не возьму.":
            $ housing_records[candidate]["decision"] = "declined"
            $ housing_outcome = "declined"
            o "Спасибо, что показали. Продолжу искать."
            agent "Хорошо. По следующей заранее напишу."
    return

label housing_confirm(candidate, chapter=4):
    "Агент присылает проект договора. Суммы в сообщении и в документе совпадают."
    $ housing_price = housing_terms(candidate)
    agent "[housing_price]"
    if candidate == "studio":
        landlord_phone "Машинка общая, по расписанию. Сушилка своя, складная. Переставлять мебель можно, но холодильник от стены дальше не выдвинуть: проход перекроете."
        "На плане Олег ещё раз смотрит, где заканчивается разложенный диван. Это устройство студии останется с ним и после оплаты."
    elif candidate == "central":
        landlord_phone "Два кресла увезу к передаче. Одно и лестница останутся. Своё рабочее место, конечно, ставьте."
        "Олег просит включить вывоз двух кресел в договорённости о передаче. Агент присылает исправленный документ. Сейчас кресла ещё стоят у входа."
    elif candidate == "modern":
        landlord_phone "Управление можно перевести на вас. При передаче вместе отвяжем мой телефон, до подписи проверите. Про ночной гул не скажу, я там ночью не был."
        "Олег смотрит на открывающуюся створку. Перенос аккаунта не выключит вентиляторы напротив. Ночной режим остался непроверенным."
    else:
        landlord_phone "Вся техника остаётся. Вещей моих нет. Дорогу вы посмотрели? Я всё-таки не рядом с метро сдаю."
    $ housing_records[candidate]["terms"] = True
    menu:
        "Условия подходят. Договоримся о ключах.":
            $ housing_pending = candidate
            $ housing_records[candidate]["decision"] = "accepted"
            $ housing_outcome = "accepted"
            if chapter == 3:
                $ chapter3_housing = "pending_new"
                agent "Собственник сможет на выходных. Напишу время."
            else:
                $ week4_home["candidate"] = candidate
                $ week4_home["keys_due"] = "friday"
                $ week4_home["viewing_result"] = "accepted"
                agent "В пятницу в половине седьмого. Здесь встретимся с собственником. Подпись и ключи на месте."
                o "Да. Сначала ещё раз всё проверим."
                "Олег подтверждает время. До передачи ключей он остаётся в прежнем жилье."
        "Пока не готов. Оставлю время подумать.":
            $ housing_records[candidate]["decision"] = "considering"
            $ housing_outcome = "considering"
            agent "До пятницы, до шести, тогда жду."
    return

label housing_ch3_view:
    "Агент прислал адрес студии. По фотографиям чисто, стол есть. Олег убирает телефон: сначала надо увидеть её вживую."
    $ housing_active = "studio"
    call housing_visit(housing_active)
    call housing_decide(housing_active, 3)
    if housing_outcome != "accepted":
        $ chapter3_housing = "search"
        $ housing_pending = ""
        $ housing_next = "central"
    return

label housing_week4_offers:
    if week4_home.get("first_viewing"):
        return
    $ week4_stamp("Объявления", 1060, 1)
    if week4_home.get("keys_due") == "friday":
        "В пятницу уже назначена передача ключей. Агент прислал новую квартиру, но две Олег не собирается снимать."
        menu:
            "Сначала закончу ту договорённость. Новые пока не смотрю.":
                return
            "Нет, ту всё-таки не хочу. Сначала отменю передачу.":
                call week4_chat("agent", "cancel_keys", [], [("cancel", "Я передумал по прежней квартире. В пятницу за ключами не приеду. Извините, что меняю решение.", [("Агент", "Понял. Предупрежу собственника, передачу отменяю.")])])
                $ week4_home["keys_due"] = ""
                $ chapter3_housing = "search"
                $ housing_cancel_pending()
    call week4_chat("agent", "housing_options", [("Агент", "Есть квартира в старом фонде с отдельной спальней. Могу сегодня в половине седьмого показать.")], [("central", "Пришлите адрес. Хочу посмотреть спальню и планировку.", [("Агент", "Пространство с характером. Ступени в прихожей и дополнительный уровень над кухней. Жду в 18:30.")]), ("later", "На этой неделе пока не поеду. Напишу сам.", [("Агент", "Хорошо, жду.")])])
    if _return == "later":
        return
    # An old save can still return the previously offered modern address.
    $ housing_active = _return if _return in ("central", "modern") else "central"
    call housing_choose_companion(4)
    $ week4_stamp("Просмотр квартиры", 1110, 1)
    scene bg housing approach with fade
    $ set_soundscape("courtyard")
    call housing_companion_arrival
    call housing_visit(housing_active)
    call housing_companion_opinion(housing_active)
    call housing_decide(housing_active)
    scene bg housing approach with dissolve
    $ set_soundscape("courtyard")
    call housing_companion_goodbye
    $ week4_home["viewing_result"] = housing_outcome
    $ week4_home["first_viewing"] = housing_active
    $ housing_next = ("modern" if housing_active == "central" else "quiet") if housing_outcome != "accepted" else ""
    $ week4_stamp("После просмотра", 1180, 1)
    scene expression week4_home_bg() with fade
    $ set_soundscape("ch3_evening")
    return

label housing_week4_defer:
    # Old saves may already contain a second Thursday appointment. Cancel it
    # explicitly in the story; do not erase the promise in an after_load hook.
    $ housing_deferred = week4_home.get("viewing")
    if not isinstance(housing_deferred, str):
        $ housing_deferred = "modern" if week4_home.get("first_viewing") == "central" else "central"
    call week4_chat("agent", "defer_viewing", [], [("later", "На этой неделе хватит просмотров. Давайте четверг отменим. Если понадобится, напишу.", [("Агент", "Хорошо, четверг убираю. Новый день согласуем отдельно.")])])
    $ week4_home["deferred_viewing"] = housing_deferred
    $ week4_home["viewing"] = False
    $ housing_next = housing_deferred if not week4_home.get("keys_due") else ""
    return

label housing_week4_second:
    # Compatibility entry: a pre-existing FIRST appointment on Thursday stays
    # valid. It must never become a second new apartment in the same chapter.
    if week4_home.get("first_viewing"):
        call housing_week4_defer
        return
    $ housing_second = week4_home.get("viewing") if isinstance(week4_home.get("viewing"), str) else "central"
    $ week4_stamp("Второй просмотр", 1110, 3)
    call housing_visit(housing_second)
    call housing_decide(housing_second)
    $ week4_home["viewing_result"] = housing_outcome
    $ week4_home["first_viewing"] = housing_second
    $ housing_next = ("modern" if housing_second == "central" else "quiet") if housing_outcome != "accepted" else ""
    $ week4_home["viewing"] = False
    $ week4_evening = "viewing"
    $ week4_stamp("После просмотра", 1200, 3)
    return
