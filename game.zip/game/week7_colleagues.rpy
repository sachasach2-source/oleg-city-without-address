define w7i = SpriteCharacter("Илья", sprite_key="w7_ilya", color="#c5b99d")
define w7m = SpriteCharacter("Максим", sprite_key="w7_maxim", color="#d7cbb5")
define w7d = SpriteCharacter("Даша", sprite_key="w7_dasha", color="#dfa777")

init python:
    def week7_colleagues():
        # Lazy upgrade also supports saves made inside the old party episode.
        return week7_venue.setdefault("colleagues", {})

    def week7_colleague_note(key, value):
        week7_colleagues()[key] = value
        week7_event("party_colleague", key+":"+str(value))

    def week7_colleague_scene(colleague, room="hall", person=None):
        if person is None:
            person = week7_party_guest()
        if person == week7_guest and week7_party.get("guest_departed"):
            person = ""
        return "bg w7 coworker "+room+" "+week7_costume+" "+colleague+(" "+person if person else "")

label week7_colleague_greeting(colleague):
    $ week7_colleague_guest = week7_party_guest()
    if week7_colleague_guest and week7_colleagues().get("introduced", {}).get(colleague) != week7_colleague_guest:
        $ week7_colleague_name = {"ilya":"Илья из разработки", "maxim":"Максим из продукта", "dasha":"Даша из дизайна"}[colleague]
        $ week7_colleague_guest_name = week4_names[week7_colleague_guest]
        if colleague == "ilya":
            o "Илья, это [week7_colleague_guest_name]. [week7_colleague_guest_name], Илья у нас за музыку отвечает."
            w7i "Привет."
        elif colleague == "maxim":
            o "[week7_colleague_guest_name], это Максим. Мы вместе работаем."
            w7m "Привет. Садитесь, я подвинусь."
            "Он переставляет свой стакан, освобождая край стола."
        else:
            o "Вы ещё не знакомы? Даша, [week7_colleague_guest_name]."
            w7d "Привет. Давайте сюда, тут место есть."
        # They hear a name, not the earlier relationship label spoken to Katya.
        $ week7_colleagues().setdefault("introduced", {})[colleague] = week7_colleague_guest
    return

label week7_colleagues_arrival:
    if week7_colleagues().get("arrival"):
        return
    $ week7_colleagues()["arrival"] = True
    $ week7_colleagues()["started_solo"] = not bool(week7_guest)
    # The invited guest has not arrived yet, even when week7_guest is populated.
    scene expression week7_colleague_scene("ilya", person="") with dissolve
    "Илья протягивает Олегу моток кабеля. Из клетчатого рукава торчит серая шерсть; на голове у него маленькие волчьи уши."
    w7i "Сейчас, сейчас... О, подержи. Я этот воткну и пойду есть."
    "Олег приподнимает моток, пока Илья освобождает провод."
    if week7_guest:
        o "Я к семи ещё человека встречаю. Пока могу помочь."
        w7i "Успеешь. Мы до семи только настраиваться будем."
    else:
        o "Я сегодня один пришёл. К вам пока можно?"
        w7i "Да конечно. Вот сюда клади, не на проходе."
    menu:
        "У вас ещё на одну гитару место есть? Я бы потом сыграл.":
            w7i "Есть. Я свою дам. Выберешь у сцены, что знаешь."
            $ week7_colleague_note("arrival_intent", "music")
        "Пойдём поедим. Ты, по-моему, с тарелкой так и не дошёл.":
            w7i "Да, пойду возьму. У меня уже тарелку унесли, пока я здесь возился."
            $ week7_colleague_note("arrival_intent", "food")
        "Я сначала осмотрюсь. В игровой уже что-то начинается?":
            w7i "Катя карточки раскладывает. До половины девятого квиз, потом просто садитесь и играйте."
            $ week7_colleague_note("arrival_intent", "look")
    scene expression week7_party_scene("") with dissolve
    return

label week7_colleagues_buffet:
    scene expression week7_colleague_scene("maxim") with dissolve
    call week7_colleague_greeting("maxim")
    "Максим подсовывает край бинта под рукав. От костюма мумии руки пришлось освободить — иначе он не мог держать вилку."
    w7m "Надо было до выхода дома поесть попробовать. Я только в зеркале проверил."
    menu:
        "Илья, вы только на корпоративах играете или ещё репетируете?":
            scene expression week7_colleague_scene("ilya") with dissolve
            call week7_colleague_greeting("ilya")
            w7i "Репетируем. Не каждую неделю: то один не может, то другой. Сегодня полсета из-за этого заново собирали."
            o "А где собираетесь?"
            w7i "Репточку снимаем. Кто может, тот приходит. В последний раз нас вообще трое было."
            if week7_colleagues().get("played_music"):
                w7i "Ты нормально к нам вошёл. Если хочешь, в следующий раз приходи без публики, попробуем ещё."
            else:
                w7i "Хочешь — приходи как-нибудь. Просто поиграть, без концерта."
            menu:
                "Да. Напиши, когда соберётесь. Я посмотрю, смогу ли.":
                    w7i "Напишу. Мы пока даже день не выбрали."
                    $ week7_colleague_note("rehearsal", "ask_when_set")
                "Пока не обещаю. Но сегодня ещё к вам подойду послушать.":
                    if week7_clock < 1275:
                        w7i "Подходи. Мы ещё поиграем."
                    else:
                        w7i "Мы уже закончили. Но в следующий раз приходи."
                    $ week7_colleague_note("rehearsal", "not_now")
            $ week7_colleague_note("buffet", "ilya")
        "Максим, ты серьёзно собрался луну домой забрать?":
            w7m "Да. Я спросил, её потом всё равно выкинут. Хочу у окна повесить."
            "Максим смотрит на бумажный полумесяц над буфетом."
            w7m "Так. Снять, сложить, довезти... Коробка есть, только короткая. Надо другую искать."
            scene expression week7_colleague_scene("dasha") with dissolve
            call week7_colleague_greeting("dasha")
            "Даша отрывает кусочек серебристой ленты от рукава своего комбинезона и приклеивает обратно ровнее."
            w7d "Вдоль шва она складывается. Но сам не тяни, там леска. Я после закрытия сниму."
            menu:
                "Давайте из двух коробок чехол сделаем. Горячее уже всё разобрали.":
                    "Олег с Максимом освобождают две чистые крышки, накладывают одну на другую. Даша приносит скотч."
                    w7d "Вот так нормально. Бумага за край теперь цепляться не будет."
                    $ week7_colleague_note("moon", "sleeve")
                "Давай сначала к двери коробку приложим. Чтобы потом не разворачивать на улице.":
                    "Максим берёт коробку. Олег придерживает дверь; по ширине проходит, если нести ребром."
                    scene expression week7_colleague_scene("maxim") with dissolve
                    w7m "Проходит. Хорошо. Теперь бы машину найти."
                    $ week7_colleague_note("moon", "measured")
                "Я бы на твоём месте попросил Дашу и упаковать. Я такую точно помну.":
                    w7d "Помогу. Только пусть за мной потом зайдёт, когда снимать будем."
                    $ week7_colleague_note("moon", "left_to_them")
            $ week7_colleague_note("buffet", "maxim")
        "Даша, ты комбинезон сама переделывала?":
            scene expression week7_colleague_scene("dasha") with dissolve
            call week7_colleague_greeting("dasha")
            w7d "Нашивки сама. Вчера доклеивала... Вру, сегодня уже. Перед работой. Комбинезон готовый, из рабочей одежды."
            w7d "Я ещё шлем хотела. Но в нём ни чаю попить, ни поговорить. На эскизе и остался."
            if week7_costume == "vampire":
                o "У меня с клыками так. Красиво, пока не надо разговаривать."
            elif week7_costume == "scientist":
                o "Я очки поэтому на лоб сдвинул. В них ещё и видно хуже."
            elif week7_costume == "scarecrow":
                o "Мне шляпа на глаза сползает. За гитарой её вообще пришлось бы снять."
            else:
                o "У меня из всего ободок. И тот сначала за ухом давил."
            scene bg w7 colleague detail dasha with dissolve
            "Она поворачивает рукав: серебряная заплата чуть отходит на сгибе."
            menu:
                "Могу у Кати ленту принести. Тут уголок уже совсем отходит.":
                    "Олег приносит рулон. Даша отрывает короткую полоску и подклеивает заплату."
                    w7d "Спасибо. Остальное ей отнесу, а то ещё кому-нибудь костюм чинить придётся."
                    $ week7_colleague_note("dasha_patch", "helped")
                "По-моему, нормально и так. Сразу видно, что сама делала.":
                    w7d "Да я тоже не буду переделывать. Запасная лента у Кати, если совсем отвалится."
                    $ week7_colleague_note("dasha_patch", "left")
            $ week7_colleague_note("buffet", "dasha")
        "Я пока поем. Вы рассказывайте, я слушаю.":
            w7m "Тогда сядь вот сюда. Тут колонка не над ухом."
            scene expression week7_colleague_scene("dasha") with dissolve
            call week7_colleague_greeting("dasha")
            "Олег подвигает стул. Даша рассказывает, как примеряла комбинезон поверх джинсов, а Максим никак не может поверить, что нужный размер она в итоге нашла в детском разделе."
            $ week7_colleague_note("buffet", "listened")
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    return

label week7_colleagues_stories:
    scene expression week7_colleague_scene("dasha", "games") with dissolve
    call week7_colleague_greeting("dasha")
    "Катя складывает карточки в коробку и уходит танцевать. За столом остаются Даша, Максим и несколько человек из соседней команды."
    w7d "Кто ещё остаётся? Давайте в две правды и ложь. Я начну, если никто не хочет."
    menu:
        "Я математик. Играл в студенческой группе. И однажды выступал перед королём Таиланда.":
            w7d "Про короля ты, конечно, зря последним поставил."
            o "Да? Я думал, уверенно прозвучит. Ладно, короля не было."
            $ week7_venue["story"] = "band"
        "У меня пять одинаковых футболок. Я умею отличать их по ощущениям. Одну из них я ни разу не надевал.":
            w7d "Ты не умеешь их отличать."
            o "Ага. Просто беру чистую."
            w7d "У меня две одинаковые рубашки. Я тоже сначала пыталась."
            $ week7_venue["story"] = "shirts"
        "Я лучше угадаю чужое. Пока не придумал свою историю.":
            w7d "Ладно. Я однажды везла в электричке дверь от шкафа. Однажды полночь провела в мебельном магазине. И один раз пришла не на тот спектакль."
            menu:
                "Про дверь верю. А в мебельном ты до полуночи что делала?":
                    w7d "Снимали выставочный уголок после закрытия. Почти до двенадцати... Вру, до часу мы там были. Неправда про спектакль."
                    $ week7_colleague_note("story_guess", "shop")
                "Про не тот спектакль — неправда?":
                    w7d "Да. С билетами я всё проверяю. Даже дату потом ещё раз."
                    $ week7_colleague_note("story_guess", "play")
                "Дверь от шкафа выдумала. Она же в вагоне весь проход займёт.":
                    w7d "Мы её вдоль стенки поставили. На выставку везли, машины ни у кого не было. Выдумала про спектакль."
                    $ week7_colleague_note("story_guess", "door")
            $ week7_venue["story"] = "dasha"
    $ week7_colleague_note("stories", "played")
    return

label week7_colleague_quiet:
    scene expression week7_colleague_scene("dasha", "quiet", person="") with dissolve
    "Даша стоит у двери со стаканом воды. Увидев Олега, убирает телефон."
    w7d "Ты тоже отдохнуть? Я на пять минут от звука спряталась."
    o "Да. Уши гудят."
    w7d "Тогда давай пока без разговоров."
    "Олег кивает и отходит к свободной стене. Из зала слышен припев, но здесь уже не нужно перекрикивать его."
    "Через несколько минут Даша допивает воду и возвращается к остальным. Олег остаётся ещё ненадолго."
    scene expression week7_venue_scene("quiet", "") with dissolve
    $ week7_colleague_note("quiet", "dasha")
    return

label week7_colleagues_farewell:
    if week7_colleagues().get("moon"):
        scene expression week7_colleague_scene("maxim") with dissolve
        if week7_colleagues()["moon"] == "sleeve":
            w7m "Чехол готов. Осталось дождаться, когда луну снимать можно. Спасибо, что собрал."
        elif week7_colleagues()["moon"] == "measured":
            w7m "Дверь мы прошли. Водитель сказал, на заднее сиденье влезет."
        else:
            w7m "Даша обещала с упаковкой помочь. Я её пока не трогаю, пусть висит."
        o "Покажешь потом, как у окна получилось?"
        w7m "Пришлю. Только повешу сначала."
    elif week7_colleagues().get("rehearsal"):
        scene expression week7_colleague_scene("ilya") with dissolve
        if week7_colleagues()["rehearsal"] == "ask_when_set":
            w7i "Я про репетицию помню. Как день выберем, напишу."
            o "Давай. Я тогда и отвечу, смогу ли."
        else:
            w7i "Ладно, до понедельника. Я ещё провода соберу и тоже поеду."
            if week7_colleagues().get("played_music"):
                o "До понедельника. Спасибо, что дал поиграть."
            else:
                o "До понедельника. Спасибо за вечер."
    scene expression week7_party_scene(week7_party_guest()) with dissolve
    return
