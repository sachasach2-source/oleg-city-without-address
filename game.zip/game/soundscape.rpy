# Original ambience and score use separate mixers. Channel levels are saved by
# Ren'Py, so rollback and loading also restore the acoustic location.
default audio_scene = "title"
default audio_reading = False

init -5 python:
    renpy.music.register_channel("ambience", mixer="ambience", loop=True)

init python:
    soundscapes = {
        "title": ("neva", .55, "returning", .60),
        "hotel_morning": ("hotel-room", .65, None, 0),
        "courtyard": ("courtyard", .75, None, 0),
        "hotel_rest": ("hotel-room", .60, None, 0),
        "river": ("neva", .80, "returning", .55),
        "hotel_evening": ("hotel-room", .60, None, 0),
        "concert": ("club-room", .40, "concert", .80),
        "concert_talk": ("club-room", .32, "concert", .42),
        "club_street": ("club-street", .70, "concert-muffled", .45),
        "morning": ("hotel-room", .65, None, 0),
        "ending_connection": ("neva", .65, "returning", .60),
        "ending_friendship": ("neva", .65, "returning", .50),
        "ending_delay": ("hotel-room", .50, "guitar-room", .60),
        "ch2_apartment": ("hotel-room", .52, None, 0),
        "ch2_lines": ("courtyard", .65, "returning", .35),
        "ch2_gallery": ("club-room", .22, "guitar-room", .25),
        "ch2_gallery_close": ("hotel-room", .42, None, 0),
        "ch2_cafe": ("club-room", .28, "guitar-room", .34),
        "ch2_lera_set": ("club-room", .30, "lera-set", .68),
        "ch2_lera_steps": ("club-street", .65, "lera-muffled", .32),
        "ch2_mug": ("hotel-room", .46, "guitar-room", .36),
        'ch3_room': ('hotel-room', 0.4, None, 0),
        'ch3_outside': ('courtyard', 0.5, 'returning', 0.24),
        'ch3_print': ('hotel-room', 0.34, None, 0),
        'ch3_music': ('club-room', 0.18, 'guitar-room', 0.36),
        'ch3_gallery': ('club-room', 0.2, 'guitar-room', 0.22),
        'ch3_cafe': ('club-room', 0.25, 'guitar-room', 0.26),
        'ch3_event': ('club-room', 0.28, 'lera-set', 0.44),
        'ch3_evening': ('hotel-room', 0.35, 'guitar-room', 0.29),
    }

    def soundscape_levels(delay=1.0):
        atmosphere, atmosphere_level, music, music_level = soundscapes[audio_scene]
        # The city stays present while messages are read; venue music recedes.
        renpy.music.set_volume(atmosphere_level * (.82 if audio_reading else 1), delay=delay, channel="ambience")
        renpy.music.set_volume(music_level * (.60 if audio_reading else 1), delay=delay, channel="music")

    def set_soundscape(scene):
        global audio_scene, audio_reading
        audio_scene = scene
        audio_reading = False
        atmosphere, atmosphere_level, music, music_level = soundscapes[scene]
        renpy.music.play("audio/" + atmosphere + ".ogg", channel="ambience", loop=True,
                         fadeout=2.0, fadein=2.5, if_changed=True)
        if music:
            renpy.music.play("audio/" + music + ".ogg", channel="music", loop=True,
                             fadeout=2.0, fadein=3.0, if_changed=True)
        else:
            renpy.music.stop(channel="music", fadeout=2.0)
        soundscape_levels(delay=1.5)

    def soundscape_reading(reading):
        global audio_reading
        audio_reading = reading
        soundscape_levels(delay=.8)

    def soundscape_muted():
        return all(_preferences.get_mute(mixer) for mixer in ("music", "ambience", "sfx", "voice"))

init 10 python:
    # Keep manually adjusted levels and mute flags from previous versions.
    # Only migrate the exact old factory defaults, which were almost inaudible.
    if not persistent.oleg_soundscape_version:
        old_defaults = {"music": .30, "sfx": .45}
        for mixer, old_slider in old_defaults.items():
            old_volume = old_slider ** 2 if config.quadratic_volumes else 10 ** ((old_slider - 1) * config.volume_db_range / 20)
            if abs(_preferences.volumes.get(mixer, -1) - old_volume) < .000001 and not _preferences.get_mute(mixer):
                _preferences.set_mixer(mixer, .68 if mixer == "music" else .65)
        _preferences.audio_when_unfocused = False
        _preferences.audio_when_minimized = False
        persistent.oleg_soundscape_version = 1
    if "ambience" not in _preferences.volumes:
        _preferences.set_mixer("ambience", .68)
