label week6_sunday_weekend:
    $ week6_stage = "sunday"
    $ week6_stamp("Утро воскресенья", 480, 7)
    scene expression home_keepsake_background(week6_home_path()) with fade
    $ set_soundscape("ch3_room")
    if week6_dates.get("lera", {}).get("night") == "shared_sleep":
        "Лера просыпается раньше Олега, но зарядку ищет он: провод ночью сполз за кровать. Она пока сидит под одеялом и показывает пальцем, куда светить телефоном."
        l "Вот поэтому я дома запасную держу. Чтобы утром не заниматься археологией."
        o "Я тебе эту отдам. Когда найду."
        l "Не надо отдавать. Пусть тут лежит. Если ещё придём."
        "Она собирается к себе за ноутбуком. На прощание целует Олега у двери и напоминает, что вечером хочет спокойно дослушать вчерашний сет."
        $ week6_event("morning_after_sleep", "Сон, зарядка, её планы; не обещание совместного быта", "lera")
    if week6_housing.get("move_due") == "sunday_morning" and not week6_housing.get("moved"):
        "После завтрака Олег забирает вещи из гостиницы: пакует всё в номере и заказывает машину. На ресепшене проверяют, не осталось ли чего в номере. Ключ-карту он возвращает."
        $ week6_housing["moved"] = True
        scene expression home_keepsake_background(week6_home_path()) with fade
        "В новой квартире чемодан сначала едет к той стене, где в гостинице был стол. Олег останавливает его и смеётся: здесь стол с другой стороны."
        "Он ставит сумки у шкафа и убирает продукты в холодильник. Разбирать всё сейчас не успеет."
        $ week6_event("moved_home", week6_home.get("actual_home", ""))
        $ week6_stamp("После переезда", 550)
    call housing_story_sunday
    if week6_dates.get("asya", {}).get("confirmed") and not week6_dates["asya"].get("played"):
        call week6_asya_gulf
    elif week6_dates.get("nika", {}).get("confirmed") and not week6_dates["nika"].get("played"):
        call week6_nika_port
    else:
        $ week6_stamp("У воды", 735)
        scene bg w6 port empty with fade
        $ set_soundscape("w6_water")
        "Днём Олег всё-таки доезжает до Канонерки. Здесь не предлагают прогуляться по красивой части. Есть вода, камни и порт, который работает в воскресенье."
        "Он стоит, пока один кран разворачивается над судном. Потом надевает перчатку обратно: фотография и так получилась."
        menu:
            "Побуду ещё. Ради этого и приехал.":
                "Олег находит место за кустами, где меньше дует, и допивает взятый с собой чай. Никому не надо придумывать реплику."
                $ week6_event("own_water", "Тихий берег")
            "Хватит ветра. Пора к еде.":
                "Он возвращается к дороге. На остановке человек ест пирожок, пряча его от ветра ровно так же, как Олег прячет телефон."
                $ week6_event("own_water", "Короткая прогулка")
        $ week6_stamp("После прогулки", 870)
    call week6_ulya_sunday_offer
    call week6_city_walk
    $ week6_stamp("Дома · воскресный вечер", max(week6_clock + 30, 1120))
    scene expression home_keepsake_background(week6_home_path(True)) with fade
    $ set_soundscape("ch3_room")
    call housing_story_first_night
    call week6_new_contacts_weekend
    call week6_known_connections_weekend
    $ week6_stamp("Вечерние сообщения", max(week6_clock, 1150))
    call week6_rita_sunday_result
    call week6_friends_sunday
    call week6_flight_idea
    jump week6_finish

label week6_known_connections_weekend:
    if connection_get("asya_varya", week6_relations).get("introduced") and week6_known("asya") and week6_known("varya"):
        if connection_get("asya_varya", week6_relations).get("scene_done"):
            $ week6_conn_line = "Варя прислала запись. Ещё рассказала про свою песню. После того раза сама мне пишет, смешная."
        else:
            $ week6_conn_line = "Варя написала про концерт. Мы пока так вживую и не пересеклись, но запись попросила."
        call week6_chat("asya", "varya_connection", [("Ася", week6_conn_line)], [("reply", "Она сама лучше расскажет. Я рад, что у вас общение продолжается.", [("Ася", "Да. Я ей и написала, что хочу послушать.")])])
        $ week6_event("connection_continued", "asya_varya", "asya")
    if connection_get("marta_varya", week6_relations).get("introduced") and week6_known("marta") and week6_known("varya"):
        if connection_get("marta_varya", week6_relations).get("scene_done"):
            $ week6_conn_line = "Варя прислала песню и спросила, это слишком грустно или нормально. После нашей партии она меня теперь так и спрашивает: выбери из двух."
        else:
            $ week6_conn_line = "Варя написала про песню. Мы после твоего знакомства пока только переписывались. Хочет две версии сравнить."
        call week6_chat("marta", "varya_connection", [("Марта", week6_conn_line)], [("reply", "Только выбери правда какую сама хочешь. Она может потом очень внимательно про ответ спрашивать.", [("Марта", "Да. Я ей уже вторую выбрала. Теперь слушаю, почему первая тоже хорошая.")])])
        $ week6_event("connection_continued", "marta_varya", "marta")
    return

label week6_friends_sunday:
    call week6_chat("friends", "pool_return", [], [("ask", "Ну как съездили? Уже вернулись?", [("Саша", "Да. Я там реально выспался. Даже будильник не ставил."), ("Саня", "Я перед завтраком ещё в воду сходил. Потом шёл одеваться и прям злился, что опять носки нужны."), ("Саша", "У нас было море за забором из стеклопакетов. Нормальный формат оказался.")])])
    $ week6_topics = [("Не буду отчитываться. Спрошу, повторят ли они ещё.", "their_trip"), ("Расскажу, как сам скучаю по теплу.", "sea")]
    python:
        for person in ("nika", "lera", "asya", "marta"):
            if week6_dates.get(person, {}).get("played"):
                week6_topics.append(("Расскажу про встречу с " + {"nika":"Никой", "lera":"Лерой", "asya":"Асей", "marta":"Мартой"}[person] + ". Без личных подробностей.", person))
        if week6_concert.get("attended"):
            week6_topics.append(("Расскажу про Варин концерт.", "concert"))
        if week6_housing or week6_home.get("kind") != "hotel" or week6_home.get("left_home"):
            week6_topics.append(("Расскажу, что с квартирой.", "home"))
        if week6_exhibition.get("visited"):
            week6_topics.append(("Расскажу про море в бывшем продуктовом.", "exhibition"))
    call screen chapter3_intentions("О чём хочется поговорить?", week6_topics)
    $ week6_topic = _return
    $ week6_weekend["friends_topic"] = week6_topic
    if week6_topic == "their_trip":
        call week6_chat("friends", "pool_again", [], [("ask", "Ещё поедете? Или один раз хватило?", [("Саша", "Я уже на декабрь смотрю. В этот раз хочу без ноутбука вообще."), ("Саня", "Я тоже. У меня в номере сумка с беговым так и осталась закрытая. И даже не стыдно.")])])
    elif week6_topic == "sea":
        call week6_chat("friends", "want_warmth", [], [
            ("plain", "Я сегодня на воду смотрел. Тут красиво, но я очень хочу, чтобы можно было просто выйти в футболке.", [("Саша", "Я поэтому и согласился на эту пальму. Дома сидел и всё откладывал. А тут хоть на день голову выключил."), ("Саня", "Ты цены сначала открой. Потом уже объявляй, что всё бросил. А то опять будешь в шарфе психовать.")]),
            ("together", "Может, потом вместе куда-нибудь в тепло? Не покупать сейчас, просто подумать.", [("Саша", "Я за подумать. Надо отпуск проверить."), ("Саня", "Я сроки с клиентами гляну. Напиши, что сам насмотришь. Без героического «любые даты».")])])
    elif week6_topic in ("nika", "lera", "asya", "marta"):
        $ week6_report = {"nika":"С Никой сегодня до порта доехали. Она кран записала. Прям стояла и ждала, пока ещё раз повернётся.", "lera":"Вчера после Лериного сета ехали в почти пустом трамвае. Она первые две остановки говорила на весь вагон, потом сама заметила.", "asya":"С Асей до Курорта доехали, к заливу. Она снимала снег с песком. Я всё боялся наступить не туда.", "marta":"С Мартой вчера гуляли. Папку с работой дома оставила, так и встретились просто так. Потом с булкой в кафе сидели."}[week6_topic]
        if week6_dates[week6_topic].get("limited"):
            $ week6_report = {"nika":"С Никой сегодня коротко у порта прошлись. Договорились на сорок пять минут, так и разошлись. После прошлого раза пока осторожно.", "lera":"Леру вчера после сета встретил. Вместе немного в трамвае проехали. Потом каждый к себе, как договаривались.", "asya":"С Асей кофе у Финляндского выпили. К заливу не поехали — только на сорок пять минут встретились.", "marta":"С Мартой вчера один круг по саду прошли. Потом у неё дела. Пока без продолжения, после прошлого раза не так просто."}[week6_topic]
        call week6_chat("friends", "weekend_report", [], [
            ("good", week6_report + " Мне понравилось.", [("Саня", {"nika":"На входящий не ставь. А то кран проснётся раньше тебя.", "lera":"Это после моего аквапарка тоже бывает. Я на стойке про шкафчик орал. Мне в ответ шёпотом сказали.", "asya":"Я сегодня на плитку так же смотрел. Только чтобы не уехать лицом.", "marta":"Вот это хороший план. Мы тоже сначала придумали отдых без работы. Удивительно, но сработало."}[week6_topic]), ("Саша", "Хорошо, что выбрались. А то у меня до субботы весь город был между квартирой и доставкой.")]),
            ("unsure", week6_report + " Я пока не очень понимаю, что дальше. Но увидеться хотел.", [("Саша", "Ну ты хотя бы хотел. Я иногда сначала соглашаюсь, потом в такси думаю, зачем еду."), ("Саня", "Ты ещё раз захочешь — позови. Только не «как-нибудь». Сам же бесишься с этого.")])])
        $ week6_event("friends_heard_date", week6_topic, "friends")
    elif week6_topic == "home":
        $ week6_home_report = "Квартиру пока не взял. Смотрел новый дом: за окном оборудование гудит. Мне объяснили, что это звуки города." if week6_home.get("kind") == "hotel" and not week6_home.get("left_home") and week6_housing.get("decision") in ("declined", "declined_at_contract", "thinking", "documents") else housing_story_report()
        call week6_chat("friends", "home_news", [], [("tell", week6_home_report, [("Саня", "Искать ещё будешь или пока хватит?"), ("Олег", "Пока хватит. Хочу неделю без просмотров."), ("Саша", "Тогда не открывай объявления перед сном. Я так машину до трёх ночи выбирал, хотя вообще не собирался покупать.")])])
    elif week6_topic == "concert":
        call week6_chat("friends", "varya_concert", [], [("tell", "Варя, стажёрка, в пятницу пела на небольшом вечере. Волновалась, потом сама же просила ещё номер. Очень круто на неё было смотреть.", [("Саша", "Я в институте на сцену с выключенным микрофоном вышел. До припева так и пел. Думал, зал маленький, слышно."), ("Олег", "Никто не показал?"), ("Саша", "Показывали. Я им кивал. Думал, поддерживают."), ("Саня", "Скинь запись, если Варя разрешит. Хочу послушать.")])])
    else:
        call week6_chat("friends", "shop_sea", [], [("tell", "В бывшем продуктовом выставка. На стене море, гамак, всё красиво. Звук авторка в ванной писала.", [("Саня", "Мы примерно туда же съездили, только нас на входе полотенцем обобрали."), ("Саша", "В следующий раз пусть нам проектор в номер ставят. Без горки мне, правда, уже будет мало.")])])
    $ week6_event("friends_evening", week6_topic, "friends")
    return

label week6_flight_idea:
    $ week6_stamp("Поздний вечер", max(week6_clock, 1260))
    scene bg w6 sea plans with dissolve
    "Олег открывает перелёты и увеличивает фотографию у первого варианта. Море на ней почти бирюзовое."
    "Он меняет даты. Один вариант получается на неделю. На другом удобнее время вылета."
    $ week6_flight_options = [("Закрою. Сейчас просто хотелось посмотреть.", "close"), ("Сохраню вариант. Потом спокойно решу.", "save"), ("Отправлю друзьям. Мы как раз заговорили про тепло.", "friends")]
    python:
        for person in ("nika", "lera", "asya", "marta"):
            if week6_dates.get(person, {}).get("played") and not week6_issues(person):
                week6_flight_options.append(("Покажу " + {"nika":"Нике", "lera":"Лере", "asya":"Асе", "marta":"Марте"}[person] + ". Интересно, что скажет.", person))
    call screen chapter3_intentions("Что сделать с найденным?", week6_flight_options)
    $ week6_flight_choice = _return
    $ week6_sea.update(flight=week6_flight_choice, booked=False)
    if week6_flight_choice == "close":
        "Он закрывает вкладку, не удаляя историю поиска. Монета остаётся рядом с телефоном."
    elif week6_flight_choice == "save":
        "Олег сохраняет вариант. Будет с чем сверить рабочие даты; сам отпуск он ещё никому не обещал."
    elif week6_flight_choice == "friends":
        call week6_chat("friends", "flight_idea", [], [
            ("week", "Посмотрел на неделю в тепло. Пока ничего не брал. Если захотите вместе — давайте сначала даты каждый проверит.", [("Саша", "Завтра отпуск посмотрю. Не обещаю пока."), ("Саня", "А я работу. Хорошо, что ты тоже «пока». Я ещё от этой пальмы не остыл.")]),
            ("alone", "Вот что насмотрел. Возможно, один выберусь. Просто хотел показать, раз заговорили про море.", [("Саня", "Ну вот. Уже план, а не просто мёрзнешь."), ("Саша", "Если поедешь, фотку из воды пришли. Теперь я понимаю жанр.")])])
        $ week6_sea["intent"] = _return
        $ week6_sea["shared_with"] = "friends"
    else:
        $ week6_flight_person = week6_flight_choice
        $ week6_flight_reply = {"nika":"Ты на сколько хочешь? У меня запись на неделе, я сейчас не выберусь.", "lera":"Ого. На сколько? Я уже про следующую субботу думала, когда тебе свой хвост скину.", "asya":"Ты это меня зовёшь или просто делишься? Я пока не поняла.", "marta":"Я уже даты смотрю. Подожди, ты мне для этого прислал или просто море показать?"}[week6_flight_person]
        call week6_chat(week6_flight_person, "flight_first", [], [("show", "Сижу перелёты смотрю. Вот вариант в тепло, примерно на неделю. Пока ничего не купил.", [(week4_names[week6_flight_person], week6_flight_reply)])])
        $ week6_flight_replies = [("share", "Пока просто делюсь. Хочу на неделю согреться, а когда — ещё не решил. Не ставь себе ничего из-за этой ссылки.", [(week4_names[week6_flight_person], {"nika":"Хорошо. Я тогда свою запись не двигаю. Если что-то решишь, напиши.", "lera":"А, поняла. Тогда я пока со своим субботним хвостом. Но море красивое, да.", "asya":"Теперь понятно. Показывай тогда, что ещё найдёшь. Я тоже уже в носках до колен сижу.", "marta":"Хорошо. Я успела два дня местами поменять, но это в голове только. Не считается."}[week6_flight_person])])]
        if not week6_friend(week6_flight_person) and week6_flight_person != "nika":
            $ week6_flight_replies.append(("together", "Я бы с тобой поехал. Но это именно предложение подумать вместе: отпуск, деньги, даты. Ничего за тебя не покупаю.", [(week4_names[week6_flight_person], {"lera":"Хочу подумать. Сеты сначала посмотрю, обещать сейчас не буду.", "asya":"Я бы хотела. Завтра по работе проверю и скажу, когда могу.", "marta":"Да. Скажу, какие даты могу, и тогда вместе посмотрим. Пока не передвигаю ничего."}[week6_flight_person])]))
        call week6_chat(week6_flight_person, "flight_meaning", [], week6_flight_replies)
        $ week6_sea.update(intent=_return, shared_with=week6_flight_person)
        $ week6_event("flight_meaning_explained", _return, week6_flight_person)
    $ week6_event("sea_plan", week6_flight_choice)
    return

label week6_finish:
    $ week6_stage = "finished"
    $ week6_finished = True
    $ week6_stamp("Дома", max(week6_clock, 1330))
    scene bg w6 thai shirt with fade
    $ set_soundscape("ch3_room")
    if week6_housing.get("moved"):
        "На новой кухне пока не найти половину нужного. Зато ключи лежат у двери, и за ними не надо спускаться на стойку."
    elif week6_home.get("kind") == "hotel":
        "В коридоре гостиницы гремит колёсами чемодан. Олег закрывает дверь плотнее и отодвигает телефон от края стола."
    else:
        "У двери сохнет коврик. Олег переставляет ботинки, чтобы утром не наступить в холодную лужу."
    "Рубашку он оставляет сверху. Завтра снова понадобится свитер, но убирать её далеко уже не хочется."
    $ quick_menu = False
    hide screen scene_marker
    call screen week6_ending
    if _return == "chapter7":
        jump week7_start
    return

screen week6_ending():
    modal True
    add Solid("#0c1822dd")
    frame:
        xalign .5 yalign .5 xsize 1080 padding (50, 42) background Solid("#142631")
        vbox:
            spacing 23
            text "ГЛАВА ШЕСТАЯ" size 19 color "#d5b384" kerning 3
            text "До тебя доехать" size 46
            text "За окном октябрьский снег. Телефон пока можно отложить." size 25
            textbutton "Продолжить · глава 7" action Return("chapter7")
            textbutton "Сохранить" action ShowMenu("save")
            textbutton "В главное меню" action MainMenu(confirm=False)
