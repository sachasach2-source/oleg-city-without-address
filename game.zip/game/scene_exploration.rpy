# Optional looking, not a completion task. Old defaults remain save-compatible.
default scene_exploration_seen = {}
default scene_exploration_selected = {}
default scene_exploration_topics = {}
default chapter2_gallery_detail = None
# Looking, checking, and actually asking are different events in this run.
default scene_exploration_checks = {}
default scene_exploration_check_feedback = {}
default scene_exploration_questions_done = {}
default scene_exploration_context = {}
default scene_exploration_followup_pending = False

init -2 python:
    ui_focus_screens += ("scene_exploration", "scene_exploration_questions")
    ui_own_controls += ("scene_exploration", "scene_exploration_questions")

    # Boxes and crops use the game's 1600x900 canvas, not source-image pixels.
    scene_exploration_places = {
        "first_kitchen": {
            "title": "Кухня на Ваське",
            "image": "images/cast/viewing-empty.webp",
            "objects": (
                dict(key="window", caption="Окна", bbox=(190, 90, 600, 390), crop=(90, 0, 1120, 630), note=None),
                dict(key="table", caption="Стол и стулья", bbox=(300, 545, 480, 245), crop=(210, 450, 800, 450), note=None),
                dict(key="radiator", caption="Батарея", bbox=(230, 485, 220, 125), crop=(160, 405, 800, 450), note="Про отопление надо будет спросить отдельно."),
            ),
        },
        "lera_kitchen": {
            "title": "Ещё одна кухня",
            "image": "images/cast/apartment-empty.webp",
            "objects": (
                dict(key="window", caption="Окно", bbox=(210, 75, 295, 440), crop=(0, 0, 1120, 630), note=None),
                dict(key="table", caption="Кухонный стол", bbox=(160, 545, 360, 225), crop=(80, 450, 800, 450), note=None),
                dict(key="passage", caption="Проход", bbox=(770, 550, 340, 210), crop=(480, 0, 1120, 630), note="У холодильника узко. С коробкой тут особенно не развернёшься."),
            ),
        },
        "gallery": {
            "title": "«Временное пользование»",
            "image": "images/chapter2-gallery-chair.webp",
            "objects": (
                dict(key="wood", caption="Потёртое дерево", bbox=(1200, 330, 330, 420), crop=(640, 340, 960, 540), note=None),
                dict(key="scarf", caption="Шарф", bbox=(820, 150, 365, 455), crop=(640, 30, 960, 540), note=None),
                # The wall is intentionally out of focus in the approved image.
                # This is a modest look across the hall, not fabricated fine detail.
                dict(key="photos", caption="Зал выставки", bbox=(460, 95, 300, 380), crop=(0, 0, 1440, 810), note=None),
            ),
        },
    }

    scene_exploration_check_data = {
        "first_kitchen": {
            "listing": dict(detail=None, action="Сверить объявление", result="В объявлении было от года. По телефону агент уже предложил полгода. Красивый свет этого расхождения не отменяет.", question="На полгода — это вся квартира? И сколько нужно при въезде?"),
            "workplace": dict(detail="table", action="Прикинуть рабочее место", result="На кухне есть стол. А жилую комнату Олег ещё не видел — где поставить ноутбук вне кухни, пока непонятно.", question="Жилую комнату тоже можно будет проверить до подписи?"),
        },
        "lera_kitchen": {
            "listing": dict(detail=None, action="Сверить объявление", result="В объявлении по-прежнему указано «квартира целиком». Что именно сдаётся, лучше уточнить у хозяина.", question="В объявлении квартира целиком. Вы её целую сдаёте?"),
            "layout": dict(detail="passage", action="Оценить проход", result="Олег уже попробовал закрыть холодильник: дверца цепляется за ручку входной двери. С коробкой в этом проходе ещё теснее.", question="А как тогда заносить вещи через этот проход?"),
        },
    }

    def scene_exploration_context_note(place, fact):
        global scene_exploration_context
        known = tuple(scene_exploration_context.get(place, ()))
        if fact not in known:
            context = dict(scene_exploration_context)
            context[place] = known + (fact,)
            scene_exploration_context = context

    def scene_exploration_check_available(place, check):
        data = scene_exploration_check_data.get(place, {}).get(check)
        if data is None:
            return False
        if check == "layout" and "fridge_door" not in scene_exploration_context.get(place, ()):
            return False
        return data["detail"] == scene_exploration_selected.get(place)

    def scene_exploration_check(place, check):
        global scene_exploration_checks, scene_exploration_check_feedback
        if not scene_exploration_check_available(place, check):
            return
        previous = tuple(scene_exploration_checks.get(place, ()))
        if check not in previous:
            checked = dict(scene_exploration_checks)
            checked[place] = previous + (check,)
            scene_exploration_checks = checked
        feedback = dict(scene_exploration_check_feedback)
        feedback[place] = check
        scene_exploration_check_feedback = feedback
        renpy.retain_after_load()

    def scene_exploration_clear_feedback(place):
        global scene_exploration_check_feedback
        feedback = dict(scene_exploration_check_feedback)
        feedback.pop(place, None)
        scene_exploration_check_feedback = feedback

    def scene_exploration_check_note(place):
        key = scene_exploration_check_feedback.get(place)
        return scene_exploration_check_data.get(place, {}).get(key, {}).get("result")

    def scene_exploration_question_options(place):
        checked = scene_exploration_checks.get(place, ())
        discussed = scene_exploration_questions_done.get(place, ())
        return tuple((key, data["question"]) for key, data in scene_exploration_check_data.get(place, {}).items() if key in checked and key not in discussed)

    def scene_exploration_question_done(place, question):
        global scene_exploration_questions_done
        previous = tuple(scene_exploration_questions_done.get(place, ()))
        if question not in previous:
            discussed = dict(scene_exploration_questions_done)
            discussed[place] = previous + (question,)
            scene_exploration_questions_done = discussed
        renpy.retain_after_load()

    def scene_exploration_object(place, detail):
        for item in scene_exploration_places.get(place, {}).get("objects", ()):
            if item["key"] == detail:
                return item
        return None

    def scene_exploration_note(place, detail):
        global scene_exploration_seen, scene_exploration_selected
        if scene_exploration_object(place, detail) is None:
            return
        previous = tuple(scene_exploration_seen.get(place, ()))
        if detail not in previous:
            updated = dict(scene_exploration_seen)
            updated[place] = previous + (detail,)
            scene_exploration_seen = updated
        scene_exploration_clear_feedback(place)
        selected_by_place = dict(scene_exploration_selected)
        selected_by_place[place] = detail
        scene_exploration_selected = selected_by_place
        # The screen expression can reuse its cached Transform after idle.
        camera = renpy.get_widget("scene_exploration", "exploration_camera")
        if camera is not None:
            renpy.redraw(camera, 0)
        # The current close-up is independent from a deliberately chosen question.
        renpy.retain_after_load()

    def scene_exploration_back(place):
        global scene_exploration_selected
        scene_exploration_clear_feedback(place)
        selected_by_place = dict(scene_exploration_selected)
        selected_by_place[place] = None
        scene_exploration_selected = selected_by_place
        camera = renpy.get_widget("scene_exploration", "exploration_camera")
        if camera is not None:
            renpy.redraw(camera, 0)
        renpy.retain_after_load()

    def scene_exploration_choose_topic(place, detail):
        global scene_exploration_topics
        if place != "gallery" or scene_exploration_object(place, detail) is None:
            return
        topics = dict(scene_exploration_topics)
        if topics.get(place) == detail:
            topics.pop(place, None)
        else:
            topics[place] = detail
        scene_exploration_topics = topics
        renpy.retain_after_load()

    def scene_exploration_result(place):
        # Looking at something never selects a line of dialogue on the player's behalf.
        topic = scene_exploration_topics.get(place)
        return topic if place == "gallery" and scene_exploration_object(place, topic) else ""

    class SceneExplorationCameraMotion(object):
        """Interpolate the actual crop; redraw only while the camera is moving."""
        def __init__(self, place):
            self.place = place
            self.target = None
            self.origin = None
            self.started = None

        def __call__(self, camera, st, at):
            detail = scene_exploration_selected.get(self.place)
            item = scene_exploration_object(self.place, detail)
            target = tuple(item["crop"]) if item else (0, 0, 1600, 900)
            if self.target != target:
                self.origin = tuple(camera.crop or (0, 0, 1600, 900))
                self.target = target
                self.started = st
            if self.origin == self.target:
                camera.crop = self.target
                return None
            progress = max(0.0, min(1.0, (st - self.started) / .42))
            eased = progress * progress * (3.0 - 2.0 * progress)
            # Plain floats are RELATIVE Ren'Py positions, even when >1.
            # Preserve absolute pixel units throughout the interpolation.
            camera.crop = tuple(absolute(origin + (end - origin) * eased) for origin, end in zip(self.origin, self.target))
            return 1.0 / 60.0 if progress < 1.0 else None

    def scene_exploration_camera(place, image):
        # A Python Transform function is re-evaluated on screen interaction even
        # after motion ends. ATL on show/on replace does not react to new targets.
        return Transform(Transform(image, xysize=(1600, 900)), function=SceneExplorationCameraMotion(place), xysize=(1600, 900), subpixel=True)

    class SceneExplorationLens(renpy.Displayable):
        """A small code-drawn cursor; no new image asset or global cursor replacement."""
        def render(self, width, height, st, at):
            rendered = renpy.Render(34, 34)
            drawing = rendered.canvas()
            drawing.circle("#182321dd", (13, 13), 10, 4)
            drawing.line("#182321dd", (20, 20), (30, 30), 6)
            drawing.circle("#f1dbb7ee", (13, 13), 10, 2)
            drawing.line("#f1dbb7ee", (20, 20), (30, 30), 3)
            drawing.line("#f1dbb7ee", (9, 13), (17, 13), 2)
            drawing.line("#f1dbb7ee", (13, 9), (13, 17), 2)
            return rendered

    _scene_exploration_previous_mouse = config.mouse_displayable
    _scene_exploration_mouse = MouseDisplayable(None)
    _scene_exploration_mouse.add("exploration_zoom", SceneExplorationLens(), 13, 13)

    def scene_exploration_mouse_displayable():
        if renpy.get_screen("scene_exploration"):
            return _scene_exploration_mouse
        previous = _scene_exploration_previous_mouse
        return previous() if callable(previous) else previous

    config.mouse_displayable = scene_exploration_mouse_displayable

screen scene_exploration(place):
    modal True
    zorder 150
    $ location = scene_exploration_places[place]
    $ selected = scene_exploration_selected.get(place)
    $ detail_object = scene_exploration_object(place, selected)
    $ view_rect = detail_object["crop"] if detail_object else (0, 0, 1600, 900)
    $ topic = scene_exploration_topics.get(place)
    $ check_note = scene_exploration_check_note(place)
    $ detail_check = next((key for key, data in scene_exploration_check_data.get(place, {}).items() if data["detail"] == selected and data["detail"] is not None and scene_exploration_check_available(place, key)), None)
    key "game_menu" action (Function(scene_exploration_back, place) if detail_object else Return(scene_exploration_result(place)))
    key "K_SPACE" action (Function(scene_exploration_back, place) if detail_object else Return(scene_exploration_result(place)))
    key "K_RETURN" action Return(scene_exploration_result(place))

    add scene_exploration_camera(place, location["image"]):
        id "exploration_camera"

    if detail_object is None:
        for item in location["objects"]:
            button:
                id ("explore_" + item["key"])
                xpos item["bbox"][0] ypos item["bbox"][1]
                xsize item["bbox"][2] ysize item["bbox"][3]
                padding (0, 0)
                background None hover_background None
                mouse "exploration_zoom"
                alt ("Рассмотреть: " + item["caption"])
                action Function(scene_exploration_note, place, item["key"])
    else:
        frame:
            xpos 36 ypos 782
            padding (10, 9)
            background context_panel("panel")
            hbox:
                spacing 12
                textbutton "← Общий вид":
                    id "exploration_back"
                    text_size 23 padding (15, 10)
                    action Function(scene_exploration_back, place)
                if detail_check:
                    textbutton scene_exploration_check_data[place][detail_check]["action"]:
                        id "exploration_check"
                        text_size 23 padding (15, 10)
                        action Function(scene_exploration_check, place, detail_check)
                if place == "gallery":
                    textbutton ("Не спрашивать" if topic == selected else "Спросить об этом"):
                        id "exploration_ask"
                        text_size 23 padding (15, 10)
                        selected (topic == selected)
                        action Function(scene_exploration_choose_topic, place, selected)

    if check_note:
        frame:
            xpos 36 ypos 620 xsize 785
            padding (21, 16)
            background context_panel("dialogue")
            text check_note size 23 line_spacing 4 xmaximum 743
    elif detail_object and detail_object["note"] and place == "gallery":
        frame:
            xpos 36 ypos 680 xsize 690
            padding (21, 16)
            background context_panel("dialogue")
            text detail_object["note"] size 23 line_spacing 4 xmaximum 648

    if detail_object is None and "listing" in scene_exploration_check_data.get(place, {}):
        frame:
            xpos 36 ypos 28
            padding (9, 7)
            background context_panel("panel")
            textbutton "Сверить объявление":
                id "exploration_listing"
                text_size 21 padding (15, 9)
                action Function(scene_exploration_check, place, "listing")

    if detail_object is None:
        frame:
            xpos 36 ypos 782 xsize 820
            padding (20, 14)
            background context_panel("panel")
            vbox:
                spacing 5
                text location["title"] size 23 color "#e6c797"
                text ("Коснись детали, чтобы приблизить." if renpy.variant("touch") else "Наведи курсор на детали. Нажми, чтобы приблизить.") size 19 color "#eeeae1"

    frame:
        xpos 1220 ypos 28
        padding (8, 6)
        background context_panel("panel")
        hbox:
            spacing 10
            textbutton "Сохранить" id "exploration_save" action ShowMenu("save") text_size 18 padding (10, 6)
            textbutton "Загрузить" id "exploration_load" action ShowMenu("load") text_size 18 padding (10, 6)

    frame:
        xpos 1045 ypos 782 xsize 515
        padding (12, 10)
        background context_panel("panel")
        textbutton ("К столу каталогов →" if place == "gallery" else "Продолжить просмотр →"):
            id "exploration_continue"
            xfill True text_size 23 padding (14, 10)
            action Return(scene_exploration_result(place))

screen scene_exploration_questions(place):
    modal True
    zorder 150
    key "game_menu" action Return("")
    $ questions = scene_exploration_question_options(place)
    frame:
        xpos 54 ypos 820 yanchor 1.0 xsize 1040
        padding (24, 20)
        background context_panel("panel")
        vbox:
            spacing 10
            text "Уточнить после осмотра?" size 23 color "#e6c797"
            for key, caption in questions:
                textbutton caption:
                    id ("exploration_question_" + key)
                    xfill True text_size 23 padding (17, 12)
                    action Return(key)
            textbutton "Продолжить разговор →":
                id "exploration_questions_continue"
                text_size 23 padding (17, 12)
                action Return("")

label scene_exploration_apartment_questions(place):
    while scene_exploration_question_options(place):
        call screen scene_exploration_questions(place)
        if not _return:
            return
        if place == "first_kitchen" and _return == "listing":
            o "На полгода — это вся квартира? И сколько нужно при въезде?"
            agent "Вся. До конца срока хозяйка здесь жить не будет. Шестьдесят восемь тысяч в месяц, столько же залог. Комиссия — тридцать четыре один раз, счётчики отдельно."
            o "Сто семьдесят на въезде. Понял."
            $ scene_exploration_question_done(place, "listing")
        elif place == "first_kitchen" and _return == "workplace":
            o "Жилую комнату тоже можно будет проверить до подписи? На кухне я работать каждый день не хочу."
            agent "Конечно. Перед подписью проверите комнаты и договор."
            $ scene_exploration_question_done(place, "workplace")
        elif place == "lera_kitchen" and _return == "layout":
            o "А как тогда заносить вещи через этот проход?"
            owner "Сначала холодильник закрыть. По одному проходить."
            o "То есть с коробкой лучше сюда не разворачиваться."
            $ scene_exploration_question_done(place, "layout")
        elif place == "lera_kitchen" and _return == "listing":
            o "В объявлении квартира целиком. Вы её целую сдаёте?"
            $ scene_exploration_question_done(place, "listing")
            # The original owner's answer follows; then remaining questions may resume.
            return "listing"
        else:
            return
    return

label scene_exploration_gallery_question(detail):
    if detail == "wood":
        o "А потёртости на нём оставили специально?"
        a "Не стали закрашивать. Видишь след на ножке? Его всю жизнь придвигали к одной батарее. Просто было холодно."
        o "На кухне я бы его вообще не заметил."
    elif detail == "scarf":
        o "Шарф тоже часть работы? Я чуть не поправил."
        a "Да. Хозяйка привезла стул вместе с ним. Тут лучше ничего не поправлять, даже если очень просится."
        o "Хорошо, что предупредила."
    elif detail == "photos":
        o "Стул с фотографиями как-то связан? Или я уже сам квартиру из них собираю?"
        a "Они про вещи и переезды. А квартиру ты, кажется, уже сам собрал."
        o "Профессиональная деформация за четыре месяца."
    return
