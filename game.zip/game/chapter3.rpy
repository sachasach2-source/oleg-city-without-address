# Chapter3: plans are made on Friday; only mutually confirmed meetings run.
image bg ch3 rental = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))
image bg ch3 home evening = Transform("images/chapter3/ch3-rental-evening-v2.webp", xysize=(1600, 900))
image bg ch3 rehearsal = Transform("images/chapter3/ch3-rehearsal-empty-v3.webp", xysize=(1600, 900))
image bg ch3 playing = Transform("images/chapter3/ch3-playing-v4.webp", xysize=(1600, 900))
image bg ch3 print = Transform("images/chapter3/ch3-print-workday-v3.webp", xysize=(1600, 900))
image bg ch3 market = Transform("images/chapter3/ch3-market-empty-v2.webp", xysize=(1600, 900))
image bg ch3 event = Transform("images/chapter3/ch3-event-empty-v2.webp", xysize=(1600, 900))
image bg ch3 lunch = Transform("images/chapter3/ch3-lunch-v2.webp", xysize=(1600, 900))
image bg ch3 photos = Transform("images/chapter3/ch3-photos-empty-v2.webp", xysize=(1600, 900))
image bg ch3 street = Transform("images/chapter3/ch3-street-sunny-v2.webp", xysize=(1600, 900))
image bg ch3 alone = Transform("images/chapter3/ch3-street-sunny-v2.webp", xysize=(1600, 900))
image bg ch3 street nika = Transform("images/chapter3/nika-record-lane-v1.webp", xysize=(1600, 900))
image bg ch3 street lera = Transform("images/chapter3/lera-bakery-sadovaya-v1.webp", xysize=(1600, 900))
image bg ch3 street varya = Transform("images/chapter3/vaska-courtyard-shade-v1.webp", xysize=(1600, 900))
image bg ch3 old rental = Transform("images/cast/apartment-empty.webp", xysize=(1600, 900))
image bg ch3 keys = Transform("images/chapter3/ch3-rental-day-v2.webp", xysize=(1600, 900))

image bg ch3 records = Transform("images/chapter3/ch3-records-empty.webp", xysize=(1600, 900))
image bg ch3 market solo = Transform("images/chapter3/ch3-market-empty-v2.webp", xysize=(1600, 900))
image bg ch3 home night = Transform("images/chapter3/ch3-rental-night-v2.webp", xysize=(1600, 900))
image bg ch3 old night = Transform("images/chapter3/old-rental-night-v1.webp", xysize=(1600, 900))

default chapter3_entry_profile = "nika"

define landlord_phone = Character("Хозяйка · по телефону", color="#b9cbd3")

label chapter3_quick_nika:
    $ chapter3_setup_entry("nika")
    jump chapter3_start

label chapter3_quick:
    $ chapter3_setup_entry(chapter3_entry_profile)
    jump chapter3_start

label chapter3_start:
    $ chapter3_reset()
    $ quick_menu = False
    hide screen scene_marker
    scene bg hotel morning with fade
    $ set_soundscape("hotel_morning")
    call screen chapter_card("Нормально посидим", "Глава третья · тёплые выходные")
    $ quick_menu = True
    show screen scene_marker
    jump ch3_morning

label ch3_morning:
    $ city_chapter = "Нормально посидим"
    $ place_name = "Отель на Ваське · пятница, 09:26"
    $ save_name = "Глава 3 · пятничное утро"
    scene bg hotel morning with dissolve
    $ set_soundscape("hotel_morning")
    "Телефон будит Олега раньше будильника. На ресепшене хотят знать, продлевает ли он номер."
    o "Я вчера продлил до воскресенья."
    reception "Да, вижу. Просто хотели уточнить, вы остаётесь?"
    o "Нет, я вам так помогаю."
    "В трубке тихо. Олег садится на кровати."
    o "Остаюсь. Извините, я ещё не проснулся."
    "Из открытого окна неожиданно тянет тёплым воздухом. На выходные обещают почти лето. Октябрь решил никому заранее не объяснять."
    mind "Куртка сегодня не нужна. Уже одно дело отменилось само."
    $ mood_menu = True
    menu:
        "Как встречаем этот день?"
        "Открыть окно пошире. О, нормальный воздух.":
            $ set_oleg_mood("ch3_morning", "calm")
            "Олег пьёт кофе у открытого окна. Снизу кто-то объясняет собаке, что лето вернулось только на два дня."
        "Включить рок. Сегодня вроде можно всё.":
            $ set_oleg_mood("ch3_morning", "playful")
            mind "Только не надо опять назначать себе фестиваль обязательств."
        "Сначала посмотреть сообщения. Обещаний уже хватает.":
            $ set_oleg_mood("ch3_morning", "engaged")
            "Олег открывает вчерашнюю переписку. На работе он бы уже предложил убрать половину пунктов."
    $ mood_menu = False
    "В чате с друзьями уже спорят о чём-то рабочем. Саня прислал скрин бегового рекорда из Москвы. Олег открывает переписку."
    call screen phone_thread([], conversation="ch3_friends_morning", past=[("Саша", "Нет, сертификат настоящий. Вопросы возникли к учебному центру."), ("Саня", "Кабан назвал меня «наш юридический департамент». Я ОДИН. На фрилансе.")])
    $ chapter3_remember_friends([], "ch3_friends_morning")
    $ set_oleg_mood("ch3_friends_morning", chapter3_friend_mood("ch3_friends_morning", []))
    "Пока Олег читает ответы, приходит сообщение агента."
    if chapter3_previous["housing"] == "conditions":
        call screen phone_thread([], "Просмотр квартиры", conversation="ch3_house_conditions")
        $ chapter3_candidate = "old" if phone_reply_log[("ch3_house_conditions", "start")] == "old" else "new"
        if phone_reply_log[("ch3_house_conditions", "start")] == "legal":
            call screen phone_thread([], conversation="ch3_legal", past=chapter3_friend_history[-2:])
            $ chapter3_remember_friends([], "ch3_legal")
            $ set_oleg_mood("ch3_friends_legal", chapter3_friend_mood("ch3_legal", []))
            $ chapter3_candidate = "old" if phone_reply_log[("ch3_legal", "start")] == "old" else "new"
    elif chapter3_previous["housing"] == "temporary":
        call screen phone_thread([], "Просмотр квартиры", conversation="ch3_house_temporary")
        $ chapter3_candidate = "month" if phone_reply_log[("ch3_house_temporary", "start")] == "old" else "new"
    else:
        call screen phone_thread([], "Просмотр квартиры", conversation="ch3_house_new")
        $ chapter3_candidate = "skip" if phone_reply_log[("ch3_house_new", "start")] == "skip" else "new"
    jump ch3_promises

label ch3_promises:
    $ place_name = "Отель на Ваське · пятница, 10:18"
    "До просмотра ещё несколько часов. Вчерашние сообщения сами собой выполненными не стали."
    menu:
        "С чего начать?"
        "Поиграть для себя. Гитара со вчера стоит рядом." if chapter3_tasks["guitar"] == "none" and "riff" not in vignette_history:
            call vignette_solo_riff_scene(False)
            "Олег ещё раз проходит знакомый кусок и убирает медиатор под струны. Теперь можно ехать."
            $ chapter3_tasks["own_guitar"] = "played"
        "Записать обещанный рифф Нике." if chapter3_tasks["guitar"] == "pending":
            call ch3_record
        "Прочитать обещанный PDF Вари." if chapter3_tasks["pdf"] == "pending":
            call ch3_pdf
        "Найти место для пластинок." if chapter3_plans.get("nika", {}).get("kind") == "album":
            call ch3_find_place
        "Сначала квартира. Сообщения после просмотра.":
            mind "Пусть хотя бы одно дело будет с дверью и адресом."
        "Начать с планов на выходные. Просмотр потом.":
            call ch3_plan_hub("10:30")
    jump ch3_rental

label ch3_record:
    call vignette_solo_riff_scene
    "Олег ставит телефон на стол, берёт гитару и играет знакомый рифф. На последней ноте чуть промахивается."
    menu:
        "Запись есть. Сосед тоже внёс вклад."
        "Отправить первый дубль. Она же просила без десяти попыток.":
            $ chapter3_tasks["guitar"] = "sent"
            "Олег отправляет файл. Ника отвечает: «На двадцать третьей секунде кто-то смывает»."
            o "Это сосед. У него тоже партия."
        "Переписать. Я могу лучше.":
            "Второй дубль отличный. На записи полная тишина: после созвона выбран другой микрофон."
            mind "Только что же играл. А микрофон не тот выбрал."
            menu:
                "Что отправляем?"
                "Ладно, первый дубль нормальный.":
                    $ chapter3_tasks["guitar"] = "sent"
                    "Ника присылает огонь и пишет: «Вот этот поворот оставь». Олег переслушивает. Может, она права."
                "Написать, что запишу вечером.":
                    $ chapter3_tasks["guitar"] = "pending"
                    "Олег пишет, что запись будет позже. Ника отвечает: «Окей, без студийного альбома обойдёмся»."
    return

label ch3_find_place:
    "На сайте магазина обещают прослушивание пластинок по субботам. Под заголовком мелко написано про занятие до двух."
    menu:
        "Афишу можно прочитать целиком."
        "Проверить время и предложить три часа.":
            $ chapter3_tasks["place"] = "checked"
            "Олег звонит в магазин. В три проигрыватель свободен. Место есть; встретиться ещё надо договориться."
        "Переслать афишу. Разберёмся на месте.":
            $ chapter3_tasks["place"] = "misread"
            "Ника увеличивает мелкий текст и возвращает скриншот: «Там до двух детское занятие». Олег тоже увеличивает. Да."
            mind "Будем открывать музыкальную школу с низкой дисциплиной."
    return

label ch3_pdf:
    "Варя прислала зин. На развороте — арка с котом, а рядом вид вверх, между стенами двора."
    $ chapter3_chat_fresh("ch3_varya_review")
    call screen phone_thread([], caption="Варя", conversation="ch3_varya_review")
    if phone_reply_log[("ch3_varya_review", "start")] == "repeat":
        o "С этого ракурса и бельё выглядит монументально."
    $ chapter3_tasks["pdf"] = "read"
    "Олег досматривает до последней страницы. Там маленькая подпись от руки: «Печатать осторожно»."
    return

label ch3_rental:
    $ place_name = "Васильевский остров · пятница, 14:00"
    $ save_name = "Глава 3 · квартира целиком"
    $ set_soundscape("ch3_room")
    if chapter3_candidate == "skip":
        scene bg ch3 alone with dissolve
        "Олег отменил сегодняшний просмотр заранее. Никто не ждёт его у домофона. Он идёт за обедом в одной футболке."
        $ chapter3_housing = "search"
    elif chapter3_candidate in ("old", "month"):
        scene bg ch3 old rental with dissolve
        "На знакомой кухне хозяин открывает маленькую комнату. В ней ещё два чемодана. Олег свой оставил в отеле."
        owner "Их вечером заберу. Полку только оставлю."
        o "Главное, чтобы вы на полке не оставались."
        "В договоре теперь назван срок и перечислены комнаты. Саня отметил пару мест, которые хозяин согласился переписать."
        menu:
            "Комнаты увидел. Условия прочитал."
            "Взять на месяц с понятной датой выезда." if chapter3_candidate == "month":
                $ chapter3_housing = "pending_month"
                "Олег просит заранее записать дату окончания и порядок приездов. Хозяин соглашается; подпись и ключи будут на встрече."
            "Взять целиком. При передаче ещё раз проверю комнату." if chapter3_candidate == "old":
                $ chapter3_housing = "pending_whole"
                "Саня просит прислать последнюю версию договора. Ключи Олег согласует отдельным сообщением."
            "Не брать. Продолжу искать.":
                $ chapter3_housing = "search"
                $ housing_next = "central"
                "Олег благодарит хозяина и уходит. Следующий адрес он будет смотреть в другой день."
    else:
        call ch3_new_rental
    $ diary_entries.append("Глава 3: квартиру посмотрел, решение по передаче ключей принимаю отдельно.")
    call ch3_plan_hub
    jump ch3_friday_friends

label ch3_new_rental:
    call housing_ch3_view
    return

label ch3_plan_hub(clock="18:10"):
    $ place_name = "Отель на Ваське · пятница, " + clock
    $ save_name = "Глава 3 · планы выходных"
    if clock == "10:30":
        scene bg hotel morning with dissolve
    else:
        scene bg hotel dusk with dissolve
    $ set_soundscape("hotel_rest")
    "Олег садится на край кровати и открывает телефон. Сначала собирался только ответить на сообщения. Теперь листает контакты и вспоминает вчерашний вечер."
label ch3_plan_loop:
    hide screen say
    call screen chapter3_planner
    if _return == "done":
        return
    if _return == "revise":
        call screen chapter3_revise_plans
        if _return == "back":
            jump ch3_plan_loop
    $ chapter3_current = _return
    if chapter3_current == "nika":
        if chapter3_tasks["guitar"] == "pending":
            menu:
                "У Ники ещё нет обещанной записи."
                "Записать и отправить сейчас.":
                    call ch3_record
                "Сначала согласовать встречу. Запись вечером.":
                    pass
        $ chapter3_chat = chapter3_nika_planning_chat()
        $ chapter3_chat_fresh(chapter3_chat)
        call screen phone_thread([], caption="Ника", conversation=chapter3_chat)
        $ chapter3_reply = phone_reply_log[(chapter3_chat, "start")]
        if chapter3_chat in ("ch3_nika_busy", "ch3_nika_unavailable"):
            $ chapter3_plan("nika", 2, None, "jam", "busy")
        elif chapter3_reply in ("coffee", "jam", "album"):
            $ chapter3_plan("nika", 0, 900 if chapter3_reply == "album" else 840, chapter3_reply)
        else:
            $ chapter3_plan("nika", 2, None, "jam", "deferred" if chapter3_reply == "later" else "canceled")
    elif chapter3_current == "asya":
        $ chapter3_chat_fresh("ch3_asya_plan")
        call screen phone_thread([], caption="Ася", conversation="ch3_asya_plan")
        $ chapter3_reply = phone_reply_log[("ch3_asya_plan", "start")]
        $ chapter3_plan("asya", 1 if chapter3_reply == "sunday" else 0, 990 if chapter3_reply != "cancel" else None, "market" if chapter3_reply == "market" else "photos", "canceled" if chapter3_reply == "cancel" else "confirmed")
    elif chapter3_current == "lera":
        $ chapter3_chat_fresh("ch3_lera_plan")
        call screen phone_thread([], caption="Лера", conversation="ch3_lera_plan")
        $ chapter3_reply = phone_reply_log[("ch3_lera_plan", "start")]
        $ chapter3_plan("lera", 1, 990 if chapter3_reply == "later" else 900 if chapter3_reply == "lunch" else None, "lunch", "canceled" if chapter3_reply == "cancel" else "confirmed")
    elif chapter3_current == "varya":
        if chapter3_tasks["pdf"] == "pending":
            call ch3_pdf
        $ chapter3_chat_fresh("ch3_varya_plan")
        call screen phone_thread([], caption="Варя", conversation="ch3_varya_plan")
        $ chapter3_reply = phone_reply_log[("ch3_varya_plan", "start")]
        $ chapter3_tasks["print_speed"] = "fast" if chapter3_reply == "fast" else "normal"
        $ chapter3_plan("varya", 0, 660 if chapter3_reply != "cancel" else None, "walk" if chapter3_reply == "walk" else "print", "canceled" if chapter3_reply == "cancel" else "confirmed")
    elif chapter3_current == "keys":
        $ chapter3_chat_fresh("ch3_keys")
        call screen phone_thread([], "Просмотр квартиры", conversation="ch3_keys")
        $ chapter3_reply = phone_reply_log[("ch3_keys", "start")]
        $ chapter3_plan("keys", 1 if chapter3_reply == "sun" else 0, 720 if chapter3_reply == "sun" else 810 if chapter3_reply == "sat" else None, "keys", "canceled" if chapter3_reply == "cancel" else "confirmed")
    jump ch3_plan_loop

label ch3_friday_friends:
    scene bg hotel night with dissolve
    $ place_name = "Отель на Ваське · пятница, 20:18"
    "К вечеру в чате накопились сообщения. Олег садится поудобнее: теперь можно нормально поговорить, а не отвечать урывками."
    call screen phone_thread([], conversation="ch3_friends_plan", past=chapter3_friend_history[-2:])
    $ chapter3_remember_friends([], "ch3_friends_plan")
    $ set_oleg_mood("ch3_friends_friday", chapter3_friend_mood("ch3_friends_plan", []))
    if phone_reply_log[("ch3_friends_plan", "start")] == "share":
        $ chapter3_shared_plans = chapter3_live_summary()
        $ chapter3_friend_messages = chapter3_friends_choices()
        $ chapter3_chat_fresh("ch3_friends_choices")
        call screen phone_thread(chapter3_friend_messages, conversation="ch3_friends_choices", past=chapter3_friend_history[-2:])
        $ chapter3_remember_friends(chapter3_friend_messages, "ch3_friends_choices")
        $ set_oleg_mood("ch3_friends_plans", chapter3_friend_mood("ch3_friends_choices", chapter3_friend_messages))
        if chapter3_schedule_notes():
            "Олег открывает карту. Вот участок, на котором ему придётся очень захотеть обладать двумя телами."
            menu:
                mind "Я опять набрал больше, чем влезает в день."
                "Да. Напишу сейчас, пока никто не ждёт.":
                    call ch3_plan_hub("20:18")
                "Оставлю. Но дорогу теперь хотя бы видел.":
                    pass
    if chapter3_tasks["guitar"] == "pending":
        menu:
            "Запись ещё не отправлена."
            "Пять минут. Запишу сейчас.":
                call ch3_record
            "Сказать Нике, что вернусь к этому после выходных.":
                $ chapter3_tasks["guitar"] = "deferred"
                "Олег предупреждает Нику. Она пишет: «Хорошо. Я уже начала думать, что там мастеринг»."
    $ chapter3_day = 0
    $ chapter3_clock = 650
    $ chapter3_area = "vaska"
    jump ch3_weekend

label ch3_weekend:
    $ city_chapter = "Тёплые выходные"
    scene bg ch3 alone with Dissolve(.6)
    $ set_soundscape("ch3_outside")
    $ chapter3_stamp("Васильевский остров")
    if chapter3_day == 0:
        "По улице идут люди с куртками в руках. Олег свою оставил в отеле. Свет попадает прямо на облупленные карнизы — оказывается, они ещё и жёлтые."
        "У пешеходного перехода греет даже через футболку. Олег поднимает лицо к солнцу; зелёный уже мигает, но можно дождаться следующего."
        mind "А я ещё свитер хотел взять."
    else:
        "Воскресенье. У соседней пекарни очередь длиннее вчерашней. Олег берёт булку с собой и проверяет, кто ждёт его сегодня."
        if chapter3_housing not in ("new", "whole", "month"):
            "В полдень заканчивается оплаченный срок. У стойки Олег договорился оставить номер до вечера: если сегодня не въедет, на обратном пути оплатит ещё одну ночь."
        if chapter3_pending():
            mind "Субботние встречи уже позади. Сегодня — другие договорённости."
        else:
            mind "На сегодня встреч нет. Можно просто погулять, а вечером вернуться и рассказать ребятам, как прошли выходные."
    call ch3_buldak_update
label ch3_day_loop:
    hide screen say
    if chapter3_pending() and not chapter3_day_conflict():
        $ chapter3_current = chapter3_pending()[0]
        $ chapter3_next_thought = chapter3_on_the_way(chapter3_current)
        mind "[chapter3_next_thought]"
        call ch3_remember_plans(chapter3_current)
        $ _return = chapter3_current
    else:
        call screen chapter3_day_agenda
    if _return == "reschedule":
        call screen chapter3_reschedule
        if _return == "back":
            jump ch3_day_loop
    if _return == "finish":
        if chapter3_pending():
            "Олег пишет тем, с кем ещё не успел встретиться. Сегодня не приедет; новый день согласуют отдельно."
            if "keys" in chapter3_pending() and chapter3_day == 0:
                "Агент подтверждает: завтра, в двенадцать. Ключи подождут до воскресенья."
            python:
                for person in chapter3_pending():
                    chapter3_defer(person)
        jump ch3_finish_day
    if _return == "free_evening":
        $ chapter3_marta_can_visit = chapter3_marta_evening_free()
        if chapter3_marta_can_visit:
            call ch3_marta_optional_evening
        jump ch3_finish_day
    if _return.startswith("defer:"):
        $ chapter3_current = _return.split(":", 1)[1]
        $ chapter3_defer(chapter3_current)
        if chapter3_current == "keys" and chapter3_day == 0:
            "Агент подтверждает воскресенье, двенадцать. Остальные встречи Олег не переносит автоматически."
        else:
            "Олег заранее пишет про перенос. Новый день согласуют отдельно."
        jump ch3_day_loop
    $ chapter3_current = _return
    $ chapter3_late_reply = ""
    $ chapter3_eta = chapter3_travel(chapter3_area_for(chapter3_current))
    $ chapter3_clock += chapter3_eta
    $ chapter3_area = chapter3_area_for(chapter3_current)
    $ chapter3_clock = max(chapter3_clock, chapter3_plans[chapter3_current]["time"])
    if not chapter3_tasks.get("warm_road") and chapter3_current != "keys":
        "Из метро Олег выходит в тёплый воздух. На выходе все машинально замедляются; кто-то впереди уже стягивает свитер."
        "Он идёт по солнечной стороне и допивает воду у перехода. Впереди ещё встреча. Хорошо, что вышел."
        $ chapter3_tasks["warm_road"] = True
    if chapter3_current == "keys":
        call ch3_keys
    else:
        if chapter3_clock > chapter3_plans[chapter3_current]["time"] + 10:
            call ch3_late
        if chapter3_plans[chapter3_current]["status"] == "confirmed":
            call expression ("ch3_" + chapter3_current)
    call ch3_after_outing
    jump ch3_day_loop

label ch3_finish_day:
    $ chapter3_marta_checked = True
    if chapter3_day not in chapter3_evening_checked_days:
        $ chapter3_evening_checked_days.append(chapter3_day)
    if chapter3_day == 0:
        call ch3_saturday_friends
        $ chapter3_day = 1
        $ chapter3_clock = 650
        $ chapter3_area = "vaska"
        $ chapter3_marta_checked = chapter3_marta_can_visit = False
        scene expression (housing_home_background() if chapter3_housing == "new" and housing_home else "bg ch3 rental" if chapter3_housing == "new" else "bg w4 home old" if chapter3_housing in ("whole", "month") else "bg hotel morning") with fade
        $ set_soundscape("hotel_morning")
        "В воскресенье так же тепло. Олег проверяет сообщения, поливает забытый кем-то цветок на подоконнике и снова идёт без куртки."
        jump ch3_weekend
    if not chapter3_solo and not chapter4_marta_seen and not any(person in chapter3_results for person in ("nika", "asya", "lera", "varya")):
        call ch3_solo_day
    jump ch3_end

label ch3_late:
    scene bg ch3 alone with dissolve
    $ chapter3_stamp("По дороге")
    $ set_soundscape("ch3_outside")
    $ chapter3_late_chat = "ch3_" + chapter3_current + "_late" + ("" if chapter3_bag else "_plain")
    $ chapter3_chat_fresh(chapter3_late_chat)
    "Назначенное время уже прошло. Это видно и без навигатора. На телефоне сообщение."
    call screen phone_thread([], caption=chapter3_names[chapter3_current], conversation=chapter3_late_chat)
    $ chapter3_late_reply = phone_reply_log[(chapter3_late_chat, "start")]
    if chapter3_late_reply == "silence":
        $ chapter3_plans[chapter3_current]["status"] = "missed"
        $ chapter3_notes.append(chapter3_names[chapter3_current] + ": не ответил вовремя, встреча сорвалась")
        "Когда Олег наконец открывает чат, его уже не ждут. Можно написать позже, но этот час не вернуть."
    else:
        if chapter3_late_reply == "lie":
            $ chapter3_clock += 15
            "Через пятнадцать минут приходит: «Ну что?» Олег всё ещё идёт. Теперь даже шутку надо начинать с настоящего времени."
        if chapter3_current == "nika" and chapter3_plans["nika"]["kind"] == "jam" and chapter3_clock >= 900:
            menu:
                "Репетиционная комната уже занята."
                "Дождаться Нику после группы и пойти есть." if chapter3_clock < 945:
                    $ chapter3_clock = max(chapter3_clock, 915)
                    $ chapter3_plans["nika"]["kind"] = "coffee"
                    $ chapter3_tasks["nika_short_meeting"] = True
                    "Ника отвечает: «Могу ненадолго. До четырёх». Олег подтверждает и ждёт у выхода."
                "Не ждать. Договоримся на другой день.":
                    $ chapter3_plans["nika"]["status"] = "missed"
                    "Олег извиняется и пишет, что сегодня уже не успеет. Ника продолжает репетицию."
        elif chapter3_current == "varya" and chapter3_plans["varya"]["kind"] == "print" and chapter3_clock >= 840:
            $ chapter3_plans["varya"]["status"] = "missed"
            "Типография уже закрылась. Варя унесла готовые экземпляры сама. Она пишет: «В следующий раз говори, если не можешь»."
        elif chapter3_current == "asya" and chapter3_clock >= 1110:
            $ chapter3_plans["asya"]["status"] = "missed"
            "Ася уже ушла. Сегодня у неё ещё свои планы; она не возвращается к входу из-за нового сообщения."
        if chapter3_current == "lera" and chapter3_clock >= 1080:
            $ chapter3_plans["lera"]["status"] = "missed"
            "Лера уже поела и ушла по своим делам. Она предлагает вернуться к разговору в другой день."
        menu:
            "Как объясниться?"
            "Коротко назвать настоящее время. Без романа.":
                "Олег отправляет время с карты. Ответ короткий, зато больше нечего исправлять."
            "Записать длинное голосовое.":
                $ chapter3_voice_text = "Я не забыл. Я не рассчитал день. " + ("С ключами пришлось сверить счётчики. " if "keys" in chapter3_results else "") + ("Варя ждала печать. " if "varya" in chapter3_results and chapter3_bag else "") + "В общем, обещал больше, чем успеваю. Прости."
                menu:
                    "В открытом чате сверху написано «Мои шлюхи»."
                    "Проверить адресата и отправить ей.":
                        "Олег открывает нужную переписку и отправляет голосовое. Без Сани в качестве неожиданного слушателя."
                    "Отправить сразу.":
                        $ chapter3_voice_wrong = True
                        call screen phone_thread([("Олег", chapter3_voice_text), ("Саша", "Но раз едешь, захвати зарядку.")], conversation="ch3_voice_friends", past=chapter3_friend_history[-2:])
                        $ chapter3_remember_friends([("Олег", chapter3_voice_text), ("Саша", "Но раз едешь, захвати зарядку.")], "ch3_voice_friends")
                        $ set_oleg_mood("ch3_friends_voice", chapter3_friend_mood("ch3_voice_friends", [("Олег", chapter3_voice_text), ("Саша", "Но раз едешь, захвати зарядку.")]))
                        "Олег отправляет исправленное объяснение в нужную переписку. Друзья никому его не пересылают."
    return

label ch3_keys:
    $ chapter3_stamp("Квартира на Ваське")
    if chapter3_day == 0 and chapter3_clock >= 840:
        scene bg ch3 alone with dissolve
        "Собственник уже уехал. Агент спрашивает, переносим ли передачу на завтра."
        menu:
            "Ключи не выдадут через закрытую дверь."
            "Да. В воскресенье в двенадцать.":
                $ chapter3_defer("keys")
                "Агент подтверждает воскресенье. Олег ставит напоминание."
            "Пока откажусь от передачи. Продолжу искать.":
                $ chapter3_plans["keys"]["status"] = "canceled"
                $ chapter3_housing = "search"
        return
    if chapter3_housing in ("pending_month", "pending_whole"):
        scene bg ch3 old rental
    else:
        scene expression (housing_background(housing_pending) if housing_pending else "bg ch3 keys")
    $ set_soundscape("ch3_room")
    "В квартире сверяют показания счётчиков. Олег ещё раз читает договор и проверяет, что комнаты свободны."
    o "А второй выключатель?"
    if chapter3_housing == "pending_new" and housing_pending == "studio":
        landlord_phone "Свет на кухне. Машинку в общей прихожей тоже покажу."
    elif chapter3_housing == "pending_new":
        landlord_phone "Мы договорились уважать историю."
    else:
        owner "Свет в коридоре. Но лампу надо вкрутить."
    menu:
        "Теперь можно подписать и взять ключи."
        "Всё совпадает. Подписать и забрать.":
            $ housing_home = housing_pending if chapter3_housing == "pending_new" else ""
            $ chapter3_housing = {"pending_new": "new", "pending_whole": "whole", "pending_month": "month"}.get(chapter3_housing, "new")
            $ chapter3_done("keys", "ключи получены", 35)
            "Связка оказывается неожиданно лёгкой. Олег кладёт её в другой карман: гостиничную карту пока тоже нельзя потерять."
        "На месте передумал. Ключи не беру.":
            $ chapter3_housing = "search"
            $ chapter3_done("keys", "после проверки отказался", 25)
            $ housing_cancel_pending("declined_at_keys")
            "Олег объясняет, что договор не подпишет. Сегодня он всё ещё ночует в отеле."
    return

label ch3_varya:
    $ chapter3_stamp("Первая линия Васьки")
    $ set_soundscape("ch3_print")
    if chapter3_plans["varya"]["kind"] == "walk":
        scene bg ch3 street varya with dissolve
        "У арки Варя машет Олегу. Вместо бордовой куртки — выцветшая сиреневая футболка, значки и сетчатые манжеты. Берцы пережили перемирие с погодой."
        v "Вот этот двор. Снаружи выглядит заброшенным. Внутри должны быть руины."
        "Из подъезда выходит человек с контейнером обеда и пропуском. За ним ещё один."
        o "Руины с бизнес-ланчем."
        v "Блять. Там офис."
        $ chapter3_varya_photo_taken = False
        menu:
            "Сюжет не тот, который ожидали."
            "Снять офис как руины рабочего дня.":
                o "После шести здесь всё равно будет археология."
                v "И «Офис» крупно. Пусть сами себе заголовок напишут."
                call vignette_photo_scene
                $ chapter3_varya_photo_taken = True
                $ chapter3_done("varya", "собрали из Олеговых кадров разворот про офис" if vignette_effect("photo") == "office_spread" else "Варя пересняла кадры для зина" if vignette_effect("photo") == "reshoot" else "нашли кадры для следующего зина", 90)
            "Пойти искать другую арку. Здесь люди работают.":
                "В соседнем дворе сидит кот. Варя снимает его так долго, что Олег успевает найти лавку с водой."
                v "Главного по двору всё равно никто не заменит. Этот заместитель."
                $ chapter3_done("varya", "сняли другого кота и новый двор", 105)
        if chapter3_varya_photo_taken and vignette_effect("photo") == "office_spread":
            v "Вечером скину уже рядом. По одному они не так работают."
            o "Только стул не выкидывай."
            v "Стул остаётся. Он тут единственный без работы."
        elif chapter3_varya_photo_taken and vignette_effect("photo") == "reshoot":
            "Варя прячет камеру. Олег возвращает пакет на прежнее место у стула."
            v "Мои вечером скину. Твои пока в отдельную папку."
            o "Папку можешь не присылать."
            v "Ладно."
        else:
            v "Скину вечером. Ты только не начинай править горизонт во всём Питере."
            o "Ладно. Но один горизонт там правда надо поправить."
            v "Один можно. Потом покажешь какой."
        call ch3_varya_after
        return
    scene bg ch3 print with Dissolve(.6)
    "Типография за стеклянной дверью на первой линии. Варя уже у заднего стола: сравнивает пробник с экраном. Олег ставит рюкзак у стены и подходит."
    v "Я попросила темнее чёрный. Теперь кот почти исчез."
    o "Он был главным по двору. Теперь работает из дома."
    v "Олег."
    o "Да. Надо переделать."
    v "И на все цветные обложки денег не хватило. Часть по-другому надо делать."
    menu:
        "Как поможем с тиражом?"
        "Остаться, переделать чёрный и дождаться печати.":
            "Варя кладёт перед ним два пробника. На одном кот сливается с аркой, на другом двор будто вымыли отбеливателем."
            v "Только не говори «где-то посередине». Я уже так сказала."
            o "У этого усы есть. У того стена лучше."
            "Она отмечает карандашом участок у морды и показывает оператору. Они меняют не всю страницу, а одну тень."
            $ chapter3_clock += 35
            "Пока сохнет новый пробник, Олег раскладывает обложки. Последние шесть другого оттенка."
            o "Эти тоже в тираж?"
            v "Да. Отдельной пачкой. Напишу, что альтернативные, и буду брать столько же."
            o "Издательский дебют?"
            v "У меня ещё утром был бюджет."
            "Варя показывает, где сгибать лист. Первый Олег загибает не туда; на втором уже получается совместить углы."
            $ chapter3_clock += 65
            $ chapter3_stamp("Типография")
            "К [chapter3_time(chapter3_clock)] кот снова различим. Оператор запускает оставшиеся страницы."
            v "Ещё минут двадцать. Наверное."
            menu:
                "Есть время уйти с частью готового."
                "Дождусь. Раз уж обещал помочь.":
                    "Они собирают первый экземпляр и находят две одинаковые страницы. Варя останавливает Олега на середине следующего."
                    v "Теперь ты листаешь, я считаю. Давай медленнее, я уже сама путаюсь."
                    "За следующую стопку они берутся уже с образцом перед глазами. Ещё через полчаса Варя закрывает пакет и прижимает его к себе."
                    $ chapter3_bag = True
                    $ chapter3_done("varya", "дождались целого тиража", 40)
                "Заберу готовые экземпляры. Остальное ты сможешь сама?":
                    v "Ты уже уходишь? Мы только кота обратно вернули."
                    o "Мне надо дальше. Готовое донесу."
                    v "Ладно. Но не вынимай их из пакета на ходу. Я ещё хотела тебе страницы показать."
                    $ chapter3_bag = True
                    $ chapter3_done("varya", "унёс готовую часть тиража", 5)
                "Давай отложим остаток на другой день.":
                    v "Олег, я не просто так сегодня забираю. Я людям уже написала, что принесу."
                    "Она смотрит на очередь готовых листов и убирает телефон в карман."
                    v "Ладно. Сама договорюсь. Только не надо говорить, что почти всё сделали."
                    $ chapter3_done("varya", "проверили пробник, печать перенесли", 5)
        "Забрать несколько готовых экземпляров и уехать раньше.":
            if chapter3_plans["varya"].get("kind") == "print" and phone_reply_log.get(("ch3_varya_plan", "start")) == "fast":
                v "Да, ты предупреждал. Я просто надеялась, что успеем быстрее и ты ещё останешься."
            else:
                v "А я думала, мы вместе закончим. У тебя прям настолько всё по минутам?"
                o "Я ещё обещал приехать."
                v "Мне тоже. Ладно, эти готовы. Бери."
            "Олег уносит несколько готовых зинов. Основной тираж остаётся с Варей."
            $ chapter3_bag = True
            $ chapter3_done("varya", "помог с готовыми экземплярами и уехал вовремя", 75)
        "Сделать обложку чёрно-белой. Цвет не обязателен.":
            v "Можно. Но рисунок сама выберу."
            o "Договорились. Я могу только бумагу держать."
            "В чёрно-белом варианте кот снова отлично виден. Они собирают небольшой тираж."
            $ chapter3_bag = True
            $ chapter3_done("varya", "собрали чёрно-белый тираж", 100)
        "Оплачу несколько цветных. Как спонсор обложку выбирать не буду.":
            v "Несколько можно. И вот эту оставляем. Не надо заказывать мне счастливого кота."
            o "Оставляем. Ты его выбираешь."
            $ chapter3_bag = True
            $ chapter3_done("varya", "помог оплатить несколько обложек", 90)
    v "Спасибо. На первой странице тебя подпишу. Но мелко, ты не здание."
    call ch3_varya_after
    return

label ch3_nika:
    $ chapter3_stamp("Встреча с Никой")
    if chapter3_plans["nika"]["kind"] == "jam":
        scene bg ch3 rehearsal with Dissolve(.6)
        $ set_soundscape("ch3_music")
        "Репетиционная комната на втором этаже у Лиговского. За окном солнце, в углу усилители; инструменты пока стоят на стойках. Ника ждёт у двери."
        "Сегодня она в светлой футболке с маленькой звуковой волной и бордовым ремнём. Кожанка осталась дома."
        n "Я до сих пор не поняла, где тут выключается кондиционер. Если замёрзнешь, скажи."
        o "Мне пока нормально. Хочешь, посмотрю?"
        n "Потом. Поиграем сначала."
        "Ника проверяет строй без тюнера, потом всё-таки включает его и поправляет одну струну."
        menu:
            "Ты с детства музыкой занимаешься?":
                o "Ты с детства музыкой занимаешься?"
                n "Да. У меня родители музыканты, дома всё время что-нибудь играли. Я и не помню, когда сама начала."
                n "Потом в школьной группе всё это пригодилось: мы знали по три песни, зато могли весь вечер их гонять."
                n "Я ещё дома что-нибудь разбирала, приносила — давайте вот это попробуем. Никому особо объяснять не надо было, все хотели играть."
                $ chapter3_tasks["nika_bio_talk"] = "family"
            "А почему именно бас?":
                o "А почему именно бас?"
                n "Мне нравится, как он под гитару ложится. Гитарист всё то же играет, а ты одну ноту поменяла — и песня уже другая."
                o "То есть всё решает басист?"
                n "Наконец-то кто-то понял."
                $ chapter3_tasks["nika_bio_talk"] = "bass"
            "У меня в универе группа была. Соскучился по всему этому.":
                o "У меня в универе группа была. Соскучился по всему этому."
                n "А чего перестали?"
                o "Работать начал. Сначала ещё с ноутбуком на репетиции приезжал, в перерыве отвечал. Потом стал пропускать."
                o "Я тогда думал: сейчас чуть разгребусь и вернусь нормально."
                o "А дома до сих пор могу за один переход зацепиться и весь вечер его играть. Особенно если завтра рано вставать."
                n "Показываешь кому-нибудь?"
                o "Редко. Но сам могу потом в метро десять раз переслушать. Если получилось, мне не надоедает. Особенно когда уже не помню, как вообще до этого додумался."
                n "Ну, сегодня выбрался. Подключайся."
                $ chapter3_tasks["nika_bio_talk"] = "oleg_band"
            "Я отвык с кем-то играть. Если начну уплывать, тормози.":
                o "Я отвык с кем-то играть. Если начну уплывать, тормози."
                n "Тогда давай с простого. Поймаем друг друга, потом разгонимся."
                $ chapter3_tasks["nika_bio_talk"] = "rusty"
            "Давай уже играть. Разговоры потом.":
                o "Давай уже играть. Разговоры потом."
                n "Давай. Подключайся, выставим громкость."
                $ chapter3_tasks["nika_bio_talk"] = "play"
        if chapter3_tasks["guitar"] == "sent":
            n "Ты рифф в отеле писал?"
            o "Да. Теперь я знаю партию соседа."
            n "Я слышала. Но рифф всё равно сохранила."
        if chapter3_clock > 840:
            n "У нас осталось меньше часа. Один рифф успеем. Только без настройки каждой ноты отдельно."
        else:
            n "Час наш. С чего начнём?"
        menu:
            "Музыка вместо вступительной речи."
            "Разобрать один рифф. Без выступления.":
                $ chapter3_nika_result = "сыграли один рифф вместе"
                scene bg ch3 playing with Dissolve(.3)
                "Они оба ждут вступления другого. Потом одновременно начинают и одновременно останавливаются."
                n "Хорошая группа. Демократичная."
                o "Нужен диктатор на четыре счёта."
                "Олег отбивает четыре раза по деке. Ника вступает со второго, он смеётся и сбивается. На следующем круге она уже не уступает ему темп."
                call vignette_riff_scene
                if vignette_effect("riff") == "duet_take":
                    $ chapter3_nika_result = "разобрали рифф и записали удачный общий дубль"
                    "Перед уходом они слушают запись с маленького динамика. Бас почти пропал; Ника просит потом переслушать в наушниках."
                elif vignette_effect("riff") == "bass_guide":
                    $ chapter3_nika_result = "разбирали рифф медленно; Ника записала бас для домашних проб"
                    "Олег ещё раз проходит трудный переход без усилителя. Ника уже сматывает провод; он сам дожидается нужной паузы."
                else:
                    n "Последнюю ноту не глуши. Я под неё уйду вниз."
                    "Он пробует. На этот раз они не останавливаются после риффа; Ника меняет одну ноту, и приходится искать, куда идти дальше."
            "Записать короткий кусок вдвоём.":
                $ chapter3_nika_result = "записали музыку вдвоём"
                scene bg ch3 playing with Dissolve(.3)
                "Ника считает вслух. С первой попытки темп уплывает; со второй получается короткий кусок, который обоим хочется переслушать."
                n "Вот этот сохраняй. Тут ты перестал торопиться."
                $ chapter3_tasks["nika_jam_recorded"] = True
                "Олег включает запись. В начале громко щёлкает выключатель усилителя. Ника тянется перемотать, он останавливает её."
                o "Не, оставь. Вступление уже есть."
                n "А в конце кондиционер. Концептуальный альбом."
                "Вторую партию они ищут прямо поверх записи. Ника снимает бас с плеча, снова надевает: придумала, пока слушала."
            "Позвать людей из соседней комнаты.":
                $ chapter3_nika_result = "получилась маленькая репетиция с компанией"
                scene bg ch3 playing with Dissolve(.3)
                "За дверью охотно соглашаются. Появляется барабанщик, которому всё равно, что они собирались играть. У него уже есть вступление."
                n "Мы вроде хотели тихо."
                o "Демократия опять подвела."
                "Барабанщик убирает палочки и садится с щётками. После первого круга Ника кивает Олегу: ещё. Он подхватывает, уже не глядя на гриф."
                "До следующей группы успевают сыграть только этот кусок. Барабанщик возвращается к своим с недопитым чаем, который так и не поставил на пол."
        scene bg ch3 rehearsal with dissolve
        "Инструменты возвращаются на стойки. В коридоре уже ждёт следующая группа."
        if chapter3_tasks.get("nika_jam_recorded"):
            "Олег проверяет, сохранилась ли запись, и отправляет Нике копию."
        $ chapter3_clock += min(60, max(5, 900 - chapter3_clock))
    elif chapter3_plans["nika"]["kind"] in ("album", "shop"):
        scene bg ch3 records with Dissolve(.6)
        $ set_soundscape("ch3_music")
        "В лавке пластинок на Ваське можно выбрать альбом и послушать его у стойки. Они встречаются у входа; Ника в светлой футболке, без куртки."
        if chapter3_tasks["place"] == "misread":
            n "Детское занятие уже закончилось. Вовремя увеличили шрифт."
            o "Я принёс музыкальную зрелость с задержкой."
        n "Два трека твои, два мои. Этот не переключай."
        "Ника показывает конверт: Joy Division, «Unknown Pleasures». На обороте ногтем находит «Disorder»."
        n "Мне вот это начало хочется ещё раз. Слушай, как бас отдельно от гитары идёт."
        o "Я его обычно пропускаю."
        menu:
            "У гитары резкий сухой звук. Олег всё время ждёт, что он станет плотнее. Ника уже отбивает пальцами ритм на колене."
            "Попросить показать, что она в нём слышит.":
                n "Вот. Под гитарой. Он здесь вообще другой ритм держит."
                o "А, я за гитарой всё время следил. Она как будто поперёк."
                n "Угу. Мне это и нравится. А ты ждал, когда все вместе ударят?"
                o "До сих пор жду."
                "Олег начинает слышать то, что раньше пропускал. Любимым трек от этого не становится, зато слушать интересно."
                $ chapter3_nika_result = "нашли в знакомом альбоме новый разговор"
            "Поспорить. А потом поставить свой.":
                o "Мне кажется, они тут просто не смогли закончить песню."
                n "Мне не кажется. Но ладно, ставь свой. Потом ещё к этому вернусь."
                "Олег выбирает «Boys Don't Cry». На первых аккордах Ника узнаёт песню и перестаёт искать следующий конверт."
                n "Ну вот. Ты сразу к людям, которые умеют заканчивать песни."
                o "И начинать. Я требовательный."
                $ chapter3_nika_result = "поспорили об альбоме и оба остались при своём"
            "Дослушать. На моей очереди всё равно включу другое.":
                "Олег даёт треку закончиться. Потом ставит свой. Ника слушает без вежливого согласия."
                n "Припев мне нравится. Остальное пока не поняла."
                $ chapter3_nika_result = "поменялись любимыми треками"
        "На второй круг они меняются местами у проигрывателя. Ника сама ставит иглу на нужную дорожку; Олег наконец перестаёт мешать ей локтем."
        n "Давай твой второй. Но потом с начала этот альбом. Я тебе его не всю жизнь продавать собираюсь."
        o "А скидка будет?"
        n "За молчание первые сорок секунд."
        $ chapter3_clock += 65
    else:
        scene bg ch3 street nika with dissolve
        $ set_soundscape("ch3_outside")
        "Ника ждёт у выхода из метро. Они берут кофе и идут вдоль солнечной стороны улицы. На ней светлая футболка со звуковой волной."
        if chapter3_late_reply:
            n "В следующий раз не назначай себе марафон. Я тоже люблю планы, но в них надо успевать приезжать."
            o "Согласен. Сейчас я хотя бы весь здесь."
        else:
            n "В этот раз мы дошли до кофе. Уже хорошо."
        $ chapter3_nika_result = "погуляли с кофе"
        $ chapter3_clock += min(45, max(5, 960 - chapter3_clock)) if chapter3_tasks.get("nika_short_meeting") else 45
    scene bg ch3 street nika with dissolve
    $ set_soundscape("ch3_outside")
    $ chapter3_stamp("На улице с Никой")
    "У маленькой шавермы очередь в тени; на солнечной стороне все держат окна открытыми. Можно ещё пройтись вместе."
    n "Ты опять в «Берсерке». Он у тебя вообще до стиралки доходит?"
    o "У меня пять одинаковых футболок. Эта чистая."
    n "Серьёзно пять? Я думала, ты просто в одной ходишь."
    o "Зато пока две стираются, я не стою голый у машинки."
    n "Ага, поняла."
    $ chapter3_tasks["nika_shirts_talk"] = True
    if chapter3_previous["origin"] == "friendship":
        n "Завтра у меня свидание. С басистом. Помоги выбрать сообщение."
        menu:
            "Советы от гитариста."
            "Напиши просто, что ждёшь встречи.":
                o "Я бы так и написал. Не надо угадывать его тон по точкам."
                n "Наверное. Я ему так и напишу."
            "Предложи ему настроить бас. Если пришёл — заинтересован.":
                n "Ты понимаешь, что это работает как доставка техника?"
                o "Зато проверяемая гипотеза."
            "Скажи, что он тебе нравится. Ему будет приятно узнать.":
                n "Да, наверное. Я почему-то уже три сообщения придумала, только не это."
        $ chapter3_nika_result += "; дружеская прогулка и советы про её свидание"
        "У остановки Ника проверяет номер автобуса. Уже из дверей показывает ему большой палец: сообщение отправлено. Олег машет вслед и достаёт свой телефон."
    else:
        if chapter3_tasks.get("nika_short_meeting"):
            n "Мне к четырём дальше ехать. Давай на сегодня закругляться."
        else:
            n "Я вечером ещё свободна. Можно не разбегаться сразу."
        call ch3_remember_plans("nika")
        menu:
            "Чего хочется Олегу?"
            "Остаться с ней. Сегодня хочу быть здесь." if not chapter3_tasks.get("nika_short_meeting"):
                $ chapter3_tasks["nika_moved_plans"] = any(p != "nika" for p in chapter3_pending())
                if chapter3_tasks["nika_moved_plans"]:
                    "Олег пишет тем, кого ещё не успел увидеть сегодня. Новое время согласуют отдельно."
                python:
                    for person in chapter3_pending():
                        if person != "nika":
                            chapter3_defer(person)
                $ chapter3_departure("nika", "warm", "stay")
                $ chapter3_nika_result += "; остались вдвоём"
                $ chapter3_clock += 40
                n "Вот теперь нормально посидим."
                call ch3_close_nika
                call ch3_nika_evening
            "Приятно, но сегодня ещё дела. Позвать её отдельно на следующей неделе.":
                o "Хочу продолжить. Только отдельным вечером, без курьера с зинами внутри меня."
                if chapter3_tasks.get("nika_short_meeting"):
                    n "Да, мне самой пора. Тогда напиши конкретный день."
                else:
                    "Ника уже открыла карту. Гасит экран, не выбрав место."
                    n "А. Я думала, сейчас поедим."
                    o "Я хочу. Но сегодня уже не получится."
                    n "Ладно. Тогда я ещё к ребятам заеду. Ты на неделе напиши."
                    $ chapter3_departure("nika", "disappointed", "later")
                $ chapter3_nika_result += "; предложили отдельный вечер"
            "На сегодня хватит. Не обещать следующую встречу сейчас.":
                if chapter3_tasks.get("nika_short_meeting"):
                    n "Да, пора. Спасибо за кофе."
                else:
                    n "Уже? Я думала, мы ещё поедим. Или что-то не так?"
                    o "Нет. Я просто на сегодня закончил. Не хочу обещать ещё один вечер из вежливости."
                    n "Ладно. Только я тебя не просила обещать ещё один вечер. Я про этот."
                    "У метро она раньше него достаёт наушники."
                    $ chapter3_departure("nika", "hurt", "leave")
                $ chapter3_nika_result += "; попрощались после разговора о продолжении"
    $ chapter3_done("nika", chapter3_nika_result, 10)
    return

label ch3_asya:
    $ chapter3_stamp("Выставка фотографий на Ваське" if chapter3_plans["asya"]["kind"] == "photos" else "Барахолка на Ваське")
    $ set_soundscape("ch3_gallery")
    if chapter3_plans["asya"]["kind"] == "photos":
        scene bg ch3 photos with Dissolve(.6)
        "В небольшом зале выставлены фотографии дворов. Олег заходит со стороны гардероба. Ася в горчичной льняной рубашке, золотая бабочка переехала вместе с ней."
        "У входа Ася встречает знакомых. Разговор обещал занять пять минут и уже просит ещё пять."
        menu:
            "Чем заняться, пока они разговаривают?"
            "Пойти смотреть самому. Потом обсудим.":
                "Олег идёт к дальней стене. На одной фотографии тот самый двор, в котором он ждал агента. Голубя нет — серьёзное упущение."
                a "Нашёл что-нибудь? Извини, давно не виделись."
                o "Да. У меня тут персональная история аренды."
            "Подождать. Разглядывать снимки отсюда тоже можно.":
                "Он прислоняется к стене. Ася заканчивает разговор и подходит."
                a "Спасибо. Больше никому сегодня не буду говорить «на минутку»."
            "Предложить вернуться в другой день.":
                o "Может, ты здесь останешься, а мы отдельно сходим потом?"
                a "Подожди, ты уже уходить хочешь? Я на пять минут отвлеклась."
                o "Не хотел вам мешать."
                a "Ты мне не мешаешь. Я с тобой сюда пришла. Это точно из-за разговора?"
                menu:
                    "Она вправе остаться."
                    "Я ещё посмотрю. Просто не хотел перебивать.":
                        a "Тогда пойдём. Я правда не собиралась оставить тебя у гардероба."
                        "Она берёт программу выставки, но на следующем снимке ещё раз смотрит, идёт ли он рядом."
                    "Тогда в другой день. Сегодня пойду.":
                        a "Мне кажется, это вежливый способ сказать, что тебе не очень хочется."
                        o "Я сейчас правда хочу уйти."
                        a "Хорошо. Не буду вытаскивать из тебя правильный ответ. Только другой день пока не обещай."
                        $ chapter3_departure("asya", "hurt", "entrance")
                        $ chapter3_done("asya", "разошлись после разговора у входа; новую встречу не согласовали", 20)
                        return
        a "Какой кадр понравился?"
        o "Этот. Тут человек, который снимал, явно устал от арки."
        a "Автор неприятный. Но фотография хорошая. Я пытаюсь разделять."
        o "То есть нельзя просто поставить единицу за поведение?"
        a "Можно. Потом приходится объяснять оценку самой себе."
        $ chapter3_clock += 55
        a "Во дворе ещё барахолка работает. Заглянем или здесь останемся?"
        call ch3_remember_plans("asya")
        menu:
            "Останемся здесь? Я ещё половину не посмотрел.":
                o "Останемся здесь? Я ещё половину не посмотрел."
                a "Давай. Там в конце зала серия, ради которой я тебя и звала."
                "На первом снимке между домами зажат узкий кусок неба. Олег отходит к противоположной стене, потом возвращается."
                o "Мне вот этот нравится. Только я не понимаю, зачем он рядом с остальными."
                a "Потому что двор тот же. Просто отсюда не видно, какой он тесный."
                o "А мне как раз нравится, что здесь можно выдохнуть. Я бы его отдельно повесил."
                "Ася ещё раз смотрит на весь ряд. Начинает отвечать, но Олег уже показывает следующий снимок."
                a "Погоди, я ещё на этот смотрю."
                $ chapter3_tasks["asya_outing"] = "photos"
                $ chapter3_asya_result = "остались на выставке и обсуждали серию фотографий"
                jump ch3_asya_after_market
            "Пойдём на барахолку. Хочу посмотреть лампы.":
                o "Пойдём на барахолку. Хочу посмотреть лампы."
                a "Тогда через двор. К выставке ещё можем вернуться."
    $ chapter3_tasks["asya_outing"] = "photos_market" if chapter3_plans["asya"]["kind"] == "photos" else "market"
    scene bg ch3 market with dissolve
    $ chapter3_area = "vaska"
    $ chapter3_stamp("Барахолка на Ваське")
    "В соседнем дворе устроили маленькую крытую барахолку. Ася в горчичной рубашке идёт к ряду ламп и старых открыток."
    "У стола с лампами Ася останавливается перед керамическим котом. Он выглядит так, будто ему сообщили цену собственной доставки."
    if chapter3_plans["asya"]["kind"] == "market":
        "Ася ещё с улицы увидела лампы и свернула сюда первой. До рядов с открытками они пока не добрались."
    a "Я решаю, куда поставить."
    o "А я думал, ты его осуждаешь."
    a "Одно другому не мешает."
    o "Я почему-то думал, тебе можно покупать только хорошие вещи."
    a "Очень тяжёлая жизнь была бы."
    menu:
        "По одной вещи друг другу. Небольшой бюджет."
        "Выбрать красивую мелочь.":
            "Олег приносит стеклянную подвеску. Ася рассматривает её на свету."
            a "Красивая. Только я такие всё время разбиваю. Повешу выше своего роста."
            $ chapter3_asya_result = "выбрали стеклянную подвеску"
        "Выбрать вещь с историей. Хотя бы своей.":
            "Он находит открытку с видом на старую кухню. Ася перестаёт изучать цену, когда он подносит её ближе."
            o "У нас в Воронеже на кухне такой же стол стоял. Я под ним маленьким прятался."
            a "Давно оттуда уехал?"
            o "После школы, в Москву поступать. В общаге потом на кухне вечно кто-нибудь готовил. Ночью придёшь — и всё равно занято."
            $ chapter3_asya_result = "нашли открытку и рассказали о своих прежних домах"
        "Принести совершенно дурацкую находку.":
            "Олег вручает ей крошечную фарфоровую рыбу с выражением руководителя."
            a "Коту начальника купил? Хорошо. Он слишком расслабился."
            $ chapter3_asya_result = "купили коту фарфорового начальника"
        "Вернуться к фотографиям и продолжить спор." if chapter3_plans["asya"]["kind"] == "photos":
            scene bg ch3 photos with dissolve
            "Они возвращаются к снимку, о котором не договорили. Ася сначала отвечает как куратор, потом просто говорит, что ей не нравится этот двор."
            a "Здесь меня один раз бросили. Очень красивое место для нелепого разговора."
            o "А. Извини. Я не знал."
            a "Ты откуда бы знал. Я поэтому сначала и про композицию заговорила."
            $ chapter3_asya_result = "вернулись к фотографии и договорили спор"
    if chapter3_asya_result != "вернулись к фотографии и договорили спор":
        call ch3_asya_gift
label ch3_asya_after_market:
    if chapter3_bag:
        "Олег ставит пакет с зинами на пол у стены. Ася замечает верхний экземпляр."
        a "Ты переехал или издательство открыл?"
        menu:
            "Пакет уже вызвал вопросы."
            "Нет, просто Варе донести обещал.":
                o "Это её работа. Кота я только одобрил."
                a "Серьёзная роль. Можно посмотреть?"
            "Хочешь экземпляр? Может, галерея будет продавать.":
                a "Посмотреть хочу. Только про продажу пусть Варя сама решает."
                menu:
                    "Она достаёт верхний экземпляр и придерживает пакет ногой."
                    "Спрошу её. Если захочет, дам твой контакт.":
                        o "Я сначала у Вари спрошу. Если ей интересно, вы сами договоритесь."
                        a "Да. Пусть пришлёт PDF. Я посмотрю и ей отвечу про тираж и цену."
                        $ chapter3_tasks["gallery_zine"] = "connect"
                    "Я могу всё за неё устроить.":
                        o "Я могу сам всё организовать."
                        a "А она тебя просила?"
                        o "Нет. Ладно, сначала спрошу."
                        $ chapter3_tasks["gallery_zine"] = "promise"
                "Ася возвращает зин в пакет. Варе Олег напишет отдельно: экземпляры пока надо донести до неё."
            "Не предлагай. Я сегодня на всё соглашаюсь.":
                a "Тогда кота пока не усыновляй."
    call ch3_remember_plans("asya")
    menu:
        "Как закончить встречу?"
        "Сказать прямо: я позвал тебя на свидание.":
            if chapter3_previous.get("route") == "asya" or chapter3_previous.get("early_evening", {}).get("person") == "asya":
                if chapter3_tasks.get("asya_outing") == "photos":
                    a "Я надеялась. А ты всё про фотографии."
                    o "Про них проще было начать. Но я и правда хотел посмотреть."
                else:
                    a "Я надеялась. Но хотела посмотреть, сколько мы ещё будем обсуждать кота."
                    o "Да, я тоже почему-то за него прятался."
                $ chapter3_asya_result += "; назвали встречу свиданием"
                if chapter3_tasks.get("asya_outing") != "photos":
                    call ch3_close_asya
            else:
                a "А я думала, мы фотографии идём смотреть."
                "Она поправляет сумку. Олег убирает руки в карманы."
                o "Ну. Теперь сказал."
                a "Давай ещё просто погуляем как-нибудь? Я пока тебя почти не знаю."
                o "Давай."
                "У выхода она останавливается сама: на столе лежит ещё одна пачка снимков. Зовёт Олега посмотреть."
                $ chapter3_tasks["asya_pace"] = "getting_to_know"
                $ chapter3_asya_result += "; Олег обозначил интерес, Ася предложила ещё погулять"
        "Мне нравится с тобой спорить. Давай ещё.":
            a "Давай. Только в следующий раз тему предложи ты."
            $ chapter3_asya_result += "; договорились продолжить разговор"
        "Взять чай и ещё побыть с Асей.":
            if chapter3_tasks.get("asya_outing") == "photos":
                a "Да. Я уже смотрела, где тут можно сесть. Пойдём."
            else:
                a "Да. Я хотела спросить, но всё отвлекалась. Пойдём. Ни одной лампы по дороге больше не покупаем."
            call ch3_asya_tea
        "На сегодня хватит. Спасибо за прогулку.":
            if chapter3_plans["asya"]["kind"] == "market":
                a "Пока. Я тут ещё в коробке с открытками покопаюсь."
                "Ася уже повернулась к прилавку, но окликает его."
                a "Погоди. Покупку-то забери. Я чуть с ней не ушла."
                o "Спасибо. Хорошо погуляли."
                a "Да. Напиши потом, доехало ли всё целым."
                $ chapter3_departure("asya", "warm", "leave")
                $ chapter3_asya_result += "; разошлись у прилавка, Ася осталась выбирать открытки"
            else:
                a "Я ещё чай хотела взять. Просто посидеть вдвоём."
                o "Я на сегодня всё. Спасибо, мне было хорошо."
                a "Мне тоже. Поэтому немного странно слышать это уже на выходе."
                "Она поправляет ручку сумки. К метро они идут по разным сторонам двора."
                $ chapter3_departure("asya", "disappointed", "leave")
                $ chapter3_asya_result += "; закончили встречу, хотя Ася хотела ещё посидеть"
    $ chapter3_done("asya", chapter3_asya_result, 30 if chapter3_tasks.get("asya_outing") == "photos" else 60 if chapter3_plans["asya"]["kind"] == "photos" else 115)
    return

label ch3_lera:
    $ chapter3_stamp("Столовая у Садовой")
    $ set_soundscape("ch3_cafe")
    scene bg ch3 lunch with Dissolve(.6)
    "Олег приходит в небольшую столовую у Садовой. Лера уже заняла стол у окна. Зелёная футболка, светлые карго, ни одного провода."
    l "Да, всё дома."
    o "Я ничего не сказал."
    l "Ты на руки посмотрел."
    o "Я в Москве студентом в такой столовой ел. Только у нас очередь до лестницы была."
    l "А я в училище к обеду только просыпалась. Ночью друзья в клуб тащили, потом уже сама вечеринки устраивала. Так училище и бросила."
    "Они едят. У Леры звонит телефон: на маленьком дневном мероприятии отвалился звук."
    l "Я им переходник оставляла. То есть он там есть. То есть они его не нашли."
    call ch3_remember_plans("lera")
    menu:
        "Договориться вдвоём."
        "Хочу сегодня побыть с тобой. Пусть сначала сами поищут.":
            l "Я тоже. Пусть пришлют фото, может, по нему понятно."
            "По фотографии Лера находит нужный провод. Отвечает голосовым на двадцать секунд и переворачивает телефон."
            $ chapter3_lera_result = "обед и тихая прогулка вдвоём"
            scene bg ch3 street lera with dissolve
            $ chapter3_clock += 45
            $ chapter3_stamp("На прогулке у Садовой")
            $ set_soundscape("ch3_outside")
            "После обеда они выходят на солнце. Лера щурится и прикрывает глаза ладонью."
            l "Дома я вообще слушаю не это всё. Фолк, например. Могу потом показать."
            o "Только не звук проверки кабеля."
            l "Фолк. Разочарован?"
            o "Нет. Хочу послушать."
            call ch3_close_lera
            menu:
                "Можно остаться в этом спокойном темпе."
                "Зайти за продуктами и продолжить прогулку.":
                    if chapter3_tasks.get("lera_bread"):
                        l "Да. Хлеб есть, ещё помидоров возьму."
                    else:
                        l "Да. Мне хлеб нужен. Не булка с мероприятия, нормальный хлеб."
                    $ chapter3_lera_result += "; закупились и гуляли без организаторов"
                    call ch3_lera_private_walk
                "На сегодня попрощаться. Позвать её на домашнюю музыку в другой день.":
                    o "Сыграю что-нибудь. Тебе не надо будет чинить звук."
                    l "А сегодня всё? Я звук от себя отбила, думала, дальше просто погуляем."
                    o "Хочу. Но сегодня уже надо заканчивать."
                    "Лера делает пару шагов по улице и останавливается. Олег всё ещё стоит у входа."
                    l "Ладно. Тогда гитару не обещай пока. Напишешь, когда сможешь."
                    $ chapter3_departure("lera", "disappointed", "later")
                    $ chapter3_lera_result += "; предложили вечер с гитарой"
                "Сказать, что мне приятно просто быть с ней.":
                    l "Мне тоже. Я весь обед ждала, когда от нас что-нибудь понадобится. А не понадобилось."
                    $ chapter3_lera_result += "; сблизились без чужой работы"
                    call ch3_lera_private_walk
                "На сегодня хватит. Хочу остаток дня один.":
                    o "Я дальше один пойду. Сегодня людей уже много."
                    l "Блин. А я только... Ладно."
                    "Она быстро складывает телефон в сумку, промахивается молнией. Пытается засмеяться и не заканчивает."
                    o "Лер. Я правда устал."
                    l "Да я слышу. Иди. Мне просто сейчас обидно."
                    $ chapter3_departure("lera", "disappointed", "rest")
                    $ chapter3_lera_result += "; Олег захотел закончить день один"
            $ chapter3_done("lera", chapter3_lera_result, 55)
        "Давай съездим вместе. Но после ремонта уйдём.":
            l "Договорились. Если начну спасать весь фестиваль, напомни."
            scene bg ch3 event with dissolve
            $ chapter3_clock += 80
            $ chapter3_stamp("Мастерская у Садовой")
            $ set_soundscape("ch3_event")
            "В мастерской днём играют музыканты. Из колонок тянется гул. Лера показывает Олегу пульт и приседает у стойки с проводами."
            call vignette_hum_scene
            if vignette_effect("hum") == "clean_channel":
                "Организатор догоняет их у выхода. Хвалит звук, потом протягивает Олегу пачку браслетов: раз уж всё наладили, можно ещё на входе помочь."
            elif vignette_effect("hum") == "bypassed_return":
                "Организатор наконец приходит к пульту. Лера ещё раз показывает, какую ручку не открывать. Освободившуюся руку Олега тут же занимают пачкой браслетов."
            else:
                "Олегу уже сунули пачку браслетов."
            o "Я сопровождающий. Моя квалификация заканчивается на бумажной полоске."
            menu:
                "Музыка играет. Организаторы только начали просить."
                "Вернуть браслеты. Мы договорились уйти.":
                    l "Да. Я помню. Всё, ребята, у меня сегодня выходной."
                    $ chapter3_lera_result = "починили звук и ушли вдвоём"
                    $ chapter3_clock += 30
                    $ chapter3_tasks["lera_left_event"] = True
                    call ch3_lera_private_walk
                    $ chapter3_done("lera", chapter3_lera_result, 0)
                "Раздать браслеты немного. Потом честно сказать, что устал.":
                    "Олег раздаёт браслеты до конца одного трека. Потом ищет Леру и предлагает выйти."
                    l "Давай. Спасибо, что сказал. А то я уже решила, что ты счастливый волонтёр."
                    $ chapter3_lera_result = "помогли и вовремя закончили чужую смену"
                    $ chapter3_clock += 60
                    $ chapter3_tasks["lera_left_event"] = True
                    call ch3_lera_private_walk
                    $ chapter3_done("lera", chapter3_lera_result, 0)
                "Сделать вид, что мне тут отлично. Пусть занимается.":
                    "Лера успевает ещё обсудить следующий сет. Олег стоит с браслетами и становится всё менее убедительным."
                    l "Ты мог сказать. Я думала, тебе интересно."
                    o "Да. Я затянул."
                    $ chapter3_done("lera", "увлеклись чужим мероприятием и неловко закончили встречу", 90)
    return

label ch3_solo_day:
    scene bg ch3 alone with dissolve
    $ chapter3_stamp("Свободный день")
    menu:
        "На сегодня никому не обещал приехать."
        "Купить себе лампу. Даже если пока для отеля.":
            scene bg ch3 market solo with dissolve
            "Олег выбирает маленькую лампу, проверяет вилку и наконец перестаёт думать, достаточно ли постоянное у него жильё для такой покупки."
            $ chapter3_solo = "купил собственную лампу"
        "Сходить на музыку одному.":
            scene bg concert performance with dissolve
            $ set_soundscape("concert")
            "Он слушает группу, не выбирая подходящий момент для знакомства. На втором треке всё-таки подходит ближе к сцене."
            $ chapter3_solo = "послушал концерт без новых обязательств"
        "Вернуться к гитаре. Играть для себя.":
            scene bg hotel dusk with dissolve
            $ set_soundscape("ch3_music")
            "Олег не включает запись. Один куплет получается, второй нет; никто не ждёт файл к вечеру."
            $ chapter3_solo = "поиграл на гитаре для себя"
    return

label ch3_end:
    $ city_chapter = "Нормально посидели"
    $ chapter3_clock = max(1140, chapter3_clock)
    $ place_name = "Воскресенье · " + chapter3_time(chapter3_clock)
    $ save_name = "Глава 3 · после выходных"
    $ set_soundscape("ch3_evening")
    if chapter3_housing == "new":
        if housing_home:
            scene expression housing_home_background(chapter3_clock >= 1110) with Dissolve(.8)
        elif chapter3_clock >= 1110:
            scene bg ch3 home night with Dissolve(.8)
        else:
            scene bg ch3 home evening with Dissolve(.8)
        "Олег заносит первые вещи в новую квартиру. Чемодан забрал из отеля уже после встреч. Из коробки достаёт чайник."
        if housing_home == "studio":
            "Чайник ставит у розетки. Потом складывает диван, чтобы достать из морозилки пельмени. Дневной сценарий в десять вечера."
        else:
            "Удлинитель остался в отеле. Чайник стоит ровно в полуметре от места, где можно получить чай."
        if housing_home == "studio":
            $ chapter3_home_text = "Получил ключи от студии. Разобрался с диваном."
        else:
            mind "У меня есть адрес. Осталось провести к нему электричество."
            $ chapter3_home_text = "Получил ключи от своей квартиры. Удлинитель ещё в отеле."
    elif chapter3_housing in ("whole", "month"):
        scene bg ch3 old night with dissolve
        "На новой для него кухне Олег ставит свою кружку и проверяет выключатели. Один включает свет, второй пока предлагает подумать."
        if chapter3_housing == "month":
            mind "До следующего переезда месяц. Но сегодня кружка стоит не на гостиничном столе."
            $ chapter3_home_text = "Снял квартиру на месяц. Дата следующего переезда известна."
        else:
            mind "Комната пустая. Именно это мне в ней нравится."
            $ chapter3_home_text = "Снял всю квартиру. Проверил, что чужие чемоданы вывезены."
    else:
        if chapter3_clock >= 1110:
            scene bg hotel night with dissolve
        else:
            scene bg hotel dusk with dissolve
        "У стойки Олег оплачивает ещё одну ночь, до понедельника. Сегодня переезда не получилось; номер, как и просил утром, оставили за ним."
        "Карточку продлевают. В знакомом номере он первым делом открывает окно."
        $ chapter3_home_text = "Пока остался в отеле. Поиск квартиры продолжается."
    call ch3_home_replies
    call ch3_evening_friends
    "Олег закрывает чат и кладёт телефон рядом."
    $ mood_menu = True
    menu:
        mind "Ещё чуть-чуть посижу. Спать пока не хочется."
        "Хорошо получилось. Даже не всё по плану.":
            $ set_oleg_mood("ch3_evening", "playful")
            mind "Нормально посидели. Иногда даже сидели."
        "Хочу повторить один момент. И больше никуда не спешить.":
            $ set_oleg_mood("ch3_evening", "engaged")
            "Олег отмечает, кому хочет написать завтра. Пока не назначает ещё один день целиком."
        "Сейчас просто отдых. Со всем остальным завтра.":
            $ set_oleg_mood("ch3_evening", "calm")
            "Он убирает телефон и вытягивает ноги. Выходные ещё немного есть."
    $ mood_menu = False
    $ diary_entries.append("Глава 3: " + chapter3_home_text)
    $ chapter3_outcomes = "\n".join(chapter3_notes + ([chapter3_solo] if chapter3_solo else [])) or "Выбрал свободные выходные."
    $ diary_entries.append("Глава 3 · выходные: " + chapter3_outcomes)
    call ch3_bedtime
    $ ending_title = "Нормально посидим"
    $ ending_body = "За окном ещё проезжает машина. Потом и её не слышно."
    hide screen scene_marker
    $ quick_menu = False
    call screen chapter3_ending
    if _return == "again":
        jump chapter3_start
    if _return == "week4":
        jump week4_start
    return
