# Dialogue staging. Background tags retain story/save compatibility; action CGs stay separate.
default cast_emotions = {}
default cast_speaker = None
default cast_state_scene = ""

init -10 python:
    class SpriteCharacter(renpy.character.ADVCharacter):
        def __init__(self, *args, **kwargs):
            self.sprite_key = kwargs.pop("sprite_key", getattr(kwargs.get("kind"), "sprite_key", None))
            super(SpriteCharacter, self).__init__(*args, **kwargs)

        def do_display(self, who, what, **display_args):
            global cast_emotions, cast_speaker, cast_state_scene
            scene_key = cast_background_key()
            if cast_state_scene != scene_key:
                cast_emotions = {}
                cast_state_scene = scene_key
            cast_speaker = self.sprite_key
            if self.sprite_key:
                direction = cast_direction_cues.get((scene_key, self.sprite_key, what))
                if direction is not None:
                    cast_direct(direction)
                fallback = cast_default_emotion(self.sprite_key)
                cast_emotions[self.sprite_key] = cast_cues.get((self.sprite_key, what), fallback)
            super(SpriteCharacter, self).do_display(who, what, **display_args)

    def cast_background_key():
        return " ".join(renpy.get_attributes("bg") or ())

    def cast_default_emotion(person):
        key = cast_background_key()
        if person == "oleg":
            # A playful earlier choice must not carry a grin into a rescue,
            # an awkward farewell, or a serious conversation with Asya.
            if key.startswith("w5 rescue ") or key in ("w4 asya", "w4 lera awkward"):
                return "earnest"
            return oleg_mood_expression()
        return "neutral"

    # Explicit direction per line; no sentiment guessing at runtime.
    cast_cues = {
        ("nika", "Ты опять в «Берсерке». Он у тебя вообще до стиралки доходит?"): "amused",
        ("nika", "Ты купил пять сменных скинов, и все одинаковые?"): "amused",
        ("nika", "Ладно, эту часть плана поддерживаю."): "amused",
        ("oleg", "У меня пять одинаковых футболок. Эта чистая."): "amused",
        ("oleg", "Зато пока две стираются, я не стою голый у машинки."): "amused",
        ("oleg", "Пока отношения со стеной самые стабильные."): "amused",
        ("oleg", "Из-за того, что платишь за жильё и всё равно находишься на улице."): "amused",
        ("oleg", "Уже четыре месяца живу в отелях. Всё какие-то просмотры, нюансы, завтра ответим. Я немного заебался."): "earnest",
        ("oleg", "Исследую тревел-продукт изнутри. Очень глубокое погружение."): "amused",
        ("oleg", "Рекомендует мне поискать квартиру."): "amused",
        ("oleg", "И уже просто мокрый?"): "amused",
        ("oleg", "Давай донесу? Только объясни, где у него дорогая сторона."): "amused",
        ("oleg", "Контроллер входит в аренду? Домашний рейв как преимущество района?"): "amused",
        ("oleg", "Почётная должность. Я у тебя хотя бы не должен ходить в чёрном?"): "amused",
        ("oleg", "Серьёзно. Оставь."): "neutral",
        ("nika", "Ты охраняешь стену или ждёшь, когда музыка закончится?"): "amused",
        ("nika", "Нет. Теперь я буду спрашивать, почему ты не на сцене. Это другой уровень неудобства."): "amused",
        ("nika", "А где ты сейчас живёшь?"): "earnest",
        ("nika", "Ну что, нашли мы искусство?"): "amused",
        ("nika", "Я тоже. Только у меня обычно заканчивается тем, что зашла за хлебом, а вышла с билетом на концерт."): "amused",
        ("nika", "А ты всё ещё хочешь здесь жить? В городе, я имею в виду."): "earnest",
        ("nika", "Ты обычно ждёшь, пока тебя куда-нибудь позовут?"): "earnest",
        ("nika", "Я вот тоже не знала. Когда тебя на выставку звала."): "earnest",
        ("nika", "Давай. Мне после двух удобно. Напиши, что узнаешь."): "amused",
        ("nika", "Запиши кусок. Хочу услышать."): "warm",
        ("nika", "Я басистка. Мы умеем ждать, пока гитарист договорится с собой."): "amused",
        ("nika", "Тогда не надо. Я тоже хорошо сижу."): "warm",
        ("nika", "В бар. Но я на всякий случай переспросила."): "warm",
        ("nika", "Ладно. Только я вообще-то вечер под нас освободила."): "earnest",
        ("nika", "Времени у тебя хватает. Ладно, езжай. Я домой."): "earnest",
        ("nika", "За этим я и хожу на современное искусство."): "amused",
        ("asya", "Перформанс отменили. У артиста температура."): "skeptical",
        ("asya", "Книга отзывов. Справа."): "skeptical",
        ("asya", "Это был твой знакомый?"): "skeptical",
        ("asya", "В следующий раз пусть хотя бы напишет заранее."): "skeptical",
        ("asya", "В следующий четверг музыканты придут. Афишу пришлю. У нас на сайте пока прошлогодняя."): "warm",
        ("asya", "У меня ещё минут пятнадцать работы. Потом можно без стаканов. Я бы посидела с тобой."): "warm",
        ("lera", "Дно держи. Ручкам не верь. Спасибо."): "amused",
        ("lera", "Отлично. Тебя ещё можно удивить."): "amused",
        ("lera", "Рейв съехал. В отличие от владельца."): "amused",
        ("lera", "Про приезды спроси отдельно. Мне однажды вечером написал, что уже в поезде."): "earnest",
        ("lera", "Сантехника сохрани. Он в отличие от хозяина предупреждает, когда приедет."): "amused",
        ("lera", "Дай мне десять минут. Если через двадцать всё ещё организую — выноси меня."): "amused",
        ("lera", "Ну как? Только не надо «для электроники нормально»."): "earnest",
        ("lera", "Уже спрашивают, куда дальше. Я ещё булку не съела."): "earnest",
        ("lera", "Да. Только выбери до того, как я выйду из дома."): "amused",
        ("lera", "Сильная рецензия. Второму диджею не пересылай."): "amused",
        ("lera", "Напиши завтра. Только не по поводу сантехника."): "amused",
        ("varya", "Серьёзно? Я эту страницу уже три раза собиралась выкинуть."): "earnest",
        ("varya", "Ладно, оставлю. Будешь художественный совет. Один скуф, зато отвечает."): "amused",
        ("varya", "Ну всё."): "amused",
        ("varya", "Нет. Сказал: у нас и так обои грустные."): "amused",
        ('nika', 'Хорошая группа. Демократичная.'): 'amused',
        ('nika', 'Мы вроде хотели тихо.'): 'amused',
        ('nika', 'В следующий раз не назначай себе марафон. Я тоже люблю планы, но в них надо успевать приезжать.'): 'earnest',
        ('nika', 'Ты сам себе это тоже потом скажи.'): 'amused',
        ('asya', 'Я надеялась. Но хотела посмотреть, сколько мы ещё будем обсуждать кота.'): 'warm',
        ('asya', 'Коту начальника купил? Хорошо. Он слишком расслабился.'): 'warm',
        ('asya', 'Очень тяжёлая жизнь была бы.'): 'skeptical',
        ('lera', 'Фолк. Разочарован?'): 'amused',
        ('lera', 'Давай. Спасибо, что сказал. А то я уже решила, что ты счастливый волонтёр.'): 'amused',
        ('lera', 'Ты мог сказать. Я думала, тебе интересно.'): 'earnest',
        ('varya', 'Блять. Там офис.'): 'earnest',
        ('varya', 'Олег.'): 'earnest',
        ('varya', 'Спасибо. На первой странице тебя подпишу. Но мелко, ты не здание.'): 'amused',
    }

    # person, wardrobe, center-x, top-y, height. Keep faces clear of left dialogue/choices.
    cast_stages = {'concert': ('concert-empty', [('oleg', 'indoor', 430, 55, 920), ('nika', 'standing', 1240, 55, 920)], None, 'club'),
     'club night': ('club-empty', [('oleg', 'outdoor', 430, 55, 920), ('nika', 'outdoor', 1240, 55, 920)], None, 'night'),
     'apartment conversation': ('apartment-empty',
                                [('oleg', 'indoor', 430, 65, 920),
                                 ('owner', '', 1250, 70, 840)],
                                None,
                                'day'),
     'apartment lera': ('apartment-empty',
                        [('owner', '', 805, 70, 840),
                         ('oleg', 'indoor', 430, 65, 920),
                         ('lera', 'indoor', 1250, 65, 920)],
                        None,
                        'day'),
     'varya reaction': ('varya-empty', [('oleg', 'outdoor', 430, 55, 920), ('varya', '', 1250, 55, 920)], None, 'day'),
     'ch3 rental': ('images/chapter3/ch3-rental-day-v2.webp',
                    [('oleg', 'indoor', 430, 55, 920), ('agent', '', 1250, 55, 840)],
                    None,
                    'warmday'),
     'ch3 keys': ('images/chapter3/ch3-rental-day-v2.webp',
                  [('oleg', 'indoor', 430, 55, 920), ('agent', '', 1250, 55, 840)],
                  None,
                  'warmday'),
     'ch3 old rental': ('apartment-empty',
                        [('oleg', 'indoor', 430, 55, 920), ('owner', '', 1250, 55, 840)],
                        None,
                        'warmday'),
     'ch3 rehearsal': ('images/chapter3/ch3-rehearsal-empty-v3.webp',
                       [('oleg', 'indoor', 430, 55, 920), ('nika', 'weekend', 1250, 55, 920)],
                       None,
                       'warmday'),
     'ch3 records': ('images/chapter3/ch3-records-empty.webp',
                     [('oleg', 'indoor', 430, 55, 920), ('nika', 'weekend', 1250, 55, 920)],
                     None,
                     'warmday'),
     'ch3 print': ('images/chapter3/ch3-print-empty-v2.webp',
                   [('oleg', 'indoor', 430, 55, 920), ('varya', 'weekend', 1250, 55, 920)],
                   None,
                   'warmday'),
     'ch3 photos': ('images/chapter3/ch3-photos-empty-v2.webp',
                    [('oleg', 'indoor', 430, 55, 920), ('asya', 'weekend', 1250, 55, 920)],
                    None,
                    'warmday'),
     'ch3 market': ('images/chapter3/ch3-market-empty-v2.webp',
                    [('oleg', 'indoor', 430, 55, 920), ('asya', 'weekend', 1250, 55, 920)],
                    None,
                    'warmday'),
     'ch3 event': ('images/chapter3/ch3-event-empty-v2.webp',
                   [('oleg', 'indoor', 430, 55, 920), ('lera', 'weekend', 1250, 55, 920)],
                   None,
                   'warmday'),
     'ch3 cafe evening': ('images/chapter3/ch3-cafe-evening-empty-v1.webp', [('oleg', 'indoor', 430, 55, 920), ('nika', 'weekend', 1250, 55, 920)], None, 'evening'),
     'ch3 cafe exit': ('images/chapter3/ch3-cafe-evening-empty-v1.webp', [('oleg', 'indoor', 430, 55, 920)], None, 'evening'),
     'ch3 street asya': ('images/chapter3/ch3-street-sunny-v2.webp', [('oleg', 'indoor', 430, 55, 920), ('asya', 'weekend', 1250, 55, 920)], None, 'warmday'),
     'ch3 cafe asya': ('images/chapter3/ch3-cafe-evening-empty-v1.webp', [('oleg', 'indoor', 430, 55, 920), ('asya', 'weekend', 1250, 55, 920)], None, 'evening'),
     'ch3 street nika': ('images/chapter3/ch3-street-sunny-v2.webp',
                         [('oleg', 'indoor', 430, 55, 920), ('nika', 'weekend', 1250, 55, 920)],
                         None,
                         'warmday'),
     'ch3 street lera': ('images/chapter3/ch3-street-sunny-v2.webp',
                         [('oleg', 'indoor', 430, 55, 920), ('lera', 'weekend', 1250, 55, 920)],
                         None,
                         'warmday'),
     'ch3 street varya': ('images/chapter3/ch3-street-sunny-v2.webp',
                          [('oleg', 'indoor', 430, 55, 920), ('varya', 'weekend', 1250, 55, 920)],
                          None,
                          'warmday'),
     'ch3 alone': ('images/chapter3/ch3-street-sunny-v2.webp', [('oleg', 'indoor', 430, 55, 920)], None, 'warmday'),
     'ch3 market solo': ('images/chapter3/ch3-market-empty-v2.webp', [('oleg', 'indoor', 430, 55, 920)], None, 'warmday'),
     'ch4 lobby': ('images/chapter4/bookshop-empty-v1.webp', [('oleg', 'indoor', 430, 55, 920)], None, 'evening'),
     'ch4 bookshop': ('images/chapter4/bookshop-empty-v1.webp',
                      [('oleg', 'indoor', 430, 55, 920), ('marta', 'bookshop', 1230, 35, 1280)],
                      None,
                      'evening')}

    def cast_background_path(name):
        return name if name.startswith("images/") else "images/cast/" + name + ".webp"

    def cast_stage_data():
        if main_menu:
            return None
        stage = cast_stages.get(cast_background_key())
        if stage is None:
            return None
        directions = cast_direction_data()
        actors = [(person, wardrobe) + tuple(directions[person][:3]) if person in directions else (person, wardrobe, center, top, height)
                  for person, wardrobe, center, top, height in stage[1]]
        if cast_background_key() == "ch3 alone" and chapter3_clock >= 1110:
            return ("images/chapter3/ch3-street-night-v1.webp", actors, stage[2], "night")
        return housing_companion_stage((stage[0], actors, stage[2], stage[3]))

    def cast_sprite_path(person, wardrobe):
        fallback = cast_default_emotion(person)
        emotion = cast_emotions.get(person, fallback) if cast_state_scene == cast_background_key() else fallback
        assets = cast_assets[(person, wardrobe)]
        pose = cast_actor_pose(person)
        if pose in assets:
            return assets[pose]
        if person == "nika" and emotion == "skeptical":
            emotion = "earnest"
        return assets.get(emotion, assets["neutral"])

    def cast_lighting(tone):
        if tone == "shade":
            return TintMatrix("#e0e9f2") * SaturationMatrix(.90)
        if tone == "workday":
            return TintMatrix("#e5edf1") * SaturationMatrix(.84)
        if tone == "windowday":
            return TintMatrix("#f1eee8") * SaturationMatrix(.90)
        if tone == "warmday":
            return TintMatrix("#fff3df") * SaturationMatrix(.96)
        if tone == "day":
            return TintMatrix("#d7e4ef") * SaturationMatrix(.85)
        if tone == "night":
            # Cold ambient fill. Sprites already carry warm painted rim light;
            # a second amber tint turned brown/blond hair orange outdoors.
            return TintMatrix("#d4dfed") * SaturationMatrix(.88) * BrightnessMatrix(-.06)
        if tone == "dusk":
            return TintMatrix("#dce4ef") * SaturationMatrix(.90) * BrightnessMatrix(-.025)
        if tone == "club":
            return TintMatrix("#edc2c4") * BrightnessMatrix(-.04)
        # Interior tungsten should not recolour hair, skin and dyed strands.
        return TintMatrix("#f5e9db") * SaturationMatrix(.96)

init -8 python:
    import struct
    # Web's progressive-download index already contains the original dimensions.
    # Reading every remote PNG at init would download the whole cast before play.
    cast_sprite_dimensions = {}
    for variants in cast_assets.values():
        for filename in variants.values():
            remote_image = renpy.loader.remote_files.get(filename)
            if remote_image and remote_image["type"] == "image":
                cast_sprite_dimensions[filename] = tuple(remote_image["size"])
            else:
                cast_sprite_dimensions[filename] = web_asset_dimensions[filename]

init python:
    # Characters are scenery: H may hide the interface, but must retain the cast.
    config.layers.insert(config.layers.index("transient"), "cast")
    config.always_shown_screens.append("cast_stage")

screen cast_stage():
    layer "cast"
    zorder 0
    $ stage = cast_stage_data()
    if stage:
        add (home_keepsake_background(cast_background_path(stage[0])) if home_keepsake_cast_home() else city_background(cast_background_path(stage[0])))
        for person, wardrobe, center, top, height in stage[1]:
            $ sprite_path = cast_sprite_path(person, wardrobe)
            $ sprite_width, sprite_height = cast_sprite_dimensions[sprite_path]
            add Transform(sprite_path, xysize=(int(round(height * sprite_width / float(sprite_height))), height), matrixcolor=cast_lighting(stage[3])) xpos center xanchor .5 ypos top
        if stage[2]:
            add Transform(cast_background_path(stage[2]), xysize=(1600, 900))

# Apartment dialogue follows an existing establishing shot; short scenes stay CGs.
image bg apartment conversation = Transform("images/chapter2-apartment-arrival.webp", xysize=(1600, 900))
