label week4_thursday:
    $ week4_stamp("Четверг дома", 750, 3)
    scene expression week4_home_bg() with fade
    $ set_soundscape("hotel_morning")
    "В четверг в исправленном отчёте впервые не приходится ничего объяснять в скобках. Катя присылает один новый случай, и проверка действительно его ловит."
    if week4_home["kind"] == "hotel":
        if week4_home.get("keys_due") == "friday":
            "До полудня Олег продлевает номер ещё на одну ночь. В пятницу после работы договорились о ключах."
            $ week4_home["paid_until"] = "friday"
        else:
            "До полудня Олег оплачивает ещё четыре ночи. Номер остаётся за ним до понедельника. На этот раз он ставит напоминание о выезде сразу."
            $ week4_home["paid_until"] = "monday"
    if week4_home.get("visit") == "pending":
        "Хозяин предлагает мастера в пятницу утром. Олег подтверждает девять: до созвонов успеют."
        $ week4_home["visit"] = "friday"
    if week4_home.get("viewing") and week4_home.get("first_viewing"):
        call housing_week4_defer
    if week4_package == "accepted" and week4_package_window not in ("tuesday_evening", "wednesday_late", "thursday_late"):
        call week4_package_lunch_agreement
    if week4_work["evening"]:
        $ week4_stamp("Вечер за работой", 1130)
        scene expression week4_home_bg() with dissolve
        "Проверять все новые статусы одному оказалось ровно настолько долго, насколько предупреждал Илья. В семь он присылает ещё два спорных случая."
        menu:
            "Позвать Илью на десять минут. Я здесь буксую.":
                wi "Давай. Я ещё онлайн."
                o "Спасибо. В следующий раз разделим сразу."
                $ week4_event("work", "asked_help")
            "Закончить самому. Но больше весь список не брать.":
                "Олег размечает спорные строки и прикладывает их отдельно. Без зелёного цвета."
        $ week4_work["report"] = "done"
        $ week4_evening = "work"
        $ week4_stamp("Дома", 1300)
    elif week4_home.get("visit") == "thursday":
        $ week4_stamp("Дома с мастером", 1110)
        scene expression week4_home_bg() with dissolve
        call week4_repair
        $ week4_evening = "repair"
        $ week4_good_moment = "перестало течь из окна"
        if week4_relations["nika"].get("call_topic") == "guitar":
            "Когда мастер уходит, Олег возвращает гитару к столу. Теперь можно записать обещанный кусок без чужого шуруповёрта."
            call week4_chat("nika", "repair_riff", [], [("rough", "Окно починили. Вот как получилось, дубль не выбирал.", [("Ника", "Слушаю. Ты на последнем аккорде торопишься."), ("Ника", "Я тебе медленно запишу, там рука сама раньше времени уходит.")]), ("try", "Попробовал твой переход. На третьем разе уже похоже.", [("Ника", "У меня он сначала тоже через раз был. Подожди, гитару возьму.")])])
            $ week4_event("nika", "repair_riff_sent")
            $ week4_good_moment = "после мастера всё-таки записал Нике обещанный кусок"
    elif week4_home.get("viewing"):
        call housing_week4_second
    elif week4_plan_status == "confirmed":
        if connection_active():
            call connections_thursday
        else:
            call expression "week4_route_" + week4_plan
    else:
        $ week4_stamp("Свободный вечер", 1140)
        scene bg w4 rain with fade
        $ set_soundscape("courtyard")
        menu:
            "Пройдусь по дворам. Весь день сидел.":
                "Дождь почти перестал. Из подвала выносят старое кресло, которое не проходит в дверь. Олег придерживает створку. С третьей попытки получается."
                $ week4_good_moment = "прошёлся по дворам"
            "Куплю еды и домой, играть на гитаре.":
                "В магазине есть ещё тёплый хлеб. Олег отламывает край по дороге, хотя до дома совсем недалеко."
                $ week4_good_moment = "поиграл дома на гитаре"
        $ week4_evening = "alone"
    call week4_package_extra_evening
    jump week4_end

label week4_end:
    $ week4_stamp("Дома", max(week4_clock, 1305), 3)
    scene expression week4_home_bg() with fade
    call home_keepsakes_unpack
    $ set_soundscape("ch3_evening")
    if week4_relations["nika"].get("home_due"):
        call week4_arrival_note
    if week4_laundry["method"] == "hotel" and week4_laundry["status"] == "washing":
        "На стойке ему выдают пакет с чистыми вещами. Олег забирает его по дороге в номер."
        $ week4_laundry.update(status="clean", where="home")
    elif week4_laundry["method"] == "own" and week4_laundry["status"] == "drying":
        "Дома он снимает с сушилки высохшие футболки. Одну оставляет на завтра, остальные убирает в шкаф."
        $ week4_laundry["status"] = "clean"
    elif week4_laundry["where"] == "lera":
        "Пакета с футболками нет. Он на секунду ищет его взглядом и вспоминает сушилку у Леры. Завтра сначала написать, потом ехать."
    if week4_home.get("candidate") and week4_home.get("keys_due") == "friday":
        "В переписке с агентом стоит завтрашнее время: половина седьмого. Олег ещё раз открывает фотографию выбранной квартиры. На этот раз он знает, что осталось за краем кадра."
    elif week4_home.get("viewing_result") == "declined":
        "Агент присылает: «Продолжаю искать». Олег закрывает переписку. Сегодня он хотя бы понял, в какой квартире жить не хочет."
    if week4_evening == "lera" and week4_has("lera", "hesitated"):
        call week4_chat("lera", "after_hesitation", [("Лера", "Дошёл?")], [("tell", "Да. Я у тебя хотел взять тебя за руку и затупил. Это не потому что не хотел.", [("Лера", "А я уже другое подумала. Ладно. Спасибо, что сказал."), ("Лера", "Я пока спать. Завтра напишу.")]), ("hide", "Да. Спасибо за вечер.", [("Лера", "И тебе. Спокойной.")])])
        if _return == "tell":
            $ week4_event("lera", "explained_hesitation")
            # Explanation is remembered; her uneasy evening is not retroactively erased.
    menu:
        "Напишу московским. Интересно, как они там.":
            call week4_friends("thursday")
        "На сегодня телефона хватит.":
            "Телефон остаётся заряжаться на столе. Олег уходит чистить зубы."
    if week4_good_moment:
        "Перед сном вспоминается, как [week4_good_moment]. Рабочий созвон почему-то вспоминается только после этого."
    else:
        "Будильник уже стоит. Олег добавляет к нему десять минут и выключает свет."
    $ week4_finished = True
    $ quick_menu = False
    hide screen scene_marker
    call screen week4_ending
    if _return == "week5":
        jump week5_start
    return

label week4_arrival_note:
    "Нике он отправляет короткое «Дома». Она отвечает, что тоже доехала. Телефон остаётся на зарядке."
    $ week4_arrival_messages = [("Олег", "Дома."), ("Ника", "Я тоже доехала. Спокойной.")]
    $ phone_stamp_messages("w4_nika_arrival_note_" + str(week4_chat_index), week4_arrival_messages, "Ника")
    $ week4_chat_index += 1
    $ week4_history["nika"] = (week4_history.get("nika", []) + week4_arrival_messages)[-20:]
    $ week4_relations["nika"]["home_due"] = False
    return

screen week4_ending():
    modal True
    add Solid("#09151bea")
    frame:
        xalign .5 yalign .5 xsize 1100 padding (50, 40) background Solid("#12232c")
        vbox:
            spacing 25
            text "КОНЕЦ ЧЕТВЁРТОЙ ГЛАВЫ" size 18 color "#d5b384" kerning 3
            text "Не сохнет" size 48
            text "В пятницу всё ещё нужно на работу.\nНо эта неделя уже не только про неё." size 28
            textbutton "Сохранить продолжение" action ShowMenu("save")
            textbutton "Продолжить · пятая глава" id "week5_continue_button" action Return("week5")
            textbutton "В главное меню" action Return()
